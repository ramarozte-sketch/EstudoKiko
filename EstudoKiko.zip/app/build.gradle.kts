plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.rui.estudokiko"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.rui.estudokiko"
        minSdk = 26
        targetSdk = 34   // 34: evita o "edge-to-edge" obrigatório do Android 15, que desalinha a WebView
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "1." + (System.getenv("GITHUB_RUN_NUMBER") ?: "0")
    }

    // Chave fixa: assim cada nova versão instala por cima da anterior sem perder o progresso
    signingConfigs {
        create("kiko") {
            storeFile = file("kiko.jks")
            storePassword = "kiko1234"
            keyAlias = "kiko"
            keyPassword = "kiko1234"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("kiko")
        }
        debug {
            signingConfig = signingConfigs.getByName("kiko")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
