/* 2.º ano — 1.º ciclo do ensino básico (Aprendizagens Essenciais da DGE) */

// ============================================================= PORTUGUÊS
TEMAS(2, 'pt', [
  {
    id: 'pt2_leitura', t: 'Leitura e escrita com dígrafos e acentos',
    k: 'leitura,escrita,digrafos,fonema,grafema,acentuacao,til,acento agudo,acento circunflexo',
    ae: 'Associar letras e dígrafos aos sons, escrever corretamente diferentes palavras e usar acentuação gráfica e til.',
    r: [
      'Cada letra ou dígrafo representa um som: ch, nh, lh, rr, ss, qu, gu.',
      'Escrever bem implica usar a letra ou o dígrafo certo para o som da palavra.',
      'O acento agudo ( ´ ) e o circunflexo ( ^ ) marcam a sílaba tónica: café, você.',
      'O til ( ~ ) marca um som nasal: mãe, pão.'
    ],
    q: [
      ['Qual destas palavras usa o dígrafo "lh"?', ['folha', 'carro', 'massa', 'quero']],
      ['O acento circunflexo aparece em…', ['você', 'café', 'mãe', 'pão']],
      ['O til marca um som…', ['nasal', 'aberto', 'fechado', 'mudo']],
      ['Qual destas palavras está bem escrita?', ['chuva', 'xuva', 'chuba', 'shuva']],
      ['O "ç" só se usa antes de a, o ou u.', true]
    ]
  },
  {
    id: 'pt2_classes', t: 'Classes de palavras',
    k: 'classes de palavras,artigo,nome,adjetivo,verbo,pronome pessoal,infinitivo',
    ae: 'Identificar as classes de palavras: artigo, nome, adjetivo, verbo e pronome pessoal; reconhecer a forma de infinitivo dos verbos.',
    r: [
      'Artigo: o, a, os, as (definidos); um, uma, uns, umas (indefinidos).',
      'Nome: dá nome a pessoas, animais e coisas (menina, cão, mesa).',
      'Adjetivo: diz como é o nome (alta, simpático).',
      'Verbo: indica uma ação; a forma de infinitivo termina em -ar, -er ou -ir (saltar, correr, partir).',
      'Pronome pessoal: eu, tu, ele, ela, nós, vós, eles, elas — substituem nomes.'
    ],
    q: [
      ['"Um" é um artigo…', ['indefinido', 'definido', 'próprio', 'coletivo']],
      ['Qual destas palavras é um verbo no infinitivo?', ['saltar', 'salto', 'saltando', 'saltou']],
      ['Na frase "Ela é alta.", qual é o adjetivo?', ['alta', 'Ela', 'é', '.']],
      ['"Nós" é um…', ['pronome pessoal', 'artigo', 'adjetivo', 'nome']],
      ['Os artigos definidos são o, a, os e as.', true]
    ]
  },
  {
    id: 'pt2_flexao', t: 'Flexão de nomes e adjetivos',
    k: 'flexao,genero,numero,masculino,feminino,singular,plural,concordancia',
    ae: 'Flexionar nomes e adjetivos em género e número, com concordância entre ambos.',
    r: [
      'Masculino/feminino: o gato branco / a gata branca.',
      'Singular/plural: a casa bonita / as casas bonitas.',
      'O adjetivo deve concordar em género e número com o nome a que se refere.',
      'Alguns plurais têm formas especiais: papel → papéis; balão → balões; pão → pães.'
    ],
    q: [
      ['Qual é o feminino de "o gato preto"?', ['a gata preta', 'a gato preta', 'o gata preto', 'a gata preto']],
      ['Qual é o plural de "balão"?', ['balões', 'balãos', 'balães', 'balãoes']],
      ['Na frase "As flores são bonitas.", o adjetivo concorda com…', ['as flores (plural, feminino)', 'só o verbo', 'só o artigo', 'nada']],
      ['Qual é o plural de "pão"?', ['pães', 'pãos', 'pãoes', 'paes']],
      ['O adjetivo deve concordar em género e número com o nome.', true]
    ]
  },
  {
    id: 'pt2_frase', t: 'Pontuação e conectores',
    k: 'pontuacao,conectores,e,ou,mas,quando,porque,coordenacao',
    ae: 'Usar corretamente a pontuação e ligar ideias com conectores de coordenação (e, ou, mas) e de causa e tempo (quando, porque).',
    r: [
      '"E" liga ideias que se juntam: "Gosto de maçãs e de peras."',
      '"Mas" liga ideias que se opõem: "Queria ir, mas estava a chover."',
      '"Ou" indica escolha: "Queres leite ou chocolate?"',
      '"Porque" indica a causa de algo: "Não saí porque chovia."',
      '"Quando" indica o momento: "Rimos quando ele chegou."'
    ],
    q: [
      ['Qual conector liga ideias que se opõem?', ['mas', 'e', 'quando', 'porque']],
      ['"Não saí porque chovia." — "porque" indica…', ['a causa', 'o tempo', 'a oposição', 'a escolha']],
      ['"Queres leite ou chocolate?" — "ou" indica…', ['uma escolha', 'uma causa', 'uma oposição', 'uma ordem']],
      ['Qual destas frases usa o conector "e" para juntar ideias?', ['Gosto de maçãs e de peras.', 'Queria ir, mas chovia.', 'Rimos quando ele chegou.', 'Não saí porque chovia.']],
      ['"Quando" pode indicar o momento em que algo acontece.', true]
    ]
  },
  {
    id: 'pt2_textos', t: 'Textos narrativos e tradição popular',
    k: 'texto narrativo,narrativa,poema,tradicao popular,lengalengas,contos de fadas,recontar,dramatizar',
    ae: 'Compreender textos narrativos e poemas da tradição popular, e recontar ou dramatizar histórias.',
    r: [
      'Um texto narrativo conta uma sequência de acontecimentos, com personagens e as suas intenções e emoções.',
      'A tradição popular inclui lengalengas, adivinhas e contos transmitidos de geração em geração.',
      'Recontar uma história é dizê-la de novo, com as nossas palavras, mantendo o essencial.',
      'Dramatizar é representar uma história com gestos e falas, como no teatro.',
      'Os poemas podem ter rimas e são escritos em versos.'
    ],
    q: [
      ['Um texto narrativo conta…', ['uma sequência de acontecimentos', 'só uma lista de palavras', 'só números', 'uma receita']],
      ['Dramatizar uma história é…', ['representá-la com gestos e falas', 'escrevê-la outra vez igual', 'copiá-la do livro', 'ignorá-la']],
      ['As lengalengas fazem parte da tradição…', ['popular', 'científica', 'matemática', 'informática']],
      ['Recontar uma história é dizê-la com as nossas próprias palavras.', true]
    ]
  }
]);

// ============================================================= MATEMÁTICA
TEMAS(2, 'mat', [
  {
    id: 'mat2_numeros', t: 'Números até 1000',
    k: 'numeros,contar de 50 em 50,contar de 100 em 100,ordinais,arredondar,valor posicional,centenas',
    ae: 'Contar de 50 em 50, de 100 em 100 e de 200 em 200; ler, comparar e ordenar números até 1000; arredondar à dezena ou centena.',
    r: [
      'Contar de 100 em 100: 100, 200, 300… até 1000.',
      'Em 356, há 3 centenas, 5 dezenas e 6 unidades.',
      'Números ordinais até ao 20.º: 15.º lê-se "décimo quinto".',
      'Arredondar à dezena mais próxima: 47 arredonda para 50.',
      'Arredondar à centena mais próxima: 320 arredonda para 300.'
    ],
    q: [
      ['Contando de 100 em 100: 300, 400, … qual é o próximo?', ['500', '450', '600', '350']],
      ['Quantas centenas tem o número 356?', ['3', '5', '6', '35']],
      ['Como se lê o 15.º?', ['décimo quinto', 'quinze', 'quinto décimo', 'primeiro']],
      ['Arredondar 47 à dezena mais próxima dá…', ['50', '40', '47', '45']],
      ['Qual é maior: 650 ou 605?', ['650', '605', 'são iguais', 'não se sabe']],
      ['1000 tem 10 centenas.', true]
    ]
  },
  {
    id: 'mat2_calculo', t: 'Cálculo mental, adição e subtração',
    k: 'calculo mental,adicao,subtracao,compensacao,decomposicao,igualdades,estimar',
    ae: 'Usar o cálculo mental (compensação, decomposição) para adicionar e subtrair, e verificar se igualdades são verdadeiras.',
    r: [
      'Decompor ajuda a calcular: 36 + 25 = 30 + 20 + 6 + 5 = 61.',
      'Compensação: 48 + 9 = 48 + 10 − 1 = 57.',
      'Uma igualdade pode ser verdadeira ou falsa: 7 + 3 = 10 (verdadeira); 7 + 3 = 11 (falsa).',
      'Estimar o resultado antes de calcular ajuda a verificar se a resposta tem sentido.'
    ],
    q: [
      ['Usando compensação, 48 + 9 é o mesmo que…', ['48 + 10 − 1', '48 + 10 + 1', '48 − 10 + 1', '48 + 9 + 1']],
      ['A igualdade 7 + 3 = 11 é…', ['falsa', 'verdadeira', 'impossível de saber', 'meio verdadeira']],
      ['Decompondo, 36 + 25 pode calcular-se como…', ['30 + 20 + 6 + 5', '3 + 2 + 6 + 5', '36 × 25', '36 − 25']],
      ['Estimar antes de calcular ajuda a…', ['verificar se a resposta tem sentido', 'inventar números', 'desistir da conta', 'copiar a resposta']],
      ['Quanto é 60 − 25?', ['35', '45', '25', '85']]
    ]
  },
  {
    id: 'mat2_tabuada', t: 'Multiplicação e divisão',
    k: 'multiplicacao,tabuada,dobro,divisao,arranjos retangulares,comutatividade',
    ae: 'Compreender a multiplicação como adição sucessiva e em arranjos retangulares, automatizar os dobros e as tabuadas do 2, 3, 4, 5 e 10, e relacioná-la com a divisão.',
    r: [
      'Multiplicar é somar parcelas iguais: 3 × 4 = 4 + 4 + 4 = 12.',
      'Num arranjo retangular com 3 filas de 4 bolas há 3 × 4 = 12 bolas.',
      'A ordem dos fatores não altera o produto: 3 × 4 = 4 × 3.',
      'O dobro de um número é multiplicá-lo por 2: o dobro de 6 é 12.',
      'A divisão é o contrário da multiplicação: se 2 × 5 = 10, então 10 : 2 = 5.'
    ],
    q: [
      ['Quanto é 3 × 4?', ['12', '7', '34', '9']],
      ['Qual é o dobro de 6?', ['12', '3', '8', '62']],
      ['Num arranjo com 2 filas de 5 bolas, quantas bolas há?', ['10', '7', '2', '25']],
      ['Se 2 × 5 = 10, então 10 : 2 = …', ['5', '2', '10', '20']],
      ['3 × 4 é igual a 4 × 3.', true],
      ['Quanto é 10 × 2?', ['20', '12', '102', '8']]
    ]
  },
  {
    id: 'mat2_fracoes', t: 'Frações simples',
    k: 'fracoes,fracao,metade,quarto,numerador,denominador,partilha',
    ae: 'Reconhecer a fração como parte de uma unidade, representar frações de diferentes formas e reconhecer metades e quartos.',
    r: [
      'Uma fração mostra partes iguais de um todo: numerador (partes tomadas) sobre denominador (partes totais).',
      '1/2 é metade; 1/4 é um quarto.',
      'Uma fração pode ser representada por desenho, por palavras ("um quarto") ou por símbolo (1/4).',
      'Se o numerador é igual ao denominador, a fração representa a unidade inteira: 4/4 = 1.'
    ],
    q: [
      ['Em 1/4, o número 4 chama-se…', ['denominador', 'numerador', 'resultado', 'soma']],
      ['Uma pizza dividida em 2 partes iguais: cada parte é…', ['1/2', '1/4', '1/3', '2/2']],
      ['Qual fração representa a unidade inteira?', ['4/4', '1/4', '2/4', '1/2']],
      ['1/2 é maior do que 1/4.', true],
      ['Como se representa "um quarto" em número?', ['1/4', '4/1', '1/2', '2/4']]
    ]
  },
  {
    id: 'mat2_geometria', t: 'Figuras, sólidos e ângulos retos',
    k: 'figuras geometricas,poligonos,triangulos,quadrilateros,pentagono,hexagono,solidos,poliedros,angulo reto',
    ae: 'Classificar figuras planas pelo número de lados, reconhecer ângulos retos e distinguir sólidos poliedros de outros sólidos.',
    r: [
      'Polígonos: triângulo (3 lados), quadrilátero (4 lados), pentágono (5), hexágono (6).',
      'Um ângulo reto mede 90°; o canto de uma folha de papel é um exemplo.',
      'O quadrado é um tipo especial de retângulo, com todos os lados iguais.',
      'Poliedros têm só faces planas (cubo, pirâmide, prisma); a esfera, o cone e o cilindro têm faces curvas e não são poliedros.'
    ],
    q: [
      ['Quantos lados tem um hexágono?', ['6', '5', '4', '8']],
      ['Um ângulo reto mede…', ['90°', '180°', '45°', '360°']],
      ['O quadrado é um tipo especial de…', ['retângulo', 'triângulo', 'círculo', 'pentágono']],
      ['Qual destes sólidos é um poliedro?', ['cubo', 'esfera', 'cone', 'cilindro']],
      ['A esfera tem faces curvas, por isso não é um poliedro.', true]
    ]
  },
  {
    id: 'mat2_medida', t: 'Comprimento, tempo e dinheiro',
    k: 'comprimento,metro,centimetro,perimetro,tempo,hora,dia,mes,ano,dinheiro,euro,centimo',
    ae: 'Medir comprimentos em metros e centímetros e calcular o perímetro; relacionar hora, dia, mês e ano; resolver problemas com dinheiro.',
    r: [
      'O metro (m) e o centímetro (cm) medem comprimentos; 1 m = 100 cm.',
      'O perímetro de uma figura é a soma dos seus lados.',
      '1 dia tem 24 horas; 1 semana tem 7 dias; 1 ano tem 12 meses.',
      '1 euro = 100 cêntimos; há moedas e notas de diferentes valores.'
    ],
    q: [
      ['Quantos centímetros tem 1 metro?', ['100', '10', '1000', '50']],
      ['Um quadrado tem lados de 4 cm. Qual é o seu perímetro?', ['16 cm', '8 cm', '4 cm', '12 cm']],
      ['Quantas horas tem 1 dia?', ['24', '12', '7', '60']],
      ['Quantos meses tem 1 ano?', ['12', '10', '7', '52']],
      ['1 euro equivale a quantos cêntimos?', ['100', '10', '1000', '50']],
      ['O perímetro é a soma dos lados de uma figura.', true]
    ]
  },
  {
    id: 'mat2_dados', t: 'Tabelas, diagramas e gráficos',
    k: 'tabelas,frequencias,diagrama de carroll,pictograma,grafico de barras,fonte,titulo,legenda',
    ae: 'Organizar dados em tabelas de frequências, usar diagramas de Carroll e representar dados em pictogramas e gráficos de barras.',
    r: [
      'Uma tabela de frequências absolutas mostra quantas vezes cada resposta aparece, com um título.',
      'Um diagrama de Carroll organiza dados por duas características (por exemplo, "tem pelo" e "não tem pelo").',
      'Um gráfico ou pictograma deve ter fonte, título e legenda, para se entender bem.',
      'Depois de recolher os dados, é importante escolher o gráfico mais adequado para os mostrar.'
    ],
    q: [
      ['Uma tabela de frequências regista…', ['quantas vezes cada resposta aparece', 'só os nomes', 'só as cores', 'nada']],
      ['Um diagrama de Carroll organiza dados usando…', ['duas características', 'só uma pergunta', 'só desenhos', 'nenhuma regra']],
      ['O que deve ter sempre um gráfico, para se entender bem?', ['título e legenda', 'só números', 'só cores', 'nada']],
      ['Depois de recolher dados, devemos escolher o gráfico mais adequado para os mostrar.', true]
    ]
  }
]);

// ============================================================= ESTUDO DO MEIO
TEMAS(2, 'em', [
  {
    id: 'em2_corpo', t: 'Sistemas do corpo e saúde',
    k: 'sistemas do corpo,sistema circulatorio,sistema respiratorio,sistema digestivo,ossos,musculos,vacinacao,medicamentos',
    ae: 'Identificar os principais sistemas do corpo (circulatório, respiratório, digestivo) e as suas funções; reconhecer a importância da vacinação e do uso correto de medicamentos.',
    r: [
      'O sistema circulatório (coração e vasos sanguíneos) transporta o sangue por todo o corpo.',
      'O sistema respiratório (nariz, traqueia, pulmões) permite respirar.',
      'O sistema digestivo (boca, estômago, intestinos) transforma os alimentos para o corpo os poder usar.',
      'Os ossos e os músculos dão forma ao corpo e permitem o movimento.',
      'As vacinas protegem-nos de doenças; os medicamentos só se tomam com indicação de um adulto ou médico.'
    ],
    q: [
      ['Qual sistema transporta o sangue pelo corpo?', ['sistema circulatório', 'sistema digestivo', 'sistema respiratório', 'nenhum']],
      ['Os pulmões fazem parte do sistema…', ['respiratório', 'circulatório', 'digestivo', 'ósseo']],
      ['O sistema digestivo serve para…', ['transformar os alimentos', 'respirar', 'ver', 'ouvir']],
      ['As vacinas ajudam a…', ['proteger-nos de doenças', 'adoecer', 'crescer mais rápido', 'nada']],
      ['Os medicamentos só devem ser tomados com indicação de um adulto ou médico.', true]
    ]
  },
  {
    id: 'em2_familia', t: 'Família, documentos e direitos',
    k: 'familia,documentos pessoais,certidao de nascimento,boletim de saude,instituicoes,direitos da crianca,conflitos,dialogo',
    ae: 'Usar documentos pessoais e familiares como fontes do passado; reconhecer instituições da comunidade e os direitos da criança.',
    r: [
      'Documentos como a certidão de nascimento, o boletim de vacinas e fotografias ajudam a conhecer o passado da família.',
      'A escola e outras instituições (centro de saúde, junta de freguesia) ajudam o bem-estar da comunidade.',
      'Resolver conflitos pode fazer-se com diálogo e negociação, em vez de gritar ou bater.',
      'As crianças têm direitos, como o direito à educação e à proteção.'
    ],
    q: [
      ['A certidão de nascimento é um exemplo de…', ['documento pessoal', 'jogo', 'receita', 'mapa']],
      ['Resolver um conflito com diálogo é…', ['falar e tentar entender-se', 'gritar', 'bater', 'ignorar sempre']],
      ['Qual destas é uma instituição da comunidade?', ['o centro de saúde', 'a Lua', 'um país estrangeiro', 'o oceano']],
      ['As crianças têm direito à educação.', true]
    ]
  },
  {
    id: 'em2_seres', t: 'Animais e plantas',
    k: 'animais,plantas,classificacao,habitat,biodiversidade,oxigenio,florestas,oceano',
    ae: 'Comparar e classificar animais e plantas por características observáveis; relacionar as suas características com o habitat; reconhecer a importância das florestas e do oceano.',
    r: [
      'Os animais classificam-se pelo revestimento, pela alimentação, pela locomoção e pela forma como nascem.',
      'As plantas têm raiz, caule, folhas, flor, fruto e semente, cada parte com uma função.',
      'Cada ser vivo está adaptado ao seu habitat (onde vive): um peixe vive na água, um camelo no deserto.',
      'As florestas e o oceano produzem grande parte do oxigénio que respiramos.',
      'Proteger a biodiversidade (a diversidade de seres vivos) é importante para o equilíbrio da natureza.'
    ],
    q: [
      ['Um peixe está adaptado a viver…', ['na água', 'no deserto', 'no gelo só', 'no ar']],
      ['Que parte da planta absorve água do solo?', ['a raiz', 'a flor', 'o fruto', 'a folha']],
      ['As florestas e o oceano produzem muito do…', ['oxigénio que respiramos', 'dinheiro', 'petróleo', 'sal']],
      ['Biodiversidade significa…', ['a diversidade de seres vivos', 'só os animais grandes', 'só as plantas', 'nada']],
      ['Proteger a natureza ajuda a manter a biodiversidade.', true]
    ]
  },
  {
    id: 'em2_materiais', t: 'Materiais e mudanças de estado',
    k: 'materiais,mudancas de estado,calor,frio,ciclo da agua,solido,liquido,gasoso,tecnologia',
    ae: 'Classificar materiais por propriedades simples e reconhecer mudanças de estado da água causadas por calor e frio.',
    r: [
      'Os materiais podem classificar-se pela textura, cor ou se flutuam na água.',
      'O calor pode transformar um sólido em líquido (o gelo derrete) e o frio pode transformar um líquido em sólido (a água congela).',
      'A água pode estar sólida (gelo), líquida ou gasosa (vapor); estas mudanças fazem parte do ciclo da água.',
      'A tecnologia (como as redes de eletricidade e de água) ajuda a satisfazer necessidades do dia a dia.'
    ],
    q: [
      ['O que acontece ao gelo quando é aquecido?', ['derrete e fica líquido', 'fica mais duro', 'desaparece para sempre', 'não muda']],
      ['A água, quando arrefece muito, transforma-se em…', ['gelo (sólido)', 'vapor (gasoso)', 'nada', 'areia']],
      ['O ciclo da água inclui a água em estado…', ['sólido, líquido e gasoso', 'só sólido', 'só líquido', 'só gasoso']],
      ['As redes de eletricidade e de água são exemplos de tecnologia do dia a dia.', true]
    ]
  },
  {
    id: 'em2_espaco', t: 'Portugal na Europa',
    k: 'portugal,europa,mapa,fronteiras,itinerarios,plantas,simbolos,legenda',
    ae: 'Localizar Portugal na Europa e no mundo, reconhecer as suas fronteiras, e desenhar mapas e itinerários simples com símbolos e legenda.',
    r: [
      'Portugal fica na Europa, na Península Ibérica, com fronteira terrestre só com a Espanha.',
      'Portugal é banhado pelo oceano Atlântico.',
      'Um mapa simples usa símbolos e uma legenda para se entender o que representa.',
      'Um itinerário mostra o caminho entre dois lugares, com pontos de referência.'
    ],
    q: [
      ['Portugal faz fronteira terrestre com…', ['a Espanha', 'a França', 'a Itália', 'a Alemanha']],
      ['Portugal é banhado pelo oceano…', ['Atlântico', 'Pacífico', 'Índico', 'Glaciar']],
      ['Um mapa usa uma legenda para…', ['explicar os símbolos', 'enfeitar', 'contar uma história', 'nada']],
      ['Portugal fica no continente…', ['europeu', 'africano', 'americano', 'asiático']],
      ['Um itinerário mostra o caminho entre dois lugares.', true]
    ]
  },
  {
    id: 'em2_tempo', t: 'Estações do ano, clima e passado',
    k: 'estacoes do ano,clima,tempo,passado,historia familiar,friso cronologico',
    ae: 'Caracterizar o tempo típico das estações em Portugal e usar a história pessoal e familiar, organizada num friso cronológico, para compreender o passado.',
    r: [
      'As quatro estações do ano são primavera, verão, outono e inverno, cada uma com um tempo típico.',
      'Em Portugal, o verão costuma ser quente e seco; o inverno mais frio e chuvoso.',
      'O tempo pode variar de ano para ano (nem sempre chove ou faz calor da mesma forma).',
      'Um friso cronológico organiza acontecimentos da vida pessoal e familiar por ordem de data.',
      'Fotografias, documentos e conversas com familiares mais velhos ajudam a conhecer o passado.'
    ],
    q: [
      ['Em Portugal, o verão costuma ser…', ['quente e seco', 'frio e nevado', 'sempre chuvoso', 'igual ao inverno']],
      ['Quantas estações tem o ano?', ['4', '2', '12', '3']],
      ['Um friso cronológico organiza acontecimentos por…', ['ordem de data', 'cor', 'tamanho', 'ordem alfabética']],
      ['Falar com familiares mais velhos ajuda a conhecer…', ['o passado da família', 'só o futuro', 'só a matemática', 'nada']],
      ['O tempo pode variar de ano para ano.', true]
    ]
  }
]);
