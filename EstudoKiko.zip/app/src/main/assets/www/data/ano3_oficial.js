/* Mais perguntas de prática para o 3.º ano, escritas a partir das Aprendizagens Essenciais
   oficiais da DGE (dge.mec.pt) de Português, Matemática, Estudo do Meio e Inglês — reforçam
   os temas com menos perguntas, sem repetir as já existentes. */
(function () {
  'use strict';
  const MAIS = {
    mat3_dados: [
      ['Numa tabela de frequências absolutas, o número ao lado de cada resposta indica…', ['quantas vezes essa resposta foi dada', 'a ordem alfabética', 'a cor do gráfico', 'o título da tabela']],
      ['Nos valores 4, 7, 2, 9, 5, qual é o valor mínimo?', ['2', '9', '7', '5']],
      ['Antes de desenhar um gráfico, o primeiro passo é…', ['recolher os dados', 'escolher as cores', 'desenhar a legenda', 'contar a moda']]
    ],
    mat3_perimetro: [
      ['Duas figuras podem ter a mesma área e perímetros diferentes.', true],
      ['Um triângulo tem lados de 3 cm, 4 cm e 5 cm. Qual é o perímetro?', ['12 cm', '7 cm', '20 cm', '60 cm']],
      ['Um pentaminó é uma figura feita com 5 quadrados iguais, unidos lado a lado.', true]
    ],
    mat3_geometria: [
      ['Um ângulo que mede exatamente 90° chama-se ângulo…', ['reto', 'agudo', 'obtuso', 'raso']],
      ['Um ângulo maior do que o ângulo reto e menor do que o ângulo raso chama-se…', ['obtuso', 'agudo', 'reto', 'giro']],
      ['Numa rotação de 180°, a figura dá…', ['meia volta', 'um quarto de volta', 'uma volta completa', 'três quartos de volta']]
    ],
    mat3_solidos: [
      ['Um prisma tem duas bases iguais e paralelas, unidas por faces retangulares.', true],
      ['Numa pirâmide, as faces laterais triangulares juntam-se todas num só…', ['vértice', 'lado', 'ângulo reto', 'eixo']],
      ['O que distingue um prisma de uma pirâmide?', ['o prisma tem duas bases iguais; a pirâmide só tem uma', 'o prisma não tem faces', 'a pirâmide tem sempre 6 faces', 'não há diferença']]
    ],
    pt3_textos: [
      ['Uma notícia serve principalmente para…', ['informar sobre um acontecimento', 'contar uma história inventada', 'convidar para uma festa', 'pedir desculpa']],
      ['Escrever um texto para convencer alguém de uma ideia chama-se…', ['argumentar', 'narrar', 'descrever', 'rimar']],
      ['Os contos de fadas são um exemplo de texto…', ['narrativo', 'informativo', 'publicitário', 'instrucional']]
    ],
    em3_localidade: [
      ['No continente, os concelhos agrupam-se em…', ['distritos', 'freguesias', 'países', 'ilhas']],
      ['A Assembleia Municipal também é eleita pelos cidadãos do concelho.', true],
      ['Emitir atestados de residência é uma função da…', ['Junta de Freguesia', 'escola', 'biblioteca', 'polícia']]
    ],
    em3_atividades: [
      ['O agricultor que planta e colhe trabalha no setor…', ['primário', 'secundário', 'terciário', 'escolar']],
      ['Vender produtos numa loja é uma atividade do setor…', ['terciário', 'primário', 'secundário', 'industrial']],
      ['O operário que trabalha numa fábrica pertence ao setor…', ['secundário', 'primário', 'terciário', 'agrícola']]
    ],
    em3_materiais: [
      ['Um material que deixa passar um pouco de luz, mas não deixa ver através dele com nitidez, é…', ['translúcido', 'transparente', 'opaco', 'rígido']],
      ['Quando o gelo se transforma em água líquida, ocorre a…', ['fusão', 'evaporação', 'condensação', 'solidificação']],
      ['Dissolver sal em água é uma transformação reversível.', true]
    ],
    em3_orientacao: [
      ['Que instrumento usamos para nos orientar pelos pontos cardeais?', ['a bússola', 'o termómetro', 'a balança', 'a régua']],
      ['Virados para Norte, o Este fica à nossa…', ['direita', 'esquerda', 'frente', 'retaguarda']],
      ['O GPS é um instrumento tecnológico que ajuda a localizarmo-nos.', true]
    ],
    em3_passado: [
      ['Um milénio tem quantos anos?', ['1000', '100', '10', '10 000']],
      ['As siglas a.C. e d.C. referem-se a…', ['antes e depois de Cristo', 'antes e depois do Carnaval', 'alto e cima', 'ano certo e ano duvidoso']],
      ['Edifícios antigos são vestígios do passado de uma localidade.', true]
    ],
    em3_seguranca: [
      ['O que se deve fazer primeiro perante uma queimadura ligeira?', ['arrefecer com água corrente', 'esfregar com gelo diretamente', 'pôr pasta de dentes', 'tapar com um cobertor']],
      ['Se alguém está a sangrar muito, deve-se…', ['pressionar o local com um pano limpo e pedir ajuda', 'ignorar e continuar a brincar', 'lavar com sabão só no fim do dia', 'não dizer a ninguém']],
      ['Perante uma situação que não sabes resolver, deves…', ['pedir ajuda a um adulto', 'resolver sozinho sem avisar', 'esconder-te', 'fugir de casa']]
    ],
    ing3_hello: [
      ['"Excuse me" é usado para…', ['chamar a atenção ou pedir desculpa', 'dizer adeus', 'contar números', 'perguntar as horas']],
      ['"See you later!" significa…', ['Até logo!', 'Bom dia!', 'Como estás?', 'Muito gosto!']],
      ['How do you say 16 in English?', ['sixteen', 'sixty', 'six', 'sixteenth']]
    ],
    ing3_colours: [
      ['"Circle" significa…', ['círculo', 'quadrado', 'triângulo', 'retângulo']],
      ['"Square" significa…', ['quadrado', 'círculo', 'triângulo', 'estrela']],
      ['What colour do you get mixing blue and yellow?', ['green', 'purple', 'orange', 'pink']]
    ],
    ing3_family: [
      ['"Aunt" significa…', ['tia', 'tio', 'prima', 'avó']],
      ['"Uncle" significa…', ['tio', 'tia', 'primo', 'avô']],
      ['"I\'ve got two brothers." significa…', ['Eu tenho dois irmãos.', 'Eu tenho duas irmãs.', 'Eu sou filho único.', 'Eu tenho dois gatos.']]
    ],
    ing3_house: [
      ['"Garden" significa…', ['jardim', 'quarto', 'cozinha', 'sala']],
      ['"It\'s windy" significa…', ['Está vento.', 'Está sol.', 'Está a chover.', 'Está frio.']],
      ['What day comes before Friday?', ['Thursday', 'Saturday', 'Wednesday', 'Monday']]
    ]
  };
  Object.keys(MAIS).forEach((id) => {
    const t = CUR.temas[id];
    if (t) MAIS[id].forEach((q) => t.q.push(q));
  });
})();
