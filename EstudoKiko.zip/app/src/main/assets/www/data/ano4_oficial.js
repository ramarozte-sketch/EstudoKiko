/* Mais perguntas de prática para o 4.º ano, escritas a partir das Aprendizagens Essenciais
   oficiais da DGE (dge.mec.pt) de Português, Matemática, Estudo do Meio e Inglês — reforçam
   os temas com menos perguntas, sem repetir as já existentes. */
(function () {
  'use strict';
  const MAIS = {
    mat4_m_simetria: [
      ['Uma figura com simetria de rotação de 180° coincide consigo mesma ao dar…', ['meia volta', 'um quarto de volta', 'três quartos de volta', 'uma volta completa']],
      ['O sentido de uma rotação pode ser horário ou anti-horário.', true],
      ['Quantos eixos de simetria tem um retângulo que não é quadrado?', ['2', '4', '1', '0']]
    ],
    mat4_m_solidos: [
      ['Quantas faces tem um prisma triangular (2 bases + faces laterais)?', ['5', '3', '6', '4'], 'Duas bases triangulares mais três faces laterais retangulares = 5.'],
      ['Numa pirâmide, a face que não é a base chama-se face…', ['lateral', 'frontal', 'principal', 'escondida']],
      ['Quantas faces tem uma pirâmide triangular?', ['4', '3', '5', '6'], 'Uma base triangular mais três faces laterais triangulares = 4.']
    ],
    mat4_m_algebra: [
      ['Se a figura n tem 2 × n + 1 bolas, quantas tem a figura 4?', ['9', '8', '7', '10'], '2 × 4 + 1 = 9.'],
      ['Sequência: 2, 5, 8, 11, … Qual é a regra?', ['somar 3', 'somar 2', 'multiplicar por 2', 'subtrair 3']],
      ['Se C = L + 5 e L = 12, quanto é C?', ['17', '7', '60', '5']]
    ],
    em4_defesas: [
      ['Como se chama o conjunto de vacinas feitas ao longo da vida em Portugal?', ['Plano Nacional de Vacinação', 'Plano Nacional de Leitura', 'Programa de Educação Física', 'Plano Rodoviário Nacional']],
      ['Tossir ou espirrar para o braço, em vez de para as mãos, ajuda a…', ['evitar espalhar micróbios', 'crescer mais depressa', 'digerir melhor', 'dormir melhor']],
      ['A puberdade acontece, em geral, por volta dos…', ['10 aos 14 anos', '1 aos 3 anos', '20 aos 25 anos', '40 aos 50 anos']]
    ],
    em4_direitos: [
      ['A Convenção sobre os Direitos da Criança foi aprovada em que ano?', ['1989', '1948', '1986', '2000']],
      ['Qual destes é um direito da criança?', ['o direito à educação', 'o direito a conduzir', 'o direito a não ir à escola', 'o direito a trabalhar em vez de estudar']],
      ['As migrações podem ter causas humanitárias, como guerras ou catástrofes.', true]
    ],
    'ing4_m_time': [
      ["\"It's quarter past four.\" significa…", ['são quatro e um quarto', 'são quatro horas', 'são três e um quarto', 'são quatro e meia']],
      ["\"What time is it?\" asks about…", ['the time', 'the date', 'the weather', 'your age']],
      ['9:15 is…', ['quarter past nine', 'quarter to nine', 'half past nine', 'nine o’clock']]
    ],
    ing4_festivities: [
      ["\"Witch\" significa…", ['bruxa', 'fantasma', 'morcego', 'abóbora']],
      ['What do people give on a birthday?', ['presents', 'homework', 'vegetables', 'rain']],
      ['Bonfire Night happens in which country?', ['the UK', 'Portugal', 'France', 'Spain']]
    ],
    ing4_town: [
      ["\"Opposite\" significa…", ['em frente a', 'ao lado de', 'atrás de', 'dentro de']],
      ['Where do you borrow books in a town?', ['at the library', 'at the zoo', 'at the bakery', 'at the hospital']],
      ["\"Behind\" significa…", ['atrás de', 'à frente de', 'ao lado de', 'dentro de']]
    ],
    pt4_m_preposicoes: [
      ['"Ao" resulta da contração de…', ['a + o', 'a + a', 'de + o', 'em + o']],
      ['Qual destas frases tem uma preposição?', ['Foi contra a parede.', 'Foi rapidamente.', 'Está bonito.', 'Correu depressa.']],
      ['"Até" pode indicar um limite de tempo ou de espaço.', true]
    ],
    pt4_obras: [
      ['Quem escreveu "A Mata dos Medos"?', ['Álvaro de Magalhães', 'José Saramago', 'Oscar Wilde', 'Couto Viana']],
      ['"Versos de Cacaracá" é uma obra de…', ['poesia', 'teatro', 'banda desenhada', 'notícia']],
      ['Ao apresentar uma obra devemos identificar o título e o autor.', true]
    ],
    mat4_m_dados: [
      ['Lançar um dado normal (1 a 6) e sair o número 7 é um acontecimento…', ['impossível', 'certo', 'provável', 'pouco provável']],
      ['Num gráfico de barras duplo, a legenda serve para…', ['distinguir os dois conjuntos de dados', 'medir ângulos', 'calcular a média', 'desenhar o mapa']],
      ['Caule 3, folha 7 (à esquerda) lê-se…', ['37', '73', '3,7', '10']]
    ],
    mat4_sequencias: [
      ['Qual é a regra da sequência 2, 6, 18, 54, …?', ['multiplicar por 3', 'somar 4', 'somar 16', 'dividir por 3']],
      ['Quanto é 10 − 2 × 3?', ['4', '24', '8', '5']],
      ['Quanto é (10 − 2) × 3?', ['24', '4', '8', '30']]
    ],
    em4_m_europa: [
      ['Qual destes países faz fronteira com Portugal e pertence à União Europeia?', ['Espanha', 'França', 'Marrocos', 'Reino Unido']],
      ['As migrações podem ter consequências económicas nos países de chegada e de partida.', true],
      ['O telégrafo foi sendo substituído, ao longo do tempo, por…', ['telefone, telemóvel e internet', 'carros de bois', 'barcos à vela', 'comboios a vapor, só']]
    ],
    em4_m_natureza: [
      ['A pesca e a caça ilegais podem levar à…', ['extinção de espécies', 'proteção de espécies', 'mais biodiversidade', 'reflorestação']],
      ['Qual destas ações ajuda a proteger o ambiente?', ['reciclar e reduzir o plástico', 'desflorestar', 'poluir os rios', 'pescar ilegalmente']],
      ['A águia-imperial é uma espécie ameaçada em Portugal.', true]
    ],
    em4_m_orientacao: [
      ['Qual é o primeiro planeta a contar do Sol?', ['Mercúrio', 'Vénus', 'Terra', 'Marte']],
      ['De noite, para nos orientarmos, procuramos…', ['a Estrela Polar', 'o Sol', 'um relógio', 'só um mapa']],
      ['Virados para a Estrela Polar, o Oeste fica à nossa…', ['esquerda', 'direita', 'frente', 'retaguarda']]
    ],
    em4_m_interior: [
      ['As rochas podem ser classificadas pela sua cor, textura, cheiro e…', ['dureza', 'sabor', 'cor do céu', 'velocidade']],
      ['Satélites e magnetómetros ajudam a…', ['estudar o interior da Terra', 'prever só o tempo', 'fazer mapas de estradas', 'cultivar a terra']],
      ['A maior parte do território de Portugal continental é ocupada por…', ['florestas', 'aeroportos', 'praias', 'desertos']]
    ],
    em4_terra: [
      ['As aldeias de xisto situam-se sobretudo…', ['no centro de Portugal', 'nos Açores', 'no Algarve', 'na Madeira']],
      ['Uma lagoa costuma ser mais … do que um lago.', ['pequena e pouco profunda', 'grande e profunda', 'salgada sempre', 'quente sempre']],
      ['O calcário é muito usado na calçada portuguesa.', true]
    ],
    ing4_m_numbers: [
      ['What is the ordinal of 5?', ['fifth', 'five', 'fiveth', 'fifteenth']],
      ['80 in English is…', ['eighty', 'eighteen', 'eight', 'eightteen']],
      ["\"I'm eleven years old.\" answers which question?", ['How old are you?', 'When is your birthday?', 'What is your name?', 'Where do you live?']]
    ],
    ing4_m_school: [
      ['"Classroom" significa…', ['sala de aula', 'recreio', 'cantina', 'ginásio']],
      ["'He is … football.' (ele está a jogar agora)", ['playing', 'play', 'plays', 'played']],
      ['Where do you play at break time?', ['playground', 'library', 'canteen', 'classroom']]
    ],
    ing4_routines: [
      ['"Quarter past four" significa…', ['quatro e um quarto', 'quatro e meia', 'três e um quarto', 'quatro horas']],
      ['"Living room" significa…', ['sala', 'quarto', 'cozinha', 'casa de banho']],
      ['The ball is … the box. (em cima da caixa)', ['on', 'in', 'under', 'behind']]
    ],
    pt4_tiposTexto: [
      ['Um convite deve indicar o quê, quem convida, dia, hora e…', ['local', 'rima', 'personagens', 'moral']],
      ['"Proibido fumar" é um exemplo de…', ['aviso', 'carta', 'receita', 'poema']],
      ['Um slogan publicitário serve sobretudo para…', ['chamar a atenção e convencer', 'dar instruções de cozinha', 'contar uma história', 'pedir desculpa']]
    ]
  };
  Object.keys(MAIS).forEach((id) => {
    const t = CUR.temas[id];
    if (t) MAIS[id].forEach((q) => t.q.push(q));
  });
})();
