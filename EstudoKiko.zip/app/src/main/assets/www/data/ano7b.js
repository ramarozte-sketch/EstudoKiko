/* 7.º ano — 3.º ciclo (Aprendizagens Essenciais em vigor 2026/2027): História, Geografia, Inglês */

// ============================================================= HISTÓRIA
TEMAS(7, 'hist', [
  {
    id: 'hist7_prehistoria', t: 'Paleolítico e Neolítico',
    k: 'pre-historia,pre historia,paleolitico,neolitico,recolectores,nomadas,sedentarizacao,agricultura,pastoricia,arte rupestre,foz coa,megalitismo,antas,menires,cromeleques,almendres,revolucao neolitica,homo sapiens',
    ae: 'Caracterizar as comunidades recolectoras do Paleolítico e as comunidades agropastoris do Neolítico, incluindo vestígios em Portugal.',
    r: [
      'Paleolítico: os seres humanos eram nómadas e recolectores — viviam da caça, pesca e recoleção. Usavam utensílios de pedra lascada e dominaram o fogo.',
      'Arte rupestre: pinturas e gravuras em grutas e rochas (em Portugal, as gravuras do Vale do Côa, Património Mundial).',
      'Neolítico (a partir de cerca de 10 000 a.C., no Médio Oriente): começam a agricultura e a pastorícia → sedentarização (aldeias). É a chamada "Revolução Neolítica".',
      'Novas técnicas: pedra polida, cerâmica, tecelagem e moagem.',
      'Megalitismo: monumentos de grandes pedras — antas/dólmenes (sepulturas coletivas), menires (pedras na vertical) e cromeleques (menires em círculo, como o dos Almendres, em Évora).',
      'Surgem a divisão do trabalho, o comércio por troca direta e diferenças sociais.'
    ],
    q: [
      ['No Paleolítico, as comunidades eram…', ['nómadas e recolectoras', 'sedentárias e agricultoras', 'urbanas', 'industriais']],
      ['O que levou à sedentarização no Neolítico?', ['a agricultura e a pastorícia', 'a descoberta do ferro', 'a escrita', 'o comércio marítimo']],
      ['Onde existem gravuras paleolíticas famosas em Portugal?', ['Vale do Côa', 'Serra da Estrela', 'Mértola', 'Sagres']],
      ['Uma sepultura coletiva megalítica chama-se…', ['anta (dólmen)', 'menir', 'pirâmide', 'zigurate']],
      ['O Cromeleque dos Almendres fica perto de…', ['Évora', 'Braga', 'Faro', 'Viseu']],
      ['A cerâmica e a pedra polida são inovações do Neolítico.', true],
      ['No Paleolítico já se praticava a agricultura.', false, 'A agricultura surge no Neolítico.']
    ]
  },
  {
    id: 'hist7_civilizacoes', t: 'Civilizações dos grandes rios (Egito e Mesopotâmia)',
    k: 'civilizacoes dos grandes rios,civilizacoes,egito,egipto,nilo,faraos,farao,piramides,hieroglifos,mumificacao,mesopotamia,tigre,eufrates,cuneiforme,codigo de hamurabi,escrita,primeiras civilizacoes,hebreus,fenicios,alfabeto',
    ae: 'Caracterizar as primeiras civilizações urbanas dos grandes rios (Egito e Mesopotâmia): organização política, social, económica, religiosa e a invenção da escrita.',
    r: [
      'As primeiras civilizações surgiram junto a grandes rios, que permitiam a agricultura de regadio: Nilo (Egito), Tigre e Eufrates (Mesopotâmia).',
      'Egito: o faraó tinha um poder absoluto e era considerado um deus (monarquia teocrática). Sociedade hierarquizada: faraó, nobres e sacerdotes, escribas, camponeses e artesãos, escravos.',
      'Religião egípcia: politeísta, com crença na vida após a morte → mumificação e túmulos (pirâmides de Gizé).',
      'Escrita: hieroglífica no Egito; cuneiforme na Mesopotâmia (a primeira escrita, por volta de 3200 a.C.). A invenção da escrita marca o início da História.',
      'Na Mesopotâmia, o rei Hamurabi criou um dos primeiros códigos de leis escritas.',
      'Outros povos: os Hebreus foram os primeiros monoteístas; os Fenícios eram grandes comerciantes e criaram um alfabeto que deu origem ao nosso.'
    ],
    q: [
      ['Que rio foi essencial para a civilização egípcia?', ['Nilo', 'Tigre', 'Eufrates', 'Tejo']],
      ['Como se chama a escrita dos antigos egípcios?', ['hieroglífica', 'cuneiforme', 'latina', 'alfabética grega']],
      ['A escrita cuneiforme surgiu na…', ['Mesopotâmia', 'Grécia', 'Roma', 'China']],
      ['O que se entende por monarquia teocrática?', ['o rei é visto como deus ou representante divino', 'o povo elege o rei', 'governam os sacerdotes eleitos', 'não há rei']],
      ['Quem criou um dos primeiros códigos de leis escritas?', ['Hamurabi', 'Péricles', 'Ramsés II', 'Júlio César']],
      ['Os Hebreus foram o primeiro povo monoteísta.', true],
      ['Que povo criou o alfabeto que deu origem ao nosso?', ['Fenícios', 'Egípcios', 'Persas', 'Mesopotâmios']],
      ['A religião egípcia era…', ['politeísta', 'monoteísta', 'cristã', 'muçulmana']]
    ]
  },
  {
    id: 'hist7_grecia', t: 'O mundo grego: Atenas e a democracia',
    k: 'grecia,grecia antiga,gregos,atenas,esparta,democracia,democracia ateniense,polis,cidade-estado,pericles,eclesia,boule,cidadaos,metecos,escravos,acropole,partenon,jogos olimpicos,teatro grego,ordens arquitetonicas,doric,jonica,corintia,filosofia',
    ae: 'Caracterizar a democracia ateniense do século V a.C. e os seus limites; identificar a herança cultural grega.',
    r: [
      'A Grécia antiga estava dividida em cidades-estado independentes (pólis), como Atenas e Esparta.',
      'No século V a.C., com Péricles, Atenas viveu o auge da democracia (governo do povo).',
      'Órgãos: Eclésia (assembleia de todos os cidadãos, que votava as leis), Bulé (preparava as leis), Magistrados (estrategos, arcontes) e Helieia (tribunal).',
      'Só eram cidadãos os homens livres, filhos de pai e mãe atenienses, maiores de 18 anos. Estavam excluídos: mulheres, metecos (estrangeiros) e escravos → democracia limitada.',
      'Cultura grega: teatro (tragédia e comédia), filosofia (Sócrates, Platão, Aristóteles), Jogos Olímpicos em honra de Zeus, arquitetura com ordens dórica, jónica e coríntia (Pártenon, na Acrópole).',
      'Religião politeísta e antropomórfica (deuses com forma e sentimentos humanos), com deuses como Zeus, Atena e Apolo.'
    ],
    q: [
      ['Que dirigente ateniense está associado ao auge da democracia no século V a.C.?', ['Péricles', 'Alexandre Magno', 'Júlio César', 'Hamurabi']],
      ['Como se chamava a assembleia de todos os cidadãos de Atenas?', ['Eclésia', 'Bulé', 'Senado', 'Helieia']],
      ['Quem podia ser cidadão em Atenas?', ['homens livres, filhos de pais atenienses', 'todos os habitantes', 'homens e mulheres livres', 'só os ricos e os metecos']],
      ['Os estrangeiros que viviam em Atenas chamavam-se…', ['metecos', 'escravos', 'patrícios', 'plebeus']],
      ['O Pártenon fica na…', ['Acrópole de Atenas', 'cidade de Esparta', 'cidade de Roma', 'ilha de Creta']],
      ['A democracia ateniense era limitada porque excluía mulheres, metecos e escravos.', true],
      ['Os Jogos Olímpicos eram realizados em honra de…', ['Zeus', 'Júpiter', 'Rá', 'Atena']],
      ['A religião grega era monoteísta.', false, 'Era politeísta: acreditavam em muitos deuses.']
    ]
  },
  {
    id: 'hist7_roma', t: 'Roma e o Império Romano',
    k: 'roma,romanos,imperio romano,imperio,republica romana,imperador,augusto,romanizacao,peninsula iberica romana,lusitanos,viriato,latim,direito romano,estradas romanas,pontes,aquedutos,termas,anfiteatro,coliseu,urbanismo,conimbriga,templo de diana',
    ae: 'Caracterizar o Império Romano e a romanização da Península Ibérica; identificar o legado romano.',
    r: [
      'Roma foi fundada, segundo a lenda, em 753 a.C. Passou por monarquia, república e império (a partir de 27 a.C., com Augusto, o primeiro imperador).',
      'O Império Romano dominou todo o Mediterrâneo ("Mare Nostrum"), com um exército poderoso e uma rede de estradas.',
      'O imperador concentrava os poderes político, militar, religioso e judicial.',
      'A Península Ibérica foi conquistada pelos romanos (séculos II a.C. – I a.C.); os Lusitanos, liderados por Viriato, resistiram.',
      'Romanização: adoção da língua latina (origem do português), do direito romano, de cidades, estradas, pontes, aquedutos, termas, teatros e anfiteatros.',
      'Vestígios em Portugal: Conímbriga, o Templo romano de Évora, a ponte romana de Chaves, as ruínas de Mirobriga e de Milreu.'
    ],
    q: [
      ['Quem foi o primeiro imperador de Roma?', ['Augusto', 'Júlio César', 'Nero', 'Constantino']],
      ['Que chefe lusitano resistiu aos romanos?', ['Viriato', 'D. Afonso Henriques', 'Aníbal', 'Péricles']],
      ['A língua portuguesa deriva do…', ['latim', 'grego', 'árabe', 'fenício']],
      ['O que é a romanização?', ['a adoção da cultura e modo de vida romanos pelos povos conquistados', 'a destruição de Roma', 'a fundação de Roma', 'a conversão ao Islão']],
      ['Qual destas é uma cidade romana em Portugal?', ['Conímbriga', 'Guimarães medieval', 'Mértola islâmica', 'Sagres']],
      ['Os romanos chamavam ao Mediterrâneo "Mare Nostrum".', true],
      ['As construções para transportar água chamam-se…', ['aquedutos', 'termas', 'anfiteatros', 'fóruns']]
    ]
  },
  {
    id: 'hist7_cristianismo', t: 'Origem e expansão do Cristianismo',
    k: 'cristianismo,cristaos,jesus,jesus cristo,apostolos,perseguicoes,edito de milao,constantino,teodosio,religiao oficial,igreja,biblia,monoteismo cristao',
    ae: 'Explicar a origem e a expansão do Cristianismo no Império Romano.',
    r: [
      'O Cristianismo surgiu na Palestina, no século I, a partir dos ensinamentos de Jesus Cristo.',
      'É uma religião monoteísta que defende o amor ao próximo, a igualdade de todos perante Deus e a vida eterna.',
      'Expandiu-se pelo Império graças aos apóstolos (como S. Paulo), às estradas romanas e ao uso do latim e do grego.',
      'Os cristãos foram perseguidos porque recusavam prestar culto ao imperador e aos deuses romanos.',
      'Em 313, o imperador Constantino deu liberdade de culto aos cristãos (Édito de Milão).',
      'Em 380, com o imperador Teodósio, o Cristianismo tornou-se a religião oficial do Império.'
    ],
    q: [
      ['Onde surgiu o Cristianismo?', ['na Palestina', 'em Roma', 'na Grécia', 'no Egito']],
      ['Em que ano foi dada liberdade de culto aos cristãos (Édito de Milão)?', ['313', '380', '476', '27 a.C.']],
      ['Que imperador tornou o Cristianismo religião oficial do Império?', ['Teodósio', 'Constantino', 'Augusto', 'Nero']],
      ['Porque eram os cristãos perseguidos?', ['recusavam prestar culto ao imperador', 'não pagavam impostos', 'eram estrangeiros', 'falavam grego']],
      ['O Cristianismo é uma religião monoteísta.', true],
      ['As estradas romanas ajudaram a expansão do Cristianismo.', true]
    ]
  },
  {
    id: 'hist7_medieval', t: 'A Europa nos séculos VI a XII: invasões e sociedade senhorial',
    k: 'idade media,europa medieval,invasoes barbaras,barbaros,povos germanicos,queda do imperio romano,476,feudalismo,sociedade senhorial,senhorio,clero,nobreza,povo,servos,vassalagem,ordens sociais,mosteiros,igreja medieval,reinos barbaros,suevos,visigodos',
    ae: 'Explicar a queda do Império Romano do Ocidente e caracterizar a sociedade senhorial e o papel da Igreja na Europa dos séculos VI a XII.',
    r: [
      'Os povos germânicos ("bárbaros") invadiram o Império Romano do Ocidente, que caiu em 476 — início da Idade Média.',
      'Na Península Ibérica instalaram-se os Suevos e os Visigodos.',
      'A insegurança levou à ruralização e ao poder dos senhores da terra: sociedade senhorial (feudal).',
      'Sociedade de ordens: clero (os que rezam), nobreza (os que combatem) — ordens privilegiadas — e povo/terceiro estado (os que trabalham).',
      'Senhorio: terras de um senhor, divididas em reserva (cultivada pelos servos para o senhor) e mansos (entregues aos camponeses, que pagavam rendas e prestavam serviços).',
      'Relações de vassalagem: o vassalo jurava fidelidade e ajuda militar ao suserano, recebendo terras (feudo) e proteção.',
      'A Igreja tinha grande poder: dirigia a vida religiosa e cultural; os mosteiros guardavam e copiavam livros.'
    ],
    q: [
      ['Em que ano caiu o Império Romano do Ocidente?', ['476', '313', '711', '1143']],
      ['Que povos germânicos se fixaram na Península Ibérica?', ['Suevos e Visigodos', 'Hunos e Mongóis', 'Vikings e Saxões', 'Fenícios e Gregos']],
      ['Quais eram as ordens privilegiadas da sociedade medieval?', ['clero e nobreza', 'povo e clero', 'nobreza e povo', 'mercadores e artesãos']],
      ['Na sociedade medieval, "os que combatem" eram…', ['a nobreza', 'o clero', 'o povo', 'os servos']],
      ['A parte do senhorio cultivada diretamente para o senhor chamava-se…', ['reserva', 'manso', 'feudo', 'burgo']],
      ['O vassalo jurava fidelidade ao suserano em troca de terras e proteção.', true],
      ['Nos mosteiros medievais copiavam-se e guardavam-se livros.', true]
    ]
  },
  {
    id: 'hist7_islao', t: 'O Islão e a Península Ibérica',
    k: 'islao,islamismo,muculmanos,maome,meca,hegira,622,corao,alcorao,mesquita,al-andalus,mouros,711,reconquista,reconquista crista,heranca muculmana,astrolabio,algarismos arabes',
    ae: 'Caracterizar o Islão, a ocupação muçulmana da Península Ibérica e a Reconquista cristã; identificar a herança muçulmana.',
    r: [
      'O Islão nasceu na Península Arábica no século VII, com Maomé. Em 622 dá-se a Hégira (fuga de Meca para Medina) — início do calendário muçulmano.',
      'É uma religião monoteísta (Alá); o livro sagrado é o Corão; o templo é a mesquita.',
      'Em 711 os muçulmanos entraram na Península Ibérica e dominaram grande parte dela (Al-Andalus).',
      'Os cristãos que resistiram no norte (Astúrias) iniciaram a Reconquista cristã, que durou vários séculos.',
      'Herança muçulmana: palavras portuguesas começadas por "al" (alface, almofada, Algarve), técnicas agrícolas (nora, açude), novos produtos (laranja, arroz), algarismos árabes, conhecimentos de matemática, astronomia e medicina, e construções como em Mértola e Silves.'
    ],
    q: [
      ['Quem fundou o Islão?', ['Maomé', 'Jesus', 'Abraão', 'Constantino']],
      ['Como se chama o livro sagrado dos muçulmanos?', ['Corão', 'Bíblia', 'Torá', 'Código de Hamurabi']],
      ['Em que ano os muçulmanos entraram na Península Ibérica?', ['711', '622', '476', '1143']],
      ['O movimento cristão para recuperar os territórios ocupados pelos muçulmanos chama-se…', ['Reconquista', 'Romanização', 'Renascimento', 'Restauração']],
      ['A palavra "Algarve" tem origem árabe.', true],
      ['A Hégira (622) marca o início do calendário muçulmano.', true],
      ['Qual destes é um contributo muçulmano?', ['os algarismos que usamos', 'o latim', 'a democracia', 'o teatro grego']]
    ]
  },
  {
    id: 'hist7_portugal', t: 'Formação do reino de Portugal',
    k: 'formacao de portugal,formacao do reino,condado portucalense,d henrique,d teresa,d afonso henriques,sao mamede,1128,ourique,1139,tratado de zamora,1143,manifestis probatum,1179,primeiro rei,independencia de portugal',
    ae: 'Explicar a formação do Reino de Portugal no contexto da Reconquista.',
    r: [
      'No final do século XI, o rei de Leão e Castela, Afonso VI, entregou o Condado Portucalense ao conde D. Henrique, casado com D. Teresa.',
      'Após a morte de D. Henrique, D. Afonso Henriques venceu a mãe na Batalha de São Mamede (1128) e passou a governar o Condado.',
      'Depois da Batalha de Ourique (1139), passou a intitular-se rei.',
      'Em 1143, pelo Tratado de Zamora, o rei de Leão e Castela, Afonso VII, reconheceu-o como rei.',
      'Em 1179, o Papa Alexandre III reconheceu a independência de Portugal (bula Manifestis Probatum).',
      'D. Afonso Henriques alargou o território para sul, conquistando Santarém e Lisboa em 1147.'
    ],
    q: [
      ['A quem foi entregue o Condado Portucalense?', ['ao conde D. Henrique', 'a D. Afonso Henriques', 'a Viriato', 'a D. Dinis']],
      ['Em que batalha D. Afonso Henriques venceu a mãe, D. Teresa?', ['São Mamede', 'Ourique', 'Aljubarrota', 'Salado']],
      ['Em que ano foi assinado o Tratado de Zamora?', ['1143', '1128', '1139', '1179']],
      ['Em 1179, quem reconheceu a independência de Portugal?', ['o Papa', 'o rei de França', 'o imperador romano', 'o califa de Córdoba']],
      ['Em que ano D. Afonso Henriques conquistou Lisboa?', ['1147', '1143', '1249', '1385']],
      ['A formação de Portugal ocorreu no contexto da Reconquista cristã.', true]
    ]
  }
]);

// ============================================================= GEOGRAFIA
TEMAS(7, 'geo', [
  {
    id: 'geo7_mapas', t: 'Representações da superfície terrestre (mapas e escalas)',
    k: 'mapas,mapa,representacoes da terra,representacao,escala,escalas,escala numerica,escala grafica,projecoes cartograficas,projecao,legenda,planta,globo,fotografia aerea,imagem de satelite,orientacao,rosa dos ventos,paisagem',
    ae: 'Comparar representações da superfície terrestre (globo, mapas, plantas, fotografias aéreas e imagens de satélite) e usar escalas e a rosa dos ventos.',
    r: [
      'A Geografia estuda a interação entre as pessoas e o meio. A paisagem pode ser natural ou humanizada.',
      'O globo é a representação mais fiel da Terra, mas pouco prático. Os mapas são representações planas e reduzidas, por isso têm sempre deformações (projeções cartográficas).',
      'Elementos de um mapa: título, legenda, escala, orientação (rosa dos ventos/seta Norte) e fonte.',
      'Escala numérica: 1 : 50 000 significa que 1 cm no mapa = 50 000 cm (500 m) na realidade.',
      'Quanto maior o denominador, menor a escala e menos pormenor (1 : 1 000 000 é escala pequena; 1 : 1000 é escala grande).',
      'Rosa dos ventos: pontos cardeais (N, S, E, O), colaterais (NE, NO, SE, SO) e subcolaterais.'
    ],
    q: [
      ['Num mapa à escala 1 : 100 000, 2 cm correspondem a…', ['2 km', '200 m', '20 km', '100 km']],
      ['Qual destas escalas mostra mais pormenor?', ['1 : 1000', '1 : 100 000', '1 : 1 000 000', '1 : 50 000 000']],
      ['Qual é a representação mais fiel da Terra?', ['o globo', 'o planisfério', 'a planta', 'o mapa de estradas']],
      ['A parte do mapa que explica os símbolos usados é a…', ['legenda', 'escala', 'orientação', 'fonte']],
      ['Todos os mapas planos têm deformações.', true],
      ['Entre o Sul e o Oeste fica o…', ['Sudoeste', 'Sudeste', 'Noroeste', 'Nordeste']],
      ['Uma paisagem transformada pelo ser humano chama-se…', ['humanizada', 'natural', 'virgem', 'física']]
    ]
  },
  {
    id: 'geo7_coordenadas', t: 'Localização: coordenadas geográficas',
    k: 'coordenadas geograficas,coordenadas,latitude,longitude,equador,meridiano de greenwich,meridianos,paralelos,hemisferios,hemisferio norte,hemisferio sul,tropicos,tropico de cancer,tropico de capricornio,circulo polar,localizacao absoluta,localizacao relativa,gps',
    ae: 'Localizar lugares usando a localização relativa e a localização absoluta (latitude e longitude).',
    r: [
      'Localização relativa: em relação a outro lugar (ex.: Lisboa fica a sul do Porto). Localização absoluta: através das coordenadas geográficas.',
      'Paralelos: círculos paralelos ao Equador. O Equador (0°) divide a Terra nos hemisférios Norte e Sul.',
      'Meridianos: semicírculos que unem os polos. O Meridiano de Greenwich (0°) divide a Terra nos hemisférios Ocidental (Oeste) e Oriental (Este).',
      'Latitude: distância angular ao Equador — de 0° a 90° N ou S.',
      'Longitude: distância angular ao Meridiano de Greenwich — de 0° a 180° E ou O.',
      'Paralelos importantes: Trópico de Câncer (≈ 23° N), Trópico de Capricórnio (≈ 23° S), Círculo Polar Ártico (≈ 66° N) e Antártico (≈ 66° S).',
      'Portugal continental fica no hemisfério Norte e no hemisfério Ocidental (cerca de 37° a 42° N e 6° a 9° O).'
    ],
    q: [
      ['Que linha divide a Terra nos hemisférios Norte e Sul?', ['Equador', 'Meridiano de Greenwich', 'Trópico de Câncer', 'Círculo Polar Ártico']],
      ['A latitude varia entre…', ['0° e 90°', '0° e 180°', '0° e 360°', '−45° e 45°']],
      ['A longitude é medida a partir do…', ['Meridiano de Greenwich', 'Equador', 'Polo Norte', 'Trópico de Capricórnio']],
      ['Portugal continental situa-se nos hemisférios…', ['Norte e Ocidental', 'Sul e Oriental', 'Norte e Oriental', 'Sul e Ocidental']],
      ['O Trópico de Câncer fica no hemisfério…', ['Norte', 'Sul', 'Oriental', 'Ocidental']],
      ['"Lisboa fica a sul do Porto" é um exemplo de localização relativa.', true],
      ['Os meridianos unem os dois polos.', true]
    ]
  },
  {
    id: 'geo7_clima', t: 'Estado do tempo, clima e climogramas',
    k: 'estado do tempo,tempo atmosferico,clima,climas,elementos do clima,temperatura,precipitacao,amplitude termica,temperatura media,climograma,climogramas,termometro,pluviometro,humidade,pressao atmosferica,vento,fatores do clima,latitude e clima,altitude,continentalidade',
    ae: 'Distinguir estado do tempo de clima, calcular e interpretar elementos do clima (temperatura média, amplitude térmica, precipitação) e ler climogramas.',
    r: [
      'Estado do tempo: condições da atmosfera num local e momento (muda rapidamente). Clima: conjunto dos estados do tempo durante muitos anos (pelo menos 30).',
      'Elementos do clima: temperatura (termómetro, °C), precipitação (pluviómetro, mm), humidade, pressão atmosférica e vento.',
      'Temperatura média = soma das temperaturas : número de valores. Amplitude térmica = temperatura máxima − temperatura mínima.',
      'Climograma: gráfico com a temperatura (linha) e a precipitação (barras) de cada mês.',
      'Fatores do clima: latitude (quanto mais longe do Equador, mais frio), altitude (a temperatura desce cerca de 6 °C por cada 1000 m), proximidade do mar (amplitudes térmicas menores) e correntes marítimas.'
    ],
    q: [
      ['As condições da atmosfera num dado momento chamam-se…', ['estado do tempo', 'clima', 'relevo', 'bioma']],
      ['Com que instrumento se mede a precipitação?', ['pluviómetro', 'termómetro', 'barómetro', 'anemómetro']],
      ['Máxima de 28 °C e mínima de 12 °C. Qual é a amplitude térmica?', ['16 °C', '40 °C', '20 °C', '14 °C']],
      ['Num climograma, a precipitação é normalmente representada por…', ['barras', 'uma linha', 'setas', 'círculos']],
      ['Quanto maior a altitude, a temperatura…', ['diminui', 'aumenta', 'não varia', 'duplica']],
      ['Os lugares junto ao mar têm geralmente amplitudes térmicas menores do que os do interior.', true],
      ['Temperaturas de 10, 14 e 18 °C. Qual é a média?', ['14 °C', '42 °C', '8 °C', '18 °C']]
    ]
  },
  {
    id: 'geo7_biomas', t: 'Zonas climáticas e biomas',
    k: 'zonas climaticas,zonas termicas,climas quentes,climas temperados,climas frios,equatorial,tropical,desertico,mediterraneo,temperado maritimo,continental,polar,biomas,bioma,floresta equatorial,savana,deserto,floresta mediterranea,taiga,tundra,vegetacao natural',
    ae: 'Caracterizar os principais tipos de clima e as formações vegetais (biomas) associadas.',
    r: [
      'Zona quente (entre os trópicos), zonas temperadas (entre os trópicos e os círculos polares) e zonas frias (para lá dos círculos polares).',
      'Clima equatorial: quente e muito chuvoso todo o ano → floresta equatorial (densa, sempre verde; ex.: Amazónia).',
      'Clima tropical: quente com estação seca e estação húmida → savana (ervas altas e árvores dispersas).',
      'Clima desértico: muito seco, com grandes amplitudes térmicas diárias → deserto (vegetação escassa, catos).',
      'Clima mediterrâneo: verões quentes e secos, invernos suaves e chuvosos → floresta mediterrânea (sobreiros, azinheiras, oliveiras). É o clima da maior parte de Portugal.',
      'Clima temperado marítimo: chuvoso e amplitudes pequenas (floresta caducifólia); continental: invernos muito frios (taiga — coníferas).',
      'Clima polar: muito frio todo o ano → tundra (musgos e líquenes) e gelo.'
    ],
    q: [
      ['A floresta da Amazónia está associada ao clima…', ['equatorial', 'mediterrâneo', 'polar', 'desértico']],
      ['A savana está associada ao clima…', ['tropical', 'polar', 'temperado marítimo', 'mediterrâneo']],
      ['Que clima tem verões quentes e secos e invernos suaves e chuvosos?', ['mediterrâneo', 'equatorial', 'polar', 'tropical seco']],
      ['A vegetação com musgos e líquenes, nas regiões frias, chama-se…', ['tundra', 'taiga', 'savana', 'estepe']],
      ['O sobreiro é uma árvore típica da floresta…', ['mediterrânea', 'equatorial', 'taiga', 'tundra']],
      ['A zona quente fica entre os dois trópicos.', true],
      ['A taiga é formada sobretudo por…', ['coníferas (pinheiros e abetos)', 'palmeiras', 'catos', 'ervas altas']]
    ]
  },
  {
    id: 'geo7_relevo', t: 'Formas de relevo',
    k: 'relevo,formas de relevo,montanha,montanhas,planalto,planicie,planicies,vale,vales,colina,altitude,curvas de nivel,perfil topografico,cordilheira,evereste,relevo de portugal,relevo submarino,plataforma continental,fossa',
    ae: 'Identificar as principais formas de relevo e interpretar representações do relevo (curvas de nível, cores hipsométricas, perfis).',
    r: [
      'Montanha: elevação de grande altitude com vertentes inclinadas. Colina: elevação de pouca altitude com vertentes suaves.',
      'Planalto: superfície relativamente plana a altitude elevada. Planície: superfície plana a baixa altitude.',
      'Vale: depressão alongada entre elevações, geralmente percorrida por um rio (vale em V nas montanhas, em U se for glaciar).',
      'Altitude: distância vertical de um ponto ao nível médio das águas do mar.',
      'Curvas de nível: linhas que unem pontos com a mesma altitude; quanto mais juntas, mais inclinado é o terreno.',
      'O ponto mais alto do mundo é o monte Evereste (cerca de 8849 m), nos Himalaias.',
      'Relevo submarino: plataforma continental, talude, planície abissal, dorsais e fossas oceânicas.'
    ],
    q: [
      ['Uma superfície plana a baixa altitude chama-se…', ['planície', 'planalto', 'montanha', 'colina']],
      ['Uma superfície relativamente plana a grande altitude chama-se…', ['planalto', 'planície', 'vale', 'colina']],
      ['Curvas de nível muito juntas indicam um terreno…', ['muito inclinado', 'plano', 'submerso', 'com rios']],
      ['Qual é o ponto mais alto do mundo?', ['Evereste', 'Monte Branco', 'Kilimanjaro', 'Aconcágua']],
      ['A altitude mede-se a partir do…', ['nível médio das águas do mar', 'centro da Terra', 'ponto mais baixo do país', 'topo da montanha mais próxima']],
      ['Um vale é uma depressão entre elevações.', true],
      ['A zona do fundo oceânico junto aos continentes, pouco profunda, chama-se…', ['plataforma continental', 'fossa oceânica', 'dorsal', 'planície abissal']]
    ]
  },
  {
    id: 'geo7_rios', t: 'Rios e bacias hidrográficas',
    k: 'rios,rio,hidrografia,bacia hidrografica,bacias hidrograficas,nascente,foz,leito,margens,margem direita,margem esquerda,afluente,afluentes,caudal,regime,estuario,delta,cheias,curso superior,curso medio,curso inferior,rede hidrografica',
    ae: 'Caracterizar os elementos de um rio e de uma bacia hidrográfica e a ação erosiva dos rios.',
    r: [
      'Nascente: onde o rio nasce. Foz: onde desagua (no mar, num lago ou noutro rio).',
      'Margem direita e esquerda: definem-se olhando para jusante (no sentido em que a água corre).',
      'Afluente: rio que desagua noutro rio. Rede hidrográfica: rio principal e todos os seus afluentes.',
      'Bacia hidrográfica: área drenada por um rio e pelos seus afluentes.',
      'Caudal: quantidade de água que passa num ponto do rio por segundo (m³/s). Regime: variação do caudal ao longo do ano.',
      'Curso superior (erosão, vales em V), curso médio (transporte) e curso inferior (acumulação de sedimentos).',
      'Tipos de foz: estuário (foz larga em forma de funil, ex.: Tejo) e delta (acumulação de sedimentos em leque, ex.: Nilo).'
    ],
    q: [
      ['O local onde o rio desagua chama-se…', ['foz', 'nascente', 'leito', 'margem']],
      ['Um rio que desagua noutro rio é um…', ['afluente', 'estuário', 'delta', 'caudal']],
      ['A área drenada por um rio e pelos seus afluentes é a…', ['bacia hidrográfica', 'rede hidrográfica', 'margem', 'planície aluvial']],
      ['O caudal de um rio é…', ['a quantidade de água que passa num ponto por segundo', 'a largura do rio', 'a profundidade máxima', 'o comprimento total']],
      ['O rio Nilo termina num…', ['delta', 'estuário', 'lago', 'glaciar']],
      ['As margens de um rio definem-se olhando no sentido em que a água corre.', true],
      ['Em que curso do rio predomina a acumulação de sedimentos?', ['inferior', 'superior', 'médio', 'na nascente']]
    ]
  },
  {
    id: 'geo7_litoral', t: 'Dinâmica do litoral',
    k: 'litoral,costa,costas,dinamica do litoral,arribas,arriba,praias,praia,costa alta,costa baixa,cabo,baia,tombolo,restinga,erosao costeira,ondas,mares,ria,laguna,ria formosa,dunas,acao do mar',
    ae: 'Caracterizar as formas do litoral resultantes da ação erosiva e de acumulação do mar.',
    r: [
      'Costa alta (arribas — escarpas a pique sobre o mar) e costa baixa (praias e dunas).',
      'Erosão marinha: as ondas desgastam as arribas, formando grutas, arcos e leixões; as arribas recuam.',
      'Acumulação: formação de praias, restingas (faixas de areia) e tômbolos (ligam uma ilha ao continente, ex.: Peniche).',
      'Cabo: saliência da costa que entra pelo mar; baía: reentrância da costa.',
      'Laguna/ria: zona de água salgada separada do mar por cordões de areia (ex.: Ria Formosa, Ria de Aveiro).',
      'Ameaças: subida do nível do mar, construção na orla costeira e destruição de dunas → medidas: esporões, alimentação artificial de praias, proteção dunar.'
    ],
    q: [
      ['Uma escarpa a pique sobre o mar chama-se…', ['arriba', 'praia', 'duna', 'baía']],
      ['Uma reentrância da costa chama-se…', ['baía', 'cabo', 'arriba', 'tômbolo']],
      ['Um cordão de areia que liga uma antiga ilha ao continente é um…', ['tômbolo', 'delta', 'leixão', 'cabo']],
      ['A Ria Formosa fica no…', ['Algarve', 'Minho', 'Alentejo interior', 'Douro']],
      ['As ondas podem provocar o recuo das arribas.', true],
      ['Qual destas é uma medida de proteção do litoral?', ['proteção das dunas', 'construir na praia', 'retirar areia das praias', 'destruir esporões']]
    ]
  }
]);

// ============================================================= INGLÊS (A2)
TEMAS(7, 'ing', [
  {
    id: 'ing7_present', t: 'Present simple and present continuous',
    k: 'present simple,present continuous,presente simples,presente continuo,adverbs of frequency,always,usually,sometimes,never,does,doesnt,dont,ing',
    ae: 'Usar o present simple (rotinas e factos) e o present continuous (ações a decorrer), com advérbios de frequência.',
    r: [
      'Present simple: rotinas, hábitos e factos. He/she/it leva -s: She plays tennis. Negativa: I don\'t play / he doesn\'t play. Pergunta: Do you play? Does she play?',
      'Present continuous: ações a decorrer agora — am/is/are + verbo-ing: I am reading now.',
      'Expressões: present simple → every day, usually, on Mondays; present continuous → now, at the moment, look!',
      'Advérbios de frequência (antes do verbo principal, depois do to be): always, usually, often, sometimes, rarely, never. Ex.: She always walks to school; He is never late.',
      'Spelling: watch → watches; study → studies; run → running; make → making.'
    ],
    q: [
      ['She … to school every day.', ['walks', 'walk', 'is walking', 'walking']],
      ['Look! The children … in the garden.', ['are playing', 'play', 'plays', 'played']],
      ['He … like fish.', ['doesn\'t', 'don\'t', 'isn\'t', 'aren\'t']],
      ['… you speak English?', ['Do', 'Does', 'Are', 'Is']],
      ['Choose the correct sentence:', ['I am always happy.', 'I always am happy.', 'Always I am happy.', 'I am happy always never.']],
      ['What is the -ing form of "run"?', ['running', 'runing', 'runeing', 'runs']],
      ['"At the moment" is used with the present continuous.', true],
      ['My father … TV now.', ['is watching', 'watches', 'watch', 'watched']]
    ]
  },
  {
    id: 'ing7_past', t: 'Past simple (regular and irregular verbs)',
    k: 'past simple,passado em ingles,preterito em ingles,irregular verbs,verbos irregulares,regular verbs,was were,did,didnt,yesterday,last week,ago',
    ae: 'Usar o past simple de verbos regulares e irregulares e do verbo to be (was/were).',
    r: [
      'To be no passado: I/he/she/it was; you/we/they were.',
      'Verbos regulares: + -ed (play → played; stop → stopped; study → studied).',
      'Verbos irregulares têm formas próprias: go → went, see → saw, have → had, eat → ate, buy → bought, come → came, make → made, take → took, write → wrote.',
      'Negativa: didn\'t + infinitivo (I didn\'t go). Pergunta: Did + sujeito + infinitivo (Did you go?).',
      'Expressões de tempo: yesterday, last week/month/year, two days ago, in 2020.'
    ],
    q: [
      ['Yesterday I … to the cinema.', ['went', 'go', 'goes', 'gone']],
      ['They … at home last night.', ['were', 'was', 'are', 'be']],
      ['What is the past simple of "buy"?', ['bought', 'buyed', 'brought', 'buys']],
      ['She … watch TV yesterday.', ['didn\'t', 'doesn\'t', 'don\'t', 'wasn\'t']],
      ['… you see the match last Saturday?', ['Did', 'Do', 'Were', 'Does']],
      ['What is the past simple of "study"?', ['studied', 'studyed', 'studed', 'studies']],
      ['"Ago" is used with the past simple: "two years ago".', true],
      ['What is the past simple of "write"?', ['wrote', 'writed', 'written', 'writ']]
    ]
  },
  {
    id: 'ing7_compar', t: 'Comparatives and superlatives',
    k: 'comparatives,comparativos,superlatives,superlativos,taller than,the tallest,more than,the most,better,best,worse,worst,as as',
    ae: 'Comparar pessoas, lugares e objetos usando comparativos e superlativos.',
    r: [
      'Adjetivos curtos: + -er / the + -est (tall → taller → the tallest; big → bigger → the biggest; happy → happier → the happiest).',
      'Adjetivos longos: more / the most (beautiful → more beautiful → the most beautiful).',
      'Irregulares: good → better → the best; bad → worse → the worst; far → farther/further → the farthest.',
      'Comparativo usa "than": My brother is taller than me.',
      'Igualdade: as … as (She is as tall as her mother).'
    ],
    q: [
      ['An elephant is … than a dog.', ['bigger', 'big', 'biggest', 'more big']],
      ['This is … film I have ever seen.', ['the best', 'the better', 'the goodest', 'best than']],
      ['Maths is … difficult than English.', ['more', 'most', 'the most', 'much']],
      ['What is the superlative of "bad"?', ['the worst', 'the baddest', 'the worse', 'the most bad']],
      ['What is the comparative of "happy"?', ['happier', 'happyer', 'more happy', 'happiest']],
      ['"She is as tall as her sister" means they have the same height.', true],
      ['Everest is … mountain in the world.', ['the highest', 'the higher', 'higher', 'the most high']]
    ]
  },
  {
    id: 'ing7_future', t: 'Future: going to and will; modals',
    k: 'future,futuro em ingles,going to,will,wont,modal verbs,must,mustnt,should,can,could,have to,plans,predictions',
    ae: 'Falar de planos e previsões (going to, will) e usar verbos modais (can, must, should, have to).',
    r: [
      'Going to: planos e intenções (I\'m going to visit my grandma next weekend) e previsões com evidência (Look at the clouds! It\'s going to rain).',
      'Will: decisões no momento, promessas e previsões gerais (I think it will be sunny tomorrow; I\'ll help you!). Negativa: won\'t.',
      'Can/can\'t: capacidade e permissão. Could: capacidade no passado ou pedido educado.',
      'Must/mustn\'t: obrigação forte e proibição (You mustn\'t use your phone in class).',
      'Should/shouldn\'t: conselhos (You should drink more water).',
      'Have to/don\'t have to: obrigação externa / ausência de obrigação.'
    ],
    q: [
      ['Look at those clouds! It … rain.', ['is going to', 'will to', 'goes', 'must']],
      ['I think people … live on Mars one day.', ['will', 'are going', 'must', 'did']],
      ['You … run in the corridors. It\'s dangerous!', ['mustn\'t', 'should', 'can', 'have to']],
      ['You look tired. You … go to bed early.', ['should', 'mustn\'t', 'won\'t', 'didn\'t']],
      ['"You don\'t have to come" means…', ['não és obrigado a vir', 'estás proibido de vir', 'tens de vir', 'vieste ontem']],
      ['"Won\'t" is the short form of "will not".', true],
      ['When I was five, I … swim.', ['could', 'can', 'will', 'must']]
    ]
  },
  {
    id: 'ing7_vocab', t: 'Vocabulary: school, free time, food and places',
    k: 'vocabulary,vocabulario ingles 7,school subjects,disciplinas em ingles,free time,hobbies,food and drink,places in town,lugares na cidade,there is there are,some any,much many,countable uncountable',
    ae: 'Usar vocabulário sobre escola, tempos livres, alimentação e a cidade; usar some/any e much/many.',
    r: [
      'School subjects: Maths, Portuguese, History, Geography, Science, Physics and Chemistry, PE (Educação Física), ICT (TIC), Art.',
      'Free time: play football, ride a bike, go swimming, listen to music, watch films, read books, play video games.',
      'Places in town: library, post office, chemist\'s (farmácia), bakery, hospital, museum, train station, shopping centre.',
      'Some (frases afirmativas) / any (negativas e perguntas): There is some milk; Are there any apples?',
      'Countable (contáveis: apples) → many / how many; uncountable (não contáveis: water, bread, money) → much / how much.'
    ],
    q: [
      ['"Farmácia" in English (British) is…', ['chemist\'s', 'library', 'bakery', 'bookshop']],
      ['"Library" significa…', ['biblioteca', 'livraria', 'laboratório', 'liberdade']],
      ['How … water do you drink a day?', ['much', 'many', 'any', 'some']],
      ['How … apples are there?', ['many', 'much', 'any', 'a']],
      ['Are there … biscuits left?', ['any', 'some', 'much', 'a']],
      ['"PE" is the school subject Physical Education.', true],
      ['"Bread" is a countable noun.', false, 'É não contável: some bread, a loaf of bread.']
    ]
  }
]);
