/* Mais conteúdo para o 3.º ano: temas novos (Português, Matemática, Estudo do Meio e
   Inglês) e mais perguntas nos temas que tinham menos, escritos a partir das
   Aprendizagens Essenciais (DGE) em vigor para o 1.º ciclo. */

// ================================================================ TEMAS NOVOS — 3.º ANO
TEMAS(3, 'pt', [
  {
    id: 'pt3_verbos', t: 'Tempos verbais: presente, pretérito e futuro',
    k: 'verbos,tempo verbal,tempos verbais,presente,preterito perfeito,futuro,infinitivo,conjugacao,primeira conjugacao,segunda conjugacao,terceira conjugacao',
    ae: 'Conjugar verbos regulares no presente, no pretérito perfeito e no futuro do indicativo, reconhecendo a ação no tempo certo.',
    r: [
      'O verbo no presente indica uma ação que acontece agora: Eu como uma maçã.',
      'O verbo no pretérito perfeito indica uma ação já terminada: Eu comi uma maçã ontem.',
      'O verbo no futuro indica uma ação que ainda vai acontecer: Eu vou comer / comerei uma maçã amanhã.',
      'O infinitivo é a forma "não conjugada" do verbo, a que aparece no dicionário: comer, saltar, partir.',
      'Os verbos regulares dividem-se em três grupos, conforme terminam em -ar (cantar), -er (comer) ou -ir (partir).'
    ],
    q: [
      ['"Eu brinco no parque." O verbo está no…', ['presente', 'pretérito perfeito', 'futuro', 'infinitivo']],
      ['"Ontem joguei à bola." O verbo está no…', ['pretérito perfeito', 'presente', 'futuro', 'infinitivo']],
      ['"Amanhã vou nadar na piscina." O verbo está no…', ['futuro', 'presente', 'pretérito perfeito', 'infinitivo']],
      ['Qual é o infinitivo do verbo em "ela canta"?', ['cantar', 'cantei', 'cantará', 'canto']],
      ['Os verbos terminados em "-er" pertencem ao…', ['2.º grupo', '1.º grupo', '3.º grupo', 'não há grupos']],
      ['"Nós comemos bolo." indica uma ação…', ['presente', 'passada', 'futura', 'que nunca aconteceu']],
      ['O infinitivo de um verbo é a forma que aparece no…', ['dicionário', 'jornal', 'caderno diário', 'calendário']],
      ['"Eles vão chegar tarde." indica uma ação do futuro.', true]
    ]
  },
  {
    id: 'pt3_leitura', t: 'Ideia principal, resumo e opinião sobre um texto',
    k: 'compreensao da leitura,ideia principal,resumo,resumir,opiniao sobre o texto,assunto do texto,titulo do texto,ler com atencao',
    ae: 'Identificar o assunto e a ideia principal de um texto, resumir a informação e exprimir uma opinião fundamentada sobre o que leu.',
    r: [
      'A ideia principal é o que o texto quer transmitir — muitas vezes dá para perceber logo no início ou pelo título.',
      'Resumir um texto é contar o essencial, por palavras próprias, sem copiar frase a frase.',
      'O título costuma dar uma pista sobre o assunto do texto.',
      'Dar uma opinião sobre um texto é dizer o que achámos dele e explicar porquê.',
      'Antes de responder a perguntas sobre um texto, deve ler-se o texto com atenção, mais do que uma vez se for preciso.'
    ],
    q: [
      ['O que é a "ideia principal" de um texto?', ['o que o texto quer transmitir', 'o título em letras grandes', 'o número de parágrafos', 'o nome do autor']],
      ['Resumir um texto é…', ['contar o essencial por palavras próprias', 'copiar o texto todo', 'só ler o título', 'desenhar uma imagem']],
      ['Antes de responder a perguntas sobre um texto, deve-se…', ['ler o texto com atenção', 'adivinhar as respostas', 'ler só o título', 'perguntar sempre a um colega']],
      ['Dar uma opinião sobre um texto é…', ['dizer o que achámos e explicar porquê', 'copiar a opinião do professor', 'não dizer nada', 'resumir o texto']],
      ['O título de um texto costuma dar uma pista sobre…', ['o assunto do texto', 'o autor', 'a data', 'o preço do livro']],
      ['Um resumo deve copiar o texto frase a frase.', false, 'Um resumo conta o essencial por palavras próprias, sem copiar tudo.'],
      ['Para perceber bem um texto, pode ser preciso lê-lo mais do que uma vez.', true]
    ]
  }
]);

TEMAS(3, 'mat', [
  {
    id: 'mat3_problemas', t: 'Problemas com uma e duas operações',
    k: 'problemas,situacoes problematicas,resolver problemas,enunciado,dados do problema,pergunta do problema,estrategias de calculo',
    ae: 'Resolver problemas de um ou dois passos envolvendo as quatro operações, em contextos do dia a dia.',
    r: [
      'Para resolver um problema: ler com atenção, perceber os dados, decidir a operação (ou operações) e calcular.',
      'Palavras como "ao todo" e "juntos" costumam indicar uma adição; "ficou com" e "a menos" costumam indicar uma subtração.',
      'Palavras como "cada" e "vezes" costumam indicar uma multiplicação; "repartir" e "por igual" costumam indicar uma divisão.',
      'Alguns problemas precisam de duas operações seguidas para se chegar à resposta.',
      'No fim, é bom verificar se a resposta faz sentido para a pergunta do problema.'
    ],
    q: [
      ['A Inês tinha 15 cromos e comprou mais 8. Com quantos cromos ficou?', ['23', '7', '120', '17']],
      ['O Pedro tinha 30€ e gastou 12€ num livro. Quanto dinheiro lhe sobrou?', ['18€', '42€', '12€', '20€']],
      ['Numa caixa cabem 6 ovos. Quantos ovos cabem em 4 caixas?', ['24', '10', '20', '30']],
      ['24 rebuçados foram repartidos por igual entre 6 amigos. Quantos recebeu cada um?', ['4', '6', '18', '30']],
      ['A Maria comprou 3 pacotes de bolachas, com 8 bolachas cada, e depois comeu 5. Quantas bolachas lhe ficaram?', ['19', '24', '13', '29']],
      ['Que palavra sugere uma multiplicação num problema?', ['cada', 'ficou com', 'a menos', 'sobrou']],
      ['Antes de calcular um problema, o mais importante é…', ['perceber bem os dados e a pergunta', 'escrever bonito', 'usar sempre a calculadora', 'adivinhar o resultado']]
    ]
  },
  {
    id: 'mat3_sequencias', t: 'Sequências, padrões e regularidades',
    k: 'sequencias,sequencia,padroes,padrao,regularidades,termo seguinte,regra da sequencia,numeros em sequencia',
    ae: 'Identificar, descrever e continuar sequências e padrões numéricos e geométricos, descobrindo a regra.',
    r: [
      'Uma sequência é um conjunto de números ou figuras organizados segundo uma regra.',
      'Na sequência 2, 4, 6, 8…, a regra é "soma 2" a cada termo.',
      'Na sequência 5, 10, 15, 20…, a regra é "soma 5".',
      'Um padrão geométrico repete uma figura ou um grupo de figuras: ⭐🔺⭐🔺⭐🔺…',
      'Para descobrir a regra de uma sequência, compara-se cada termo com o anterior.'
    ],
    q: [
      ['Qual é o termo seguinte: 3, 6, 9, 12, …?', ['15', '13', '14', '18']],
      ['Qual é a regra da sequência 10, 20, 30, 40…?', ['soma 10', 'soma 5', 'multiplica por 2', 'soma 20']],
      ['Na sequência ⭐🔺⭐🔺⭐…, qual é a figura seguinte?', ['🔺', '⭐', '⬛', 'nenhuma']],
      ['Qual é o termo que falta: 2, 4, __, 8, 10?', ['6', '5', '7', '9']],
      ['Na sequência 20, 17, 14, 11…, a regra é…', ['subtrai 3', 'soma 3', 'subtrai 2', 'multiplica por 3']],
      ['Numa sequência, para descobrir a regra compara-se cada termo com…', ['o termo anterior', 'só o primeiro termo', 'só o último termo', 'nada, é só sorte']],
      ['Qual é o termo seguinte: 1, 2, 4, 8, …?', ['16', '10', '12', '9']]
    ]
  }
]);

TEMAS(3, 'em', [
  {
    id: 'em3_portugal', t: 'Portugal: o território e os símbolos nacionais',
    k: 'portugal,territorio portugues,continente e ilhas,acores,madeira,bandeira de portugal,hino nacional,simbolos nacionais,capital de portugal,paises vizinhos,espanha,peninsula iberica',
    ae: 'Localizar Portugal no mapa (Península Ibérica, Europa), identificar o seu território (continente e ilhas) e os símbolos nacionais.',
    r: [
      'Portugal fica na Europa, na Península Ibérica, faz fronteira com Espanha e é banhado pelo oceano Atlântico.',
      'O território português tem uma parte continental e duas regiões autónomas insulares: os Açores e a Madeira.',
      'A capital de Portugal é Lisboa.',
      'A bandeira de Portugal tem as cores verde e vermelha, com o escudo e a esfera armilar ao centro.',
      'O hino nacional português chama-se "A Portuguesa".',
      'Portugal é um dos países mais antigos da Europa, com fronteiras praticamente inalteradas há séculos.'
    ],
    q: [
      ['Qual é a capital de Portugal?', ['Lisboa', 'Porto', 'Coimbra', 'Faro']],
      ['Portugal faz fronteira terrestre com…', ['Espanha', 'França', 'Marrocos', 'Itália']],
      ['Que oceano banha Portugal?', ['Atlântico', 'Pacífico', 'Índico', 'Glaciar Ártico']],
      ['Quais são as duas regiões autónomas de Portugal?', ['Açores e Madeira', 'Algarve e Alentejo', 'Porto e Lisboa', 'Minho e Douro']],
      ['Como se chama o hino nacional português?', ['A Portuguesa', 'Hino à Alegria', 'Grândola, Vila Morena', 'Ave Maria']],
      ['A bandeira de Portugal tem as cores…', ['verde e vermelha', 'azul e branca', 'amarela e preta', 'roxa e dourada']],
      ['Portugal situa-se na Península…', ['Ibérica', 'Balcânica', 'Escandinava', 'Itálica']]
    ]
  }
]);

TEMAS(3, 'ing', [
  {
    id: 'ing3_animals', t: 'Wild animals, farm animals and "can"',
    k: 'wild animals,animais selvagens em ingles,farm animals,animais da quinta em ingles,can,cant,abilities,jump,run,swim,fly,climb',
    ae: 'Identificar animais selvagens e da quinta em inglês e usar "can/can\'t" para descrever capacidades.',
    r: [
      'Farm animals: cow (vaca), pig (porco), sheep (ovelha), horse (cavalo), hen (galinha), duck (pato).',
      'Wild animals: lion (leão), elephant (elefante), monkey (macaco), tiger (tigre), giraffe (girafa), zebra, snake (cobra).',
      'Can (consegue) / can\'t (não consegue): A fish can swim. A fish can\'t fly.',
      'A monkey can climb. A bird can fly. A horse can run fast.',
      'Action verbs: jump (saltar), run (correr), swim (nadar), fly (voar), climb (trepar), walk (andar).'
    ],
    q: [
      ['"Cow" significa…', ['vaca', 'porco', 'ovelha', 'cavalo']],
      ['"Monkey" significa…', ['macaco', 'leão', 'elefante', 'tigre']],
      ['"A fish can swim." "Can" significa…', ['consegue', 'não consegue', 'gosta', 'tem']],
      ['"A bird can fly." significa…', ['Um pássaro consegue voar.', 'Um pássaro não consegue voar.', 'Um pássaro gosta de nadar.', 'Um pássaro tem asas pequenas.']],
      ['"Sheep" significa…', ['ovelha', 'porco', 'galinha', 'pato']],
      ['A fish can\'t fly.', true],
      ['"Elephant" significa…', ['elefante', 'zebra', 'girafa', 'cobra']]
    ]
  },
  {
    id: 'ing3_feelings', t: 'Feelings and daily routine',
    k: 'feelings,sentimentos em ingles,happy,sad,tired,hungry,daily routine,rotina diaria em ingles,get up,go to bed,brush your teeth',
    ae: 'Identificar sentimentos simples e expressões da rotina diária em inglês.',
    r: [
      'Feelings: happy (feliz), sad (triste), tired (cansado), hungry (com fome), thirsty (com sede), scared (assustado).',
      'How are you feeling? — I\'m happy! / I\'m tired.',
      'Daily routine: get up (levantar-se), have breakfast (tomar o pequeno-almoço), go to school, have lunch, do homework, go to bed (ir para a cama).',
      'Brush your teeth! (Lava os dentes!) Wash your hands! (Lava as mãos!)',
      'What time do you get up? — I get up at seven o\'clock.'
    ],
    q: [
      ['"Happy" significa…', ['feliz', 'triste', 'cansado', 'com fome']],
      ['"Tired" significa…', ['cansado', 'feliz', 'assustado', 'com sede']],
      ['"Get up" significa…', ['levantar-se', 'ir para a cama', 'tomar o pequeno-almoço', 'lavar os dentes']],
      ['"Brush your teeth!" significa…', ['Lava os dentes!', 'Lava as mãos!', 'Vai dormir!', 'Come a sopa!']],
      ['"I\'m hungry" significa…', ['Tenho fome.', 'Tenho sede.', 'Estou cansado.', 'Estou feliz.']],
      ['"Go to bed" significa ir para a cama.', true],
      ['"Scared" significa…', ['assustado', 'feliz', 'triste', 'com sede']]
    ]
  }
]);

// ================================================================ MAIS PERGUNTAS NOS TEMAS COM MENOS
(function () {
  const MAIS = {
    pt3_flexao: [
      ['Qual é o feminino de "homem"?', ['mulher', 'homema', 'homenzinha', 'homens']],
      ['Qual é o plural de "pão"?', ['pães', 'pãos', 'pãoes', 'pões']],
      ['Qual é o aumentativo de "cão"?', ['cãozarrão', 'cãozinho', 'canzito', 'cão pequeno']]
    ],
    pt3_silabas: [
      ['Quantas sílabas tem "lâmpada"?', ['três', 'duas', 'quatro', 'uma']],
      ['Qual é a sílaba tónica de "âncora"?', ['ân', 'co', 'ra', 'nenhuma']],
      ['Em "carro", as duas letras "rr" ficam…', ['na mesma sílaba', 'em sílabas diferentes', 'não se separam nunca', 'no início da palavra']]
    ],
    pt3_palavras: [
      ['Qual é o sinónimo de "rápido"?', ['veloz', 'lento', 'grande', 'pequeno']],
      ['Qual é o antónimo de "cheio"?', ['vazio', 'grande', 'pesado', 'novo']],
      ['Qual destas palavras vem depois de "gato" na ordem alfabética?', ['girafa', 'elefante', 'abelha', 'cão']]
    ],
    pt3_ortografia: [
      ['Qual palavra está bem escrita?', ['açúcar', 'asucar', 'açucar', 'asúcar']],
      ['Como se escreve o animal que mia?', ['gato', 'gatto', 'ghato', 'gatho']],
      ['Antes de "a", "o" e "u" usa-se…', ['ç', 's', 'ss', 'x']]
    ],
    mat3_divisao: [
      ['Quanto é 36 : 6?', ['6', '9', '30', '42']],
      ['Qual é a quarta parte de 20?', ['5', '4', '10', '15']],
      ['Se 7 × 3 = 21, então 21 : 7 = …', ['3', '7', '14', '28']]
    ],
    mat3_fracoes: [
      ['Quanto é um quinto de 20?', ['4', '5', '10', '15']],
      ['Qual é menor: 1/5 ou 1/3?', ['1/5', '1/3', 'são iguais', 'não se pode saber']],
      ['Quantos décimos tem uma unidade?', ['10', '5', '4', '100']]
    ],
    mat3_medida: [
      ['Quantos metros tem 1 quilómetro?', ['1000', '100', '10', '10 000']],
      ['Qual é a unidade mais adequada para medir a água de uma piscina?', ['litro', 'grama', 'centímetro', 'quilómetro']],
      ['Um saco de arroz tem 1 kg. Quantos gramas são?', ['1000', '100', '10', '500']]
    ],
    mat3_tempo: [
      ['Quantos minutos tem um quarto de hora?', ['15', '30', '45', '60']],
      ['Quantos dias tem o mês de fevereiro num ano normal (não bissexto)?', ['28', '29', '30', '31']],
      ['Compraste um livro de 8,50 € e pagaste com uma nota de 10 €. Qual é o troco?', ['1,50 €', '2 €', '1 €', '0,50 €']]
    ]
  };
  Object.keys(MAIS).forEach((id) => {
    const t = CUR.temas[id];
    if (t) MAIS[id].forEach((q) => t.q.push(q));
  });
})();
