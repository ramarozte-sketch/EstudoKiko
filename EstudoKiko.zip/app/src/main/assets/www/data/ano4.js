/* 4.º ano — 1.º ciclo do ensino básico (Aprendizagens Essenciais em vigor 2026/2027) */

// ============================================================= PORTUGUÊS
TEMAS(4, 'pt', [
  {
    id: 'pt4_classes', t: 'Classes de palavras',
    k: 'classes de palavras,classe de palavras,nomes,nome,adjetivo,adjetivos,determinante,determinantes,pronome,pronomes,adverbio,adverbios,preposicao,preposicoes,interjeicao',
    ae: 'Identificar nomes, adjetivos, verbos, determinantes, pronomes pessoais, quantificadores numerais, advérbios, preposições e interjeições.',
    r: [
      'Nome: dá nome a pessoas, animais, coisas, lugares e sentimentos. Pode ser próprio (Lisboa, Rita — com maiúscula), comum (cão, mesa) ou coletivo (cardume, rebanho, multidão).',
      'Adjetivo qualificativo: diz como é o nome (bonito, alto, azul). Adjetivo numeral: indica a ordem (primeiro, segundo, décimo).',
      'Verbo: indica ações, estados ou fenómenos da natureza (correr, ser, estar, chover).',
      'Determinantes: artigos definidos (o, a, os, as) e indefinidos (um, uma, uns, umas); possessivos (meu, teu, seu, nosso…) e demonstrativos (este, esse, aquele…).',
      'Pronome pessoal: substitui o nome (eu, tu, ele, ela, nós, vós, eles, elas).',
      'Quantificador numeral: indica uma quantidade exata (dois, dez, cem).',
      'Advérbio: dá informação sobre o verbo — de lugar (aqui, lá), de tempo (ontem, hoje, amanhã), de modo (bem, mal, depressa), de negação (não) e de afirmação (sim).',
      'Preposição: liga palavras (a, de, em, para, por, com, sem, até…). Pode juntar-se ao determinante: de + o = do; em + a = na; a + a = à.',
      'Interjeição: exprime emoções ou sensações (Oh! Ai! Viva! Olá!).'
    ],
    q: [
      ['Na frase "O gato preto dorme.", qual é o adjetivo?', ['preto', 'gato', 'dorme', 'O']],
      ['"Cardume" é um nome…', ['coletivo', 'próprio', 'adjetivo', 'verbo'], 'Nome coletivo designa um conjunto: cardume é um conjunto de peixes.'],
      ['Qual destas palavras é um nome próprio?', ['Porto', 'cidade', 'rio', 'bonito']],
      ['Em "Eu gosto de maçãs.", a palavra "Eu" é…', ['um pronome pessoal', 'um determinante', 'um nome', 'um advérbio']],
      ['Qual destas palavras é um determinante artigo indefinido?', ['uma', 'a', 'esta', 'minha']],
      ['Em "Ontem choveu muito.", a palavra "ontem" é um advérbio de…', ['tempo', 'lugar', 'modo', 'negação']],
      ['Em "Comprei três livros.", "três" é um…', ['quantificador numeral', 'adjetivo numeral', 'determinante possessivo', 'advérbio'], 'Indica uma quantidade exata.'],
      ['Em "Fiquei em primeiro lugar.", "primeiro" é um…', ['adjetivo numeral', 'quantificador numeral', 'advérbio', 'nome'], 'Indica a ordem.'],
      ['Qual destas palavras é um verbo?', ['saltar', 'alegria', 'alto', 'depressa']],
      ['"Do" resulta da contração da preposição "de" com…', ['o determinante "o"', 'o pronome "eu"', 'o verbo "dar"', 'o advérbio "onde"']],
      ['"Meu", "teu" e "seu" são determinantes…', ['possessivos', 'demonstrativos', 'artigos definidos', 'indefinidos']],
      ['"Ai!" é uma interjeição.', true],
      ['"Aquele" é um determinante demonstrativo.', true],
      ['Em "O Rui corre depressa.", "depressa" é um advérbio de…', ['modo', 'tempo', 'lugar', 'afirmação']]
    ]
  },
  {
    id: 'pt4_verbos', t: 'Verbos: conjugações e tempos',
    k: 'verbos,verbo,tempos verbais,conjugacao,conjugacoes,conjugar,presente,preterito,preterito perfeito,preterito imperfeito,futuro,imperativo,infinitivo',
    ae: 'Conjugar verbos regulares e irregulares no presente, pretérito perfeito, pretérito imperfeito e futuro do indicativo e no imperativo.',
    r: [
      'No infinitivo, os verbos terminam em -ar (1.ª conjugação: cantar), -er (2.ª conjugação: comer) ou -ir (3.ª conjugação: partir). O verbo pôr pertence à 2.ª conjugação.',
      'Os verbos variam em pessoa e número: eu, tu, ele/ela (singular); nós, vós, eles/elas (plural).',
      'Presente do indicativo: o que acontece agora ou habitualmente (eu canto, tu comes).',
      'Pretérito perfeito: ação passada e terminada (ontem eu cantei, ele comeu).',
      'Pretérito imperfeito: ação passada que se repetia ou durava (antigamente eu cantava, nós comíamos).',
      'Futuro: ação que vai acontecer (amanhã eu cantarei, eles partirão).',
      'Imperativo: serve para dar ordens, pedidos ou conselhos (Canta! Come a sopa! Fecha a porta!).',
      'Verbos irregulares mudam a forma: ser (sou, és, é), ir (vou, vais, vai), ter (tenho), fazer (faço, fiz), dizer (digo, disse).',
      'Atenção: nós cantamos (presente) e nós cantámos (pretérito perfeito).'
    ],
    q: [
      ['Em que conjugação está o verbo "beber"?', ['2.ª conjugação', '1.ª conjugação', '3.ª conjugação', 'não tem conjugação'], 'Termina em -er.'],
      ['"Ontem eu brinquei no parque." O verbo está no…', ['pretérito perfeito', 'presente', 'futuro', 'pretérito imperfeito']],
      ['"Quando era pequeno, eu brincava muito." "Brincava" está no…', ['pretérito imperfeito', 'pretérito perfeito', 'futuro', 'presente']],
      ['Qual é o futuro de "nós cantar"?', ['nós cantaremos', 'nós cantámos', 'nós cantávamos', 'nós cantamos']],
      ['"Fecha a janela!" Em que modo está o verbo?', ['imperativo', 'indicativo', 'infinitivo', 'é um nome']],
      ['Qual é a 1.ª pessoa do singular do presente do verbo "ser"?', ['eu sou', 'eu é', 'eu fui', 'eu era']],
      ['"Eles partem amanhã." Em que pessoa está o verbo?', ['3.ª pessoa do plural', '1.ª pessoa do plural', '3.ª pessoa do singular', '2.ª pessoa do plural']],
      ['O verbo "pôr" pertence à 2.ª conjugação.', true],
      ['Pretérito perfeito do verbo "fazer" na 1.ª pessoa do singular:', ['eu fiz', 'eu fazi', 'eu fazia', 'eu farei']],
      ['Qual destas formas está no presente do indicativo?', ['tu corres', 'tu correste', 'tu corrias', 'tu correrás']],
      ['"Nós chegámos tarde." Em que tempo está o verbo?', ['pretérito perfeito', 'presente', 'futuro', 'imperativo'], 'Chegamos (presente) / chegámos (pretérito perfeito).'],
      ['Qual é o infinitivo de "fui"?', ['ir ou ser', 'fugir', 'fazer', 'ficar'], '"Fui" pode ser do verbo ir (fui à escola) ou do verbo ser (fui o primeiro).'],
      ['"Partir" é um verbo da 3.ª conjugação.', true]
    ]
  },
  {
    id: 'pt4_flexao', t: 'Género, número e grau',
    k: 'genero,numero,grau,feminino,masculino,plural,singular,diminutivo,aumentativo,superlativo,comparativo,flexao,grau dos adjetivos',
    ae: 'Flexionar nomes e adjetivos em género, número e grau.',
    r: [
      'Género: masculino (o menino, o leão) e feminino (a menina, a leoa). Alguns nomes mudam de palavra: cavalo → égua, homem → mulher, bode → cabra, pai → mãe.',
      'Número: singular (um) e plural (vários). Regra geral junta-se -s: casa → casas.',
      'Palavras em -ão: balão → balões, pão → pães, mão → mãos. Em -l: animal → animais, papel → papéis. Em -r, -z: flor → flores, luz → luzes.',
      'Grau dos nomes: aumentativo (casarão, gatão) e diminutivo (casinha, gatinho).',
      'Grau dos adjetivos: normal (alto); comparativo de superioridade (mais alto do que), de igualdade (tão alto como) e de inferioridade (menos alto do que); superlativo (o mais alto; muito alto; altíssimo).',
      'Formas especiais: bom → melhor → ótimo; mau → pior → péssimo; grande → maior → máximo; pequeno → menor → mínimo.'
    ],
    q: [
      ['Qual é o feminino de "cavalo"?', ['égua', 'cavala', 'cavalinha', 'cavalona']],
      ['Qual é o plural de "pão"?', ['pães', 'pãos', 'pões', 'pãoes']],
      ['Qual é o plural de "papel"?', ['papéis', 'papeles', 'papels', 'papéles']],
      ['Qual é o plural de "flor"?', ['flores', 'flors', 'floris', 'flôres']],
      ['Qual é o diminutivo de "casa"?', ['casinha', 'casarão', 'casas', 'caseiro']],
      ['"O João é tão alto como o Pedro." O adjetivo está no grau…', ['comparativo de igualdade', 'comparativo de superioridade', 'superlativo', 'normal']],
      ['"Ótima" é o superlativo de…', ['boa', 'má', 'grande', 'pequena']],
      ['Qual é o feminino de "leão"?', ['leoa', 'leã', 'leona', 'leãzinha']],
      ['Qual é o plural de "mão"?', ['mãos', 'mães', 'mões', 'mãoes']],
      ['"Facílimo" é um superlativo de "fácil".', true],
      ['O aumentativo de "gato" é "gatinho".', false, 'Gatinho é diminutivo; o aumentativo é gatão.'],
      ['"A Ana é mais rápida do que a Inês." O adjetivo está no grau…', ['comparativo de superioridade', 'comparativo de inferioridade', 'superlativo', 'normal']],
      ['Qual é o plural de "animal"?', ['animais', 'animales', 'animals', 'animaes']]
    ]
  },
  {
    id: 'pt4_silabas', t: 'Sílabas e acentuação',
    k: 'silabas,silaba,silaba tonica,acentuacao,acento,acentos,agudas,graves,esdruxulas,divisao silabica,monossilabo,monossilabas,palavras agudas',
    ae: 'Dividir palavras em sílabas, identificar a sílaba tónica e classificar palavras quanto ao número de sílabas e à posição da sílaba tónica.',
    r: [
      'Pelo número de sílabas: monossílabas (pão), dissílabas (ca-sa), trissílabas (ja-ne-la) e polissílabas (bor-bo-le-ta).',
      'A sílaba tónica é a que se pronuncia com mais força.',
      'Palavras agudas: a sílaba tónica é a última (ca-fé, pa-pel). Graves: é a penúltima (me-sa, li-vro). Esdrúxulas: é a antepenúltima (lâm-pa-da, mú-si-ca).',
      'Todas as palavras esdrúxulas têm acento gráfico.',
      'Sinais gráficos: acento agudo ´ (som aberto: café), acento circunflexo ^ (som fechado: avô), acento grave ` (contração: à) e til ~ (som nasal: mãe, pão).',
      'Na divisão silábica separam-se rr, ss, sc, sç e xc: car-ro, pás-sa-ro, pis-ci-na, nas-ço, ex-ce-len-te.'
    ],
    q: [
      ['Quantas sílabas tem "borboleta"?', ['quatro', 'três', 'cinco', 'duas']],
      ['Qual é a sílaba tónica de "janela"?', ['ne', 'ja', 'la', 'não tem']],
      ['"Lâmpada" é uma palavra…', ['esdrúxula', 'grave', 'aguda', 'monossílaba']],
      ['"Café" é uma palavra…', ['aguda', 'grave', 'esdrúxula', 'trissílaba']],
      ['"Mesa" é uma palavra grave.', true, 'A sílaba tónica é "me", a penúltima.'],
      ['Qual é a divisão silábica correta de "carro"?', ['car-ro', 'ca-rro', 'carr-o', 'c-arro']],
      ['Qual é a divisão silábica correta de "piscina"?', ['pis-ci-na', 'pi-sci-na', 'pisc-i-na', 'pi-sc-ina']],
      ['Qual destas palavras é monossílaba?', ['sol', 'solar', 'soldado', 'sola']],
      ['Em "avô", o acento circunflexo indica um som…', ['fechado', 'aberto', 'nasal', 'mudo'], 'Avô (som fechado) e avó (som aberto).'],
      ['Todas as palavras esdrúxulas levam acento gráfico.', true],
      ['Qual destas palavras é trissílaba?', ['sapato', 'sapo', 'pé', 'sapataria']]
    ]
  },
  {
    id: 'pt4_frase', t: 'Tipos de frase, sujeito e predicado',
    k: 'tipos de frase,frase,frases,sujeito,predicado,declarativa,interrogativa,exclamativa,imperativa,afirmativa,negativa,funcoes sintaticas,complemento direto,vocativo',
    ae: 'Identificar tipos de frase (declarativa, interrogativa, exclamativa, imperativa; afirmativa e negativa) e funções sintáticas (sujeito, predicado, complemento direto, vocativo).',
    r: [
      'Frase declarativa: informa ou declara (O Rui tem dez anos.) — termina com ponto final.',
      'Frase interrogativa: faz uma pergunta (Onde moras?) — termina com ponto de interrogação.',
      'Frase exclamativa: exprime emoção (Que lindo dia!) — termina com ponto de exclamação.',
      'Frase imperativa: dá uma ordem, pedido ou conselho (Arruma o quarto.).',
      'As frases podem ser afirmativas (Eu gosto de sopa.) ou negativas (Eu não gosto de sopa.).',
      'Sujeito: de quem ou de quê se fala. Predicado: o que se diz do sujeito; tem sempre um verbo. Em "O cão ladra muito", o sujeito é "O cão" e o predicado é "ladra muito".',
      'Complemento direto: completa o verbo e responde a "o quê?" ou "quem?" (A Ana comeu a maçã → comeu o quê? a maçã). Pode ser substituído por o, a, os, as: A Ana comeu-a.',
      'Vocativo: serve para chamar alguém e fica separado por vírgula (Maria, anda cá!).'
    ],
    q: [
      ['"Que bonito arco-íris!" é uma frase…', ['exclamativa', 'interrogativa', 'declarativa', 'imperativa']],
      ['"Lava os dentes antes de dormir." é uma frase…', ['imperativa', 'exclamativa', 'interrogativa', 'negativa']],
      ['Na frase "O meu irmão joga futebol.", qual é o sujeito?', ['O meu irmão', 'joga futebol', 'futebol', 'joga']],
      ['Na frase "As andorinhas voltaram na primavera.", qual é o predicado?', ['voltaram na primavera', 'As andorinhas', 'na primavera', 'andorinhas voltaram']],
      ['Qual é a forma negativa de "Eu gosto de peixe."?', ['Eu não gosto de peixe.', 'Eu gosto muito de peixe.', 'Tu gostas de peixe?', 'Gosto de peixe!']],
      ['Em "Pedro, fecha a porta!", "Pedro" é…', ['vocativo', 'sujeito', 'complemento direto', 'predicado']],
      ['Em "A Ana leu um livro.", qual é o complemento direto?', ['um livro', 'A Ana', 'leu', 'A Ana leu']],
      ['O predicado tem sempre um verbo.', true],
      ['"Onde fica a escola?" é uma frase declarativa.', false, 'É interrogativa: faz uma pergunta.'],
      ['Em "Os alunos ouviram a história.", substitui o complemento direto por um pronome:', ['Os alunos ouviram-na.', 'Os alunos ouviram-lhe.', 'Eles ouviram a história.', 'Os alunos ouviram-nos a história.']]
    ]
  },
  {
    id: 'pt4_palavras', t: 'Sinónimos, antónimos e formação de palavras',
    k: 'sinonimos,sinonimo,antonimos,antonimo,familia de palavras,familias de palavras,palavras derivadas,derivacao,prefixo,prefixos,sufixo,sufixos,palavras compostas,composicao',
    ae: 'Identificar sinónimos, antónimos, famílias de palavras e palavras formadas por derivação (prefixação e sufixação) e por composição.',
    r: [
      'Sinónimos: palavras com significado parecido (contente = alegre; começar = iniciar).',
      'Antónimos: palavras com significado contrário (alto ↔ baixo; feliz ↔ infeliz).',
      'Família de palavras: palavras que vêm da mesma palavra (mar, marinheiro, marítimo, marinho).',
      'Derivação por prefixação: junta-se um prefixo antes da palavra (fazer → desfazer; feliz → infeliz; ver → rever).',
      'Derivação por sufixação: junta-se um sufixo depois (pão → padeiro; jardim → jardineiro; rápido → rapidamente).',
      'Palavras compostas: formadas por duas ou mais palavras (guarda-chuva, couve-flor, girassol, passatempo).'
    ],
    q: [
      ['Qual é um sinónimo de "contente"?', ['alegre', 'triste', 'zangado', 'cansado']],
      ['Qual é o antónimo de "pesado"?', ['leve', 'grande', 'forte', 'grosso']],
      ['Qual destas palavras NÃO pertence à família de "mar"?', ['martelo', 'marinheiro', 'marítimo', 'marinho']],
      ['"Infeliz" foi formada por…', ['prefixação', 'sufixação', 'composição', 'não é derivada'], 'Juntou-se o prefixo in- a "feliz".'],
      ['"Jardineiro" foi formada por…', ['sufixação', 'prefixação', 'composição', 'contração']],
      ['Qual destas é uma palavra composta?', ['guarda-chuva', 'chuvoso', 'chuvinha', 'chuva']],
      ['Qual é o antónimo de "antes"?', ['depois', 'agora', 'cedo', 'nunca']],
      ['"Desarrumar" tem o prefixo "des-".', true],
      ['"Começar" e "iniciar" são antónimos.', false, 'São sinónimos: têm significado parecido.'],
      ['Qual é o antónimo de "possível"?', ['impossível', 'desposível', 'possivelmente', 'repossível']]
    ]
  },
  {
    id: 'pt4_pontuacao', t: 'Pontuação e discurso direto e indireto',
    k: 'pontuacao,sinais de pontuacao,virgula,ponto final,travessao,dois pontos,discurso direto,discurso indireto,reticencias,ponto de interrogacao,ponto de exclamacao',
    ae: 'Usar corretamente os sinais de pontuação e transformar frases do discurso direto para o discurso indireto.',
    r: [
      'Ponto final (.) termina frases declarativas; ponto de interrogação (?) termina perguntas; ponto de exclamação (!) mostra emoções.',
      'Vírgula (,): separa elementos de uma enumeração (Comprei pão, leite e ovos.) e isola o vocativo (Ana, vem cá.).',
      'Dois pontos (:) anunciam uma enumeração ou a fala de uma personagem.',
      'Travessão (—) marca a fala das personagens no discurso direto.',
      'Discurso direto: reproduz as palavras exatas da personagem (— Estou cansado — disse o Rui.).',
      'Discurso indireto: o narrador conta o que a personagem disse (O Rui disse que estava cansado.). Mudam os tempos verbais e os pronomes.',
      'Reticências (…) indicam que a frase fica suspensa ou incompleta.'
    ],
    q: [
      ['Que sinal marca a fala de uma personagem no discurso direto?', ['travessão', 'reticências', 'ponto final', 'parênteses']],
      ['"A mãe disse que ia ao mercado." Esta frase está em discurso…', ['indireto', 'direto', 'interrogativo', 'exclamativo']],
      ['Passa para o discurso indireto: — Eu tenho fome — disse a Rita.', ['A Rita disse que tinha fome.', 'A Rita disse: eu tenho fome.', 'Eu tenho fome, disse a Rita.', 'A Rita tem fome?']],
      ['Qual frase está bem pontuada?', ['Comprei maçãs, peras e uvas.', 'Comprei, maçãs peras e uvas.', 'Comprei maçãs peras, e uvas.', 'Comprei maçãs peras e, uvas.']],
      ['Que sinal indica uma frase suspensa ou incompleta?', ['reticências', 'dois pontos', 'vírgula', 'ponto final']],
      ['Numa enumeração simples, normalmente não se coloca vírgula antes do "e".', true],
      ['O vocativo fica separado por vírgula do resto da frase.', true],
      ['Qual sinal se usa no fim de "Como te chamas"?', ['ponto de interrogação', 'ponto final', 'ponto de exclamação', 'vírgula']]
    ]
  },
  {
    id: 'pt4_ortografia', t: 'Ortografia',
    k: 'ortografia,erros de ortografia,escrever bem,ss,c cedilha,cedilha,m antes de p e b,letra h,x ou ch,s ou z,digrafos,lh nh ch',
    ae: 'Escrever corretamente palavras com dificuldades ortográficas (m antes de p e b, ç, ss, rr, h inicial, x/ch, s/z, dígrafos).',
    r: [
      'Antes de p e b escreve-se sempre m (campo, tambor, empurrar); antes das outras consoantes escreve-se n (canto, ponte).',
      'O ç só aparece antes de a, o, u (caça, poço, açúcar) e nunca no início de uma palavra.',
      'Entre vogais, o som "s" escreve-se com ss (pássaro) e o som "r" forte com rr (carro).',
      'O h no início das palavras não se lê (hoje, homem, hora).',
      'Lh, nh e ch são dígrafos: duas letras que representam um só som (filho, ninho, chave).',
      'Palavras parecidas com sentidos diferentes: concerto (espetáculo de música) e conserto (reparação); cela (de prisão) e sela (do cavalo).'
    ],
    q: [
      ['Qual palavra está bem escrita?', ['campo', 'canpo', 'cãpo', 'kampo']],
      ['Qual palavra está bem escrita?', ['pássaro', 'pásaro', 'páçaro', 'páçsaro']],
      ['Qual palavra está bem escrita?', ['hoje', 'oje', 'hoge', 'oge']],
      ['Qual palavra está bem escrita?', ['açúcar', 'assúcar', 'acúcar', 'asúcar']],
      ['Qual palavra está bem escrita?', ['tambor', 'tanbor', 'tâmbor', 'tambôr']],
      ['Qual palavra está bem escrita?', ['chave', 'xave', 'chavi', 'xavi']],
      ['O ç pode aparecer antes de "e" e de "i".', false, 'O ç só se usa antes de a, o e u.'],
      ['"O mecânico fez o … do carro."', ['conserto', 'concerto', 'consêrto', 'comcerto'], 'Conserto = reparação; concerto = espetáculo de música.'],
      ['Qual palavra está bem escrita?', ['cozinha', 'cosinha', 'cozínha', 'cuzinha']],
      ['Em "filho", "lh" é um dígrafo.', true]
    ]
  },
  {
    id: 'pt4_texto', t: 'Texto narrativo, poético e dramático',
    k: 'texto narrativo,narrativo,narrador,narrativa,personagens,personagem,espaco,tempo,acao,poema,poesia,verso,versos,estrofe,estrofes,rima,texto poetico,texto dramatico,teatro,conto,educacao literaria',
    ae: 'Identificar os elementos da narrativa (personagens, espaço, tempo, ação) e a sua estrutura; reconhecer características do texto poético e do texto dramático.',
    r: [
      'O texto narrativo conta uma história com: personagens (quem?), espaço (onde?), tempo (quando?) e ação (o que acontece?).',
      'Estrutura: introdução (apresenta a situação), desenvolvimento (acontecimentos e problema) e conclusão (como termina).',
      'O narrador conta a história. A personagem principal é a mais importante; as secundárias aparecem menos.',
      'O texto poético (poema) é escrito em versos; um conjunto de versos forma uma estrofe.',
      'Rima: repetição do som final das palavras (balão / coração).',
      'Estrofes: dístico (2 versos), terceto (3), quadra (4), quintilha (5) e sextilha (6).',
      'O texto dramático (teatro) é escrito para ser representado: tem as falas das personagens e indicações cénicas (didascálias) sobre gestos, cenário e movimentos.'
    ],
    q: [
      ['Num texto narrativo, o espaço responde à pergunta…', ['Onde?', 'Quando?', 'Quem?', 'Porquê?']],
      ['Como se chama cada linha de um poema?', ['verso', 'estrofe', 'parágrafo', 'rima']],
      ['Uma estrofe com 4 versos chama-se…', ['quadra', 'terceto', 'dístico', 'quintilha']],
      ['"Mar" rima com…', ['luar', 'mesa', 'sol', 'céu']],
      ['Quem conta a história num texto narrativo?', ['o narrador', 'o ilustrador', 'o leitor', 'o editor']],
      ['A parte da narrativa que apresenta a situação inicial chama-se…', ['introdução', 'conclusão', 'desenvolvimento', 'título']],
      ['O texto dramático é escrito para ser representado.', true],
      ['"Era uma vez, num reino distante…" indica o tempo e o espaço da história.', true],
      ['Nos textos de teatro, as indicações sobre gestos e cenário chamam-se…', ['didascálias', 'estrofes', 'rimas', 'parágrafos']]
    ]
  }
]);

// ============================================================= MATEMÁTICA (AE 2021)
TEMAS(4, 'mat', [
  {
    id: 'mat4_numeros', t: 'Números até ao milhão', gen: 'numeros4',
    k: 'numeros,numero,milhao,milhar,milhares,ordens,classes,valor posicional,ler numeros,arredondar,arredondamentos,comparar numeros,numeros naturais',
    ae: 'Ler, representar, comparar e ordenar números naturais até ao milhão, identificando o valor posicional dos algarismos.',
    r: [
      'Os algarismos agrupam-se em classes de três: classe das unidades (unidades, dezenas, centenas) e classe dos milhares (unidades de milhar, dezenas de milhar, centenas de milhar).',
      'Exemplo: 345 678 lê-se "trezentos e quarenta e cinco mil seiscentos e setenta e oito".',
      'O valor de um algarismo depende da posição: em 345 678, o 4 vale 40 000 (está nas dezenas de milhar).',
      'Um milhão = 1 000 000 = mil milhares.',
      'Para comparar: o número com mais algarismos é maior; se tiverem os mesmos, compara-se da esquerda para a direita. Sinais: > maior, < menor, = igual.',
      'Arredondar às centenas: olha-se para o algarismo das dezenas; se for 5 ou mais, arredonda-se para cima (1 260 → 1 300); se for menos, para baixo (1 240 → 1 200).'
    ],
    q: [
      ['Como se escreve "duzentos e cinco mil e trinta"?', ['205 030', '250 030', '205 300', '2 530']],
      ['Qual é o maior número?', ['98 765', '98 756', '89 999', '97 999']],
      ['Quantos milhares há num milhão?', ['1000', '100', '10', '10 000']],
      ['Arredonda 4 352 às centenas.', ['4 400', '4 300', '4 350', '4 000'], 'O algarismo das dezenas é 5, por isso arredonda-se para cima.'],
      ['Que sinal completa: 45 300 … 45 030?', ['>', '<', '=', '+']],
      ['1 000 000 lê-se "um milhão".', true],
      ['Qual é o antecessor de 100 000?', ['99 999', '100 001', '99 000', '10 000']]
    ]
  },
  {
    id: 'mat4_operacoes', t: 'Multiplicação e tabuadas', gen: 'tabuada4',
    k: 'multiplicacao,multiplicar,multiplicacoes,tabuada,tabuadas,vezes,produto,calculo mental,adicao,subtracao,contas',
    ae: 'Compreender e usar a multiplicação (e o algoritmo), as suas propriedades e estratégias de cálculo mental.',
    r: [
      'Os números que se multiplicam chamam-se fatores; o resultado chama-se produto.',
      'Propriedade comutativa: a ordem dos fatores não altera o produto (3 × 5 = 5 × 3).',
      'Qualquer número × 1 dá o próprio número; qualquer número × 0 dá 0.',
      'Multiplicar por 10, 100 ou 1000 num número natural: acrescentam-se 1, 2 ou 3 zeros (25 × 100 = 2 500).',
      'Propriedade distributiva: 6 × 12 = 6 × 10 + 6 × 2 = 60 + 12 = 72.',
      'Na adição, os números chamam-se parcelas e o resultado soma; na subtração, o resultado chama-se diferença.'
    ],
    q: [
      ['Quanto é 25 × 100?', ['2 500', '250', '25 000', '2 050']],
      ['Como se chama o resultado de uma multiplicação?', ['produto', 'soma', 'diferença', 'quociente']],
      ['7 × 0 = ?', ['0', '7', '1', '70']],
      ['6 × 8 = 8 × 6 é um exemplo da propriedade…', ['comutativa', 'distributiva', 'associativa', 'do elemento neutro']],
      ['Quanto é 9 × 12?', ['108', '98', '112', '118']],
      ['Na subtração, o resultado chama-se diferença.', true],
      ['Quanto é 340 × 10?', ['3 400', '340', '34 000', '3 040']]
    ]
  },
  {
    id: 'mat4_divisao', t: 'Divisão', gen: 'divisao4',
    k: 'divisao,dividir,divisoes,quociente,resto,dividendo,divisor,divisao inteira,algoritmo da divisao,repartir',
    ae: 'Compreender a divisão inteira, usar o algoritmo e relacionar a divisão com a multiplicação.',
    r: [
      'Termos da divisão: dividendo : divisor = quociente (e resto).',
      'Na divisão inteira, o resto é sempre menor do que o divisor.',
      'Prova: divisor × quociente + resto = dividendo. Ex.: 47 : 5 = 9 e resto 2, porque 5 × 9 + 2 = 47.',
      'Se o resto é 0, a divisão é exata.',
      'Dividir por 10, 100 ou 1000 um número terminado em zeros: tiram-se 1, 2 ou 3 zeros (3 000 : 100 = 30).',
      'A divisão é a operação inversa da multiplicação: se 6 × 7 = 42, então 42 : 7 = 6.'
    ],
    q: [
      ['Em 35 : 5 = 7, como se chama o 35?', ['dividendo', 'divisor', 'quociente', 'resto']],
      ['Numa divisão por 6, qual destes NÃO pode ser o resto?', ['6', '5', '0', '3'], 'O resto tem de ser menor do que o divisor.'],
      ['Quanto é 4 200 : 100?', ['42', '420', '4 200', '4,2']],
      ['Repartem-se 24 rebuçados por 4 amigos em partes iguais. Quantos recebe cada um?', ['6', '8', '4', '20']],
      ['Uma divisão com resto 0 chama-se divisão exata.', true],
      ['Se 8 × 9 = 72, então 72 : 9 = …', ['8', '9', '63', '81']]
    ]
  },
  {
    id: 'mat4_multiplos', t: 'Múltiplos e divisores', gen: 'multiplos4',
    k: 'multiplos,multiplo,divisores,divisor,numeros pares,numeros impares,pares,impares,par,impar',
    ae: 'Identificar múltiplos e divisores de números naturais e relacioná-los; reconhecer números pares e ímpares.',
    r: [
      'Os múltiplos de um número obtêm-se multiplicando-o por 0, 1, 2, 3… Múltiplos de 4: 0, 4, 8, 12, 16…',
      'Um número é divisor de outro se a divisão for exata (resto 0). Divisores de 12: 1, 2, 3, 4, 6 e 12.',
      'Se 15 é múltiplo de 5, então 5 é divisor de 15.',
      'Os números pares são múltiplos de 2 (terminam em 0, 2, 4, 6 ou 8); os outros são ímpares.',
      'Os múltiplos de 5 terminam em 0 ou 5; os múltiplos de 10 terminam em 0.',
      'O 1 é divisor de todos os números, e cada número é divisor de si próprio.'
    ],
    q: [
      ['Quais são os divisores de 10?', ['1, 2, 5 e 10', '2 e 5', '10, 20 e 30', '1, 3, 5 e 10']],
      ['Qual destes números é ímpar?', ['37', '48', '50', '64']],
      ['Qual destes números é múltiplo de 5?', ['85', '52', '57', '103']],
      ['Se 6 × 4 = 24, então 24 é múltiplo de 6.', true],
      ['O 0 é múltiplo de qualquer número.', true, 'Porque qualquer número × 0 = 0.'],
      ['Qual destes números é múltiplo de 2 e de 3 ao mesmo tempo?', ['18', '16', '21', '25']]
    ]
  },
  {
    id: 'mat4_fracoes', t: 'Frações', gen: 'fracoes4',
    k: 'fracoes,fracao,metade,terco,tercos,quarto,quartos,numerador,denominador,fracoes equivalentes,comparar fracoes,partes iguais',
    ae: 'Compreender frações como parte-todo, quociente e operador; comparar e ordenar frações e reconhecer frações equivalentes.',
    r: [
      'Uma fração representa partes iguais de uma unidade. Em 3/4, o 4 é o denominador (em quantas partes iguais se divide) e o 3 é o numerador (quantas partes se tomam).',
      'Leitura: 1/2 um meio, 1/3 um terço, 1/4 um quarto, 1/5 um quinto, 1/10 um décimo, 1/100 um centésimo.',
      'Frações equivalentes representam a mesma quantidade: 1/2 = 2/4 = 3/6.',
      'Com o mesmo denominador, é maior a que tem maior numerador (3/5 > 2/5). Com o mesmo numerador, é maior a que tem menor denominador (1/3 > 1/4).',
      'Fração de uma quantidade: 2/3 de 12 → 12 : 3 = 4 e 4 × 2 = 8.',
      'Quando o numerador é igual ao denominador, a fração vale 1 unidade (4/4 = 1).',
      'As frações decimais têm denominador 10, 100, 1000… e escrevem-se como numerais decimais (3/10 = 0,3).'
    ],
    q: [
      ['Em 5/8, como se chama o 8?', ['denominador', 'numerador', 'quociente', 'fator']],
      ['Qual é a fração maior?', ['1/3', '1/4', '1/5', '1/8']],
      ['A quanto é igual 4/4?', ['1 unidade', '4 unidades', '0', 'um quarto']],
      ['Uma pizza foi dividida em 8 fatias iguais e comeram-se 3. Que fração se comeu?', ['3/8', '5/8', '8/3', '3/5']],
      ['2/4 é equivalente a 1/2.', true],
      ['Como se escreve 3/10 em numeral decimal?', ['0,3', '3,10', '0,03', '30']],
      ['Quanto é metade de 50?', ['25', '20', '100', '5']]
    ]
  },
  {
    id: 'mat4_decimais', t: 'Números decimais', gen: 'decimais4',
    k: 'decimais,numeros decimais,decima,decimas,centesima,centesimas,milesima,milesimas,virgula,numeral decimal',
    ae: 'Ler, representar, comparar e ordenar números decimais até às milésimas e operar com eles.',
    r: [
      '1 unidade = 10 décimas = 100 centésimas = 1000 milésimas.',
      'Em 2,345 há 2 unidades, 3 décimas, 4 centésimas e 5 milésimas.',
      'Para comparar, vê-se primeiro a parte inteira, depois as décimas, as centésimas… (0,7 > 0,65 porque 7 décimas > 6 décimas).',
      'Zeros à direita, depois da vírgula, não mudam o valor: 0,5 = 0,50 = 0,500.',
      'Para adicionar ou subtrair decimais, alinham-se as vírgulas.',
      'Multiplicar por 10, 100 ou 1000: a vírgula anda 1, 2 ou 3 casas para a direita (2,5 × 10 = 25). Dividir: anda para a esquerda (36 : 100 = 0,36).'
    ],
    q: [
      ['Em 4,72, o algarismo 7 representa…', ['7 décimas', '7 centésimas', '7 unidades', '7 dezenas']],
      ['Qual é o maior: 0,8 ou 0,75?', ['0,8', '0,75', 'são iguais', 'não se pode comparar']],
      ['Quanto é 3,6 × 10?', ['36', '0,36', '360', '3,60']],
      ['Quanto é 45 : 100?', ['0,45', '4,5', '450', '0,045']],
      ['0,5 é igual a 0,50.', true],
      ['Quantas centésimas tem 1 unidade?', ['100', '10', '1000', '1']],
      ['Quanto é 2,5 + 1,25?', ['3,75', '3,30', '4,75', '3,5']]
    ]
  },
  {
    id: 'mat4_geometria', t: 'Retas, ângulos e polígonos',
    k: 'geometria,retas,reta,paralelas,perpendiculares,angulos,angulo,angulo reto,agudo,obtuso,raso,poligonos,poligono,triangulos,triangulo,quadrilateros,circunferencia,circulo,simetria,eixo de simetria,eixos de simetria',
    ae: 'Identificar retas paralelas e perpendiculares; classificar ângulos, polígonos, triângulos e quadriláteros; distinguir círculo e circunferência; reconhecer simetrias de reflexão.',
    r: [
      'Retas paralelas nunca se cruzam; retas perpendiculares cruzam-se formando ângulos retos (90°).',
      'Ângulos: agudo (menor do que o reto), reto (90°), obtuso (maior do que o reto e menor do que o raso) e raso (180°).',
      'Polígonos são figuras planas fechadas limitadas por segmentos de reta: triângulo (3 lados), quadrilátero (4), pentágono (5), hexágono (6), octógono (8).',
      'Triângulos quanto aos lados: equilátero (3 lados iguais), isósceles (pelo menos 2 lados iguais) e escaleno (lados todos diferentes). Quanto aos ângulos: retângulo, acutângulo e obtusângulo.',
      'Quadriláteros: quadrado (4 lados iguais e 4 ângulos retos), retângulo (4 ângulos retos), losango (4 lados iguais), paralelogramo (lados opostos paralelos) e trapézio (pelo menos um par de lados paralelos).',
      'A circunferência é a linha; o círculo é a linha e o seu interior. O diâmetro é o dobro do raio.',
      'Um eixo de simetria divide uma figura em duas partes que coincidem como num espelho. O quadrado tem 4 eixos de simetria e o retângulo tem 2.'
    ],
    q: [
      ['Um ângulo de 90° chama-se…', ['ângulo reto', 'ângulo agudo', 'ângulo obtuso', 'ângulo raso']],
      ['Um triângulo com os três lados iguais é…', ['equilátero', 'isósceles', 'escaleno', 'retângulo']],
      ['Quantos lados tem um hexágono?', ['6', '5', '8', '7']],
      ['Retas que nunca se cruzam chamam-se…', ['paralelas', 'perpendiculares', 'concorrentes', 'oblíquas']],
      ['O raio de uma circunferência mede 4 cm. Quanto mede o diâmetro?', ['8 cm', '4 cm', '2 cm', '16 cm']],
      ['Quantos eixos de simetria tem um quadrado?', ['4', '2', '1', '0']],
      ['Um ângulo de 120° é…', ['obtuso', 'agudo', 'reto', 'raso']],
      ['Todo o quadrado é um retângulo.', true, 'Tem 4 ângulos retos, por isso é um retângulo especial.'],
      ['O círculo é apenas a linha que limita a figura.', false, 'Essa linha é a circunferência; o círculo inclui o interior.'],
      ['Quantos eixos de simetria tem um retângulo (que não é quadrado)?', ['2', '4', '1', '0']]
    ]
  },
  {
    id: 'mat4_solidos', t: 'Sólidos geométricos',
    k: 'solidos,solidos geometricos,cubo,prisma,prismas,piramide,piramides,cilindro,cone,esfera,faces,arestas,vertices,planificacao,planificacoes,paralelepipedo,poliedros',
    ae: 'Identificar e classificar sólidos geométricos (poliedros e não poliedros), relacionar faces, arestas e vértices e reconhecer planificações.',
    r: [
      'Poliedros têm todas as faces planas e poligonais: cubo, paralelepípedo, prismas e pirâmides.',
      'Os não poliedros têm superfícies curvas: esfera, cilindro e cone.',
      'Faces são as superfícies planas; arestas são os segmentos onde duas faces se encontram; vértices são os pontos onde as arestas se encontram.',
      'O cubo tem 6 faces quadradas iguais, 12 arestas e 8 vértices.',
      'Os prismas têm 2 bases iguais e paralelas e faces laterais retangulares. O nome depende da base (prisma triangular, pentagonal…).',
      'As pirâmides têm 1 base e faces laterais triangulares que se juntam num vértice.',
      'A planificação é o sólido "aberto" e estendido num plano.'
    ],
    q: [
      ['Quantas faces tem um cubo?', ['6', '8', '12', '4']],
      ['Quantas arestas tem um cubo?', ['12', '8', '6', '10']],
      ['Qual destes sólidos NÃO é um poliedro?', ['cilindro', 'cubo', 'pirâmide quadrangular', 'prisma triangular']],
      ['Quantos vértices tem uma pirâmide quadrangular?', ['5', '4', '8', '6']],
      ['As faces laterais de uma pirâmide são…', ['triângulos', 'retângulos', 'círculos', 'pentágonos']],
      ['Que sólido não tem vértices nem arestas e rola em todas as direções?', ['esfera', 'cilindro', 'cone', 'cubo']],
      ['Um prisma triangular tem 2 bases triangulares.', true],
      ['Quantas faces tem um prisma pentagonal?', ['7', '5', '10', '6'], '2 bases + 5 faces laterais = 7 faces.']
    ]
  },
  {
    id: 'mat4_medida', t: 'Comprimento, massa e capacidade', gen: 'medida4',
    k: 'medidas,medida,comprimento,metro,metros,centimetro,quilometro,milimetro,massa,quilograma,grama,capacidade,litro,litros,mililitro,converter,conversoes,unidades de medida',
    ae: 'Medir e converter unidades de comprimento, massa e capacidade do sistema métrico.',
    r: [
      'Comprimento: a unidade principal é o metro (m). km → hm → dam → m → dm → cm → mm: cada unidade é 10 vezes maior do que a seguinte.',
      '1 km = 1000 m; 1 m = 100 cm = 1000 mm; 1 cm = 10 mm.',
      'Massa: a unidade principal é o quilograma (kg). 1 kg = 1000 g; 1 tonelada (t) = 1000 kg.',
      'Capacidade: a unidade principal é o litro (L). 1 L = 10 dL = 100 cL = 1000 mL.',
      'Para passar para uma unidade mais pequena multiplica-se; para uma unidade maior divide-se.'
    ],
    q: [
      ['Quantos centímetros tem 1 metro?', ['100', '10', '1000', '60']],
      ['Qual é a unidade mais adequada para medir a distância entre Lisboa e o Porto?', ['quilómetro', 'centímetro', 'metro', 'milímetro']],
      ['1 kg de algodão tem a mesma massa que 1 kg de ferro.', true],
      ['Quantos mililitros tem 1 litro?', ['1000', '100', '10', '10 000']],
      ['Qual é a unidade principal de massa?', ['quilograma', 'grama', 'litro', 'metro']],
      ['Meio litro é igual a…', ['500 mL', '50 mL', '5 mL', '5000 mL']],
      ['Quantos metros são 2,5 km?', ['2500', '250', '25', '25 000']]
    ]
  },
  {
    id: 'mat4_area', t: 'Perímetro e área', gen: 'area4',
    k: 'perimetro,perimetros,area,areas,centimetro quadrado,metro quadrado,quadricula,contorno,superficie',
    ae: 'Calcular perímetros de polígonos e áreas de retângulos e quadrados, usando unidades de área (cm², m²).',
    r: [
      'O perímetro é a medida do contorno de uma figura: somam-se as medidas de todos os lados.',
      'A área é a medida da superfície (o interior) da figura.',
      'Área do retângulo = comprimento × largura. Área do quadrado = lado × lado.',
      'Perímetro do quadrado = 4 × lado.',
      'Unidades de área: centímetro quadrado (cm²) e metro quadrado (m²). 1 m² = 10 000 cm².',
      'Figuras com a mesma área podem ter perímetros diferentes, e figuras com o mesmo perímetro podem ter áreas diferentes.'
    ],
    q: [
      ['O que mede o perímetro?', ['o contorno da figura', 'o interior da figura', 'o volume', 'a altura']],
      ['Um quadrado tem 5 cm de lado. Qual é o perímetro?', ['20 cm', '25 cm', '10 cm', '25 cm²']],
      ['Um retângulo tem 8 m por 3 m. Qual é a área?', ['24 m²', '22 m²', '11 m²', '24 m']],
      ['Em que unidade se mede a área de uma sala?', ['metro quadrado (m²)', 'metro (m)', 'litro (L)', 'quilograma (kg)']],
      ['Duas figuras com a mesma área têm sempre o mesmo perímetro.', false],
      ['Quantos cm² tem 1 m²?', ['10 000', '100', '1000', '1 000 000']]
    ]
  },
  {
    id: 'mat4_tempo', t: 'Tempo e dinheiro', gen: 'tempo4',
    k: 'tempo,horas,minutos,segundos,relogio,dinheiro,euros,euro,centimos,moedas,notas,calendario,ano bissexto,seculo,duracao,troco',
    ae: 'Relacionar unidades de tempo, calcular durações e resolver problemas com dinheiro (euros e cêntimos).',
    r: [
      '1 hora = 60 minutos; 1 minuto = 60 segundos; 1 dia = 24 horas.',
      '1 semana = 7 dias; 1 ano = 12 meses = 365 dias (366 no ano bissexto, quando fevereiro tem 29 dias).',
      '1 década = 10 anos; 1 século = 100 anos; 1 milénio = 1000 anos.',
      'Meia hora = 30 minutos; um quarto de hora = 15 minutos.',
      '1 euro = 100 cêntimos. Moedas: 1, 2, 5, 10, 20 e 50 cêntimos, 1 € e 2 €. Notas: 5, 10, 20, 50, 100 e 200 €.',
      'Para calcular o troco, subtrai-se o preço ao dinheiro entregue.'
    ],
    q: [
      ['Quantos minutos tem um quarto de hora?', ['15', '25', '30', '45']],
      ['Quantos anos tem um século?', ['100', '10', '1000', '50']],
      ['Quantos dias tem um ano bissexto?', ['366', '365', '360', '364']],
      ['Compraste um livro de 7,50 € e pagaste com uma nota de 10 €. Quanto recebes de troco?', ['2,50 €', '3,50 €', '2,00 €', '17,50 €']],
      ['Quantas horas tem um dia?', ['24', '12', '60', '48']],
      ['1 euro = 100 cêntimos.', true],
      ['14h30 é…', ['duas e meia da tarde', 'quatro e meia da tarde', 'duas e meia da manhã', 'meio-dia e meia']]
    ]
  },
  {
    id: 'mat4_dados', t: 'Dados, gráficos e probabilidades',
    k: 'dados,graficos,grafico,grafico de barras,pictograma,pictogramas,tabela,tabelas,frequencias,moda,frequencia absoluta,probabilidade,probabilidades,provavel,impossivel,acontecimento,acontecimentos',
    ae: 'Organizar e interpretar dados em tabelas de frequências, pictogramas e gráficos de barras; identificar a moda; classificar acontecimentos (certo, possível, impossível) e comparar a sua probabilidade.',
    r: [
      'Os dados podem organizar-se em tabelas de frequências: a frequência absoluta é o número de vezes que um valor aparece.',
      'Pictograma: usa símbolos para representar quantidades; é preciso ver a legenda (ex.: cada símbolo = 2 alunos).',
      'Gráfico de barras: a altura de cada barra mostra a frequência.',
      'A moda é o valor (ou categoria) que aparece mais vezes.',
      'Acontecimento certo: acontece sempre. Impossível: nunca acontece. Possível: pode ou não acontecer.',
      'Um acontecimento é mais provável do que outro quando tem mais hipóteses de acontecer.'
    ],
    q: [
      ['Ao lançar um dado normal, sair o número 7 é um acontecimento…', ['impossível', 'certo', 'possível', 'muito provável']],
      ['Ao lançar um dado normal, sair um número menor do que 7 é…', ['certo', 'impossível', 'pouco provável', 'raro']],
      ['Frutas preferidas de uma turma: maçã 8, banana 5, laranja 3. Qual é a moda?', ['maçã', 'banana', 'laranja', '8']],
      ['Num pictograma, cada 🍎 representa 4 alunos. Quantos alunos representam 3 🍎?', ['12', '3', '7', '4']],
      ['Num saco há 9 bolas azuis e 1 vermelha. Tirar uma bola azul é…', ['muito provável', 'impossível', 'pouco provável', 'certo']],
      ['A frequência absoluta indica quantas vezes um valor aparece.', true]
    ]
  },
  {
    id: 'mat4_sequencias', t: 'Sequências e expressões numéricas',
    k: 'sequencias,sequencia,regularidades,padroes,padrao,termo,termos,proximo numero,expressoes numericas,parenteses,ordem das operacoes',
    ae: 'Identificar regularidades e determinar termos de sequências; usar expressões numéricas com parênteses.',
    r: [
      'Uma sequência segue uma regra. Ex.: 3, 7, 11, 15… → soma-se 4 de cada vez.',
      'Cada elemento de uma sequência chama-se termo.',
      'As sequências podem ser de números ou de figuras que se repetem ou crescem.',
      'Numa expressão numérica resolve-se primeiro o que está dentro dos parênteses.',
      'Sem parênteses, fazem-se primeiro as multiplicações e divisões e depois as adições e subtrações: 2 + 3 × 4 = 2 + 12 = 14.'
    ],
    q: [
      ['Qual é o número seguinte: 5, 10, 15, 20, …?', ['25', '30', '21', '24']],
      ['Qual é o número seguinte: 2, 4, 8, 16, …?', ['32', '18', '24', '20']],
      ['Qual é a regra da sequência 50, 45, 40, 35…?', ['subtrair 5', 'somar 5', 'dividir por 5', 'subtrair 10']],
      ['Quanto é 2 + 3 × 4?', ['14', '20', '24', '9']],
      ['Quanto é (2 + 3) × 4?', ['20', '14', '24', '9']],
      ['Quanto é 20 − (8 − 3)?', ['15', '9', '25', '5']],
      ['Na sequência ●○●○●○…, a 10.ª figura é ○.', true, 'Nas posições pares aparece ○.']
    ]
  }
]);

// ============================================================= ESTUDO DO MEIO
TEMAS(4, 'em', [
  {
    id: 'em4_historia', t: 'História de Portugal',
    k: 'historia de portugal,historia,afonso henriques,d afonso henriques,fundacao de portugal,reis,rei,descobrimentos,1143,25 de abril,republica,restauracao,1640,aljubarrota,implantacao da republica,primeiro rei',
    ae: 'Reconhecer factos e datas importantes da história de Portugal e localizá-los no tempo (friso cronológico).',
    r: [
      'D. Afonso Henriques foi o primeiro rei de Portugal. Em 1128 venceu a Batalha de São Mamede e, em 1143, com o Tratado de Zamora, Portugal tornou-se um reino independente.',
      'Em 1179, o Papa reconheceu Portugal como reino (bula Manifestis Probatum).',
      'Em 1385, na Batalha de Aljubarrota, D. João I defendeu a independência de Portugal contra Castela.',
      'Descobrimentos: 1415, conquista de Ceuta; 1488, Bartolomeu Dias dobra o Cabo da Boa Esperança; 1498, Vasco da Gama chega à Índia por mar; 1500, Pedro Álvares Cabral chega ao Brasil.',
      'Em 1580 Portugal passou a ter reis espanhóis; a 1 de dezembro de 1640 recuperou a independência (Restauração), com D. João IV.',
      '5 de outubro de 1910: implantação da República — Portugal deixou de ter rei.',
      '25 de Abril de 1974: Revolução dos Cravos, que acabou com a ditadura e trouxe a liberdade e a democracia.',
      '1986: Portugal entrou na Comunidade Económica Europeia (atual União Europeia).'
    ],
    q: [
      ['Quem foi o primeiro rei de Portugal?', ['D. Afonso Henriques', 'D. Dinis', 'D. João I', 'D. Manuel I']],
      ['Em que ano foi assinado o Tratado de Zamora?', ['1143', '1128', '1385', '1640']],
      ['Quem chegou à Índia por mar em 1498?', ['Vasco da Gama', 'Pedro Álvares Cabral', 'Bartolomeu Dias', 'Fernão de Magalhães']],
      ['Em que ano os portugueses chegaram ao Brasil?', ['1500', '1498', '1415', '1640']],
      ['O que se comemora a 25 de Abril?', ['a Revolução dos Cravos e a liberdade', 'a implantação da República', 'a Restauração da Independência', 'o Dia de Portugal']],
      ['A República foi implantada em Portugal a 5 de outubro de…', ['1910', '1974', '1640', '1143']],
      ['A 1 de dezembro de 1640 Portugal recuperou a independência.', true],
      ['Quem dobrou o Cabo da Boa Esperança em 1488?', ['Bartolomeu Dias', 'Vasco da Gama', 'Gil Eanes', 'Infante D. Henrique']],
      ['Que batalha venceu D. Afonso Henriques em 1128?', ['São Mamede', 'Aljubarrota', 'Salado', 'Trafalgar']],
      ['Portugal entrou na CEE (atual União Europeia) em 1986.', true]
    ]
  },
  {
    id: 'em4_simbolos', t: 'Símbolos nacionais e órgãos de soberania',
    k: 'simbolos nacionais,bandeira,hino,hino nacional,a portuguesa,orgaos de soberania,presidente da republica,assembleia da republica,governo,tribunais,constituicao,uniao europeia,paises lusofonos,cplp,deputados,primeiro ministro',
    ae: 'Identificar os símbolos nacionais e os órgãos de soberania; reconhecer a pertença de Portugal à União Europeia e à comunidade de países de língua portuguesa.',
    r: [
      'Os símbolos nacionais são a Bandeira Nacional e o Hino Nacional ("A Portuguesa").',
      'A Bandeira é verde e vermelha, com a esfera armilar e o escudo com os castelos e as quinas.',
      'Os órgãos de soberania são: o Presidente da República, a Assembleia da República, o Governo e os Tribunais.',
      'O Presidente da República é eleito de 5 em 5 anos; os deputados da Assembleia da República são eleitos de 4 em 4 anos.',
      'A Assembleia da República faz as leis; o Governo, chefiado pelo Primeiro-Ministro, governa o país; os Tribunais aplicam a justiça.',
      'A Constituição da República Portuguesa é a lei mais importante do país.',
      'Portugal faz parte da União Europeia e da CPLP, com Angola, Brasil, Cabo Verde, Guiné-Bissau, Guiné Equatorial, Moçambique, São Tomé e Príncipe e Timor-Leste.',
      'O Dia de Portugal, de Camões e das Comunidades Portuguesas é a 10 de junho.'
    ],
    q: [
      ['Como se chama o Hino Nacional?', ['A Portuguesa', 'Grândola, Vila Morena', 'Hino da Liberdade', 'Avante Portugal']],
      ['Qual destes NÃO é um órgão de soberania?', ['a Câmara Municipal', 'o Governo', 'a Assembleia da República', 'os Tribunais']],
      ['Quem faz as leis em Portugal?', ['a Assembleia da República', 'os Tribunais', 'a Câmara Municipal', 'a polícia']],
      ['De quantos em quantos anos é eleito o Presidente da República?', ['5', '4', '2', '10']],
      ['Quem chefia o Governo?', ['o Primeiro-Ministro', 'o Presidente da República', 'o Presidente da Assembleia', 'um juiz']],
      ['Qual destes países tem o português como língua oficial?', ['Moçambique', 'Espanha', 'Marrocos', 'Itália']],
      ['As cores da Bandeira Nacional são o verde e o vermelho.', true],
      ['O Dia de Portugal comemora-se a…', ['10 de junho', '25 de abril', '5 de outubro', '1 de dezembro']]
    ]
  },
  {
    id: 'em4_corpo', t: 'O corpo humano',
    k: 'corpo humano,corpo,sistema digestivo,digestao,sistema respiratorio,respiracao,pulmoes,coracao,sistema circulatorio,sangue,sistema excretor,rins,esqueleto,ossos,musculos,orgaos,sistema nervoso,cerebro,sentidos,saude',
    ae: 'Identificar os principais órgãos dos sistemas digestivo, respiratório, circulatório, excretor, músculo-esquelético e nervoso e as suas funções; reconhecer hábitos de vida saudável.',
    r: [
      'Sistema digestivo: transforma os alimentos em nutrientes. Percurso: boca → faringe → esófago → estômago → intestino delgado → intestino grosso. Glândulas anexas: glândulas salivares, fígado e pâncreas.',
      'Sistema respiratório: fossas nasais → faringe → laringe → traqueia → brônquios → pulmões. Inspiramos ar com oxigénio e expiramos ar com mais dióxido de carbono.',
      'Sistema circulatório: o coração bombeia o sangue pelos vasos sanguíneos (artérias, veias e capilares), levando nutrientes e oxigénio a todo o corpo.',
      'Sistema excretor: os rins filtram o sangue e produzem a urina, que se acumula na bexiga.',
      'Os ossos formam o esqueleto, que suporta e protege o corpo; os músculos permitem o movimento. O crânio protege o cérebro e as costelas protegem o coração e os pulmões.',
      'Sistema nervoso: o cérebro comanda o corpo; os órgãos dos sentidos (olhos, ouvidos, nariz, língua e pele) recebem informações.',
      'Para ter saúde: alimentação equilibrada, beber água, fazer exercício físico, dormir bem e ter cuidados de higiene.'
    ],
    q: [
      ['Qual é o órgão que bombeia o sangue?', ['coração', 'pulmão', 'fígado', 'estômago']],
      ['Que órgãos filtram o sangue e produzem a urina?', ['rins', 'pulmões', 'intestinos', 'glândulas salivares']],
      ['Onde se fazem as trocas de oxigénio e dióxido de carbono?', ['nos pulmões', 'no estômago', 'nos rins', 'no fígado']],
      ['Qual é o percurso correto dos alimentos?', ['boca, esófago, estômago, intestinos', 'boca, traqueia, pulmões, estômago', 'esófago, boca, intestinos, estômago', 'boca, estômago, esófago, intestinos']],
      ['Que conjunto de ossos protege o cérebro?', ['crânio', 'costelas', 'fémur', 'bacia']],
      ['Os vasos que levam o sangue do coração para o resto do corpo chamam-se…', ['artérias', 'veias', 'brônquios', 'nervos']],
      ['O fígado e o pâncreas são glândulas anexas do sistema digestivo.', true],
      ['Quando inspiramos, o ar entra pelas fossas nasais.', true],
      ['O que permite o movimento do corpo, juntamente com os ossos?', ['os músculos', 'os rins', 'os pulmões', 'o estômago']]
    ]
  },
  {
    id: 'em4_relevo', t: 'Portugal: relevo, rios e costa',
    k: 'relevo,serras,serra,montanhas,serra da estrela,montanha do pico,rios,rio,rios de portugal,tejo,douro,mondego,guadiana,minho,sado,costa,litoral,arquipelagos,acores,madeira,ilhas,planicies,cabo da roca',
    ae: 'Localizar no mapa de Portugal as principais elevações, rios, arquipélagos e acidentes da costa.',
    r: [
      'Portugal tem o território continental e duas regiões autónomas: os arquipélagos dos Açores (9 ilhas) e da Madeira (ilhas da Madeira e do Porto Santo, e as ilhas Desertas e Selvagens).',
      'O ponto mais alto de Portugal é a Montanha do Pico, nos Açores (2351 m). No continente, o ponto mais alto fica na Serra da Estrela (1993 m).',
      'No norte e no centro há mais montanhas; no sul predominam as planícies (por exemplo, no Alentejo).',
      'O rio Tejo é o maior rio da Península Ibérica: nasce em Espanha e desagua junto a Lisboa.',
      'O Mondego é o maior rio que nasce e corre só em Portugal: nasce na Serra da Estrela e desagua na Figueira da Foz.',
      'Outros rios: Minho (fronteira a norte), Douro (desagua no Porto), Vouga, Sado (corre de sul para norte) e Guadiana (parte da fronteira a leste).',
      'Na costa há praias, arribas e cabos, como o Cabo da Roca (o ponto mais ocidental da Europa continental) e o Cabo de São Vicente.'
    ],
    q: [
      ['Qual é o ponto mais alto de Portugal?', ['Montanha do Pico', 'Serra da Estrela', 'Serra do Gerês', 'Serra de Monchique']],
      ['Qual é a serra mais alta de Portugal continental?', ['Serra da Estrela', 'Serra do Marão', 'Serra de Sintra', 'Serra do Caldeirão']],
      ['Quantas ilhas tem o arquipélago dos Açores?', ['9', '2', '7', '12']],
      ['Qual é o maior rio que nasce e corre só em Portugal?', ['Mondego', 'Tejo', 'Douro', 'Guadiana']],
      ['Em que cidade desagua o rio Douro?', ['Porto', 'Lisboa', 'Coimbra', 'Faro']],
      ['Qual é o maior rio da Península Ibérica?', ['Tejo', 'Douro', 'Minho', 'Mondego']],
      ['O Cabo da Roca é o ponto mais ocidental da Europa continental.', true],
      ['O Alentejo é uma região com muitas planícies.', true],
      ['Que rio faz fronteira com Espanha no extremo norte de Portugal?', ['Minho', 'Mondego', 'Sado', 'Vouga']]
    ]
  },
  {
    id: 'em4_mundo', t: 'Portugal na Europa e no Mundo',
    k: 'mapa,mapas,continentes,oceanos,europa,pontos cardeais,rosa dos ventos,norte,sul,este,oeste,planisferio,globo,orientacao,peninsula iberica',
    ae: 'Localizar Portugal na Europa e no Mundo, identificar continentes e oceanos e orientar-se com os pontos cardeais e a rosa dos ventos.',
    r: [
      'Pontos cardeais: Norte (N), Sul (S), Este (E) e Oeste (O). Pontos colaterais: Nordeste, Noroeste, Sudeste e Sudoeste.',
      'O Sol nasce a Este (Nascente) e põe-se a Oeste (Poente).',
      'Os continentes são: Europa, Ásia, África, América, Oceânia e Antártida.',
      'Os oceanos são: Atlântico, Pacífico (o maior), Índico, Glaciar Ártico e Glaciar Antártico.',
      'Portugal fica no sudoeste da Europa, na Península Ibérica, e só faz fronteira com Espanha (a norte e a leste). A oeste e a sul é banhado pelo Oceano Atlântico.',
      'O globo terrestre representa a Terra em forma de esfera; o planisfério é um mapa do mundo numa superfície plana.'
    ],
    q: [
      ['Onde nasce o Sol?', ['a Este', 'a Oeste', 'a Norte', 'a Sul']],
      ['Qual é o maior oceano?', ['Pacífico', 'Atlântico', 'Índico', 'Glaciar Ártico']],
      ['Com que país faz Portugal fronteira?', ['Espanha', 'França', 'Marrocos', 'Itália']],
      ['Que oceano banha Portugal?', ['Atlântico', 'Pacífico', 'Índico', 'Glaciar Ártico']],
      ['Em que continente fica Portugal?', ['Europa', 'África', 'América', 'Ásia']],
      ['Entre o Norte e o Este fica o…', ['Nordeste', 'Noroeste', 'Sudeste', 'Sudoeste']],
      ['O planisfério representa a Terra numa superfície plana.', true],
      ['Portugal fica na Península…', ['Ibérica', 'Itálica', 'Balcânica', 'Escandinava']]
    ]
  },
  {
    id: 'em4_universo', t: 'O Sistema Solar e os movimentos da Terra',
    k: 'sistema solar,planetas,planeta,sol,lua,fases da lua,terra,movimento de rotacao,rotacao,translacao,estacoes do ano,dia e noite,universo,estrelas,astros',
    ae: 'Identificar os astros do Sistema Solar e relacionar os movimentos da Terra com a sucessão dos dias e das noites e com as estações do ano.',
    r: [
      'O Sistema Solar tem o Sol (uma estrela) e 8 planetas: Mercúrio, Vénus, Terra, Marte, Júpiter, Saturno, Úrano e Neptuno.',
      'Mercúrio é o planeta mais próximo do Sol; Júpiter é o maior planeta.',
      'A Lua é o satélite natural da Terra. Não tem luz própria: reflete a luz do Sol.',
      'Movimento de rotação: a Terra gira sobre si própria em cerca de 24 horas → dá origem aos dias e às noites.',
      'Movimento de translação: a Terra dá uma volta ao Sol em cerca de 365 dias e 6 horas → associado às estações do ano (primavera, verão, outono e inverno).',
      'Fases da Lua: Lua Nova, Quarto Crescente, Lua Cheia e Quarto Minguante.'
    ],
    q: [
      ['Quantos planetas tem o Sistema Solar?', ['8', '9', '7', '10']],
      ['Qual é o maior planeta do Sistema Solar?', ['Júpiter', 'Saturno', 'Terra', 'Neptuno']],
      ['O movimento da Terra à volta do Sol chama-se…', ['translação', 'rotação', 'órbita lunar', 'eclipse']],
      ['Que movimento dá origem aos dias e às noites?', ['rotação', 'translação', 'o movimento da Lua', 'as marés']],
      ['Quanto tempo demora a Terra a dar uma volta completa ao Sol?', ['cerca de 365 dias', '24 horas', '30 dias', '7 dias']],
      ['O Sol é uma estrela.', true],
      ['A Lua tem luz própria.', false, 'A Lua reflete a luz do Sol.'],
      ['Qual é o planeta mais próximo do Sol?', ['Mercúrio', 'Vénus', 'Marte', 'Terra']],
      ['Em que fase vemos a Lua toda iluminada?', ['Lua Cheia', 'Lua Nova', 'Quarto Crescente', 'Quarto Minguante']]
    ]
  },
  {
    id: 'em4_materiais', t: 'Materiais, luz, ímanes e eletricidade',
    k: 'materiais,propriedades dos materiais,iman,imanes,magnetismo,eletricidade,circuito eletrico,circuitos,condutores,isoladores,luz,sombra,sombras,transparente,opaco,translucido,experiencias',
    ae: 'Realizar experiências com materiais: comportamento face à luz, aos ímanes e à corrente elétrica; montar circuitos elétricos simples.',
    r: [
      'Materiais transparentes deixam passar a luz e vê-se bem através deles (vidro); translúcidos deixam passar alguma luz (papel vegetal); opacos não deixam passar a luz (madeira) e formam sombra.',
      'Os ímanes atraem objetos de ferro e de alguns outros metais (como o níquel). Não atraem plástico, madeira, cortiça, alumínio ou cobre.',
      'Os ímanes têm dois polos: norte e sul. Polos iguais repelem-se; polos diferentes atraem-se.',
      'Os bons condutores deixam passar a corrente elétrica (metais, como o cobre); os isoladores não deixam (plástico, borracha, madeira seca).',
      'Um circuito elétrico simples tem uma fonte de energia (pilha), fios condutores, um recetor (lâmpada) e um interruptor. A lâmpada só acende com o circuito fechado.',
      'Nunca se deve mexer em tomadas ou aparelhos elétricos com as mãos molhadas.'
    ],
    q: [
      ['Um material que não deixa passar a luz é…', ['opaco', 'transparente', 'translúcido', 'condutor']],
      ['Qual destes objetos é atraído por um íman?', ['um prego de ferro', 'uma régua de plástico', 'uma rolha de cortiça', 'uma lata de alumínio']],
      ['Os polos norte de dois ímanes, quando aproximados…', ['repelem-se', 'atraem-se', 'não fazem nada', 'colam-se']],
      ['Qual destes materiais é um bom condutor elétrico?', ['cobre', 'borracha', 'plástico', 'cortiça']],
      ['Para a lâmpada de um circuito acender, o circuito tem de estar…', ['fechado', 'aberto', 'partido', 'sem pilha']],
      ['O vidro de uma janela é transparente.', true],
      ['A borracha é um material isolador.', true],
      ['Para que serve o interruptor num circuito?', ['abrir e fechar o circuito', 'produzir energia', 'fazer luz', 'aquecer os fios']]
    ]
  },
  {
    id: 'em4_ambiente', t: 'Ambiente, água e recursos naturais',
    k: 'ambiente,reciclagem,reciclar,ecoponto,ecopontos,poluicao,recursos naturais,agua,ciclo da agua,energias renovaveis,3r,reduzir,reutilizar,estados da agua,poupar agua,evaporacao,condensacao',
    ae: 'Reconhecer a importância dos recursos naturais e de comportamentos que protegem o ambiente; identificar os estados físicos da água e o ciclo da água.',
    r: [
      'Os 3 R: Reduzir (gastar menos), Reutilizar (voltar a usar) e Reciclar (transformar em novos produtos).',
      'Ecopontos: azul → papel e cartão; amarelo → embalagens de plástico e de metal; verde → vidro. As pilhas vão para o pilhão (vermelho).',
      'A água pode estar no estado sólido (gelo), líquido ou gasoso (vapor de água).',
      'Ciclo da água: evaporação (o calor do Sol transforma a água em vapor) → condensação (o vapor arrefece e forma nuvens) → precipitação (chuva, neve, granizo) → a água volta aos rios, ao solo e ao mar.',
      'Energias renováveis não se esgotam: solar, eólica (vento), hídrica (água) e das ondas. O petróleo e o carvão não são renováveis e poluem.',
      'A poluição pode afetar o ar, a água e o solo.'
    ],
    q: [
      ['Em que ecoponto se coloca uma garrafa de vidro?', ['verde', 'azul', 'amarelo', 'vermelho']],
      ['Onde se colocam as caixas de cartão?', ['no ecoponto azul', 'no ecoponto verde', 'no ecoponto amarelo', 'no pilhão']],
      ['Uma embalagem de iogurte de plástico vai para o ecoponto…', ['amarelo', 'verde', 'azul', 'vermelho']],
      ['Quando o vapor de água arrefece e forma nuvens, chama-se…', ['condensação', 'evaporação', 'precipitação', 'fusão']],
      ['Qual destas energias é renovável?', ['eólica', 'petróleo', 'carvão', 'gás natural']],
      ['O gelo é água no estado…', ['sólido', 'líquido', 'gasoso', 'quente']],
      ['Usar o mesmo saco de pano muitas vezes é um exemplo de…', ['reutilizar', 'reciclar', 'poluir', 'evaporar']],
      ['Fechar a torneira enquanto lavamos os dentes ajuda a poupar água.', true]
    ]
  }
]);

// ============================================================= INGLÊS
TEMAS(4, 'ing', [
  {
    id: 'ing4_vocab', t: 'Colours, numbers, family and school',
    k: 'ingles vocabulario,vocabulary,colours,colors,cores em ingles,numbers,numeros em ingles,family,familia em ingles,school objects,material escolar em ingles,animals,animais em ingles,food,comida em ingles',
    ae: 'Compreender e usar vocabulário sobre cores, números até 100, família, material escolar, animais e alimentos.',
    r: [
      'Colours: red (vermelho), blue (azul), yellow (amarelo), green (verde), orange (laranja), purple (roxo), pink (cor-de-rosa), black (preto), white (branco), brown (castanho), grey (cinzento).',
      'Numbers: twenty (20), thirty (30), forty (40), fifty (50), sixty (60), seventy (70), eighty (80), ninety (90), one hundred (100). Ex.: 45 = forty-five.',
      'Family: mother/mum, father/dad, sister, brother, grandmother/grandma, grandfather/grandpa, aunt, uncle, cousin.',
      'School objects: pencil, pen, rubber (borracha), ruler (régua), schoolbag, book, notebook, pencil case.',
      'Animals: dog, cat, bird, fish, horse, cow, rabbit, elephant, lion, monkey.',
      'Food: apple, banana, bread, milk, water, cheese, chicken, soup, cake, orange juice.'
    ],
    q: [
      ['How do you say "amarelo" in English?', ['yellow', 'green', 'purple', 'brown']],
      ['What number is "forty-five"?', ['45', '54', '40', '15']],
      ['"Grandmother" significa…', ['avó', 'mãe', 'tia', 'irmã']],
      ['What is "borracha" in English?', ['rubber', 'ruler', 'pencil', 'glue']],
      ['"Brother" significa…', ['irmão', 'primo', 'tio', 'pai']],
      ['How do you say "cinzento" in English?', ['grey', 'green', 'brown', 'black']],
      ['What number is "ninety"?', ['90', '19', '9', '99']],
      ['"Cousin" significa primo ou prima.', true],
      ['"Rabbit" significa…', ['coelho', 'rato', 'cavalo', 'pássaro']]
    ]
  },
  {
    id: 'ing4_days', t: 'Days, months, seasons and weather',
    k: 'dias da semana em ingles,days of the week,days,months,meses em ingles,seasons,estacoes do ano em ingles,weather,tempo em ingles,birthday',
    ae: 'Identificar os dias da semana, os meses, as estações do ano e o estado do tempo em inglês.',
    r: [
      'Days of the week: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday — sempre com letra maiúscula.',
      'Months: January, February, March, April, May, June, July, August, September, October, November, December.',
      'Seasons: spring (primavera), summer (verão), autumn (outono), winter (inverno).',
      'Weather: It\'s sunny (está sol), rainy (chuva), cloudy (nublado), windy (vento), snowy (neve), hot (calor), cold (frio).',
      'What\'s the weather like today? — It\'s sunny and hot!',
      'My birthday is in May. / Today is Monday.'
    ],
    q: [
      ['What day comes after Monday?', ['Tuesday', 'Sunday', 'Wednesday', 'Thursday']],
      ['"Sábado" in English is…', ['Saturday', 'Sunday', 'Thursday', 'Tuesday']],
      ['"Outono" in English is…', ['autumn', 'spring', 'summer', 'winter']],
      ['Which month comes after March?', ['April', 'May', 'February', 'June']],
      ['"It\'s rainy" significa…', ['está a chover', 'está sol', 'está vento', 'está frio']],
      ['"Winter" significa inverno.', true],
      ['Em inglês, os dias da semana escrevem-se com letra maiúscula.', true],
      ['"It\'s windy" significa…', ['está vento', 'está nublado', 'está a nevar', 'está calor']]
    ]
  },
  {
    id: 'ing4_grammar', t: 'Grammar: to be, have got, can',
    k: 'verb to be,to be,have got,has got,can,gramatica inglesa,gramatica de ingles,there is,there are,plural em ingles',
    ae: 'Usar o verbo to be, have got, can, there is/there are e plurais simples.',
    r: [
      'Verb to be: I am, you are, he/she/it is, we are, you are, they are. Forma curta: I\'m, you\'re, he\'s.',
      'Negativa: I\'m not, he isn\'t (is not), they aren\'t (are not).',
      'Have got (ter): I/you/we/they have got; he/she/it has got. Ex.: She has got a cat.',
      'Can (saber/conseguir): I can swim. I can\'t (cannot) fly. Can you dance? — Yes, I can. / No, I can\'t.',
      'There is (há — singular) / There are (há — plural): There is a book. There are two pens.',
      'Plurais: cat → cats; box → boxes; irregulares: child → children, man → men, foot → feet.'
    ],
    q: [
      ['She … my sister.', ['is', 'am', 'are', 'be']],
      ['They … got a dog.', ['have', 'has', 'is', 'are']],
      ['He … got blue eyes.', ['has', 'have', 'is', 'are']],
      ['Birds … fly.', ['can', 'can\'t', 'is', 'are']],
      ['I … ten years old.', ['am', 'is', 'are', 'have']],
      ['There … three apples on the table.', ['are', 'is', 'am', 'has']],
      ['What is the plural of "child"?', ['children', 'childs', 'childes', 'childrens']],
      ['"I can\'t swim" significa "eu não sei nadar".', true]
    ]
  },
  {
    id: 'ing4_routines', t: 'Routines, time, house and clothes',
    k: 'rotinas,routine,daily routine,clothes,roupa em ingles,house,casa em ingles,rooms,divisoes da casa,time,horas em ingles,what time is it,body,corpo em ingles,prepositions',
    ae: 'Descrever rotinas, dizer as horas e identificar divisões da casa, roupa, partes do corpo e preposições de lugar.',
    r: [
      'Daily routine: wake up, get up, have breakfast, brush my teeth, go to school, have lunch, do my homework, have dinner, go to bed.',
      'Telling the time: It\'s seven o\'clock (7:00); It\'s half past three (3:30); It\'s quarter past four (4:15).',
      'House: kitchen (cozinha), bedroom (quarto), bathroom (casa de banho), living room (sala), garden (jardim).',
      'Clothes: T-shirt, trousers (calças), skirt (saia), dress (vestido), shoes, socks, jacket, hat.',
      'Body: head, eyes, ears, nose, mouth, arms, hands, legs, feet.',
      'Prepositions: in (dentro de), on (em cima de), under (debaixo de), next to (ao lado de), behind (atrás de).'
    ],
    q: [
      ['"Cozinha" in English is…', ['kitchen', 'bedroom', 'bathroom', 'garden']],
      ['"It\'s half past three" corresponde a…', ['3:30', '3:15', '2:30', '3:45']],
      ['"Trousers" significa…', ['calças', 'saia', 'sapatos', 'meias']],
      ['The cat is … the table. (debaixo da mesa)', ['under', 'on', 'in', 'next to']],
      ['"I brush my teeth" significa…', ['eu lavo os dentes', 'eu tomo o pequeno-almoço', 'eu vou para a escola', 'eu penteio o cabelo']],
      ['"Feet" é o plural de "foot".', true],
      ['"It\'s seven o\'clock" significa…', ['são sete horas', 'são sete e meia', 'são onze horas', 'faltam sete minutos']]
    ]
  }
]);
