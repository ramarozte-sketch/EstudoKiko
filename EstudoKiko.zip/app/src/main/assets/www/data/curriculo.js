/*
 * Estrutura curricular — organizada segundo as Aprendizagens Essenciais (DGE)
 * em vigor no ano letivo 2026/2027 para o 4.º ano (1.º ciclo) e o 7.º ano (3.º ciclo).
 *
 * Cada tema: { id, t: título, k: palavras-chave para o reconhecimento por voz,
 *              ae: aprendizagem essencial resumida (usada também para orientar a IA),
 *              r: [pontos do resumo], q: [perguntas], gen: gerador opcional }
 * Pergunta:  [enunciado, [certa, errada1, errada2, ...], explicação?]
 *            [enunciado, true|false, explicação?]   -> Verdadeiro / Falso
 */
window.CUR = {
  disciplinas: {
    3: [
      { id: 'pt',  nome: 'Português',       emo: '📖', cor: '#FF5A5F' },
      { id: 'mat', nome: 'Matemática',      emo: '🔢', cor: '#4D96FF' },
      { id: 'em',  nome: 'Estudo do Meio',  emo: '🌍', cor: '#2EC4A0' },
      { id: 'ing', nome: 'Inglês',          emo: '💂', cor: '#9B5DE5' }
    ],
    4: [
      { id: 'pt',  nome: 'Português',       emo: '📖', cor: '#FF5A5F' },
      { id: 'mat', nome: 'Matemática',      emo: '🔢', cor: '#4D96FF' },
      { id: 'em',  nome: 'Estudo do Meio',  emo: '🌍', cor: '#2EC4A0' },
      { id: 'ing', nome: 'Inglês',          emo: '💂', cor: '#9B5DE5' }
    ],
    7: [
      { id: 'pt',   nome: 'Português',         emo: '📖', cor: '#FF5A5F' },
      { id: 'mat',  nome: 'Matemática',        emo: '🔢', cor: '#4D96FF' },
      { id: 'cn',   nome: 'Ciências Naturais', emo: '🌋', cor: '#2EC4A0' },
      { id: 'fq',   nome: 'Físico-Química',    emo: '⚗️', cor: '#00A6D6' },
      { id: 'hist', nome: 'História',          emo: '🏛️', cor: '#C98B2E' },
      { id: 'geo',  nome: 'Geografia',         emo: '🗺️', cor: '#5B8C3A' },
      { id: 'ing',  nome: 'Inglês',            emo: '💂', cor: '#9B5DE5' },
      { id: 'fr',   nome: 'Francês',           emo: '🥐', cor: '#3D5AFE' },
      { id: 'tic',  nome: 'TIC',               emo: '💻', cor: '#455A64' },
      { id: 'ev',   nome: 'Educação Visual',   emo: '🎨', cor: '#F15BB5' }
    ]
  },
  // manuais adotados na escola de cada filho (ano letivo 2026/2027)
  manuais: {
    4: { pt: 'PLIM Português 4.º ano (+ Manual Inclusivo)', mat: 'PLIM Matemática 4.º ano (+ Manual Inclusivo)', em: 'PLIM Estudo do Meio 4.º ano (+ Manual Inclusivo)', ing: 'Start the Magic! 4' },
    7: { pt: 'O Mundo em Palavras 7', mat: 'Espiral 7', cn: 'GEOCienTIC 7', fq: 'FQ 7', hist: 'Manual de História 7', geo: 'GEO+ 7', ing: 'Engaging 7', fr: 'Ça Marche ! 7', tic: 'TecnIC 7', ev: 'Novo Visual 7/8/9' }
  },
  // palavras que identificam cada disciplina numa frase falada (sem acentos)
  palavrasDisc: {
    pt: ['portugues', 'lingua portuguesa', 'gramatica'],
    mat: ['matematica', 'mate', 'contas'],
    em: ['estudo do meio', 'meio'],
    ing: ['ingles', 'english'],
    cn: ['ciencias', 'ciencias naturais', 'cn'],
    fq: ['fisico', 'quimica', 'fisico-quimica', 'fisico quimica', 'fq'],
    hist: ['historia'],
    geo: ['geografia'],
    fr: ['frances', 'french', 'francais'],
    tic: ['tic', 'informatica', 'tecnologias de informacao'],
    ev: ['educacao visual', 'visual', 'desenho']
  },
  temas: {},          // id -> tema
  porAno: { 3: {}, 4: {}, 7: {} }  // ano -> disciplina -> [temas]
};

window.TEMAS = function (ano, disc, lista) {
  const alvo = (CUR.porAno[ano][disc] = CUR.porAno[ano][disc] || []);
  lista.forEach(function (t) {
    t.ano = ano; t.disc = disc;
    CUR.temas[t.id] = t;
    alvo.push(t);
  });
};
