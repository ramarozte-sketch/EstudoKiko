/* Reforço de conteúdos: temas novos e mais perguntas nos temas existentes (3.º, 4.º e 7.º ano) */

// ================================================================ TEMAS NOVOS — 3.º ANO
TEMAS(3, 'em', [
  {
    id: 'em3_passado', t: 'A minha família e o passado',
    k: 'familia,arvore genealogica,passado,antigamente,friso cronologico,geracoes,avos,bisavos,datas,historia da familia,objetos antigos,tradicoes,festas',
    ae: 'Reconstituir o passado familiar e local, usando fontes (fotografias, objetos, testemunhos) e frisos cronológicos; identificar tradições e festas.',
    r: [
      'A árvore genealógica mostra a família: eu, pais, avós, bisavós… Cada nível é uma geração.',
      'Os pais dos meus pais são os meus avós; os irmãos dos meus pais são os meus tios; os filhos dos meus tios são os meus primos.',
      'Para conhecer o passado usamos fontes: fotografias, documentos, objetos antigos e conversas com os mais velhos.',
      'O friso cronológico organiza os acontecimentos por ordem de datas (do mais antigo para o mais recente).',
      'Década = 10 anos; século = 100 anos.',
      'Tradições e festas da localidade: santos populares, Carnaval, Natal, feiras e romarias.'
    ],
    q: [
      ['Os pais do meu pai são os meus…', ['avós', 'tios', 'primos', 'bisavós']],
      ['Os filhos dos meus tios são os meus…', ['primos', 'irmãos', 'sobrinhos', 'avós']],
      ['O que mostra uma árvore genealógica?', ['a família ao longo das gerações', 'as árvores da floresta', 'os meses do ano', 'o mapa da cidade']],
      ['Quantos anos tem uma década?', ['10', '100', '1', '1000']],
      ['Uma fotografia antiga é uma fonte para conhecer o passado.', true],
      ['Num friso cronológico os acontecimentos estão ordenados por…', ['datas', 'cores', 'tamanho', 'ordem alfabética']]
    ]
  },
  {
    id: 'em3_seguranca', t: 'Segurança: rua, casa e emergências',
    k: 'seguranca,regras de transito,passadeira,semaforo,sinais de transito,peao,cinto de seguranca,cadeirinha,emergencia,112,sismo,incendio,acidentes domesticos,bombeiros',
    ae: 'Conhecer regras de segurança rodoviária, prevenção de acidentes domésticos e comportamentos em situações de emergência.',
    r: [
      'Atravessa sempre na passadeira e com o sinal verde para os peões. Olha para a esquerda, para a direita e outra vez para a esquerda.',
      'No carro, as crianças viajam no banco de trás, com cadeirinha ou banco elevatório e cinto apertado.',
      'Na bicicleta usa capacete e roupa de cores vivas ou refletora.',
      'Em casa: não mexer em tomadas, fogões, medicamentos ou produtos de limpeza.',
      'Número europeu de emergência: 112. Diz o que aconteceu, onde estás e o teu nome.',
      'Num sismo: baixar, proteger e aguardar (debaixo de uma mesa). Num incêndio: sair rápido, baixinho por causa do fumo, e não usar o elevador.'
    ],
    q: [
      ['Qual é o número de emergência?', ['112', '911', '123', '100']],
      ['Onde se deve atravessar a rua?', ['na passadeira', 'entre carros estacionados', 'numa curva', 'em qualquer lado']],
      ['Na bicicleta deves usar…', ['capacete', 'chinelos', 'auscultadores', 'nada']],
      ['Num incêndio deves sair pelo elevador.', false, 'Nunca se usa o elevador num incêndio; usa as escadas.'],
      ['As crianças devem viajar no banco de trás com cadeirinha e cinto.', true],
      ['O que fazes durante um sismo?', ['baixar, proteger e aguardar', 'correr para a varanda', 'usar o elevador', 'ficar junto às janelas']]
    ]
  }
]);
TEMAS(3, 'mat', [
  {
    id: 'mat3_perimetro', t: 'Perímetro e área com quadrículas',
    k: 'perimetro,area,quadricula,quadriculas,contorno,medir o contorno,unidade de area',
    ae: 'Medir o perímetro de figuras e comparar áreas contando unidades (quadrículas).',
    r: [
      'O perímetro é o comprimento do contorno de uma figura: somam-se todos os lados.',
      'Um quadrado com lados de 3 cm tem perímetro 3 + 3 + 3 + 3 = 12 cm.',
      'A área é o espaço ocupado pela figura. Pode medir-se contando quadrículas.',
      'Duas figuras diferentes podem ter a mesma área (o mesmo número de quadrículas).'
    ],
    q: [
      ['O que é o perímetro?', ['o comprimento do contorno', 'o espaço de dentro', 'a altura', 'a cor da figura']],
      ['Um quadrado tem lados de 5 cm. Qual é o perímetro?', ['20 cm', '25 cm', '10 cm', '15 cm']],
      ['Um retângulo tem lados de 4 cm e 2 cm. Qual é o perímetro?', ['12 cm', '8 cm', '6 cm', '16 cm']],
      ['Uma figura ocupa 6 quadrículas. A sua área é…', ['6 quadrículas', '12 quadrículas', '3 quadrículas', '24 quadrículas']],
      ['Figuras diferentes podem ter a mesma área.', true]
    ]
  }
]);
TEMAS(3, 'ing', [
  {
    id: 'ing3_house', t: 'My house, clothes and the weather',
    k: 'house,casa em ingles,rooms,clothes,roupa em ingles,weather,tempo em ingles,sunny,rainy,days of the week',
    ae: 'Identificar divisões da casa, peças de roupa, o estado do tempo e os dias da semana em inglês.',
    r: [
      'House: kitchen (cozinha), bedroom (quarto), bathroom (casa de banho), living room (sala), garden (jardim).',
      'Clothes: T-shirt, trousers (calças), dress (vestido), skirt (saia), shoes (sapatos), hat (chapéu), coat (casaco).',
      'Weather: sunny (sol), rainy (chuva), cloudy (nublado), windy (vento), snowy (neve), hot (calor), cold (frio).',
      'Days: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday.'
    ],
    q: [
      ['"Bedroom" significa…', ['quarto', 'cozinha', 'sala', 'jardim']],
      ['"Shoes" significa…', ['sapatos', 'meias', 'calças', 'chapéu']],
      ['"It\'s sunny" significa…', ['está sol', 'está a chover', 'está vento', 'está frio']],
      ['What day comes after Sunday?', ['Monday', 'Saturday', 'Friday', 'Tuesday']],
      ['"Kitchen" significa cozinha.', true],
      ['"Cold" significa…', ['frio', 'calor', 'nuvem', 'neve']]
    ]
  }
]);

// ================================================================ TEMAS NOVOS — 4.º ANO
TEMAS(4, 'pt', [
  {
    id: 'pt4_tiposTexto', t: 'Textos do dia a dia: notícia, carta, receita, aviso',
    k: 'tipos de texto,texto informativo,noticia,carta,receita,aviso,convite,anuncio,banda desenhada,texto instrucional,entrevista',
    ae: 'Identificar a finalidade e a estrutura de textos do quotidiano (notícia, carta, receita, aviso, convite, anúncio, banda desenhada).',
    r: [
      'Notícia: informa sobre um acontecimento recente. Responde a: o quê? quem? quando? onde? como? porquê? Tem título (manchete) e lead.',
      'Carta: local e data, saudação, corpo da carta, despedida e assinatura.',
      'Receita (texto instrucional): título, ingredientes e modo de preparação, com verbos no imperativo ou infinitivo (Junte, Misture).',
      'Aviso: informação curta e importante (Proibido fumar; Piso molhado).',
      'Convite: o quê, quem convida, dia, hora e local.',
      'Anúncio publicitário: quer convencer a comprar ou a fazer algo, com slogan e imagens apelativas.'
    ],
    q: [
      ['Que texto tem "ingredientes" e "modo de preparação"?', ['receita', 'notícia', 'carta', 'poema']],
      ['Uma notícia serve para…', ['informar sobre um acontecimento', 'contar uma história inventada', 'dar uma receita', 'vender um produto']],
      ['O título de uma notícia chama-se também…', ['manchete', 'assinatura', 'saudação', 'estrofe']],
      ['Numa carta, a assinatura aparece…', ['no fim', 'no início', 'no título', 'não aparece']],
      ['O anúncio publicitário quer convencer as pessoas.', true],
      ['"Junte a farinha e mexa bem." Este texto é…', ['instrucional (receita)', 'poético', 'narrativo', 'uma notícia']]
    ]
  }
]);
TEMAS(4, 'ing', [
  {
    id: 'ing4_town', t: 'My town: places and directions',
    k: 'town,city,places in town,lugares na cidade,directions,direcoes,turn left,turn right,go straight on,shops,supermarket,school,hospital,park',
    ae: 'Identificar lugares da cidade e dar/compreender indicações simples de direção.',
    r: [
      'Places: school, park, supermarket, hospital, library (biblioteca), museum, cinema, swimming pool (piscina), bakery (padaria), zoo.',
      'Directions: turn left (vira à esquerda), turn right (vira à direita), go straight on (segue em frente).',
      'Where is the park? — It\'s next to the school. / It\'s opposite the cinema.',
      'Prepositions: next to (ao lado de), opposite (em frente a), between (entre), behind (atrás de).'
    ],
    q: [
      ['"Library" significa…', ['biblioteca', 'livraria só de venda', 'laboratório', 'liberdade']],
      ['"Turn left" significa…', ['vira à esquerda', 'vira à direita', 'segue em frente', 'para']],
      ['"Swimming pool" significa…', ['piscina', 'praia', 'parque', 'banheira']],
      ['"Go straight on" significa…', ['segue em frente', 'volta para trás', 'vira à direita', 'sobe']],
      ['"Between" significa "entre".', true],
      ['Where do you buy bread?', ['at the bakery', 'at the hospital', 'at the zoo', 'at the library']]
    ]
  }
]);

// ================================================================ TEMAS NOVOS — 7.º ANO
TEMAS(7, 'pt', [
  {
    id: 'pt7_textos', t: 'Textos não literários: notícia, entrevista, biografia, opinião',
    k: 'textos nao literarios,noticia,entrevista,biografia,autobiografia,texto de opiniao,artigo de opiniao,carta formal,texto expositivo,reportagem,roteiro,leitura',
    ae: 'Ler e escrever textos não literários: notícia, entrevista, biografia, texto de opinião, texto expositivo e carta formal.',
    r: [
      'Notícia: relato objetivo de um acontecimento atual; estrutura em pirâmide invertida (o mais importante primeiro). Título, lead (responde a o quê, quem, quando, onde, como, porquê) e corpo.',
      'Entrevista: conjunto de perguntas e respostas a uma pessoa; tem introdução que apresenta o entrevistado.',
      'Biografia: relato da vida de alguém escrito por outra pessoa, na 3.ª pessoa e por ordem cronológica. Autobiografia: escrita pelo próprio, na 1.ª pessoa.',
      'Texto de opinião: defende um ponto de vista com argumentos e exemplos; termina com uma conclusão. Usa conectores (em primeiro lugar, além disso, por isso, em suma).',
      'Texto expositivo: explica um tema de forma clara e objetiva (introdução, desenvolvimento, conclusão).',
      'Carta formal: local e data, destinatário, assunto, saudação formal (Exmo. Senhor), corpo, despedida formal (Com os melhores cumprimentos) e assinatura.'
    ],
    q: [
      ['Numa notícia, a parte que resume o essencial logo a seguir ao título chama-se…', ['lead', 'corpo', 'assinatura', 'didascália']],
      ['A biografia é escrita…', ['por outra pessoa, na 3.ª pessoa', 'pelo próprio, na 1.ª pessoa', 'em verso', 'só com diálogos']],
      ['Um texto que defende um ponto de vista com argumentos é um…', ['texto de opinião', 'texto narrativo', 'poema', 'roteiro']],
      ['"Com os melhores cumprimentos" é uma despedida de…', ['carta formal', 'mensagem a um amigo', 'receita', 'notícia']],
      ['Na notícia, a informação mais importante aparece no início (pirâmide invertida).', true],
      ['"Em suma" é um conector usado para…', ['concluir', 'dar um exemplo', 'opor ideias', 'indicar tempo']]
    ]
  }
]);
TEMAS(7, 'ing', [
  {
    id: 'ing7_grammar', t: 'Possessives, pronouns, prepositions and question words',
    k: 'possessive adjectives,possessives,object pronouns,pronouns,prepositions of time,in on at,question words,wh questions,what where when who why how,genitive,saxon genitive',
    ae: 'Usar adjetivos possessivos, pronomes pessoais complemento, o genitivo, preposições de tempo e palavras interrogativas.',
    r: [
      'Possessive adjectives: my, your, his, her, its, our, their (This is my book).',
      'Object pronouns: me, you, him, her, it, us, them (Call me! I like them).',
      'Saxon genitive: Tom\'s bike (a bicicleta do Tom); the girls\' room.',
      'Prepositions of time: at + hours (at 8 o\'clock), on + days/dates (on Monday, on 5th May), in + months/years/seasons (in May, in 2026, in summer).',
      'Question words: What (o quê), Where (onde), When (quando), Who (quem), Why (porquê), How (como), How many/How much (quantos/quanto).'
    ],
    q: [
      ['This is Ana. … brother is 10.', ['Her', 'His', 'Their', 'Its']],
      ['I love my grandparents. I visit … every Sunday.', ['them', 'they', 'their', 'us']],
      ['The party is … Saturday.', ['on', 'in', 'at', 'to']],
      ['My birthday is … July.', ['in', 'on', 'at', 'by']],
      ['… do you live? — In Lisbon.', ['Where', 'When', 'Who', 'Why']],
      ['"Tom\'s dog" means the dog belongs to Tom.', true],
      ['School starts … 8:30.', ['at', 'on', 'in', 'by']]
    ]
  }
]);
TEMAS(7, 'fr', [
  {
    id: 'fr7_loisirs', t: 'Les loisirs, les animaux et la maison',
    k: 'loisirs,tempos livres em frances,sports,desportos em frances,jouer au,faire du,animaux,animais em frances,maison,casa em frances,pieces,chambre,cuisine',
    ae: 'Falar de tempos livres, desportos, animais de estimação e da casa em francês.',
    r: [
      'Jouer au + jogo/desporto masculino: jouer au foot, au tennis, aux jeux vidéo. Jouer à la + feminino: à la console.',
      'Faire du / de la: faire du vélo, faire de la natation, faire du judo.',
      'Gostos: J\'aime lire, J\'adore la musique, Je n\'aime pas le sport.',
      'Animais: le chien, le chat, l\'oiseau, le poisson, le lapin, le cheval, la tortue.',
      'A casa: la chambre (quarto), la cuisine (cozinha), la salle de bains (casa de banho), le salon (sala), le jardin.'
    ],
    q: [
      ['Como se diz "jogar futebol"?', ['jouer au foot', 'jouer à foot', 'faire le foot', 'jouer du foot']],
      ['"Faire du vélo" significa…', ['andar de bicicleta', 'nadar', 'correr', 'jogar ténis']],
      ['"Le chien" significa…', ['o cão', 'o gato', 'o cavalo', 'o coelho']],
      ['"La cuisine" é…', ['a cozinha', 'o quarto', 'a sala', 'o jardim']],
      ['"J\'adore la musique" significa "Adoro música".', true],
      ['Como se diz "o quarto"?', ['la chambre', 'la cuisine', 'le salon', 'la salle de bains']]
    ]
  }
]);
TEMAS(7, 'geo', [
  {
    id: 'geo7_mundo', t: 'Continentes, oceanos e países',
    k: 'continentes,oceanos,paises,mundo,europa,asia,africa,america,oceania,antartida,localizacao de portugal,capitais,planisferio',
    ae: 'Localizar continentes, oceanos e alguns países, e caracterizar a posição de Portugal no mundo.',
    r: [
      'Continentes: Ásia (o maior e mais populoso), América, África, Antártida, Europa e Oceânia.',
      'Oceanos: Pacífico (o maior), Atlântico, Índico, Glaciar Ártico e Glaciar Antártico.',
      'Portugal fica no sudoeste da Europa, na Península Ibérica, banhado pelo Atlântico; inclui os arquipélagos dos Açores e da Madeira.',
      'A Europa e a Ásia formam um só bloco de terra (Eurásia), separados pelos Montes Urais.',
      'O Canal do Suez separa a África da Ásia; o Canal do Panamá liga o Atlântico ao Pacífico.'
    ],
    q: [
      ['Qual é o maior continente?', ['Ásia', 'América', 'África', 'Europa']],
      ['Qual é o maior oceano?', ['Pacífico', 'Atlântico', 'Índico', 'Glaciar Ártico']],
      ['Que montes separam a Europa da Ásia?', ['Urais', 'Alpes', 'Pirenéus', 'Himalaias']],
      ['Que canal liga o oceano Atlântico ao Pacífico?', ['Canal do Panamá', 'Canal do Suez', 'Canal da Mancha', 'Estreito de Gibraltar']],
      ['Portugal situa-se no sudoeste da Europa.', true],
      ['Em que continente fica o Brasil?', ['América', 'África', 'Europa', 'Oceânia']]
    ]
  }
]);
TEMAS(7, 'hist', [
  {
    id: 'hist7_legado', t: 'O legado da Grécia e de Roma',
    k: 'legado,heranca classica,cultura classica,arte grega,arte romana,teatro grego,filosofia,olimpiadas,arquitetura,ordens arquitetonicas,coliseu,panteao,direito romano,latim,numeracao romana,alfabeto',
    ae: 'Identificar o legado cultural grego e romano na sociedade atual (língua, direito, arte, ciência, desporto, política).',
    r: [
      'Herança grega: democracia, filosofia (Sócrates, Platão, Aristóteles), teatro (tragédia e comédia), Jogos Olímpicos, matemática (Pitágoras, Euclides), medicina (Hipócrates).',
      'Arquitetura grega: templos com colunas das ordens dórica (simples), jónica (com volutas) e coríntia (folhas de acanto). Ex.: Pártenon.',
      'Herança romana: língua latina (origem do português, espanhol, francês, italiano…), direito romano, numeração romana, calendário, estradas, pontes e aquedutos.',
      'Construções romanas: arco e abóbada, Coliseu (anfiteatro), Panteão, termas, fórum.',
      'A cultura greco-romana chama-se "cultura clássica" e influencia a arte e o pensamento até hoje.'
    ],
    q: [
      ['Que ordem arquitetónica grega tem capitéis com folhas de acanto?', ['coríntia', 'dórica', 'jónica', 'toscana']],
      ['O português deriva de que língua?', ['latim', 'grego', 'árabe', 'germânico']],
      ['Qual destes filósofos era grego?', ['Aristóteles', 'Júlio César', 'Augusto', 'Viriato']],
      ['Que número romano é XIV?', ['14', '16', '9', '41']],
      ['O Coliseu de Roma é um anfiteatro.', true],
      ['A tragédia e a comédia são heranças do teatro…', ['grego', 'egípcio', 'medieval', 'chinês']]
    ]
  }
]);

// ================================================================ MAIS PERGUNTAS NOS TEMAS EXISTENTES
(function () {
  const MAIS = {
    // ---------- 3.º ano
    pt3_classes: [
      ['Qual destas palavras é um nome comum?', ['bicicleta', 'Porto', 'Pedro', 'Tejo']],
      ['"Cardume" é um conjunto de…', ['peixes', 'abelhas', 'ovelhas', 'lobos']],
      ['Qual é o artigo definido feminino plural?', ['as', 'os', 'umas', 'a']]
    ],
    pt3_frase: [
      ['"Gostas de chocolate?" termina com…', ['ponto de interrogação', 'ponto final', 'ponto de exclamação', 'vírgula']],
      ['"Eu não quero sopa." é uma frase…', ['negativa', 'afirmativa', 'interrogativa', 'exclamativa']]
    ],
    mat3_numeros: [
      ['Qual é o número ímpar?', ['47', '48', '50', '62']],
      ['Qual é o antecessor de 1000?', ['999', '1001', '990', '100']],
      ['Quantas unidades tem 1 dezena?', ['10', '100', '1', '1000']]
    ],
    mat3_adicao: [
      ['Quanto é 300 + 400?', ['700', '600', '7000', '340']],
      ['Quanto é 90 − 45?', ['45', '55', '35', '135']]
    ],
    mat3_tabuada: [
      ['Quanto é 7 × 8?', ['56', '54', '48', '63']],
      ['Quanto é 9 × 9?', ['81', '72', '99', '18']],
      ['Qual é o quádruplo de 5?', ['20', '9', '25', '15']]
    ],
    em3_plantas: [
      ['Que parte da planta se transforma em fruto?', ['a flor', 'a raiz', 'o caule', 'a folha']],
      ['O nenúfar é uma planta…', ['aquática', 'do deserto', 'sem folhas', 'que não precisa de água']]
    ],
    em3_animais: [
      ['O peixe tem o corpo coberto de…', ['escamas', 'penas', 'pelos', 'carapaça']],
      ['O leão come outros animais. É…', ['carnívoro', 'herbívoro', 'omnívoro', 'ovíparo']],
      ['A tartaruga tem uma carapaça.', true]
    ],
    em3_corpo: [
      ['Com que órgão ouvimos?', ['ouvido', 'nariz', 'olhos', 'língua']],
      ['O conjunto dos ossos chama-se…', ['esqueleto', 'músculo', 'pele', 'sangue']]
    ],
    // ---------- 4.º ano
    pt4_classes: [
      ['Em "Ela vive aqui.", "aqui" é um advérbio de…', ['lugar', 'tempo', 'modo', 'negação']],
      ['"Esta" em "Esta caneta é minha." é um determinante…', ['demonstrativo', 'possessivo', 'artigo definido', 'interrogativo']],
      ['"Multidão" é um nome…', ['coletivo', 'próprio', 'adjetivo', 'verbo']]
    ],
    pt4_verbos: [
      ['Qual é o pretérito perfeito de "eu ir"?', ['eu fui', 'eu ia', 'eu irei', 'eu vou']],
      ['"Vocês estudam muito." Em que tempo está o verbo?', ['presente', 'pretérito perfeito', 'futuro', 'imperativo']],
      ['Qual é a forma do imperativo de "comer" (tu)?', ['Come!', 'Comes!', 'Comeste!', 'Comerás!']]
    ],
    pt4_frase: [
      ['Em "O João deu um presente à Rita.", qual é o complemento direto?', ['um presente', 'à Rita', 'O João', 'deu']],
      ['"Que medo!" é uma frase…', ['exclamativa', 'imperativa', 'declarativa', 'interrogativa']]
    ],
    mat4_fracoes: [
      ['Quanto é 3/4 de 20?', ['15', '5', '12', '16']],
      ['Qual fração representa metade?', ['2/4', '1/3', '3/4', '1/5']]
    ],
    mat4_geometria: [
      ['Um triângulo com dois lados iguais é…', ['isósceles', 'equilátero', 'escaleno', 'obtusângulo']],
      ['Quantos lados tem um octógono?', ['8', '6', '10', '7']],
      ['Um ângulo de 180° é…', ['raso', 'reto', 'agudo', 'obtuso']]
    ],
    em4_historia: [
      ['Qual foi o primeiro rei da 2.ª dinastia, vencedor em Aljubarrota?', ['D. João I', 'D. Afonso Henriques', 'D. Manuel I', 'D. Sebastião']],
      ['Quem era o Infante D. Henrique?', ['impulsionador dos Descobrimentos', 'primeiro rei de Portugal', 'presidente da República', 'navegador que chegou à Índia']],
      ['Em 1580, Portugal passou a ter reis de…', ['Espanha', 'França', 'Inglaterra', 'Marrocos']]
    ],
    em4_corpo: [
      ['Onde começa a digestão?', ['na boca', 'no estômago', 'no intestino grosso', 'nos rins']],
      ['O ar entra nos pulmões através da traqueia e dos…', ['brônquios', 'rins', 'intestinos', 'ossos']]
    ],
    em4_universo: [
      ['Qual é o planeta conhecido como "planeta vermelho"?', ['Marte', 'Júpiter', 'Vénus', 'Saturno']],
      ['Que planeta tem anéis muito visíveis?', ['Saturno', 'Marte', 'Mercúrio', 'Terra']]
    ],
    // ---------- 7.º ano
    pt7_funcoes: [
      ['Em "O livro está na mesa.", "na mesa" é…', ['complemento oblíquo', 'complemento direto', 'modificador do nome', 'sujeito']],
      ['Em "A casa amarela é nova.", "amarela" é…', ['modificador do nome', 'predicativo do sujeito', 'complemento direto', 'vocativo']],
      ['Em "Telefonei ao meu avô.", "ao meu avô" é…', ['complemento indireto', 'complemento direto', 'sujeito', 'modificador']]
    ],
    pt7_verbos: [
      ['"Talvez ele venha amanhã." "Venha" está no…', ['presente do conjuntivo', 'presente do indicativo', 'futuro', 'imperativo']],
      ['"Tinha" em "Eu tinha um cão." está no…', ['pretérito imperfeito do indicativo', 'pretérito perfeito', 'condicional', 'conjuntivo']]
    ],
    mat7_equacoes: [
      ['Qual é a solução de x − 9 = −4?', ['x = 5', 'x = −13', 'x = 13', 'x = −5']],
      ['Qual é a solução de 3(x − 2) = 12?', ['x = 6', 'x = 4', 'x = 2', 'x = 14/3']],
      ['O triplo de um número menos 5 é 16. Que número é?', ['7', '11', '3', '21']]
    ],
    mat7_potencias: [
      ['Quanto é 10³?', ['1000', '30', '100', '10 000']],
      ['5⁶ : 5² é igual a…', ['5⁴', '5³', '5⁸', '1⁴']]
    ],
    cn7_tectonica: [
      ['A teoria da tectónica de placas explica…', ['o movimento das placas litosféricas', 'a formação das nuvens', 'as fases da Lua', 'a fotossíntese']],
      ['As placas tectónicas movem-se sobre a…', ['astenosfera', 'atmosfera', 'hidrosfera', 'crosta oceânica']]
    ],
    cn7_magmaticas: [
      ['Que rocha forma a ilha do Pico e muitas ilhas dos Açores?', ['basalto', 'granito', 'mármore', 'calcário']],
      ['A cratera é a abertura no topo do vulcão.', true]
    ],
    fq7_materiais: [
      ['A maionese é um exemplo de…', ['coloide', 'substância', 'solução', 'mistura heterogénea visível']],
      ['O oxigénio puro é uma…', ['substância', 'mistura homogénea', 'mistura heterogénea', 'coloide']]
    ],
    fq7_universo: [
      ['A grande galáxia espiral mais próxima da Via Láctea é…', ['Andrómeda', 'Orion', 'Sirius', 'Plutão']],
      ['Um ano-luz é a distância percorrida pela luz em…', ['um ano', 'um dia', 'uma hora', 'um segundo']]
    ],
    hist7_grecia: [
      ['Qual era a cidade-estado grega famosa pela educação militar?', ['Esparta', 'Atenas', 'Roma', 'Cartago']],
      ['Em Atenas, o ostracismo permitia…', ['exilar um cidadão considerado perigoso', 'eleger o rei', 'libertar escravos', 'declarar guerra a Roma']]
    ],
    hist7_roma: [
      ['Como se chamavam os cidadãos ricos e privilegiados de Roma?', ['patrícios', 'plebeus', 'metecos', 'servos']],
      ['O local central das cidades romanas, com templos e edifícios públicos, era o…', ['fórum', 'coliseu', 'aqueduto', 'termas']]
    ],
    geo7_clima: [
      ['O que é a precipitação?', ['a água que cai da atmosfera (chuva, neve, granizo)', 'a temperatura máxima', 'a força do vento', 'a humidade do solo']],
      ['O clima define-se a partir de observações de pelo menos…', ['30 anos', '1 mês', '1 ano', '5 dias']]
    ],
    ing7_past: [
      ['What is the past simple of "see"?', ['saw', 'seed', 'seen', 'sawed']],
      ['They … to Paris last summer.', ['went', 'go', 'gone', 'goes']]
    ],
    ing7_present: [
      ['How often … you go to the cinema?', ['do', 'does', 'are', 'is']],
      ['She is … a book right now.', ['reading', 'reads', 'read', 'readed']]
    ]
  };
  Object.keys(MAIS).forEach((id) => {
    const t = CUR.temas[id];
    if (t) MAIS[id].forEach((q) => t.q.push(q));
  });
})();
