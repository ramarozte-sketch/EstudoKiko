/* 3.º ano — 1.º ciclo do ensino básico (Aprendizagens Essenciais em vigor 2026/2027) */

// ============================================================= PORTUGUÊS
TEMAS(3, 'pt', [
  {
    id: 'pt3_classes', t: 'Nomes, adjetivos, verbos e determinantes',
    k: 'classes de palavras,nomes,nome,nome proprio,nome comum,nome coletivo,adjetivo,adjetivos,verbo,verbos,determinante,artigo,artigos,pronome pessoal',
    ae: 'Identificar nomes (próprios, comuns e coletivos), adjetivos qualificativos, verbos, determinantes artigos e pronomes pessoais.',
    r: [
      'Nome: palavra que dá nome a pessoas, animais, coisas e lugares. Nome próprio escreve-se com letra maiúscula (Ana, Lisboa); nome comum com minúscula (gato, mesa).',
      'Nome coletivo: nome de um conjunto (rebanho = conjunto de ovelhas; cardume = de peixes; enxame = de abelhas; bando = de aves).',
      'Adjetivo: diz como é o nome (alto, simpático, vermelho).',
      'Verbo: indica uma ação (correr, saltar, ler).',
      'Artigos definidos: o, a, os, as. Artigos indefinidos: um, uma, uns, umas.',
      'Pronomes pessoais: eu, tu, ele, ela, nós, vós, eles, elas — substituem os nomes.'
    ],
    q: [
      ['Qual destas palavras é um nome próprio?', ['Maria', 'menina', 'bonita', 'correr']],
      ['"Rebanho" é um nome coletivo de…', ['ovelhas', 'peixes', 'abelhas', 'pássaros']],
      ['Na frase "O cão castanho ladra.", qual é o adjetivo?', ['castanho', 'cão', 'ladra', 'O']],
      ['Qual destas palavras é um verbo?', ['nadar', 'nadador', 'azul', 'mar']],
      ['"Um" é um artigo…', ['indefinido', 'definido', 'próprio', 'coletivo']],
      ['Na frase "Ela gosta de ler.", "Ela" é um pronome pessoal.', true],
      ['"Enxame" é um conjunto de…', ['abelhas', 'lobos', 'livros', 'árvores']],
      ['Os nomes próprios escrevem-se com letra maiúscula.', true]
    ]
  },
  {
    id: 'pt3_flexao', t: 'Masculino e feminino, singular e plural',
    k: 'masculino,feminino,genero,singular,plural,numero,diminutivo,aumentativo,grau',
    ae: 'Flexionar nomes e adjetivos em género (masculino/feminino) e número (singular/plural); formar diminutivos e aumentativos.',
    r: [
      'Masculino: o menino, o gato. Feminino: a menina, a gata.',
      'Alguns femininos são palavras diferentes: pai → mãe, homem → mulher, boi → vaca, galo → galinha.',
      'Singular: um (a flor). Plural: mais do que um (as flores).',
      'Para formar o plural: casa → casas; flor → flores; papel → papéis; balão → balões; pão → pães; mão → mãos.',
      'Diminutivo: coisa pequena (casinha, gatinho). Aumentativo: coisa grande (casarão, gatão).'
    ],
    q: [
      ['Qual é o feminino de "galo"?', ['galinha', 'gala', 'galona', 'galinho']],
      ['Qual é o feminino de "pai"?', ['mãe', 'paia', 'paizinha', 'madrinha']],
      ['Qual é o plural de "flor"?', ['flores', 'flors', 'floris', 'florres']],
      ['Qual é o plural de "balão"?', ['balões', 'balãos', 'balães', 'balãoes']],
      ['Qual é o diminutivo de "gato"?', ['gatinho', 'gatão', 'gatos', 'gataria']],
      ['"Casarão" é o aumentativo de "casa".', true],
      ['Qual é o plural de "papel"?', ['papéis', 'papels', 'papeles', 'papéles']]
    ]
  },
  {
    id: 'pt3_silabas', t: 'Sílabas, sílaba tónica e acentos',
    k: 'silabas,silaba,silaba tonica,divisao silabica,acentos,acento,acento agudo,acento circunflexo,til,monossilabo,dissilabo,trissilabo,polissilabo',
    ae: 'Dividir palavras em sílabas, identificar a sílaba tónica e conhecer os sinais gráficos (acentos e til).',
    r: [
      'As palavras dividem-se em sílabas: mo-chi-la.',
      'Monossílabas (1 sílaba: sol), dissílabas (2: ca-sa), trissílabas (3: sa-pa-to) e polissílabas (4 ou mais: bor-bo-le-ta).',
      'A sílaba tónica é a que se diz com mais força: ca-FÉ, ME-sa, LÂM-pa-da.',
      'Acento agudo ( ´ ): som aberto — café, avó. Acento circunflexo ( ^ ): som fechado — avô, você.',
      'Til ( ~ ): som nasal — mãe, pão, limões.',
      'Na divisão silábica, rr e ss separam-se: car-ro, pás-sa-ro.'
    ],
    q: [
      ['Quantas sílabas tem "sapato"?', ['três', 'duas', 'quatro', 'uma']],
      ['Qual é a sílaba tónica de "café"?', ['fé', 'ca', 'não tem', 'as duas']],
      ['Qual é a palavra monossílaba?', ['mar', 'mar-é', 'marinheiro', 'mar-ti-lo']],
      ['Qual é a divisão silábica correta de "pássaro"?', ['pás-sa-ro', 'pá-ssa-ro', 'páss-a-ro', 'pá-s-saro']],
      ['Em "mãe", o til indica um som…', ['nasal', 'aberto', 'fechado', 'mudo']],
      ['"Borboleta" é uma palavra polissílaba.', true],
      ['Qual é a palavra com acento circunflexo?', ['avô', 'avó', 'café', 'mãe']]
    ]
  },
  {
    id: 'pt3_frase', t: 'Tipos de frase e pontuação',
    k: 'tipos de frase,frase,frases,declarativa,interrogativa,exclamativa,imperativa,afirmativa,negativa,pontuacao,ponto final,ponto de interrogacao,ponto de exclamacao,virgula,travessao,dois pontos',
    ae: 'Identificar tipos de frase (declarativa, interrogativa, exclamativa e imperativa; afirmativa e negativa) e usar os sinais de pontuação.',
    r: [
      'Frase declarativa: conta ou informa algo — termina com ponto final (O Rui tem um cão.).',
      'Frase interrogativa: faz uma pergunta — termina com ponto de interrogação (Gostas de gelado?).',
      'Frase exclamativa: mostra uma emoção — termina com ponto de exclamação (Que bonito!).',
      'Frase imperativa: dá uma ordem ou um pedido (Fecha a porta, por favor.).',
      'Frase afirmativa: Eu gosto de sopa. Frase negativa: Eu não gosto de sopa.',
      'A vírgula separa palavras numa enumeração (Comprei maçãs, peras e uvas.). O travessão marca a fala de uma personagem.'
    ],
    q: [
      ['"Que dia tão lindo!" é uma frase…', ['exclamativa', 'interrogativa', 'declarativa', 'negativa']],
      ['"Onde moras?" é uma frase…', ['interrogativa', 'exclamativa', 'imperativa', 'declarativa']],
      ['"Arruma os brinquedos." é uma frase…', ['imperativa', 'interrogativa', 'exclamativa', 'negativa']],
      ['Qual é a forma negativa de "O Tomás joga à bola."?', ['O Tomás não joga à bola.', 'O Tomás joga muito à bola.', 'O Tomás joga à bola?', 'O Tomás joga à bola!']],
      ['No fim de uma pergunta coloca-se…', ['ponto de interrogação', 'ponto final', 'vírgula', 'travessão']],
      ['O travessão marca a fala das personagens.', true],
      ['Qual frase está bem pontuada?', ['Gosto de cães, gatos e coelhos.', 'Gosto, de cães gatos e coelhos.', 'Gosto de cães gatos, e coelhos.', 'Gosto de, cães, gatos coelhos.']]
    ]
  },
  {
    id: 'pt3_palavras', t: 'Sinónimos, antónimos, famílias e ordem alfabética',
    k: 'sinonimos,sinonimo,antonimos,antonimo,familia de palavras,familias de palavras,ordem alfabetica,alfabeto,dicionario',
    ae: 'Identificar sinónimos, antónimos e famílias de palavras; ordenar palavras alfabeticamente e consultar o dicionário.',
    r: [
      'Sinónimos: palavras com significado parecido (alegre = contente; bonito = lindo).',
      'Antónimos: palavras com significado contrário (grande ↔ pequeno; dia ↔ noite).',
      'Família de palavras: palavras que nascem da mesma palavra (flor, florista, floreira, florido).',
      'O alfabeto tem 26 letras: a b c d e f g h i j k l m n o p q r s t u v w x y z.',
      'Ordem alfabética: compara-se a primeira letra; se for igual, a segunda, e assim por diante (bola, boneca, brinquedo). Os dicionários estão em ordem alfabética.'
    ],
    q: [
      ['Qual é um sinónimo de "bonito"?', ['lindo', 'feio', 'grande', 'rápido']],
      ['Qual é o antónimo de "frio"?', ['quente', 'gelado', 'molhado', 'fresco']],
      ['Qual destas palavras pertence à família de "flor"?', ['florista', 'floresta', 'flauta', 'fruta']],
      ['Qual é a palavra que vem primeiro na ordem alfabética?', ['abelha', 'bola', 'casa', 'dado']],
      ['Qual vem primeiro: "bola" ou "boneca"?', ['bola', 'boneca', 'são iguais', 'depende']],
      ['O alfabeto português tem 26 letras.', true],
      ['Qual é o antónimo de "subir"?', ['descer', 'saltar', 'correr', 'trepar']]
    ]
  },
  {
    id: 'pt3_ortografia', t: 'Ortografia',
    k: 'ortografia,escrever bem,erros,r ou rr,s ou ss,cedilha,c cedilhado,m antes de p e b,nh,lh,ch,letra h',
    ae: 'Escrever corretamente palavras com dificuldades ortográficas frequentes.',
    r: [
      'Entre vogais: r tem som brando (caro) e rr tem som forte (carro); s tem som de z (casa) e ss tem som de s (massa).',
      'O ç (cê cedilhado) só se usa antes de a, o, u: caçar, poço, açúcar.',
      'Antes de p e b escreve-se m: campo, sombra. Antes das outras letras escreve-se n: canto.',
      'Nh, lh e ch representam um só som: ninho, folha, chuva.',
      'O h no início da palavra não se lê: horta, hoje, homem.'
    ],
    q: [
      ['Como se escreve o nome do veículo com rodas e motor?', ['carro', 'caro', 'karro', 'carrro']],
      ['Qual palavra está bem escrita?', ['sombra', 'sonbra', 'sõbra', 'sombrra']],
      ['Como se escreve o buraco fundo de onde se tira água?', ['poço', 'posso', 'poso', 'pooço']],
      ['Completa: a … da árvore caiu.', ['folha', 'follha', 'foia', 'folla']],
      ['Qual palavra está bem escrita?', ['hoje', 'oje', 'hoge', 'oge']],
      ['Antes de "p" e "b" escreve-se sempre "m".', true],
      ['Qual palavra está bem escrita?', ['chuva', 'xuva', 'chuba', 'shuva']]
    ]
  },
  {
    id: 'pt3_textos', t: 'Histórias, poemas, cartas e convites',
    k: 'texto narrativo,historia,historias,personagens,personagem,poema,poesia,verso,estrofe,rima,carta,convite,banda desenhada,receita,texto',
    ae: 'Identificar elementos da narrativa e do poema; conhecer a estrutura de textos do dia a dia (carta, convite, receita).',
    r: [
      'Uma história tem personagens (quem?), espaço (onde?), tempo (quando?) e ação (o que acontece?).',
      'Partes da história: princípio (introdução), meio (desenvolvimento) e fim (conclusão).',
      'O poema escreve-se em versos (cada linha). Um grupo de versos é uma estrofe. A rima é a repetição do som final (pão / limão).',
      'A carta tem: local e data, saudação (Querida avó,), mensagem, despedida (Um beijinho,) e assinatura.',
      'O convite indica: o que é a festa, o dia, a hora e o local.',
      'A banda desenhada conta histórias com vinhetas e balões de fala.'
    ],
    q: [
      ['Numa história, o "espaço" diz-nos…', ['onde acontece', 'quando acontece', 'quem participa', 'quantas páginas tem']],
      ['Cada linha de um poema chama-se…', ['verso', 'estrofe', 'rima', 'título']],
      ['"Pão" rima com…', ['limão', 'mesa', 'sol', 'livro']],
      ['Numa carta, "Querida avó," é a…', ['saudação', 'despedida', 'assinatura', 'data']],
      ['O que não pode faltar num convite?', ['dia, hora e local', 'uma receita', 'uma rima', 'uma estrofe']],
      ['Na banda desenhada as falas aparecem em balões.', true]
    ]
  }
]);

// ============================================================= MATEMÁTICA (AE 2021)
TEMAS(3, 'mat', [
  {
    id: 'mat3_numeros', t: 'Números e valor posicional', gen: 'numeros3',
    k: 'numeros,numero,milhar,milhares,centenas,dezenas,unidades,valor posicional,comparar numeros,pares,impares,ordinais,numeros ordinais,maior,menor',
    ae: 'Ler, representar, comparar e ordenar números naturais, compreendendo o valor posicional; identificar números pares e ímpares e números ordinais.',
    r: [
      'Ordens: unidades (U), dezenas (D), centenas (C) e milhares (M). 10 unidades = 1 dezena; 10 dezenas = 1 centena; 10 centenas = 1 milhar.',
      'Em 3 452: 3 milhares, 4 centenas, 5 dezenas e 2 unidades. Lê-se "três mil quatrocentos e cinquenta e dois".',
      'Comparar: > maior do que; < menor do que; = igual a.',
      'Números pares terminam em 0, 2, 4, 6 ou 8; números ímpares terminam em 1, 3, 5, 7 ou 9.',
      'Números ordinais indicam a ordem: 1.º primeiro, 2.º segundo, 3.º terceiro, 10.º décimo.'
    ],
    q: [
      ['Quantas dezenas tem 1 centena?', ['10', '100', '1', '1000']],
      ['Qual é o maior número?', ['2 310', '2 301', '2 130', '1 999']],
      ['Qual destes números é par?', ['348', '345', '351', '1 001']],
      ['Como se escreve "mil e cinquenta"?', ['1 050', '1 500', '150', '1 005']],
      ['Que sinal completa: 450 … 405?', ['>', '<', '=', '+']],
      ['O 3.º lê-se "terceiro".', true],
      ['Quantas centenas tem 1 milhar?', ['10', '100', '1000', '1']]
    ]
  },
  {
    id: 'mat3_adicao', t: 'Adição e subtração', gen: 'adicao3',
    k: 'adicao,somar,soma,contas de mais,subtracao,subtrair,contas de menos,diferenca,parcelas,calculo mental,algoritmo,vai um',
    ae: 'Adicionar e subtrair números naturais com os algoritmos e estratégias de cálculo mental, resolvendo problemas.',
    r: [
      'Adição: os números chamam-se parcelas e o resultado soma ou total (25 + 13 = 38).',
      'Subtração: o resultado chama-se diferença (40 − 15 = 25).',
      'No algoritmo, alinham-se as unidades com as unidades, as dezenas com as dezenas…; quando a soma passa de 9, "vai um" para a ordem seguinte.',
      'A ordem das parcelas não altera a soma: 7 + 5 = 5 + 7.',
      'A subtração confirma-se com uma adição: se 40 − 15 = 25, então 25 + 15 = 40.',
      'Cálculo mental: 48 + 9 = 48 + 10 − 1 = 57.'
    ],
    q: [
      ['Como se chama o resultado de uma adição?', ['soma', 'diferença', 'produto', 'parcela']],
      ['Quanto é 250 + 150?', ['400', '300', '350', '450']],
      ['Quanto é 100 − 35?', ['65', '75', '135', '55']],
      ['A Rita tinha 120 cromos e deu 45. Com quantos ficou?', ['75', '85', '165', '65']],
      ['7 + 5 = 5 + 7', true],
      ['Quanto é 48 + 9?', ['57', '56', '58', '47']]
    ]
  },
  {
    id: 'mat3_tabuada', t: 'Multiplicação e tabuadas', gen: 'tabuada4',
    k: 'multiplicacao,multiplicar,tabuada,tabuadas,vezes,produto,dobro,triplo,quadruplo',
    ae: 'Compreender a multiplicação, memorizar as tabuadas e usar o dobro, o triplo e o quádruplo.',
    r: [
      'Multiplicar é somar parcelas iguais: 4 × 3 = 3 + 3 + 3 + 3 = 12.',
      'O resultado chama-se produto. A ordem dos fatores não altera o produto: 4 × 3 = 3 × 4.',
      'Dobro = × 2; triplo = × 3; quádruplo = × 4.',
      'Qualquer número × 1 = o próprio número; qualquer número × 0 = 0.',
      'Multiplicar por 10: acrescenta-se um zero (7 × 10 = 70).'
    ],
    q: [
      ['Quanto é 6 × 7?', ['42', '36', '48', '13']],
      ['Qual é o dobro de 15?', ['30', '17', '45', '25']],
      ['Quanto é 8 × 10?', ['80', '18', '800', '810']],
      ['5 + 5 + 5 + 5 é o mesmo que…', ['4 × 5', '5 × 5', '4 + 5', '20 × 4']],
      ['9 × 0 = 0', true],
      ['Qual é o triplo de 7?', ['21', '14', '10', '28']]
    ]
  },
  {
    id: 'mat3_divisao', t: 'Divisão, metade e terça parte', gen: 'divisao3',
    k: 'divisao,dividir,repartir,partilhar,metade,terca parte,quarta parte,quociente,grupos iguais',
    ae: 'Compreender a divisão como partilha em partes iguais e como formação de grupos; relacioná-la com a multiplicação.',
    r: [
      'Dividir é repartir em partes iguais: 12 : 3 = 4 (12 rebuçados por 3 meninos, cada um recebe 4).',
      'Também serve para saber quantos grupos se fazem: com 12 ovos, quantas caixas de 6? 12 : 6 = 2.',
      'A divisão é o contrário da multiplicação: se 3 × 4 = 12, então 12 : 3 = 4.',
      'Metade = dividir por 2; terça parte = dividir por 3; quarta parte = dividir por 4.',
      'O resultado da divisão chama-se quociente.'
    ],
    q: [
      ['Quanto é 20 : 4?', ['5', '4', '16', '80']],
      ['Qual é a metade de 18?', ['9', '8', '36', '6']],
      ['Qual é a terça parte de 15?', ['5', '3', '45', '12']],
      ['Se 6 × 5 = 30, então 30 : 6 = …', ['5', '6', '24', '36']],
      ['Com 24 ovos, quantas caixas de 6 ovos se enchem?', ['4', '6', '18', '3']],
      ['O resultado da divisão chama-se quociente.', true]
    ]
  },
  {
    id: 'mat3_fracoes', t: 'Frações: metade, terço e quarto', gen: 'fracoes3',
    k: 'fracoes,fracao,metade,meio,terco,quarto,quinto,decimo,partes iguais,numerador,denominador',
    ae: 'Compreender frações unitárias (1/2, 1/3, 1/4, 1/5, 1/10) como partes iguais de uma unidade ou de uma quantidade.',
    r: [
      'Uma fração mostra partes iguais de um todo.',
      '1/2 = um meio (metade); 1/3 = um terço; 1/4 = um quarto; 1/5 = um quinto; 1/10 = um décimo.',
      'Em 1/4, o 4 (denominador) diz em quantas partes iguais se divide e o 1 (numerador) quantas se tomam.',
      'Quanto mais partes, mais pequena é cada parte: 1/2 > 1/3 > 1/4.',
      'Duas metades fazem a unidade: 1/2 + 1/2 = 1. Quatro quartos também: 4/4 = 1.'
    ],
    q: [
      ['Uma pizza foi dividida em 4 partes iguais. Cada parte é…', ['um quarto (1/4)', 'um meio (1/2)', 'um terço (1/3)', 'um décimo (1/10)']],
      ['Qual é maior: 1/2 ou 1/4?', ['1/2', '1/4', 'são iguais', 'não se pode saber']],
      ['Quanto é metade de 20?', ['10', '5', '40', '2']],
      ['Quantos quartos tem uma unidade?', ['4', '2', '1', '10']],
      ['Duas metades formam uma unidade.', true],
      ['Como se lê 1/3?', ['um terço', 'um quarto', 'três', 'um meio']]
    ]
  },
  {
    id: 'mat3_geometria', t: 'Figuras geométricas, retas e simetria',
    k: 'geometria,figuras geometricas,figuras planas,poligonos,triangulo,quadrado,retangulo,circulo,pentagono,hexagono,lados,vertices,retas,paralelas,perpendiculares,angulo reto,simetria,eixo de simetria',
    ae: 'Identificar e descrever figuras planas (lados e vértices), retas paralelas e perpendiculares, ângulos retos e simetrias.',
    r: [
      'Polígonos: triângulo (3 lados), quadrilátero (4 lados — quadrado, retângulo), pentágono (5), hexágono (6).',
      'Os vértices são os "cantos" onde se juntam os lados.',
      'O quadrado tem 4 lados iguais e 4 ângulos retos. O retângulo tem 4 ângulos retos e lados opostos iguais.',
      'O círculo não é um polígono: não tem lados retos.',
      'Retas paralelas nunca se encontram (como os carris do comboio). Retas perpendiculares cruzam-se e formam ângulos retos.',
      'Uma figura tem simetria quando, dobrada pelo eixo de simetria, as duas metades ficam iguais.'
    ],
    q: [
      ['Quantos lados tem um pentágono?', ['5', '6', '4', '8']],
      ['Quantos vértices tem um triângulo?', ['3', '4', '2', '6']],
      ['Que figura tem 4 lados iguais e 4 ângulos retos?', ['quadrado', 'retângulo comprido', 'triângulo', 'hexágono']],
      ['O círculo é um polígono.', false, 'O círculo não tem lados retos.'],
      ['Os carris de um comboio lembram retas…', ['paralelas', 'perpendiculares', 'curvas', 'cruzadas']],
      ['Quantos lados tem um hexágono?', ['6', '5', '8', '4']]
    ]
  },
  {
    id: 'mat3_solidos', t: 'Sólidos geométricos',
    k: 'solidos,solidos geometricos,cubo,paralelepipedo,piramide,esfera,cilindro,cone,faces,arestas,vertices,rolar',
    ae: 'Identificar e descrever sólidos geométricos (cubo, paralelepípedo, pirâmide, cilindro, cone e esfera).',
    r: [
      'O cubo tem 6 faces quadradas iguais, 12 arestas e 8 vértices (ex.: um dado).',
      'O paralelepípedo tem 6 faces retangulares (ex.: uma caixa de sapatos).',
      'A esfera é redonda e rola em todas as direções (ex.: uma bola).',
      'O cilindro tem 2 bases em forma de círculo e rola (ex.: uma lata).',
      'O cone tem 1 base circular e um bico (ex.: um chapéu de festa).',
      'A pirâmide tem faces triangulares que se juntam num vértice.'
    ],
    q: [
      ['Um dado tem a forma de um…', ['cubo', 'cilindro', 'cone', 'esfera']],
      ['Uma bola tem a forma de uma…', ['esfera', 'pirâmide', 'cubo', 'cone']],
      ['Uma lata de conserva tem a forma de um…', ['cilindro', 'cubo', 'cone', 'paralelepípedo']],
      ['Quantas faces tem um cubo?', ['6', '4', '8', '12']],
      ['O cone tem uma base em forma de círculo.', true],
      ['Qual destes sólidos rola em todas as direções?', ['esfera', 'cubo', 'pirâmide', 'paralelepípedo']]
    ]
  },
  {
    id: 'mat3_medida', t: 'Comprimento, massa e capacidade', gen: 'medida3',
    k: 'medidas,medida,comprimento,metro,centimetro,quilometro,massa,peso,quilograma,grama,capacidade,litro,mililitro,regua,balanca',
    ae: 'Medir comprimentos, massas e capacidades com unidades do sistema métrico e relacioná-las.',
    r: [
      'Comprimento mede-se em metros (m). 1 m = 100 cm; 1 km = 1000 m. Usa-se a régua ou a fita métrica.',
      'Massa mede-se em quilogramas (kg) e gramas (g). 1 kg = 1000 g. Usa-se a balança.',
      'Capacidade mede-se em litros (L). 1 L = 1000 mL; meio litro = 500 mL.',
      'Para distâncias grandes usa-se o quilómetro; para objetos pequenos, o centímetro.'
    ],
    q: [
      ['Quantos centímetros tem 1 metro?', ['100', '10', '1000', '50']],
      ['Com que instrumento se mede a massa?', ['balança', 'régua', 'relógio', 'termómetro']],
      ['Quantos gramas tem 1 quilograma?', ['1000', '100', '10', '500']],
      ['Meio litro de leite tem…', ['500 mL', '50 mL', '100 mL', '1000 mL']],
      ['Para medir a distância entre duas cidades usa-se o quilómetro.', true],
      ['Qual é a unidade mais adequada para medir um lápis?', ['centímetro', 'quilómetro', 'litro', 'quilograma']]
    ]
  },
  {
    id: 'mat3_tempo', t: 'Tempo, calendário e dinheiro', gen: 'tempo4',
    k: 'tempo,horas,minutos,relogio,calendario,dias da semana,meses,ano,dinheiro,euros,euro,centimos,moedas,notas,troco',
    ae: 'Ler as horas, usar o calendário e resolver problemas com dinheiro.',
    r: [
      '1 dia = 24 horas; 1 hora = 60 minutos; meia hora = 30 minutos; um quarto de hora = 15 minutos.',
      'Uma semana tem 7 dias; um ano tem 12 meses e 365 dias (366 nos anos bissextos).',
      'Meses com 31 dias: janeiro, março, maio, julho, agosto, outubro e dezembro. Fevereiro tem 28 ou 29.',
      '1 euro = 100 cêntimos. Moedas: 1, 2, 5, 10, 20, 50 cêntimos, 1 € e 2 €. Notas: 5 €, 10 €, 20 €, 50 €…',
      'Troco = dinheiro entregue − preço.'
    ],
    q: [
      ['Quantos minutos tem meia hora?', ['30', '15', '60', '45']],
      ['Quantos dias tem uma semana?', ['7', '5', '10', '12']],
      ['Quantos meses tem um ano?', ['12', '10', '7', '52']],
      ['Pagaste 2 € por um gelado de 1,50 €. Quanto recebes de troco?', ['0,50 €', '1 €', '3,50 €', '0,25 €']],
      ['1 euro = 100 cêntimos.', true],
      ['Qual destes meses tem 31 dias?', ['julho', 'abril', 'junho', 'novembro']]
    ]
  },
  {
    id: 'mat3_dados', t: 'Tabelas e gráficos',
    k: 'dados,tabelas,tabela,graficos,grafico de barras,pictograma,pictogramas,contagens,moda,mais votado',
    ae: 'Recolher, organizar e interpretar dados em tabelas, pictogramas e gráficos de barras.',
    r: [
      'Os dados podem ser contados e registados numa tabela.',
      'No pictograma, cada desenho vale uma quantidade (ver a legenda).',
      'No gráfico de barras, a barra mais alta é a que tem mais votos.',
      'A moda é o que aparece mais vezes (o mais escolhido).'
    ],
    q: [
      ['Num gráfico de barras, a barra mais alta mostra…', ['o que tem mais votos', 'o que tem menos votos', 'o título', 'a legenda']],
      ['Num pictograma, 1 ⭐ = 2 alunos. Quantos alunos são 4 ⭐?', ['8', '4', '6', '2']],
      ['Animais preferidos: cão 9, gato 6, peixe 2. Qual é a moda?', ['cão', 'gato', 'peixe', '9']],
      ['A legenda de um pictograma diz quanto vale cada desenho.', true],
      ['Na turma, 12 alunos gostam de futebol e 8 de natação. Quantos alunos responderam?', ['20', '4', '12', '96']]
    ]
  }
]);

// ============================================================= ESTUDO DO MEIO
TEMAS(3, 'em', [
  {
    id: 'em3_plantas', t: 'As plantas',
    k: 'plantas,planta,raiz,caule,folhas,flor,fruto,semente,germinacao,germinar,folha caduca,folha persistente,arvores,o que as plantas precisam',
    ae: 'Identificar as partes de uma planta e as suas funções, as condições necessárias à germinação e ao crescimento e a diversidade de plantas.',
    r: [
      'Partes da planta: raiz (fixa a planta e absorve água e sais minerais), caule (sustenta e transporta a seiva), folhas (produzem o alimento da planta com a luz do Sol), flor, fruto e semente.',
      'As plantas precisam de água, luz, ar e de um solo com nutrientes.',
      'Germinação: a semente, com água, ar e temperatura adequada, começa a crescer e dá origem a uma nova planta.',
      'Árvores de folha caduca perdem as folhas no outono (castanheiro, carvalho). Árvores de folha persistente têm folhas todo o ano (pinheiro, sobreiro, oliveira).',
      'Há plantas terrestres e aquáticas (nenúfar). As plantas libertam oxigénio, que é importante para respirarmos.'
    ],
    q: [
      ['Que parte da planta absorve a água do solo?', ['raiz', 'flor', 'folha', 'fruto']],
      ['O que precisa uma semente para germinar?', ['água, ar e temperatura adequada', 'só escuridão', 'sal', 'nada']],
      ['O pinheiro é uma árvore de folha…', ['persistente', 'caduca', 'aquática', 'sem folhas']],
      ['Que parte da planta produz o alimento com a luz do Sol?', ['folha', 'raiz', 'semente', 'caule']],
      ['Dentro do fruto encontramos…', ['as sementes', 'as raízes', 'o caule', 'a terra']],
      ['As plantas libertam oxigénio.', true],
      ['Qual destas árvores perde as folhas no outono?', ['castanheiro', 'pinheiro', 'oliveira', 'sobreiro']]
    ]
  },
  {
    id: 'em3_animais', t: 'Os animais',
    k: 'animais,animal,revestimento,pelos,penas,escamas,locomocao,alimentacao,herbivoros,carnivoros,omnivoros,oviparos,viviparos,reproducao,domesticos,selvagens,cadeia alimentar',
    ae: 'Classificar animais quanto ao revestimento, locomoção, alimentação e reprodução; distinguir animais domésticos e selvagens.',
    r: [
      'Revestimento: pelos (cão), penas (galinha), escamas (peixe), pele nua (rã), carapaça ou concha (tartaruga, caracol).',
      'Locomoção: andam/correm, voam, nadam, rastejam ou saltam.',
      'Alimentação: herbívoros comem plantas (vaca); carnívoros comem outros animais (leão); omnívoros comem de tudo (porco, ser humano).',
      'Reprodução: ovíparos nascem de ovos (galinha, peixe); vivíparos nascem da barriga da mãe (cão, golfinho).',
      'Animais domésticos vivem com as pessoas (gato); selvagens vivem livres na natureza (lobo).',
      'Cadeia alimentar: erva → coelho → raposa (cada ser serve de alimento ao seguinte).'
    ],
    q: [
      ['Qual é o revestimento de uma galinha?', ['penas', 'pelos', 'escamas', 'pele nua']],
      ['A vaca come erva. É um animal…', ['herbívoro', 'carnívoro', 'omnívoro', 'aquático']],
      ['Os animais que nascem de ovos chamam-se…', ['ovíparos', 'vivíparos', 'herbívoros', 'domésticos']],
      ['O golfinho é vivíparo.', true, 'As crias nascem da barriga da mãe e mamam.'],
      ['Qual destes animais é selvagem?', ['lobo', 'gato', 'galinha', 'cão']],
      ['Como se desloca uma cobra?', ['rasteja', 'voa', 'salta', 'nada só']],
      ['Na cadeia erva → coelho → raposa, quem come o coelho?', ['a raposa', 'a erva', 'ninguém', 'outro coelho']]
    ]
  },
  {
    id: 'em3_corpo', t: 'O meu corpo e a saúde',
    k: 'corpo,corpo humano,sentidos,cinco sentidos,orgaos,ossos,esqueleto,musculos,coracao,pulmoes,estomago,cerebro,saude,alimentacao saudavel,roda dos alimentos,higiene',
    ae: 'Identificar os órgãos dos sentidos, os principais órgãos do corpo e as regras de higiene e de alimentação saudável.',
    r: [
      'Os cinco sentidos: visão (olhos), audição (ouvidos), olfato (nariz), paladar (língua) e tato (pele).',
      'Os ossos formam o esqueleto e os músculos ajudam-nos a mexer.',
      'O cérebro (na cabeça) comanda o corpo; o coração bombeia o sangue; os pulmões servem para respirar; o estômago ajuda a digerir os alimentos.',
      'A Roda dos Alimentos ensina a comer de tudo, em quantidades certas, e a beber água.',
      'Higiene: lavar as mãos antes de comer, lavar os dentes depois das refeições, tomar banho.',
      'Dormir bem e fazer exercício também fazem parte de uma vida saudável.'
    ],
    q: [
      ['Com que órgão sentimos os cheiros?', ['nariz', 'ouvido', 'língua', 'olhos']],
      ['Que órgão bombeia o sangue?', ['coração', 'estômago', 'pulmão', 'cérebro']],
      ['Para que servem os pulmões?', ['para respirar', 'para ver', 'para digerir', 'para pensar']],
      ['O tato sente-se através da…', ['pele', 'língua', 'orelha', 'unha']],
      ['Devemos lavar as mãos antes de comer.', true],
      ['O que nos ajuda a escolher uma alimentação equilibrada?', ['a Roda dos Alimentos', 'o calendário', 'o mapa', 'o relógio']]
    ]
  },
  {
    id: 'em3_localidade', t: 'A minha localidade e as autarquias',
    k: 'localidade,freguesia,concelho,municipio,distrito,autarquias,junta de freguesia,camara municipal,presidente da camara,assembleia municipal,servicos publicos,brasao,bandeira do concelho',
    ae: 'Identificar a freguesia, o concelho e o distrito onde vive e os órgãos das autarquias locais e as suas funções.',
    r: [
      'Portugal está dividido em concelhos (municípios), e cada concelho em freguesias. No continente, os concelhos agrupam-se em distritos.',
      'A Junta de Freguesia trata de assuntos da freguesia (por exemplo, atestados, jardins, apoio à população).',
      'A Câmara Municipal governa o concelho (ruas, escolas do 1.º ciclo, recolha do lixo, água, transportes).',
      'O Presidente da Câmara é eleito pelos cidadãos do concelho, tal como a Assembleia Municipal.',
      'Cada concelho tem os seus símbolos: brasão e bandeira.',
      'Serviços públicos: escola, centro de saúde, correios, bombeiros, polícia, biblioteca.'
    ],
    q: [
      ['Quem governa o concelho?', ['a Câmara Municipal', 'a escola', 'o centro de saúde', 'os bombeiros']],
      ['Cada concelho divide-se em…', ['freguesias', 'distritos', 'países', 'continentes']],
      ['Como é escolhido o Presidente da Câmara?', ['é eleito pelos cidadãos', 'é sorteado', 'é o mais velho', 'é o diretor da escola']],
      ['A Junta de Freguesia trata de assuntos da freguesia.', true],
      ['Qual é um símbolo do concelho?', ['o brasão', 'o hino de Inglaterra', 'a roda dos alimentos', 'o semáforo']],
      ['Qual destes é um serviço público?', ['centro de saúde', 'loja de brinquedos', 'pastelaria', 'cinema privado']]
    ]
  },
  {
    id: 'em3_atividades', t: 'Atividades económicas e profissões',
    k: 'atividades economicas,profissoes,profissao,setor primario,setor secundario,setor terciario,agricultura,pesca,industria,comercio,servicos,turismo,transportes,trabalho',
    ae: 'Identificar atividades económicas (primárias, secundárias e terciárias) e profissões da localidade.',
    r: [
      'Setor primário: tirar produtos da natureza — agricultura, pecuária (criar animais), pesca e exploração da floresta.',
      'Setor secundário: transformar matérias-primas em produtos — fábricas (indústria) e construção.',
      'Setor terciário: prestar serviços — comércio, saúde, educação, transportes, turismo.',
      'Exemplos: agricultor e pescador (primário); operário fabril e pedreiro (secundário); professor, médico, vendedor, motorista (terciário).',
      'Todas as profissões são importantes e dependem umas das outras.'
    ],
    q: [
      ['O pescador trabalha no setor…', ['primário', 'secundário', 'terciário', 'nenhum']],
      ['Uma fábrica de bolachas pertence ao setor…', ['secundário', 'primário', 'terciário', 'escolar']],
      ['O professor presta um serviço. Trabalha no setor…', ['terciário', 'primário', 'secundário', 'industrial']],
      ['Criar animais chama-se…', ['pecuária', 'indústria', 'comércio', 'turismo']],
      ['O comércio e o turismo pertencem ao setor terciário.', true],
      ['Quem constrói casas?', ['o pedreiro', 'o pescador', 'o médico', 'o carteiro']]
    ]
  },
  {
    id: 'em3_materiais', t: 'Materiais, água e ar',
    k: 'materiais,material,madeira,metal,plastico,vidro,papel,tecido,propriedades,flutua,afunda,transparente,opaco,agua,estados da agua,gelo,vapor,ar,vento,reciclagem',
    ae: 'Explorar propriedades de materiais e realizar experiências simples com a água e o ar.',
    r: [
      'Materiais: madeira, metal, plástico, vidro, papel, tecido, cortiça. Cada um tem propriedades diferentes.',
      'Rígido (não dobra: madeira) ou flexível (dobra: borracha); transparente (vidro) ou opaco (madeira).',
      'Alguns objetos flutuam na água (cortiça, madeira) e outros afundam (pedra, prego).',
      'A água pode estar sólida (gelo), líquida ou gasosa (vapor). Aquecida evapora; arrefecida congela a 0 °C.',
      'O ar está à nossa volta, mesmo sem o vermos. O vento é ar em movimento.',
      'Reciclar: papel no ecoponto azul, embalagens no amarelo, vidro no verde.'
    ],
    q: [
      ['Qual destes materiais é transparente?', ['vidro', 'madeira', 'metal', 'cartão']],
      ['Qual destes objetos flutua na água?', ['rolha de cortiça', 'prego', 'pedra', 'moeda']],
      ['O gelo é água no estado…', ['sólido', 'líquido', 'gasoso', 'quente']],
      ['O vento é ar em movimento.', true],
      ['Em que ecoponto se põe o jornal velho?', ['azul', 'verde', 'amarelo', 'vermelho']],
      ['Um elástico é um material…', ['flexível', 'rígido', 'transparente', 'de vidro']]
    ]
  },
  {
    id: 'em3_orientacao', t: 'Orientação, o Sol e o tempo',
    k: 'orientacao,pontos cardeais,norte,sul,este,oeste,sol,nascer do sol,por do sol,sombra,dia e noite,estacoes do ano,primavera,verao,outono,inverno,estado do tempo,termometro',
    ae: 'Orientar-se usando os pontos cardeais e o Sol; relacionar o dia e a noite e as estações do ano; registar o estado do tempo.',
    r: [
      'Pontos cardeais: Norte, Sul, Este e Oeste.',
      'O Sol nasce a Este (nascente) e põe-se a Oeste (poente).',
      'A sombra de um objeto muda ao longo do dia: é mais curta ao meio-dia.',
      'O dia e a noite acontecem porque a Terra gira sobre si mesma.',
      'Estações do ano: primavera, verão, outono e inverno.',
      'O estado do tempo pode ser: sol, chuva, nuvens, vento, nevoeiro, neve. A temperatura mede-se com o termómetro.'
    ],
    q: [
      ['De que lado nasce o Sol?', ['Este', 'Oeste', 'Norte', 'Sul']],
      ['Quantas estações tem o ano?', ['4', '2', '12', '7']],
      ['Com que instrumento se mede a temperatura?', ['termómetro', 'régua', 'balança', 'relógio']],
      ['A que hora a sombra é mais curta?', ['ao meio-dia', 'ao nascer do Sol', 'ao pôr do Sol', 'à meia-noite']],
      ['O Sol põe-se a Oeste.', true],
      ['Em que estação as árvores de folha caduca perdem as folhas?', ['outono', 'primavera', 'verão', 'nenhuma']]
    ]
  }
]);

// ============================================================= INGLÊS (1.º ano de Inglês, nível A1)
TEMAS(3, 'ing', [
  {
    id: 'ing3_hello', t: 'Hello! Greetings and numbers 1-20',
    k: 'hello,greetings,cumprimentos em ingles,whats your name,how old are you,numbers,numeros em ingles,one to twenty,goodbye',
    ae: 'Cumprimentar, apresentar-se e contar até 20 em inglês.',
    r: [
      'Hello! / Hi! (olá), Goodbye! / Bye! (adeus), Good morning! (bom dia), Good afternoon! (boa tarde), Good night! (boa noite).',
      'What\'s your name? — My name is Tomás. / How are you? — I\'m fine, thank you!',
      'How old are you? — I\'m eight (years old).',
      'Numbers: one, two, three, four, five, six, seven, eight, nine, ten.',
      'eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen, twenty.',
      'Please (por favor), thank you (obrigado), sorry (desculpa).'
    ],
    q: [
      ['How do you say "olá" in English?', ['Hello', 'Goodbye', 'Please', 'Sorry']],
      ['"What\'s your name?" significa…', ['Como te chamas?', 'Quantos anos tens?', 'Como estás?', 'Onde moras?']],
      ['What number is "twelve"?', ['12', '20', '2', '11']],
      ['How do you say 8 in English?', ['eight', 'eighteen', 'six', 'nine']],
      ['"Thank you" significa obrigado.', true],
      ['What number is "fifteen"?', ['15', '50', '5', '14']]
    ]
  },
  {
    id: 'ing3_colours', t: 'Colours, school objects and toys',
    k: 'colours,colors,cores em ingles,school objects,material escolar em ingles,toys,brinquedos em ingles,classroom',
    ae: 'Identificar cores, objetos da sala de aula e brinquedos em inglês.',
    r: [
      'Colours: red, blue, yellow, green, orange, pink, purple, black, white, brown.',
      'School objects: pencil (lápis), pen (caneta), rubber (borracha), ruler (régua), book (livro), schoolbag (mochila), pencil case (estojo), crayons (lápis de cera).',
      'Toys: ball (bola), doll (boneca), car (carro), kite (papagaio de papel), teddy bear (urso de peluche), bike (bicicleta).',
      'What colour is it? — It\'s red!',
      'Classroom: Sit down! Stand up! Open your book! Listen!'
    ],
    q: [
      ['"Azul" in English is…', ['blue', 'black', 'brown', 'green']],
      ['"Pencil" significa…', ['lápis', 'caneta', 'borracha', 'régua']],
      ['What colour is a banana?', ['yellow', 'purple', 'blue', 'pink']],
      ['"Teddy bear" significa…', ['urso de peluche', 'boneca', 'bola', 'carro']],
      ['"Sit down!" significa "Senta-te!".', true],
      ['"Schoolbag" significa…', ['mochila', 'estojo', 'livro', 'caderno']]
    ]
  },
  {
    id: 'ing3_family', t: 'Family, pets, food and body',
    k: 'family,familia em ingles,pets,animais em ingles,food,comida em ingles,body,corpo em ingles,i like,mother,father',
    ae: 'Identificar membros da família, animais de estimação, alimentos e partes do corpo; exprimir gostos (I like / I don\'t like).',
    r: [
      'Family: mum, dad, brother, sister, grandma, grandpa, baby.',
      'Pets: dog, cat, fish, bird, rabbit, hamster, turtle.',
      'Food: apple, banana, orange, bread, milk, water, cake, pizza, chicken, ice cream.',
      'Body: head, eyes, ears, nose, mouth, arms, hands, legs, feet.',
      'I like apples! 😀 / I don\'t like fish. 😕',
      'I\'ve got a dog. (Tenho um cão.)'
    ],
    q: [
      ['"Sister" significa…', ['irmã', 'mãe', 'avó', 'tia']],
      ['"Coelho" in English is…', ['rabbit', 'bird', 'turtle', 'fish']],
      ['"Milk" significa…', ['leite', 'pão', 'água', 'bolo']],
      ['"Nose" significa…', ['nariz', 'boca', 'orelha', 'olho']],
      ['"I like apples" significa "Eu gosto de maçãs".', true],
      ['How do you say "avô" in English?', ['grandpa', 'grandma', 'dad', 'brother']]
    ]
  }
]);
