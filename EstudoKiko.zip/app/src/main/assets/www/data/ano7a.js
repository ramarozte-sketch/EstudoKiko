/* 7.º ano — 3.º ciclo (Aprendizagens Essenciais em vigor 2026/2027): Português, Matemática, Ciências Naturais, Físico-Química */

// ============================================================= PORTUGUÊS
TEMAS(7, 'pt', [
  {
    id: 'pt7_classes', t: 'Classes de palavras',
    k: 'classes de palavras,classe de palavras,nomes,adjetivos,determinantes,pronomes,pronome,quantificadores,adverbios,preposicoes,conjuncoes,conjuncao,interjeicao',
    ae: 'Identificar e classificar nomes, adjetivos, verbos, advérbios, determinantes, pronomes, quantificadores, preposições, conjunções e interjeições.',
    r: [
      'Nome: próprio, comum (contável/não contável) e coletivo (alcateia, arquipélago).',
      'Adjetivo: qualificativo (lindo), relacional (escolar, solar — não varia em grau) e numeral (primeiro).',
      'Determinantes acompanham o nome: artigo (o, um), demonstrativo (este), possessivo (meu), indefinido (algum, certo), interrogativo (que livro?) e relativo (cujo).',
      'Pronomes substituem o nome: pessoal (eu, me, lhe), demonstrativo (isto, aquilo), possessivo (o meu), indefinido (alguém, nada), interrogativo (quem?) e relativo (que, quem, o qual, onde).',
      'Quantificadores: numeral (três), universal (todos, ambos, cada) e existencial (alguns, vários, muitos).',
      'Advérbios: de negação, afirmação, tempo, lugar, modo, quantidade e grau, inclusão (também), exclusão (só, apenas), interrogativo (onde? quando?) e conectivo (contudo, depois).',
      'Conjunções coordenativas (e, mas, ou, portanto, pois) e subordinativas (porque, quando, para que, se, que).',
      'Preposições ligam palavras (a, de, em, para, com, sem, sobre, entre…).'
    ],
    q: [
      ['Em "Alguém bateu à porta.", "alguém" é um…', ['pronome indefinido', 'determinante indefinido', 'quantificador existencial', 'advérbio']],
      ['Em "Todos os alunos vieram.", "todos" é um…', ['quantificador universal', 'pronome indefinido', 'determinante artigo', 'adjetivo']],
      ['Em "O livro cujo autor conheço é ótimo.", "cujo" é um…', ['determinante relativo', 'pronome relativo', 'conjunção', 'advérbio']],
      ['"Mas" é uma conjunção…', ['coordenativa adversativa', 'subordinativa causal', 'coordenativa copulativa', 'subordinativa temporal']],
      ['Em "Ela só come fruta.", "só" é um advérbio de…', ['exclusão', 'inclusão', 'modo', 'tempo']],
      ['"Solar" em "energia solar" é um adjetivo…', ['relacional', 'qualificativo', 'numeral', 'possessivo']],
      ['Em "Dá-lhe o livro.", "lhe" é um pronome pessoal.', true],
      ['Em "Que filme queres ver?", "que" é um…', ['determinante interrogativo', 'pronome relativo', 'conjunção', 'advérbio interrogativo']],
      ['"Alcateia" é um nome coletivo.', true],
      ['Em "Isto é meu.", "isto" é um…', ['pronome demonstrativo', 'determinante demonstrativo', 'advérbio de lugar', 'nome']]
    ]
  },
  {
    id: 'pt7_funcoes', t: 'Funções sintáticas',
    k: 'funcoes sintaticas,funcao sintatica,sujeito,predicado,complemento direto,complemento indireto,complemento obliquo,predicativo do sujeito,modificador,vocativo,complemento agente da passiva,sujeito subentendido,sujeito indeterminado',
    ae: 'Identificar as funções sintáticas: sujeito (simples, composto, subentendido, indeterminado), predicado, complementos direto, indireto, oblíquo e agente da passiva, predicativo do sujeito, modificador e vocativo.',
    r: [
      'Sujeito simples (um núcleo: O João saiu), composto (vários núcleos: O João e a Ana saíram), subentendido (não está expresso: Saímos cedo → nós) e indeterminado (Disseram-me que…).',
      'Predicado: o que se diz do sujeito; tem um verbo como núcleo.',
      'Complemento direto: responde a "o quê?/quem?" e é substituível por o, a, os, as (Li o livro → Li-o).',
      'Complemento indireto: responde a "a quem?" e é substituível por lhe/lhes (Dei o livro à Ana → Dei-lhe o livro).',
      'Complemento oblíquo: exigido pelo verbo, mas não é direto nem indireto (Gosto de música; Vou a Lisboa).',
      'Predicativo do sujeito: com verbos copulativos (ser, estar, parecer, ficar, permanecer) — A Ana está cansada.',
      'Complemento agente da passiva: quem pratica a ação na frase passiva (O bolo foi feito pela avó).',
      'Modificador: informação acessória que pode ser retirada (Ontem, choveu muito). Vocativo: chamamento (Rita, vem cá!).'
    ],
    q: [
      ['Em "O Rui ofereceu flores à mãe.", "à mãe" é…', ['complemento indireto', 'complemento direto', 'complemento oblíquo', 'modificador']],
      ['Em "A Sofia parece feliz.", "feliz" é…', ['predicativo do sujeito', 'complemento direto', 'modificador', 'sujeito']],
      ['Em "Chegámos tarde.", o sujeito é…', ['subentendido (nós)', 'indeterminado', 'composto', '"tarde"']],
      ['Em "O João e o Miguel jogam xadrez.", o sujeito é…', ['composto', 'simples', 'subentendido', 'indeterminado']],
      ['Em "Gosto de chocolate.", "de chocolate" é…', ['complemento oblíquo', 'complemento direto', 'complemento indireto', 'modificador']],
      ['Em "O muro foi pintado pelos alunos.", "pelos alunos" é…', ['complemento agente da passiva', 'complemento indireto', 'sujeito', 'modificador']],
      ['Em "Ontem, a turma visitou o museu.", "Ontem" é…', ['modificador', 'sujeito', 'complemento direto', 'vocativo']],
      ['Em "Disseram que vai chover.", o sujeito é indeterminado.', true],
      ['Em "Comprei um casaco.", "um casaco" é…', ['complemento direto', 'complemento indireto', 'predicativo do sujeito', 'complemento oblíquo']],
      ['Em "Professora, posso sair?", "Professora" é…', ['vocativo', 'sujeito', 'modificador', 'complemento indireto']]
    ]
  },
  {
    id: 'pt7_verbos', t: 'Verbos: modos e tempos',
    k: 'verbos,verbo,modos verbais,tempos verbais,indicativo,conjuntivo,imperativo,condicional,infinitivo,gerundio,participio,formas nominais,mais que perfeito,verbos copulativos,verbos auxiliares',
    ae: 'Conjugar verbos regulares e irregulares nos modos indicativo, conjuntivo, imperativo e condicional; identificar as formas não finitas.',
    r: [
      'Indicativo: factos reais (canto, cantei, cantava, cantara, cantarei).',
      'Conjuntivo: dúvida, desejo, hipótese — presente (que eu cante), pretérito imperfeito (se eu cantasse), futuro (quando eu cantar).',
      'Condicional: ação dependente de uma condição (eu cantaria se pudesse).',
      'Imperativo: ordens, pedidos e conselhos (Canta! Cantem!). A forma negativa usa o conjuntivo (Não cantes!).',
      'Pretérito mais-que-perfeito: ação passada anterior a outra passada (Quando cheguei, ele já tinha saído / saíra).',
      'Formas não finitas: infinitivo (cantar), gerúndio (cantando) e particípio passado (cantado).',
      'Verbos copulativos (ser, estar, parecer, ficar, permanecer, continuar) ligam o sujeito ao predicativo; verbos auxiliares (ter, haver, ser, estar) formam tempos compostos e a passiva.'
    ],
    q: [
      ['"Se eu tivesse tempo, ia contigo." "Tivesse" está no…', ['pretérito imperfeito do conjuntivo', 'pretérito imperfeito do indicativo', 'condicional', 'futuro do conjuntivo']],
      ['"Eu compraria uma bicicleta." O verbo está no…', ['condicional', 'futuro do indicativo', 'conjuntivo', 'imperativo']],
      ['Qual é a forma correta do imperativo negativo de "fazer" (tu)?', ['Não faças!', 'Não faz!', 'Não fazes!', 'Não fizeste!']],
      ['"Cantando" é…', ['gerúndio', 'infinitivo', 'particípio passado', 'conjuntivo']],
      ['"Quando eu chegar, telefono-te." "Chegar" está no…', ['futuro do conjuntivo', 'infinitivo', 'futuro do indicativo', 'presente do conjuntivo']],
      ['"Espero que tu venhas." "Venhas" está no presente do conjuntivo.', true],
      ['Qual destes verbos é copulativo em "A sopa está quente."?', ['estar', 'quente', 'sopa', 'nenhum']],
      ['"Quando cheguei, o comboio já tinha partido." "Tinha partido" é o…', ['pretérito mais-que-perfeito composto', 'pretérito perfeito simples', 'futuro composto', 'condicional']]
    ]
  },
  {
    id: 'pt7_frases', t: 'Frase complexa: coordenação, subordinação e voz passiva',
    k: 'coordenacao,subordinacao,oracoes,oracao,oracoes coordenadas,oracoes subordinadas,frase complexa,copulativa,adversativa,disjuntiva,conclusiva,explicativa,causal,temporal,final,voz passiva,frase passiva,frase ativa',
    ae: 'Identificar orações coordenadas (copulativas, adversativas, disjuntivas, conclusivas, explicativas) e subordinadas adverbiais (causais, temporais, finais); transformar frases ativas em passivas.',
    r: [
      'Frase complexa: tem mais do que uma oração (mais do que um verbo principal).',
      'Coordenadas: copulativas (e, nem), adversativas (mas, porém, contudo), disjuntivas (ou… ou), conclusivas (portanto, por isso, logo) e explicativas (pois, porque — explicação).',
      'Subordinadas adverbiais: causais (porque, visto que, como), temporais (quando, enquanto, logo que, antes que) e finais (para que, a fim de que).',
      'A oração subordinada depende da subordinante e não tem sentido sozinha.',
      'Voz ativa: o sujeito pratica a ação (O cão mordeu o carteiro). Voz passiva: o sujeito sofre a ação (O carteiro foi mordido pelo cão).',
      'Passiva = verbo ser + particípio passado; o complemento direto da ativa passa a sujeito e o sujeito passa a complemento agente da passiva.'
    ],
    q: [
      ['"Estudei muito, mas não passei." A oração "mas não passei" é coordenada…', ['adversativa', 'copulativa', 'conclusiva', 'disjuntiva']],
      ['"Choveu muito, portanto ficámos em casa." A 2.ª oração é coordenada…', ['conclusiva', 'explicativa', 'adversativa', 'copulativa']],
      ['"Fiquei em casa porque estava doente." A oração "porque estava doente" é subordinada adverbial…', ['causal', 'temporal', 'final', 'concessiva']],
      ['"Quando o sol nasceu, partimos." A oração destacada é subordinada adverbial…', ['temporal', 'causal', 'final', 'condicional']],
      ['"Estudo para que tenha boas notas." A oração "para que tenha boas notas" é…', ['subordinada adverbial final', 'coordenada explicativa', 'subordinada causal', 'coordenada conclusiva']],
      ['Passa para a passiva: "A Ana escreveu a carta."', ['A carta foi escrita pela Ana.', 'A Ana foi escrita pela carta.', 'A carta escreveu a Ana.', 'A carta é escrevida pela Ana.']],
      ['Na passiva, o sujeito da frase ativa passa a complemento agente da passiva.', true],
      ['"Ou estudas, ou não vais à festa." As orações são coordenadas…', ['disjuntivas', 'copulativas', 'conclusivas', 'adversativas']]
    ]
  },
  {
    id: 'pt7_narrativa', t: 'Texto narrativo',
    k: 'texto narrativo,narrativa,narrador,categorias da narrativa,personagens,acao,espaco,tempo,narrador participante,narrador nao participante,conto,lenda,mito,fabula,educacao literaria',
    ae: 'Analisar textos narrativos: narrador, personagens, ação, espaço, tempo e estrutura; distinguir conto, lenda, mito e fábula.',
    r: [
      'Narrador: participante (é personagem; conta na 1.ª pessoa) ou não participante (conta na 3.ª pessoa).',
      'Personagens: quanto ao relevo — principal (protagonista), secundária e figurante. Caracterização direta (o narrador ou outra personagem diz como é) e indireta (deduz-se pelas ações e falas).',
      'Ação: principal e secundária; estrutura em introdução (situação inicial), desenvolvimento (peripécias, conflito) e conclusão (desfecho).',
      'Espaço: físico (lugares), social (ambiente, grupos sociais) e psicológico (pensamentos e emoções).',
      'Tempo: cronológico (sequência dos acontecimentos), histórico (época) e psicológico (como a personagem vive o tempo).',
      'Lenda: relato tradicional que mistura factos e elementos fantásticos ligados a um lugar ou figura; mito: explica a origem do mundo ou de fenómenos através de deuses e heróis; fábula: animais personificados e uma moral.'
    ],
    q: [
      ['Um narrador que é também personagem da história é…', ['participante', 'não participante', 'omnisciente obrigatoriamente', 'secundário']],
      ['Quando conhecemos uma personagem pelas suas ações e falas, a caracterização é…', ['indireta', 'direta', 'física', 'social']],
      ['O espaço que corresponde aos pensamentos e emoções da personagem é o espaço…', ['psicológico', 'físico', 'social', 'cronológico']],
      ['Uma narrativa com animais personificados e uma moral final é uma…', ['fábula', 'lenda', 'crónica', 'notícia']],
      ['O desfecho da história corresponde à…', ['conclusão', 'introdução', 'peripécia', 'situação inicial']],
      ['O protagonista é a personagem principal.', true],
      ['O tempo histórico corresponde à época em que decorre a ação.', true],
      ['Um texto que explica a origem do mundo através de deuses é um…', ['mito', 'conto realista', 'diário', 'texto expositivo']]
    ]
  },
  {
    id: 'pt7_poesia', t: 'Texto poético e recursos expressivos',
    k: 'poesia,poema,texto poetico,recursos expressivos,figuras de estilo,comparacao,metafora,personificacao,anafora,hiperbole,enumeracao,aliteracao,onomatopeia,antitese,rima,metrica,verso,estrofe,soneto',
    ae: 'Analisar o texto poético (estrofe, verso, rima, métrica) e identificar recursos expressivos.',
    r: [
      'Comparação: aproxima dois elementos com um conector (como, tal como, parece): "Os olhos dela são como estrelas".',
      'Metáfora: comparação sem conector: "Os olhos dela são estrelas".',
      'Personificação: atribuir características humanas a seres não humanos: "O vento cantava".',
      'Anáfora: repetição de palavras no início de versos ou frases.',
      'Hipérbole: exagero ("Chorei rios de lágrimas"). Enumeração: sequência de elementos. Antítese: ideias opostas ("riso e pranto").',
      'Aliteração: repetição de sons consonânticos; onomatopeia: palavra que imita um som (tique-taque).',
      'Rima: emparelhada (AABB), cruzada (ABAB) e interpolada (ABBA). Métrica: contagem de sílabas métricas até à última sílaba tónica.',
      'Soneto: 14 versos (duas quadras e dois tercetos).'
    ],
    q: [
      ['"O teu sorriso é um sol." Que recurso expressivo é este?', ['metáfora', 'comparação', 'personificação', 'hipérbole']],
      ['"A lua sorria para nós." Que recurso expressivo é este?', ['personificação', 'metáfora', 'anáfora', 'enumeração']],
      ['"Esperei uma eternidade!" Que recurso expressivo é este?', ['hipérbole', 'comparação', 'aliteração', 'antítese']],
      ['"És forte como um touro." Que recurso expressivo é este?', ['comparação', 'metáfora', 'personificação', 'onomatopeia']],
      ['Um esquema rimático ABAB chama-se rima…', ['cruzada', 'emparelhada', 'interpolada', 'solta']],
      ['Quantos versos tem um soneto?', ['14', '12', '10', '16']],
      ['"Tique-taque" é uma onomatopeia.', true],
      ['A repetição de palavras no início de vários versos chama-se…', ['anáfora', 'antítese', 'hipérbole', 'metáfora']]
    ]
  },
  {
    id: 'pt7_drama', t: 'Texto dramático',
    k: 'texto dramatico,teatro,didascalias,ato,atos,cena,cenas,dialogo,monologo,aparte,personagens do teatro,auto,dramaturgo',
    ae: 'Identificar as características do texto dramático: estrutura (atos e cenas), texto principal e texto secundário, formas de discurso (diálogo, monólogo, aparte).',
    r: [
      'O texto dramático é escrito para ser representado em palco.',
      'Texto principal: as falas das personagens. Texto secundário (didascálias): indicações sobre cenário, gestos, tom de voz, entradas e saídas.',
      'Estrutura externa: atos (grandes partes) e cenas (mudam com a entrada ou saída de personagens).',
      'Diálogo: conversa entre personagens. Monólogo: uma personagem fala sozinha. Aparte: fala dirigida ao público que as outras personagens supostamente não ouvem.',
      'No teatro não há narrador: a ação é mostrada pelas personagens.'
    ],
    q: [
      ['As indicações sobre cenário e gestos chamam-se…', ['didascálias', 'falas', 'apartes', 'monólogos']],
      ['Quando uma personagem fala sozinha em palco, chama-se…', ['monólogo', 'diálogo', 'aparte', 'didascália']],
      ['O que muda normalmente quando entra ou sai uma personagem?', ['a cena', 'o ato', 'o autor', 'o narrador']],
      ['No texto dramático existe um narrador.', false, 'No teatro a ação é mostrada pelas próprias personagens.'],
      ['As falas das personagens constituem o texto…', ['principal', 'secundário', 'narrativo', 'poético']],
      ['Uma fala dirigida ao público, que as outras personagens não ouvem, é um…', ['aparte', 'monólogo', 'diálogo', 'ato']]
    ]
  },
  {
    id: 'pt7_palavras', t: 'Formação de palavras e relações semânticas',
    k: 'formacao de palavras,derivacao,composicao,prefixacao,sufixacao,parassintese,derivacao nao afixal,conversao,composicao morfologica,composicao morfossintatica,relacoes semanticas,hiperonimia,hiponimia,holonimia,meronimia,sinonimia,antonimia,campo lexical,campo semantico',
    ae: 'Identificar processos de formação de palavras e relações semânticas entre palavras (sinonímia, antonímia, hiperonímia/hiponímia, holonímia/meronímia).',
    r: [
      'Derivação por prefixação (refazer), sufixação (felizmente) e parassíntese (prefixo e sufixo ao mesmo tempo: entardecer, envelhecer).',
      'Derivação não afixal: forma-se um nome a partir de um verbo, sem afixo (pescar → pesca; ajudar → ajuda).',
      'Conversão: a palavra muda de classe sem mudar de forma (o jantar, o olhar).',
      'Composição morfológica: junção de radicais (hidroelétrico, biologia). Composição morfossintática: junção de palavras (guarda-chuva, amor-perfeito).',
      'Hiperonímia/hiponímia: palavra geral e palavras específicas (flor → rosa, tulipa).',
      'Holonímia/meronímia: o todo e as suas partes (corpo → braço, mão).',
      'Campo lexical: palavras relacionadas com um tema (escola: professor, caderno, recreio). Campo semântico: vários sentidos de uma palavra (cabeça da turma, cabeça de alho).'
    ],
    q: [
      ['"Entardecer" formou-se por…', ['parassíntese', 'prefixação', 'composição', 'conversão']],
      ['"A pesca" (de pescar) formou-se por…', ['derivação não afixal', 'sufixação', 'composição morfossintática', 'parassíntese']],
      ['"Guarda-chuva" formou-se por…', ['composição morfossintática', 'composição morfológica', 'sufixação', 'derivação não afixal']],
      ['"Fruta" em relação a "maçã" é um…', ['hiperónimo', 'hipónimo', 'merónimo', 'antónimo']],
      ['"Roda" em relação a "bicicleta" é um…', ['merónimo', 'holónimo', 'hiperónimo', 'sinónimo']],
      ['Em "O olhar dela era triste.", "olhar" formou-se por conversão.', true],
      ['"Biologia" é um exemplo de composição morfológica.', true],
      ['Professor, caderno e recreio pertencem ao mesmo…', ['campo lexical', 'campo semântico', 'radical', 'grau']]
    ]
  }
]);

// ============================================================= MATEMÁTICA (AE 2021)
TEMAS(7, 'mat', [
  {
    id: 'mat7_racionais', t: 'Números racionais (operações)', gen: 'inteiros7',
    k: 'numeros racionais,racionais,numeros inteiros,inteiros,numeros negativos,negativos,simetrico,valor absoluto,regra dos sinais,reta numerica,operacoes com negativos',
    ae: 'Operar com números racionais (incluindo negativos), usando valor absoluto, simétrico e regras de sinais.',
    r: [
      'Números racionais: podem escrever-se como fração de inteiros (−3, 0,5, −2/3…).',
      'Valor absoluto: distância ao zero (|−5| = 5). Simétrico: mesmo valor absoluto e sinal contrário (o simétrico de 4 é −4).',
      'Adição com sinais iguais: somam-se os valores absolutos e mantém-se o sinal (−3 + (−4) = −7). Sinais diferentes: subtraem-se e fica o sinal do de maior valor absoluto (−7 + 3 = −4).',
      'Subtrair é adicionar o simétrico: 5 − (−2) = 5 + 2 = 7.',
      'Multiplicação e divisão: sinais iguais → positivo; sinais diferentes → negativo.',
      'Na reta numérica, os números aumentam da esquerda para a direita: −5 < −2 < 0 < 3.'
    ],
    q: [
      ['Qual é o valor absoluto de −8?', ['8', '−8', '0', '1/8']],
      ['Qual é maior: −3 ou −7?', ['−3', '−7', 'são iguais', 'não se pode comparar']],
      ['Quanto é 5 − (−2)?', ['7', '3', '−7', '−3']],
      ['Quanto é (−4) × (−6)?', ['24', '−24', '10', '−10']],
      ['Quanto é −12 : 3?', ['−4', '4', '−9', '−36']],
      ['O simétrico de −2/5 é 2/5.', true],
      ['Quanto é −3 + 8?', ['5', '−11', '−5', '11']]
    ]
  },
  {
    id: 'mat7_potencias', t: 'Potências e raízes', gen: 'potencias7',
    k: 'potencias,potencia,expoente,base,raiz quadrada,raiz cubica,raizes,quadrados perfeitos,cubos perfeitos,regras das potencias',
    ae: 'Calcular potências de expoente natural, aplicar as regras operatórias das potências e determinar raízes quadradas e cúbicas.',
    r: [
      'Potência: a^n = a × a × … × a (n vezes). a é a base e n o expoente. Ex.: 2⁴ = 16.',
      'Produto de potências com a mesma base: soma dos expoentes (3² × 3⁴ = 3⁶). Quociente: subtração dos expoentes (5⁶ : 5² = 5⁴).',
      'Potência de potência: multiplicação dos expoentes ((2³)² = 2⁶).',
      'Mesmo expoente: multiplicam-se as bases (2³ × 5³ = 10³).',
      'a¹ = a e a⁰ = 1 (a ≠ 0). Base negativa: expoente par → positivo ((−2)⁴ = 16); ímpar → negativo ((−2)³ = −8).',
      'Raiz quadrada: √49 = 7 porque 7² = 49. Raiz cúbica: ∛27 = 3 porque 3³ = 27; ∛(−8) = −2.'
    ],
    q: [
      ['Quanto é 2⁵?', ['32', '10', '25', '16']],
      ['Qual é o resultado de 3² × 3⁴ na forma de potência?', ['3⁶', '3⁸', '9⁶', '3²']],
      ['Quanto é (−2)³?', ['−8', '8', '−6', '6']],
      ['Quanto é √81?', ['9', '8', '40,5', '18']],
      ['Quanto é ∛64?', ['4', '8', '21', '16']],
      ['Qualquer número (diferente de 0) elevado a 0 é 1.', true],
      ['(5²)³ é igual a…', ['5⁶', '5⁵', '25³ não se simplifica', '10³']]
    ]
  },
  {
    id: 'mat7_sequencias', t: 'Sequências e expressões algébricas', gen: 'sequencias7',
    k: 'sequencias,sequencia,termo geral,regularidades,expressoes algebricas,expressao algebrica,monomios,termos semelhantes,simplificar expressoes,variavel',
    ae: 'Determinar termos e o termo geral de sequências; escrever e simplificar expressões algébricas.',
    r: [
      'O termo geral de uma sequência permite calcular qualquer termo a partir da ordem n. Ex.: 3n + 1 → 1.º termo 4, 2.º termo 7, 10.º termo 31.',
      'Se a diferença entre termos consecutivos é constante (d), o termo geral tem a forma d × n + k.',
      'Uma expressão algébrica tem números, letras (variáveis) e operações: 2x + 5.',
      'Termos semelhantes têm a mesma parte literal e podem juntar-se: 3x + 5x = 8x; 4a − a = 3a.',
      'Propriedade distributiva: 3(x + 2) = 3x + 6.',
      'Para calcular o valor de uma expressão, substitui-se a letra pelo número: se x = 2, 4x − 1 = 7.'
    ],
    q: [
      ['Qual é o termo geral da sequência 5, 10, 15, 20…?', ['5n', 'n + 5', '5n + 5', '10n']],
      ['Simplifica: 3x + 5x', ['8x', '15x', '8x²', '8']],
      ['Se x = 3, quanto vale 2x + 4?', ['10', '9', '24', '14']],
      ['Desenvolve: 4(x + 3)', ['4x + 12', '4x + 3', 'x + 12', '4x + 7']],
      ['O 10.º termo da sequência de termo geral 2n − 1 é…', ['19', '20', '21', '9']],
      ['3x e 3x² são termos semelhantes.', false, 'Têm partes literais diferentes (x e x²).'],
      ['Simplifica: 7a − 2a + a', ['6a', '4a', '5a', '10a']]
    ]
  },
  {
    id: 'mat7_equacoes', t: 'Equações do 1.º grau', gen: 'equacoes7',
    k: 'equacoes,equacao,equacoes do primeiro grau,resolver equacoes,incognita,solucao,membros,equacoes equivalentes,problemas com equacoes',
    ae: 'Resolver equações do 1.º grau a uma incógnita e usá-las na resolução de problemas.',
    r: [
      'Uma equação é uma igualdade com uma incógnita (x + 3 = 10). Tem 1.º membro e 2.º membro.',
      'Solução: o valor que torna a igualdade verdadeira (x = 7).',
      'Princípio da adição: podemos adicionar ou subtrair o mesmo número aos dois membros (passar um termo para o outro membro trocando-lhe o sinal).',
      'Princípio da multiplicação: podemos multiplicar ou dividir os dois membros pelo mesmo número diferente de zero.',
      'Passos: desembaraçar de parênteses → termos com x num membro e números no outro → reduzir termos semelhantes → dividir pelo coeficiente de x → verificar.',
      'Equação possível e determinada: uma solução; impossível: nenhuma (0x = 5); possível indeterminada: infinitas (0x = 0).'
    ],
    q: [
      ['Qual é a solução de x + 7 = 15?', ['x = 8', 'x = 22', 'x = 7', 'x = −8']],
      ['Qual é a solução de 3x = 21?', ['x = 7', 'x = 18', 'x = 24', 'x = 63']],
      ['Qual é a solução de 2x − 4 = 10?', ['x = 7', 'x = 3', 'x = 14', 'x = 6']],
      ['Qual é a solução de 5x + 2 = 3x + 10?', ['x = 4', 'x = 6', 'x = 1', 'x = 8']],
      ['A equação 0x = 5 é…', ['impossível', 'possível e determinada', 'possível e indeterminada', 'de solução x = 5']],
      ['x = 2 é solução de 4x − 3 = 5.', true],
      ['O dobro de um número mais 3 é 17. Que número é?', ['7', '10', '14', '8,5']]
    ]
  },
  {
    id: 'mat7_funcoes', t: 'Proporcionalidade direta e funções', gen: 'proporc7',
    k: 'proporcionalidade direta,proporcionalidade,funcoes,funcao,constante de proporcionalidade,grafico de uma funcao,dominio,contradominio,referencial,coordenadas,regra de tres simples,escala',
    ae: 'Reconhecer situações de proporcionalidade direta e representá-las como funções (y = kx); interpretar e representar funções em gráficos, tabelas e expressões.',
    r: [
      'Duas grandezas são diretamente proporcionais quando o quociente y/x é constante: é a constante de proporcionalidade (k).',
      'A proporcionalidade direta é uma função do tipo y = kx; o gráfico é uma reta que passa na origem do referencial.',
      'Função: a cada objeto (x) do domínio corresponde uma e uma só imagem (y). O conjunto das imagens é o contradomínio.',
      'Num referencial cartesiano, um ponto tem coordenadas (abcissa, ordenada), ex.: A(2, 5).',
      'Em escalas: 1 : 100 000 significa que 1 cm no mapa corresponde a 100 000 cm (1 km) na realidade.'
    ],
    q: [
      ['Na função y = 3x, qual é a imagem de 4?', ['12', '7', '4/3', '1']],
      ['O gráfico de uma proporcionalidade direta é uma reta que passa…', ['na origem do referencial', 'no ponto (1, 1) sempre', 'paralela ao eixo das abcissas', 'abaixo do eixo x']],
      ['Se 2 kg de laranjas custam 3 €, quanto custam 6 kg?', ['9 €', '6 €', '12 €', '18 €']],
      ['No ponto A(−2, 5), a abcissa é…', ['−2', '5', '3', '−5']],
      ['Numa escala 1 : 100 000, 3 cm no mapa correspondem a…', ['3 km', '300 m', '30 km', '100 km']],
      ['Numa função, um objeto pode ter duas imagens diferentes.', false],
      ['Se y é diretamente proporcional a x e y = 20 quando x = 5, qual é k?', ['4', '25', '100', '15']]
    ]
  },
  {
    id: 'mat7_geometria', t: 'Triângulos, quadriláteros e ângulos', gen: 'angulos7',
    k: 'triangulos,quadrilateros,angulos,soma dos angulos internos,angulos internos,angulos externos,angulos suplementares,angulos complementares,angulos verticalmente opostos,paralelogramo,trapezio,losango,criterios de igualdade',
    ae: 'Relacionar ângulos (complementares, suplementares, verticalmente opostos, ângulos de retas paralelas cortadas por uma secante); conhecer a soma dos ângulos internos de triângulos e quadriláteros e propriedades dos quadriláteros.',
    r: [
      'Ângulos complementares somam 90°; suplementares somam 180°.',
      'Ângulos verticalmente opostos são iguais.',
      'Retas paralelas cortadas por uma secante: ângulos alternos internos são iguais; ângulos correspondentes são iguais.',
      'A soma dos ângulos internos de um triângulo é 180°; de um quadrilátero é 360°.',
      'Num triângulo, ao maior lado opõe-se o maior ângulo. Cada lado é menor do que a soma dos outros dois (desigualdade triangular).',
      'Paralelogramos: lados opostos paralelos e iguais, ângulos opostos iguais, diagonais que se bissetam (retângulo, losango e quadrado são paralelogramos).'
    ],
    q: [
      ['Qual é o complemento de um ângulo de 35°?', ['55°', '145°', '65°', '35°']],
      ['Qual é o suplemento de um ângulo de 110°?', ['70°', '250°', '20°', '110°']],
      ['Ângulos verticalmente opostos são…', ['iguais', 'suplementares', 'complementares', 'sempre retos']],
      ['A soma dos ângulos internos de um quadrilátero é…', ['360°', '180°', '540°', '270°']],
      ['É possível um triângulo com lados de 2 cm, 3 cm e 7 cm?', ['Não', 'Sim', 'Só se for retângulo', 'Só se for isósceles'], 'Desigualdade triangular: 7 não é menor do que 2 + 3.'],
      ['Num paralelogramo, os ângulos opostos são iguais.', true],
      ['Retas paralelas cortadas por uma secante formam ângulos alternos internos iguais.', true]
    ]
  },
  {
    id: 'mat7_semelhanca', t: 'Semelhança de figuras',
    k: 'semelhanca,figuras semelhantes,triangulos semelhantes,razao de semelhanca,ampliacao,reducao,criterios de semelhanca,escala,teorema de tales,homotetia',
    ae: 'Identificar figuras semelhantes, determinar a razão de semelhança e usar critérios de semelhança de triângulos.',
    r: [
      'Duas figuras são semelhantes se uma é ampliação ou redução da outra: ângulos iguais e lados proporcionais.',
      'Razão de semelhança (r): quociente entre comprimentos correspondentes. r > 1 ampliação; r < 1 redução; r = 1 figuras geometricamente iguais.',
      'Critérios de semelhança de triângulos: AA (dois ângulos iguais), LLL (três lados proporcionais) e LAL (dois lados proporcionais e o ângulo entre eles igual).',
      'Se a razão de semelhança é r, os perímetros estão na razão r e as áreas na razão r².',
      'Todos os quadrados são semelhantes entre si; todos os círculos também.'
    ],
    q: [
      ['Um retângulo 4 cm × 6 cm é ampliado com razão 2. Quais são as novas medidas?', ['8 cm × 12 cm', '6 cm × 8 cm', '16 cm × 36 cm', '4 cm × 12 cm']],
      ['Se a razão de semelhança é 0,5, trata-se de uma…', ['redução', 'ampliação', 'figura igual', 'rotação']],
      ['Dois triângulos com dois ângulos iguais são semelhantes (critério AA).', true],
      ['Se a razão de semelhança é 3, as áreas estão na razão…', ['9', '3', '6', '1/3']],
      ['Todos os retângulos são semelhantes entre si.', false, 'Os lados podem não ser proporcionais.'],
      ['Um lado de 5 cm corresponde a 15 cm na figura semelhante. Qual é a razão de semelhança?', ['3', '10', '1/3', '75']]
    ]
  },
  {
    id: 'mat7_areas', t: 'Áreas de polígonos e do círculo',
    k: 'areas,area,area do trapezio,area do paralelogramo,area do triangulo,area do losango,area do circulo,perimetro do circulo,pi,poligonos regulares',
    ae: 'Calcular áreas de paralelogramos, triângulos, trapézios, losangos e do círculo, e perímetros de círculos.',
    r: [
      'Área do paralelogramo = base × altura.',
      'Área do triângulo = (base × altura) : 2.',
      'Área do trapézio = (base maior + base menor) : 2 × altura.',
      'Área do losango = (diagonal maior × diagonal menor) : 2.',
      'Perímetro do círculo = 2 × π × r (ou π × diâmetro). Área do círculo = π × r². π ≈ 3,14.'
    ],
    q: [
      ['Área de um triângulo com base 10 cm e altura 4 cm?', ['20 cm²', '40 cm²', '14 cm²', '28 cm²']],
      ['Área de um trapézio com bases 8 cm e 4 cm e altura 5 cm?', ['30 cm²', '60 cm²', '17 cm²', '160 cm²']],
      ['Área de um losango com diagonais 6 cm e 4 cm?', ['12 cm²', '24 cm²', '10 cm²', '20 cm²']],
      ['Qual é a fórmula da área do círculo?', ['π × r²', '2 × π × r', 'π × d', 'r² : 2']],
      ['Perímetro de um círculo com raio 5 cm (π ≈ 3,14)?', ['31,4 cm', '15,7 cm', '78,5 cm', '62,8 cm']],
      ['A área do paralelogramo é base × altura.', true]
    ]
  },
  {
    id: 'mat7_dados', t: 'Estatística: média, mediana e moda', gen: 'estat7',
    k: 'estatistica,dados,media,mediana,moda,amplitude,medidas de tendencia central,graficos,histograma,diagrama de caule e folhas,frequencia relativa,tabela de frequencias',
    ae: 'Organizar dados em tabelas e gráficos (incluindo diagramas de caule e folhas e histogramas) e calcular média, mediana, moda e amplitude, interpretando-as.',
    r: [
      'Média: soma de todos os dados a dividir pelo número de dados.',
      'Mediana: valor do meio dos dados ordenados (com número par de dados, é a média dos dois centrais).',
      'Moda: valor mais frequente (pode haver mais do que uma, ou nenhuma).',
      'Amplitude: diferença entre o maior e o menor valor.',
      'Frequência relativa = frequência absoluta : número total de dados (pode escrever-se em percentagem).',
      'A média é afetada por valores extremos; a mediana não.'
    ],
    q: [
      ['Qual é a média de 4, 6, 8 e 10?', ['7', '6', '28', '8']],
      ['Qual é a mediana de 3, 9, 5, 7, 1?', ['5', '9', '7', '3']],
      ['Qual é a moda de 2, 4, 4, 5, 7?', ['4', '2', '5', '7']],
      ['Qual é a amplitude de 12, 20, 8, 15?', ['12', '20', '8', '7']],
      ['Num grupo de 20 alunos, 5 têm olhos azuis. Qual é a frequência relativa?', ['25%', '5%', '20%', '15%']],
      ['A mediana é muito afetada por valores extremos.', false, 'A média é que é afetada; a mediana não.']
    ]
  }
]);

// ============================================================= CIÊNCIAS NATURAIS — A Terra em transformação
TEMAS(7, 'cn', [
  {
    id: 'cn7_paisagens', t: 'Paisagens geológicas e minerais',
    k: 'paisagens geologicas,paisagem geologica,minerais,mineral,propriedades dos minerais,dureza,escala de mohs,cor,risca,brilho,clivagem,fratura,rochas e minerais,quartzo,feldspato,mica',
    ae: 'Identificar paisagens geológicas e distinguir rochas de minerais; identificar minerais pelas suas propriedades (dureza, cor, risca, brilho, clivagem).',
    r: [
      'As paisagens geológicas são formadas por rochas: graníticas, basálticas, calcárias, xistosas, areníticas…',
      'As rochas são formadas por minerais (ex.: o granito tem quartzo, feldspato e mica).',
      'Dureza: resistência a ser riscado. Escala de Mohs (1 a 10): talco (1), gesso (2), calcite (3), fluorite (4), apatite (5), ortóclase (6), quartzo (7), topázio (8), corindo (9), diamante (10).',
      'Risca: cor do pó do mineral (vê-se riscando numa placa de porcelana). Pode ser diferente da cor do mineral.',
      'Brilho: metálico ou não metálico. Clivagem: tendência para partir segundo planos; fratura: superfície irregular.',
      'A calcite faz efervescência com ácido clorídrico diluído.'
    ],
    q: [
      ['Qual é o mineral mais duro da escala de Mohs?', ['diamante', 'quartzo', 'talco', 'corindo']],
      ['Qual é o mineral mais macio da escala de Mohs?', ['talco', 'gesso', 'calcite', 'mica']],
      ['Quais são os minerais principais do granito?', ['quartzo, feldspato e mica', 'calcite e gesso', 'talco e diamante', 'olivina e piroxena']],
      ['A cor do pó de um mineral chama-se…', ['risca', 'brilho', 'clivagem', 'dureza']],
      ['Que mineral faz efervescência com ácido clorídrico?', ['calcite', 'quartzo', 'mica', 'feldspato']],
      ['Um mineral de dureza 7 risca um de dureza 5.', true],
      ['A cor de um mineral é sempre igual à sua risca.', false, 'A risca pode ser diferente da cor do mineral.']
    ]
  },
  {
    id: 'cn7_sedimentares', t: 'Rochas sedimentares',
    k: 'rochas sedimentares,sedimentares,sedimentacao,meteorizacao,erosao,transporte,diagenese,detriticas,quimiogenicas,biogenicas,calcario,arenito,argila,carvao,sal-gema,conglomerado,estratos',
    ae: 'Explicar a formação das rochas sedimentares (meteorização, erosão, transporte, sedimentação e diagénese) e classificá-las (detríticas, quimiogénicas, biogénicas).',
    r: [
      'Meteorização: alteração das rochas à superfície (física — desagregação; química — alteração dos minerais).',
      'Erosão: remoção dos materiais; transporte: pela água, vento, gelo e gravidade; sedimentação: deposição dos sedimentos em camadas (estratos).',
      'Diagénese: compactação e cimentação dos sedimentos que os transformam em rocha.',
      'Detríticas: formadas por fragmentos de outras rochas (conglomerado, arenito, argilito).',
      'Quimiogénicas: por precipitação química (sal-gema, calcário quimiogénico, gesso).',
      'Biogénicas: com origem em seres vivos (carvão, calcário conquífero).',
      'É nas rochas sedimentares que se encontram os fósseis.'
    ],
    q: [
      ['O processo que transforma sedimentos soltos em rocha chama-se…', ['diagénese', 'erosão', 'meteorização', 'metamorfismo']],
      ['O arenito é uma rocha sedimentar…', ['detrítica', 'quimiogénica', 'biogénica', 'magmática']],
      ['O carvão é uma rocha sedimentar…', ['biogénica', 'detrítica', 'quimiogénica', 'metamórfica']],
      ['O sal-gema forma-se por…', ['precipitação química', 'arrefecimento de magma', 'pressão e temperatura', 'compactação de seres vivos']],
      ['A ordem correta é…', ['meteorização, erosão, transporte, sedimentação, diagénese', 'sedimentação, erosão, transporte, diagénese', 'diagénese, erosão, sedimentação, transporte', 'transporte, meteorização, diagénese, erosão']],
      ['Os fósseis encontram-se sobretudo em rochas sedimentares.', true],
      ['As camadas de rochas sedimentares chamam-se…', ['estratos', 'filões', 'placas', 'cristais']]
    ]
  },
  {
    id: 'cn7_magmaticas', t: 'Rochas magmáticas e vulcanismo',
    k: 'rochas magmaticas,magmaticas,granito,basalto,plutonicas,intrusivas,vulcanicas,extrusivas,magma,lava,vulcoes,vulcao,vulcanismo,cratera,chamine,camara magmatica,erupcao,lavas,piroclastos,atividade vulcanica,vulcanismo residual,geiseres,fumarolas',
    ae: 'Explicar a formação das rochas magmáticas (plutónicas e vulcânicas) e caracterizar a atividade vulcânica.',
    r: [
      'Rochas magmáticas formam-se pelo arrefecimento e solidificação do magma.',
      'Plutónicas (intrusivas): arrefecem lentamente em profundidade → cristais grandes e visíveis. Ex.: granito.',
      'Vulcânicas (extrusivas): arrefecem rapidamente à superfície → cristais muito pequenos. Ex.: basalto.',
      'Estrutura de um vulcão: câmara magmática, chaminé, cratera e cone vulcânico.',
      'Produtos: lava (magma à superfície), piroclastos (cinzas, bagacina/lapilli, bombas) e gases.',
      'Atividade efusiva: lavas fluidas, pouco explosiva. Explosiva: lavas viscosas e muitos gases.',
      'Vulcanismo residual: fumarolas, géiseres e nascentes termais (frequentes nos Açores).'
    ],
    q: [
      ['O granito é uma rocha magmática…', ['plutónica', 'vulcânica', 'sedimentar', 'metamórfica']],
      ['O basalto forma-se…', ['pelo arrefecimento rápido da lava à superfície', 'em grande profundidade lentamente', 'por compactação de sedimentos', 'por pressão e temperatura']],
      ['Porque é que o granito tem cristais grandes?', ['porque arrefeceu lentamente', 'porque arrefeceu rapidamente', 'porque tem fósseis', 'porque é sedimentar']],
      ['Como se chama o magma quando chega à superfície?', ['lava', 'piroclasto', 'fumarola', 'cratera']],
      ['Os géiseres e as fumarolas são manifestações de…', ['vulcanismo residual', 'erosão', 'sedimentação', 'metamorfismo']],
      ['Lavas viscosas e ricas em gases originam erupções explosivas.', true],
      ['O canal por onde o magma sobe no vulcão chama-se…', ['chaminé', 'cratera', 'câmara magmática', 'cone']]
    ]
  },
  {
    id: 'cn7_metamorficas', t: 'Rochas metamórficas e ciclo das rochas',
    k: 'rochas metamorficas,metamorficas,metamorfismo,marmore,xisto,ardosia,gnaisse,quartzito,ciclo das rochas,ciclo litologico,foliacao',
    ae: 'Explicar a formação das rochas metamórficas e interpretar o ciclo das rochas.',
    r: [
      'Metamorfismo: transformação de rochas no estado sólido, devido a alterações de pressão, temperatura e fluidos.',
      'Exemplos: calcário → mármore; arenito → quartzito; argilito → ardósia → xisto; granito → gnaisse.',
      'Muitas rochas metamórficas têm foliação (minerais alinhados em planos), como o xisto e a ardósia.',
      'Ciclo das rochas: qualquer rocha pode transformar-se noutra tipo — por meteorização/erosão/sedimentação (sedimentares), metamorfismo (metamórficas) ou fusão e arrefecimento (magmáticas).',
      'Se a temperatura for tão alta que a rocha funde, forma-se magma (deixa de ser metamorfismo).'
    ],
    q: [
      ['O mármore resulta do metamorfismo do…', ['calcário', 'granito', 'basalto', 'arenito']],
      ['O metamorfismo ocorre…', ['no estado sólido', 'com a rocha fundida', 'à superfície por erosão', 'só no fundo do mar']],
      ['Que fatores provocam o metamorfismo?', ['pressão, temperatura e fluidos', 'vento e chuva', 'seres vivos', 'apenas a água']],
      ['O quartzito forma-se a partir do…', ['arenito', 'calcário', 'basalto', 'carvão']],
      ['No ciclo das rochas, uma rocha metamórfica pode originar uma rocha sedimentar.', true],
      ['O xisto apresenta foliação.', true],
      ['Quando uma rocha funde completamente, forma-se…', ['magma', 'mármore', 'sedimento', 'fóssil']]
    ]
  },
  {
    id: 'cn7_estrutura', t: 'Estrutura interna da Terra',
    k: 'estrutura interna da terra,estrutura da terra,camadas da terra,crosta,manto,nucleo,litosfera,astenosfera,mesosfera,descontinuidades,modelo geoquimico,modelo fisico,interior da terra',
    ae: 'Caracterizar a estrutura interna da Terra segundo os modelos geoquímico (composição) e físico (propriedades).',
    r: [
      'Modelo geoquímico (composição): crosta (continental e oceânica), manto e núcleo (externo e interno).',
      'Modelo físico (propriedades): litosfera (rígida: crosta + parte superior do manto), astenosfera (plástica), mesosfera, núcleo externo (líquido) e núcleo interno (sólido).',
      'O núcleo é formado sobretudo por ferro e níquel.',
      'A crosta oceânica é mais fina e mais densa (basáltica); a continental é mais espessa (granítica).',
      'O conhecimento do interior da Terra vem sobretudo do estudo das ondas sísmicas, que mudam de velocidade nas descontinuidades (ex.: Moho, entre crosta e manto).'
    ],
    q: [
      ['A camada mais interna da Terra é…', ['o núcleo', 'o manto', 'a crosta', 'a astenosfera']],
      ['Que camada do modelo físico é plástica e permite o movimento das placas?', ['astenosfera', 'litosfera', 'mesosfera', 'núcleo interno']],
      ['A litosfera é formada pela crosta e pela parte superior do…', ['manto', 'núcleo', 'mesosfera', 'astenosfera inferior']],
      ['O núcleo externo está no estado…', ['líquido', 'sólido', 'gasoso', 'plástico']],
      ['A crosta oceânica é mais fina do que a continental.', true],
      ['Os cientistas conhecem o interior da Terra sobretudo graças…', ['às ondas sísmicas', 'a furos até ao núcleo', 'aos fósseis', 'aos satélites meteorológicos']],
      ['O núcleo é composto principalmente por…', ['ferro e níquel', 'granito e basalto', 'água e gelo', 'oxigénio e silício']]
    ]
  },
  {
    id: 'cn7_tectonica', t: 'Deriva continental e tectónica de placas',
    k: 'tectonica de placas,placas tectonicas,placas,deriva continental,wegener,pangeia,dorsal,dorsais,fossas,limites de placas,limites divergentes,limites convergentes,limites transformantes,expansao dos fundos oceanicos,subducao,cadeias montanhosas,falhas,dobras',
    ae: 'Relacionar a teoria da deriva continental e a teoria da tectónica de placas com a formação de oceanos, montanhas, sismos e vulcões.',
    r: [
      'Alfred Wegener propôs a deriva continental (1912): os continentes já estiveram unidos num supercontinente, a Pangeia.',
      'Argumentos: forma dos continentes (encaixe da América do Sul e África), fósseis iguais em continentes separados, rochas e cadeias montanhosas semelhantes e vestígios de antigos glaciares (paleoclimáticos).',
      'A litosfera está dividida em placas tectónicas que se movem sobre a astenosfera (correntes de convecção no manto).',
      'Limites divergentes: as placas afastam-se (dorsais oceânicas — cria-se nova crosta). Convergentes: aproximam-se (subducção, fossas, cadeias montanhosas como os Himalaias). Transformantes: deslizam lado a lado (falhas).',
      'Deformações das rochas: dobras (comportamento dúctil) e falhas (fratura com deslocamento).',
      'Os Açores ficam numa zona de junção de três placas: Norte-Americana, Euroasiática e Africana (Núbia).'
    ],
    q: [
      ['Quem propôs a teoria da deriva continental?', ['Alfred Wegener', 'Charles Darwin', 'Isaac Newton', 'Charles Richter']],
      ['Como se chamava o supercontinente que existiu há cerca de 250 milhões de anos?', ['Pangeia', 'Laurásia apenas', 'Atlântida', 'Gondwana apenas']],
      ['Nas dorsais oceânicas, as placas…', ['afastam-se e forma-se nova crosta', 'aproximam-se e afundam', 'deslizam lado a lado sem criar crosta', 'ficam paradas']],
      ['Os Himalaias formaram-se num limite…', ['convergente', 'divergente', 'transformante', 'passivo']],
      ['O mergulho de uma placa sob outra chama-se…', ['subducção', 'diagénese', 'erosão', 'sedimentação']],
      ['Fósseis da mesma espécie em continentes hoje separados são um argumento a favor da deriva continental.', true],
      ['Uma fratura nas rochas com deslocamento dos blocos chama-se…', ['falha', 'dobra', 'estrato', 'cratera']]
    ]
  },
  {
    id: 'cn7_sismos', t: 'Sismos',
    k: 'sismos,sismo,terramoto,terramotos,abalos,ondas sismicas,hipocentro,foco,epicentro,sismografo,sismograma,escala de richter,magnitude,intensidade,escala de mercalli,escala macrossismica europeia,tsunami,risco sismico,1755',
    ae: 'Explicar a origem dos sismos, distinguir magnitude e intensidade e conhecer medidas de proteção.',
    r: [
      'Um sismo é uma vibração da Terra causada pela libertação brusca de energia acumulada nas rochas (normalmente em falhas).',
      'Hipocentro (foco): local, em profundidade, onde o sismo se origina. Epicentro: ponto à superfície, na vertical do hipocentro.',
      'As ondas sísmicas são registadas por sismógrafos; o registo chama-se sismograma.',
      'Magnitude (escala de Richter): energia libertada — é um valor único para cada sismo.',
      'Intensidade (Escala Macrossísmica Europeia ou de Mercalli modificada): efeitos causados em pessoas e construções — varia de lugar para lugar.',
      'Tsunami: ondas gigantes provocadas por um sismo no fundo do mar (como em Lisboa, em 1755).',
      'Durante um sismo: baixar, proteger e aguardar — debaixo de uma mesa resistente, longe de janelas.'
    ],
    q: [
      ['O ponto à superfície por cima do foco do sismo chama-se…', ['epicentro', 'hipocentro', 'sismograma', 'falha']],
      ['A escala de Richter mede…', ['a magnitude (energia libertada)', 'a intensidade (estragos)', 'a profundidade', 'a duração']],
      ['A intensidade de um sismo…', ['varia de lugar para lugar', 'é igual em todo o lado', 'mede-se em graus Celsius', 'só se mede no epicentro']],
      ['O aparelho que regista as ondas sísmicas chama-se…', ['sismógrafo', 'barómetro', 'termómetro', 'dinamómetro']],
      ['Em que ano Lisboa foi destruída por um sismo seguido de tsunami?', ['1755', '1640', '1910', '1580']],
      ['Durante um sismo, deves abrigar-te debaixo de uma mesa resistente.', true],
      ['O local em profundidade onde se origina o sismo chama-se…', ['hipocentro', 'epicentro', 'cratera', 'dorsal']]
    ]
  },
  {
    id: 'cn7_fosseis', t: 'Fósseis e história da Terra',
    k: 'fosseis,fossil,fossilizacao,mumificacao,moldagem,mineralizacao,icnofosseis,pegadas,dinossauros,tempo geologico,escala do tempo geologico,eras geologicas,paleozoico,mesozoico,cenozoico,principio da sobreposicao,datacao relativa,fosseis de idade,trilobites,amonites',
    ae: 'Explicar a formação de fósseis, a sua importância na reconstituição da história da Terra e os princípios de datação relativa.',
    r: [
      'Fósseis: restos ou vestígios de seres vivos que viveram no passado, preservados nas rochas (sobretudo sedimentares).',
      'Processos de fossilização: mineralização (substituição por minerais), moldagem (molde interno/externo), mumificação (conservação total — ex.: no gelo ou no âmbar) e marcas de atividade (icnofósseis: pegadas, ovos, excrementos).',
      'Condições favoráveis: soterramento rápido, partes duras e ausência de decomposição.',
      'Princípio da sobreposição: numa sequência de estratos não deformados, os de baixo são mais antigos do que os de cima.',
      'Fósseis de idade: viveram pouco tempo e em muitos locais → permitem datar estratos (ex.: trilobites no Paleozoico, amonites no Mesozoico).',
      'Eras geológicas: Pré-Câmbrico, Paleozoico, Mesozoico (dos dinossauros) e Cenozoico (dos mamíferos). A Terra tem cerca de 4600 milhões de anos.',
      'Em Portugal há muitas pegadas de dinossauros (ex.: Serra de Aire, Cabo Espichel).'
    ],
    q: [
      ['Uma pegada de dinossauro preservada numa rocha é um…', ['icnofóssil', 'fóssil mumificado', 'mineral', 'magma']],
      ['Um mamute conservado no gelo é um exemplo de…', ['mumificação', 'moldagem', 'mineralização', 'sedimentação']],
      ['Segundo o princípio da sobreposição, os estratos mais antigos estão…', ['em baixo', 'em cima', 'no meio', 'sempre na vertical']],
      ['Em que era viveram os dinossauros?', ['Mesozoico', 'Cenozoico', 'Paleozoico', 'Pré-Câmbrico']],
      ['As trilobites são fósseis de idade do…', ['Paleozoico', 'Cenozoico', 'Mesozoico', 'Holocénico']],
      ['O soterramento rápido favorece a fossilização.', true],
      ['Qual é a idade aproximada da Terra?', ['4600 milhões de anos', '6000 anos', '4,6 milhões de anos', '460 mil milhões de anos']]
    ]
  }
]);

// ============================================================= FÍSICO-QUÍMICA
TEMAS(7, 'fq', [
  {
    id: 'fq7_universo', t: 'Universo e distâncias no Universo',
    k: 'universo,galaxias,galaxia,via lactea,estrelas,estrela,big bang,nebulosas,enxames,constelacoes,ano-luz,ano luz,unidade astronomica,distancias no universo,astros',
    ae: 'Descrever a organização do Universo (galáxias, estrelas, sistemas planetários) e usar unidades de distância astronómicas (UA e ano-luz).',
    r: [
      'O Universo terá começado há cerca de 13 800 milhões de anos (teoria do Big Bang) e está em expansão.',
      'Galáxias: enormes conjuntos de estrelas, gás e poeiras. A nossa é a Via Láctea (galáxia espiral). Formas: espirais, elípticas e irregulares.',
      'Estrelas: astros com luz própria. O Sol é uma estrela de tamanho médio. Nascem em nebulosas.',
      'Constelações: grupos de estrelas que, vistas da Terra, parecem formar figuras (Ursa Maior, Orion).',
      'Unidade astronómica (UA): distância média Terra–Sol ≈ 150 milhões de km.',
      'Ano-luz (a.l.): distância percorrida pela luz num ano ≈ 9,5 × 10¹² km. A velocidade da luz é cerca de 300 000 km/s.'
    ],
    q: [
      ['Como se chama a nossa galáxia?', ['Via Láctea', 'Andrómeda', 'Ursa Maior', 'Orion']],
      ['O ano-luz é uma unidade de…', ['distância', 'tempo', 'massa', 'velocidade']],
      ['A unidade astronómica corresponde à distância média…', ['da Terra ao Sol', 'da Terra à Lua', 'do Sol a Neptuno', 'entre duas galáxias']],
      ['Qual é, aproximadamente, a velocidade da luz?', ['300 000 km/s', '300 km/h', '150 milhões de km/s', '1 ano-luz por hora']],
      ['As estrelas nascem em…', ['nebulosas', 'planetas', 'cometas', 'satélites']],
      ['O Sol é uma estrela.', true],
      ['Segundo a teoria do Big Bang, o Universo está em contração.', false, 'Está em expansão.']
    ]
  },
  {
    id: 'fq7_sistemasolar', t: 'Sistema Solar, Terra e Lua',
    k: 'sistema solar,planetas,planetas rochosos,planetas gasosos,cometas,asteroides,cintura de asteroides,satelites,lua,fases da lua,eclipses,eclipse,eclipse do sol,eclipse da lua,rotacao,translacao,estacoes do ano,eixo da terra,movimentos da terra',
    ae: 'Caracterizar os astros do Sistema Solar; relacionar os movimentos da Terra e da Lua com o dia e a noite, as estações do ano, as fases da Lua e os eclipses.',
    r: [
      'Planetas principais: rochosos/telúricos (Mercúrio, Vénus, Terra, Marte) e gasosos/gigantes (Júpiter, Saturno, Úrano, Neptuno). Entre Marte e Júpiter fica a cintura de asteroides.',
      'Planetas anões: Plutão, Ceres, Éris…; cometas (núcleo de gelo e poeira, com cauda quando se aproximam do Sol).',
      'Rotação da Terra (≈ 24 h) → dias e noites e movimento aparente do Sol. Translação (≈ 365,25 dias) + inclinação do eixo → estações do ano.',
      'A Lua demora cerca de 27,3 dias a dar a volta à Terra e mostra-nos sempre a mesma face. Fases (≈ 29,5 dias): Lua Nova, Quarto Crescente, Lua Cheia, Quarto Minguante.',
      'Eclipse do Sol: a Lua fica entre o Sol e a Terra (só em Lua Nova). Eclipse da Lua: a Terra fica entre o Sol e a Lua (só em Lua Cheia).',
      'No solstício de junho começa o verão no hemisfério norte; nos equinócios, o dia e a noite têm igual duração.'
    ],
    q: [
      ['Qual destes é um planeta gasoso?', ['Saturno', 'Marte', 'Vénus', 'Mercúrio']],
      ['Onde se situa a cintura principal de asteroides?', ['entre Marte e Júpiter', 'entre a Terra e Marte', 'depois de Neptuno', 'entre Vénus e a Terra']],
      ['As estações do ano devem-se à translação e…', ['à inclinação do eixo da Terra', 'à distância à Lua', 'à rotação da Lua', 'às marés']],
      ['Num eclipse do Sol, quem está no meio?', ['a Lua', 'a Terra', 'o Sol', 'Marte']],
      ['Um eclipse da Lua só pode acontecer na fase de…', ['Lua Cheia', 'Lua Nova', 'Quarto Crescente', 'Quarto Minguante']],
      ['Plutão é atualmente classificado como planeta anão.', true],
      ['Vemos sempre a mesma face da Lua.', true]
    ]
  },
  {
    id: 'fq7_forcas', t: 'Forças, peso e massa',
    k: 'forcas,forca,newton,dinamometro,peso,massa,peso e massa,forca gravitica,gravidade,gravitacao,intensidade da forca,vetor,forca resultante,aceleracao gravitica',
    ae: 'Caracterizar forças (intensidade, direção, sentido e ponto de aplicação); distinguir peso de massa e relacionar o peso com a força gravítica.',
    r: [
      'Força: ação capaz de alterar o movimento ou a forma de um corpo. Representa-se por um vetor: ponto de aplicação, direção, sentido e intensidade.',
      'A intensidade das forças mede-se com um dinamómetro, em newtons (N).',
      'Força gravítica: força atrativa entre corpos com massa; aumenta com as massas e diminui com a distância.',
      'Peso: força gravítica exercida pela Terra (ou outro astro) sobre um corpo. Na Terra, P ≈ massa × 10 (N/kg) → 1 kg pesa cerca de 10 N.',
      'Massa: quantidade de matéria, medida em kg com uma balança; não varia de lugar para lugar. O peso varia (na Lua é cerca de 6 vezes menor).',
      'Força resultante: força que produz o mesmo efeito do que todas as forças juntas.'
    ],
    q: [
      ['Em que unidade se mede a intensidade de uma força?', ['newton (N)', 'quilograma (kg)', 'joule (J)', 'metro (m)']],
      ['Com que instrumento se mede a intensidade de uma força?', ['dinamómetro', 'balança', 'termómetro', 'cronómetro']],
      ['Um astronauta vai da Terra para a Lua. O que acontece à sua massa?', ['fica igual', 'diminui 6 vezes', 'aumenta', 'passa a zero']],
      ['Na Terra, qual é aproximadamente o peso de um corpo com 5 kg?', ['50 N', '5 N', '0,5 N', '500 N']],
      ['A força gravítica diminui quando a distância entre os corpos…', ['aumenta', 'diminui', 'fica igual', 'é zero']],
      ['Peso e massa são a mesma coisa.', false, 'Massa é quantidade de matéria (kg); peso é uma força (N).'],
      ['Duas forças de 3 N e 5 N com a mesma direção e sentido têm resultante de…', ['8 N', '2 N', '15 N', '5 N']]
    ]
  },
  {
    id: 'fq7_materiais', t: 'Substâncias e misturas',
    k: 'materiais,substancias,substancia,misturas,mistura,mistura homogenea,mistura heterogenea,coloide,coloidal,substancia pura,solucao,solucoes,composicao qualitativa,materiais naturais,materiais manufaturados',
    ae: 'Distinguir substâncias de misturas e classificar misturas em homogéneas, heterogéneas e coloidais.',
    r: [
      'Substância: material formado por um só componente (ex.: água destilada, oxigénio, ouro puro).',
      'Mistura: material com dois ou mais componentes.',
      'Mistura homogénea: não se distinguem os componentes, mesmo ao microscópio (água com açúcar dissolvido, ar, latão). As misturas homogéneas são soluções.',
      'Mistura heterogénea: distinguem-se os componentes à vista desarmada (água e azeite, granito, areia e água).',
      'Coloide: parece homogéneo à vista, mas ao microscópio vêem-se os componentes (leite, maionese, nevoeiro, gelatina, sangue).',
      'Materiais naturais existem na natureza (madeira, granito); manufaturados são produzidos pelo ser humano (vidro, plástico).'
    ],
    q: [
      ['Água com sal completamente dissolvido é uma mistura…', ['homogénea', 'heterogénea', 'coloidal', 'que é substância']],
      ['Água e azeite formam uma mistura…', ['heterogénea', 'homogénea', 'coloidal', 'substância']],
      ['O leite é um exemplo de…', ['coloide', 'substância', 'mistura heterogénea visível', 'solução']],
      ['Qual destes materiais é uma substância?', ['água destilada', 'ar', 'água do mar', 'granito']],
      ['O ar é uma mistura homogénea de gases.', true],
      ['O granito é uma mistura…', ['heterogénea', 'homogénea', 'coloidal', 'substância']],
      ['As misturas homogéneas também se chamam…', ['soluções', 'coloides', 'suspensões', 'substâncias']]
    ]
  },
  {
    id: 'fq7_solucoes', t: 'Soluções e concentração mássica',
    k: 'solucoes,solucao,soluto,solvente,concentracao,concentracao massica,solucao saturada,solucao diluida,solucao concentrada,solubilidade,dissolver,g/l,g/dm3',
    ae: 'Identificar soluto e solvente e calcular a concentração mássica de uma solução.',
    r: [
      'Solução: mistura homogénea. O solvente é o componente em maior quantidade (ou o que dissolve, ex.: água); o soluto é o que se dissolve.',
      'Concentração mássica: Cm = massa de soluto : volume de solução (normalmente em g/dm³ ou g/L).',
      'Exemplo: 20 g de açúcar em 0,5 dm³ de solução → Cm = 20 : 0,5 = 40 g/dm³.',
      'Diluir: adicionar solvente → a concentração diminui. Concentrar: evaporar solvente ou adicionar soluto.',
      'Solução saturada: já não dissolve mais soluto a essa temperatura.',
      '1 dm³ = 1 L = 1000 mL = 1000 cm³.'
    ],
    q: [
      ['Na água com açúcar, o açúcar é o…', ['soluto', 'solvente', 'coloide', 'precipitado']],
      ['Dissolvem-se 30 g de sal em água até 0,5 dm³ de solução. Qual é a concentração mássica?', ['60 g/dm³', '15 g/dm³', '30 g/dm³', '150 g/dm³']],
      ['Se adicionarmos água a uma solução, a concentração…', ['diminui', 'aumenta', 'fica igual', 'duplica sempre']],
      ['Uma solução que já não dissolve mais soluto chama-se…', ['saturada', 'diluída', 'insaturada', 'coloidal']],
      ['1 dm³ é igual a 1 L.', true],
      ['Qual é a fórmula da concentração mássica?', ['massa de soluto : volume de solução', 'volume : massa', 'massa × volume', 'massa de solvente : massa de soluto']],
      ['Quantos gramas de soluto há em 2 dm³ de uma solução com 25 g/dm³?', ['50 g', '12,5 g', '25 g', '27 g']]
    ]
  },
  {
    id: 'fq7_propriedades', t: 'Propriedades físicas: massa volúmica e pontos de fusão e ebulição',
    k: 'propriedades fisicas,massa volumica,densidade,ponto de fusao,ponto de ebulicao,estados fisicos,mudancas de estado,fusao,solidificacao,vaporizacao,condensacao,sublimacao,ebulicao,evaporacao,identificar substancias',
    ae: 'Usar propriedades físicas (massa volúmica, ponto de fusão, ponto de ebulição) para identificar substâncias e prever o seu estado físico.',
    r: [
      'Estados físicos: sólido, líquido e gasoso. Mudanças: fusão (s→l), solidificação (l→s), vaporização (l→g: evaporação ou ebulição), condensação (g→l), sublimação (s→g) e sublimação inversa/ressublimação (g→s).',
      'Ponto de fusão (PF): temperatura a que uma substância passa de sólido a líquido. Ponto de ebulição (PE): temperatura a que entra em ebulição. Para a água pura (à pressão normal): PF = 0 °C e PE = 100 °C.',
      'Durante a mudança de estado de uma substância pura, a temperatura mantém-se constante (patamar no gráfico).',
      'Massa volúmica: ρ = massa : volume (g/cm³ ou kg/m³). Água: 1 g/cm³. Materiais com ρ menor do que a água flutuam nela.',
      'Se uma substância está a uma temperatura abaixo do PF, é sólida; entre PF e PE, líquida; acima do PE, gasosa.'
    ],
    q: [
      ['Um objeto tem 40 g de massa e 20 cm³ de volume. Qual é a sua massa volúmica?', ['2 g/cm³', '800 g/cm³', '0,5 g/cm³', '60 g/cm³']],
      ['A passagem de sólido a líquido chama-se…', ['fusão', 'solidificação', 'condensação', 'sublimação']],
      ['A passagem direta de sólido a gasoso chama-se…', ['sublimação', 'vaporização', 'fusão', 'condensação']],
      ['Uma substância tem PF = −10 °C e PE = 80 °C. A 25 °C está no estado…', ['líquido', 'sólido', 'gasoso', 'plasma']],
      ['Durante a fusão do gelo puro, a temperatura mantém-se constante.', true],
      ['Um material com massa volúmica 0,8 g/cm³ colocado em água…', ['flutua', 'afunda', 'dissolve-se sempre', 'evapora']],
      ['Qual é o ponto de ebulição da água pura à pressão normal?', ['100 °C', '0 °C', '50 °C', '273 °C']]
    ]
  },
  {
    id: 'fq7_transformacoes', t: 'Transformações físicas e químicas',
    k: 'transformacoes fisicas,transformacoes quimicas,transformacao fisica,transformacao quimica,reacao quimica,reacoes quimicas,reagentes,produtos,combustao,eletrolise,fotolise,termolise,acao mecanica,juntar substancias',
    ae: 'Distinguir transformações físicas de transformações químicas e identificar formas de provocar transformações químicas.',
    r: [
      'Transformação física: não se formam novas substâncias (mudanças de estado, dissolver açúcar, partir vidro).',
      'Transformação química (reação química): formam-se novas substâncias (combustão, ferrugem, cozinhar um ovo, fruta a apodrecer).',
      'Indícios de reação química: mudança de cor, libertação de gás, formação de sólido (precipitado), variação de temperatura, emissão de luz, cheiro.',
      'Formas de provocar reações: junção de substâncias, aquecimento (termólise), luz (fotólise), corrente elétrica (eletrólise) e ação mecânica (fricção/choque).',
      'Numa reação, as substâncias iniciais são os reagentes e as que se formam são os produtos.'
    ],
    q: [
      ['Qual destas é uma transformação química?', ['queimar papel', 'derreter gelo', 'dissolver sal em água', 'cortar papel']],
      ['Qual destas é uma transformação física?', ['evaporação da água', 'formação de ferrugem', 'cozer um bolo', 'combustão do gás']],
      ['Uma reação provocada pela luz chama-se…', ['fotólise', 'eletrólise', 'termólise', 'combustão']],
      ['A decomposição da água pela corrente elétrica chama-se…', ['eletrólise', 'fotólise', 'termólise', 'fusão']],
      ['Numa reação química, as substâncias que se formam chamam-se…', ['produtos', 'reagentes', 'solventes', 'solutos']],
      ['A libertação de um gás pode indicar uma reação química.', true],
      ['Acender um fósforo por fricção é uma reação provocada por…', ['ação mecânica', 'luz', 'corrente elétrica', 'junção de água']]
    ]
  },
  {
    id: 'fq7_separacao', t: 'Técnicas de separação de misturas',
    k: 'separacao de misturas,tecnicas de separacao,filtracao,decantacao,destilacao,destilacao simples,cristalizacao,evaporacao,centrifugacao,separacao magnetica,peneiracao,cromatografia,funil de decantacao,ampola de decantacao,sublimacao',
    ae: 'Selecionar e aplicar técnicas de separação dos componentes de misturas.',
    r: [
      'Misturas heterogéneas: peneiração (sólidos de tamanhos diferentes), filtração (sólido não dissolvido de um líquido), decantação (sólido-líquido ou dois líquidos imiscíveis, com ampola/funil de decantação), centrifugação (acelera a separação) e separação magnética (com íman).',
      'Misturas homogéneas: destilação simples (separa um líquido de um sólido dissolvido, ou líquidos com pontos de ebulição diferentes), cristalização/evaporação (obter o sólido dissolvido) e cromatografia (separar corantes/pigmentos).',
      'Água e azeite → decantação (ampola de decantação).',
      'Água e areia → decantação e filtração.',
      'Água salgada → evaporação/cristalização (para obter o sal) ou destilação (para obter a água).',
      'Limalha de ferro e enxofre → separação magnética.'
    ],
    q: [
      ['Que técnica usas para separar água e azeite?', ['decantação', 'filtração', 'destilação', 'separação magnética']],
      ['Que técnica separa limalha de ferro de areia?', ['separação magnética', 'cromatografia', 'destilação', 'evaporação']],
      ['Para obter água pura a partir de água salgada usa-se…', ['destilação simples', 'filtração', 'decantação', 'peneiração']],
      ['Que técnica separa os pigmentos de uma tinta de caneta?', ['cromatografia', 'filtração', 'decantação', 'centrifugação']],
      ['Para separar a areia da água, usa-se…', ['filtração', 'destilação', 'cromatografia', 'separação magnética']],
      ['As salinas obtêm sal por evaporação da água do mar.', true],
      ['A filtração separa o sal dissolvido na água.', false, 'O sal dissolvido passa pelo filtro; usa-se evaporação ou destilação.']
    ]
  },
  {
    id: 'fq7_energia', t: 'Energia: fontes e transferências',
    k: 'energia,fontes de energia,energias renovaveis,energias nao renovaveis,transferencias de energia,energia cinetica,energia potencial,conducao,conveccao,radiacao,calor,temperatura,joule,eficiencia,equilibrio termico,isoladores termicos,condutores termicos',
    ae: 'Identificar fontes e formas de energia, transferências de energia (calor por condução, convecção e radiação) e a sua utilização sustentável.',
    r: [
      'A energia mede-se em joules (J). Pode manifestar-se como energia cinética (movimento) ou potencial (armazenada: gravítica, química, elástica).',
      'Fontes renováveis: Sol, vento, água (hídrica), ondas, marés, geotérmica, biomassa. Não renováveis: petróleo, carvão, gás natural, urânio.',
      'A energia transfere-se de um sistema para outro, por exemplo como calor (do corpo mais quente para o mais frio até ao equilíbrio térmico).',
      'Condução: transferência de calor por contacto, sobretudo em sólidos (bons condutores: metais; maus condutores/isoladores: madeira, cortiça, ar).',
      'Convecção: transferência de calor em líquidos e gases através de correntes (o fluido quente sobe, o frio desce).',
      'Radiação: transferência de energia sem necessidade de meio material (ex.: energia do Sol a chegar à Terra).',
      'Temperatura não é o mesmo que calor: temperatura mede o grau de agitação das partículas; calor é energia transferida.'
    ],
    q: [
      ['Em que unidade se mede a energia no Sistema Internacional?', ['joule (J)', 'newton (N)', 'watt (W)', 'grau Celsius (°C)']],
      ['Como chega a energia do Sol à Terra?', ['por radiação', 'por condução', 'por convecção', 'por eletrólise']],
      ['A água a aquecer numa panela forma correntes. É uma transferência por…', ['convecção', 'condução', 'radiação', 'sublimação']],
      ['Qual destas fontes de energia é renovável?', ['solar', 'carvão', 'petróleo', 'gás natural']],
      ['Uma colher de metal aquece toda quando uma ponta está na sopa quente. Isto é…', ['condução', 'convecção', 'radiação', 'fotólise']],
      ['Um corpo em movimento tem energia cinética.', true],
      ['O calor transfere-se espontaneamente do corpo mais frio para o mais quente.', false, 'Transfere-se do mais quente para o mais frio.']
    ]
  }
]);
