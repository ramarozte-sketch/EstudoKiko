/* 4.º ano — conteúdos alinhados com os manuais PLIM (versões inclusivas) e com
   o caderno de revisões "O meu Smartphone de Finalista". Fonte prioritária. */

// ============================================================= PORTUGUÊS (PLIM 4)
TEMAS(4, 'pt', [
  {
    id: 'pt4_m_formacao', t: 'Prefixos, sufixos e família de palavras', livro: 1,
    k: 'prefixos,prefixo,sufixos,sufixo,palavras simples,palavras complexas,afixos,familia de palavras,radical,formacao de palavras',
    ae: 'Identificar palavras simples e complexas, o significado de prefixos e sufixos e famílias de palavras.',
    r: [
      'Palavra simples: não vem de nenhuma outra (casa, gato, mar).',
      'Palavra complexa: forma-se a partir de outra palavra ou de um radical, juntando afixos.',
      'Prefixo: vai antes da base. re- (outra vez: reler), des- (o contrário: desmontar), in-/im-/i- (negação: incompleto, impaciente, ilegal).',
      'Sufixo: vai depois da base. -ista e -eiro (profissão: jornalista, livreiro), -mente (modo: felizmente), -inho (diminutivo: fofinho).',
      'Família de palavras: palavras que nascem da mesma palavra ou radical. Ex.: sol → solar, solarengo, guarda-sol; mar → maresia, marinha, beira-mar.'
    ],
    q: [
      ['Qual destas palavras tem um prefixo?', ['desarrumar', 'arrumação', 'arrumado', 'arrumar'], 'des- é um prefixo: vem antes da base.'],
      ['O prefixo "re-" em "reler" significa…', ['outra vez', 'o contrário', 'muito pequeno', 'sem']],
      ['Em "impaciente", o prefixo "im-" dá a ideia de…', ['negação', 'repetição', 'profissão', 'lugar']],
      ['Qual destas palavras tem um sufixo que indica profissão?', ['jornalista', 'felizmente', 'gatinho', 'reler']],
      ['Qual destas palavras é simples?', ['casa', 'casinha', 'casarão', 'caseiro']],
      ['"Felizmente" forma-se com o sufixo…', ['-mente', '-feliz', '-ente', 'feliz-']],
      ['Qual destas palavras NÃO pertence à família de "mar"?', ['martelo', 'maresia', 'marinheiro', 'beira-mar'], '"Martelo" começa por "mar", mas não tem nada a ver com o mar.'],
      ['"Livreiro" é uma palavra complexa formada com um sufixo.', true],
      ['Qual destas palavras pertence à família de "sol"?', ['solarengo', 'soldado', 'solteiro', 'solução']],
      ['"Ilegal" significa…', ['que não é legal', 'muito legal', 'outra vez legal', 'pouco legal']]
    ]
  },
  {
    id: 'pt4_m_plurais', t: 'Plurais e femininos irregulares', livro: 1,
    k: 'plurais irregulares,plural irregular,plural,plurais,femininos irregulares,feminino irregular,feminino,femininos,masculino',
    ae: 'Formar o plural e o feminino irregulares de nomes e adjetivos.',
    r: [
      'Plural — regra geral: junta-se -s (gato castanho → gatos castanhos).',
      'Palavras em -ão fazem o plural de três maneiras: -ães (capitães), -ãos (mãos) ou -ões (feijões).',
      'Palavras em -m trocam o -m por -ns: garagem → garagens; jardim → jardins.',
      'Palavras em -al, -el, -ol, -ul trocam o -l por -is: anzol → anzóis; papel → papéis. Em -il: se a palavra for aguda, -il → -is (barril → barris); se for grave, -il → -eis (frágil → frágeis).',
      'Palavras em -r, -s, -z (e algumas em -n, -x) juntam -es: cantor → cantores; país → países; rapaz → rapazes.',
      'Feminino — regra geral: o -o passa a -a (pato branco → pata branca).',
      'Em -ão: leitão → leitoa; alemão → alemã; comilão → comilona. Em -or: -eira ou -triz (vendedor → vendedeira; ator → atriz).',
      'Às vezes o feminino é outra palavra (cão → cadela; genro → nora; boi → vaca). Outras palavras são iguais nos dois géneros e só muda o determinante (o/a ilusionista; um/uma intérprete).',
      'Alguns animais só têm uma forma: junta-se macho ou fêmea (a cobra macho, a cobra fêmea).'
    ],
    q: [
      ['Qual é o plural de "garagem"?', ['garagens', 'garagems', 'garageis', 'garagem']],
      ['Qual é o plural de "anzol"?', ['anzóis', 'anzols', 'anzoles', 'anzóes']],
      ['Qual é o plural de "barril"?', ['barris', 'barrils', 'barreis', 'barriles'], 'É palavra aguda em -il: troca-se -l por -s.'],
      ['Qual é o plural de "frágil"?', ['frágeis', 'frágils', 'frágis', 'frágiles'], 'É palavra grave em -il: muda para -eis.'],
      ['Qual é o plural de "capitão"?', ['capitães', 'capitãos', 'capitões', 'capitãoes']],
      ['Qual é o plural de "feijão"?', ['feijões', 'feijães', 'feijãos', 'feijãs']],
      ['Qual é o plural de "rapaz"?', ['rapazes', 'rapazs', 'rapazis', 'rapaz']],
      ['Qual é o feminino de "ator"?', ['atriz', 'atora', 'atoreira', 'atrixa']],
      ['Qual é o feminino de "leitão"?', ['leitoa', 'leitã', 'leitona', 'leitoã']],
      ['Qual é o feminino de "alemão"?', ['alemã', 'alemoa', 'alemona', 'alemãe']],
      ['Qual é o feminino de "genro"?', ['nora', 'genra', 'genrinha', 'sogra']],
      ['Em "o ilusionista / a ilusionista", o que muda?', ['só o determinante', 'a terminação da palavra', 'a palavra inteira', 'nada, é sempre igual']],
      ['Qual é o feminino de "vendedor"?', ['vendedeira', 'vendedriz', 'vendedoa', 'vendedã']],
      ['O plural de "mão" é "mãos".', true]
    ]
  },
  {
    id: 'pt4_m_graus', t: 'Graus dos nomes e dos adjetivos', livro: 1,
    k: 'graus,grau,diminutivo,aumentativo,comparativo,superlativo,superlativo absoluto,superlativo relativo,analitico,sintetico,graus dos adjetivos,graus dos nomes',
    ae: 'Identificar o grau diminutivo e aumentativo dos nomes e os graus normal, comparativo e superlativo dos adjetivos.',
    r: [
      'Nomes — diminutivo com -inho, -zinho, -ito, -ote (abelhinha, passarito); aumentativo com -ão, -arrão, -aço, -ona (gatona, canzarrão).',
      'Adjetivos — grau normal: bonito.',
      'Comparativo de superioridade: mais bonito do que…; de igualdade: tão bonito como…; de inferioridade: menos bonito do que…',
      'Superlativo relativo: o mais bonito (de superioridade) ou o menos bonito (de inferioridade) — compara com um grupo.',
      'Superlativo absoluto: analítico com "muito" (muito bonito) ou sintético com -íssimo (bonitíssimo).',
      'Casos especiais: bom → melhor → ótimo; mau → pior → péssimo; grande → maior → máximo; pequeno → menor → mínimo.'
    ],
    q: [
      ['"Canzarrão" está no grau…', ['aumentativo', 'diminutivo', 'normal', 'superlativo']],
      ['"Passarito" está no grau…', ['diminutivo', 'aumentativo', 'comparativo', 'normal']],
      ['"A Ana é tão alta como a Rita." O adjetivo está no…', ['comparativo de igualdade', 'comparativo de superioridade', 'superlativo absoluto', 'grau normal']],
      ['"A Lua é muito bonita." O adjetivo está no…', ['superlativo absoluto analítico', 'superlativo absoluto sintético', 'comparativo de superioridade', 'superlativo relativo']],
      ['"Bonitíssimo" está no…', ['superlativo absoluto sintético', 'superlativo absoluto analítico', 'comparativo de inferioridade', 'grau normal']],
      ['"O Rui é o mais rápido da turma." O adjetivo está no…', ['superlativo relativo de superioridade', 'comparativo de superioridade', 'superlativo absoluto', 'grau normal']],
      ['"O livro é menos caro do que o jogo." O adjetivo está no…', ['comparativo de inferioridade', 'comparativo de igualdade', 'superlativo relativo de inferioridade', 'grau normal']],
      ['Qual é o superlativo absoluto sintético de "bom"?', ['ótimo', 'boníssimo', 'melhor', 'muito bom']],
      ['Qual é o comparativo de superioridade de "mau"?', ['pior', 'mais mau', 'péssimo', 'malíssimo']],
      ['Qual destas palavras está no diminutivo?', ['abelhinha', 'abelhão', 'abelhona', 'abelha']]
    ]
  },
  {
    id: 'pt4_m_pronomes', t: 'Pronomes e determinantes interrogativos', livro: 1,
    k: 'pronomes,pronome,pronomes pessoais,formas tonicas,formas atonas,tonica,atona,pronomes possessivos,possessivo,pronomes demonstrativos,demonstrativo,isto,isso,aquilo,determinantes interrogativos,interrogativo',
    ae: 'Identificar pronomes pessoais (formas tónicas e átonas), possessivos e demonstrativos, e determinantes interrogativos.',
    r: [
      'Os pronomes substituem um nome ou um grupo nominal, para não repetir palavras.',
      'Pronomes pessoais — formas tónicas: eu, tu, ele, ela, nós, vós, eles, elas; mim, ti, si; comigo, contigo, consigo, connosco, convosco.',
      'Formas átonas: aparecem junto ao verbo, muitas vezes com hífen: me, te, lhe, se, nos, vos, lhes, o, a, os, as (leu-me, viu-a, deu-lhes).',
      'Em frases negativas ou com certos advérbios antes do verbo, o pronome átono passa para antes do verbo: «Vi-o» → «Não o vi»; «Já o vi».',
      'Pronomes possessivos: indicam a quem pertence (meu, minha, teu, tua, seu, sua, nosso, nossa, vosso, vossa e plurais). «De quem é? É meu.»',
      'Pronomes demonstrativos: indicam a posição em relação a quem fala — este/esta (perto de mim), esse/essa (perto de ti), aquele/aquela (longe dos dois). Invariáveis: isto, isso, aquilo.',
      'Determinantes interrogativos: começam perguntas e acompanham o nome — que (invariável), qual/quais (variável). «Que carta escolhes?» «Quais as pistas?»'
    ],
    q: [
      ['Em "O pai fez-me o jantar.", "me" é um pronome pessoal na forma…', ['átona', 'tónica', 'possessiva', 'demonstrativa']],
      ['Qual destes é um pronome pessoal na forma tónica?', ['comigo', 'lhe', 'o', 'nos']],
      ['"Vi a Ana." Substitui "a Ana" por um pronome:', ['Vi-a.', 'Vi-lhe.', 'Vi-ela.', 'Vi-o.']],
      ['"Vi o filme." Na negativa fica…', ['Não o vi.', 'Não vi-o.', 'Não vi-lo.', 'Não lhe vi.']],
      ['"De quem é o casaco? É teu." "Teu" é um pronome…', ['possessivo', 'demonstrativo', 'pessoal', 'interrogativo']],
      ['Que pronome demonstrativo indica algo longe de quem fala e de quem ouve?', ['aquele', 'este', 'esse', 'meu']],
      ['Qual destes pronomes demonstrativos é invariável?', ['isto', 'este', 'esta', 'estes']],
      ['Em "Que livro queres ler?", "que" é um…', ['determinante interrogativo', 'pronome possessivo', 'pronome pessoal', 'advérbio']],
      ['"Quais" é um determinante interrogativo variável.', true],
      ['Qual é o pronome possessivo feminino plural da 1.ª pessoa do singular?', ['minhas', 'meus', 'nossas', 'tuas']],
      ['Em "Este é o melhor de todos os livros.", "este" é um pronome…', ['demonstrativo', 'possessivo', 'pessoal', 'interrogativo']]
    ]
  },
  {
    id: 'pt4_m_preposicoes', t: 'Preposições', livro: 1,
    k: 'preposicoes,preposicao,sob,sobre,contracao,contracoes',
    ae: 'Identificar preposições e usá-las corretamente.',
    r: [
      'As preposições são palavras invariáveis que ligam dois elementos da frase.',
      'Preposições simples: a, ante, após, até, com, contra, de, desde, em, entre, para, perante, por, sem, sob, sobre, trás.',
      'Sob = por baixo de («O caminho sob a ponte»). Sobre = por cima de ou acerca de («Os livros estão sobre a mesa»; «um texto sobre baleias»).',
      'Contrações: de + o = do; em + a = na; a + o = ao; a + a = à; por + o = pelo.'
    ],
    q: [
      ['"Os livros estão … a mesa." (por cima)', ['sobre', 'sob', 'entre', 'sem']],
      ['"O gato dormia … a cama." (por baixo)', ['sob', 'sobre', 'após', 'contra']],
      ['Qual destas palavras é uma preposição?', ['após', 'depois', 'aqui', 'bonito']],
      ['"Na" resulta da contração de…', ['em + a', 'de + a', 'a + a', 'para + a']],
      ['"Pelo" resulta da contração de…', ['por + o', 'para + o', 'pé + lo', 'de + lo']],
      ['As preposições variam em género e número.', false, 'São invariáveis: nunca mudam de forma.'],
      ['Em "Entre os dois, prefiro o primeiro.", a preposição é…', ['entre', 'os', 'prefiro', 'primeiro']]
    ]
  },
  {
    id: 'pt4_m_frases', t: 'Sujeito, predicado, conectores e frases complexas', livro: 1,
    k: 'grupo nominal,grupo verbal,sujeito,predicado,conectores,conector,conectores discursivos,frase complexa,frases complexas,frase simples,expansao,reducao,expandir frases,reduzir frases',
    ae: 'Identificar sujeito/grupo nominal e predicado/grupo verbal; expandir e reduzir frases; formar frases complexas; usar conectores discursivos.',
    r: [
      'O sujeito é desempenhado por um grupo nominal (GN); o predicado é desempenhado pelo grupo verbal (GV). «[A Marta]GN [comprou uma caderneta]GV.»',
      'Expandir uma frase: acrescentar adjetivos, determinantes, advérbios ou expressões de tempo, lugar e modo. Reduzir: retirar esses elementos sem perder o sentido principal.',
      'Frase simples tem um verbo; frase complexa tem mais do que um verbo. Juntam-se frases com: e, mas, ou, pois, logo, porque, quando, para que, se…',
      'Conectores discursivos ligam ideias: acrescentar (e, além disso), ordenar (em primeiro lugar, de seguida, finalmente), explicar (isto é, ou seja), exemplificar (por exemplo), oposição (contudo, no entanto, porém), tempo (quando, depois, entretanto), causa (porque, visto que, uma vez que), conclusão (logo, portanto, por isso, em conclusão).'
    ],
    q: [
      ['Em "O Jorge visita um castelo.", qual é o grupo nominal sujeito?', ['O Jorge', 'visita um castelo', 'um castelo', 'visita']],
      ['Em "A Marta comprou uma caderneta.", qual é o grupo verbal?', ['comprou uma caderneta', 'A Marta', 'uma caderneta', 'Marta']],
      ['Qual destas frases é complexa?', ['Desliga o computador e vem lanchar.', 'O gato dorme.', 'Amanhã vou à praia.', 'A Rita leu um livro.'], 'Tem dois verbos: desliga e vem.'],
      ['"Gostava de ir, … estou cansado." Que conector indica oposição?', ['mas', 'porque', 'logo', 'e']],
      ['"Em conclusão" é um conector que serve para…', ['concluir', 'exemplificar', 'ordenar', 'indicar tempo']],
      ['"Fiquei em casa … estava a chover." Que conector indica causa?', ['porque', 'contudo', 'finalmente', 'por exemplo']],
      ['"Em primeiro lugar", "de seguida" e "finalmente" servem para…', ['ordenar ideias', 'mostrar oposição', 'explicar', 'concluir']],
      ['"A prima deu-me um abraço." Qual é a frase expandida?', ['A minha prima Alexandra deu-me um abraço muito forte.', 'A prima deu-me.', 'Deu-me um abraço.', 'Um abraço.']],
      ['Reduzir uma frase é retirar elementos como adjetivos e advérbios.', true],
      ['"Isto é" e "ou seja" são conectores para…', ['explicar', 'acrescentar', 'indicar tempo', 'mostrar causa']]
    ]
  },
  {
    id: 'pt4_m_sentido', t: 'Onomatopeias, sentido figurado e expressões idiomáticas', livro: 1,
    k: 'onomatopeias,onomatopeia,sentido figurado,sentido literal,expressoes idiomaticas,expressao idiomatica,significado nao literal',
    ae: 'Reconhecer onomatopeias, distinguir sentido literal e figurado e compreender expressões idiomáticas.',
    r: [
      'Onomatopeias são palavras que imitam sons de animais, pessoas, objetos e da Natureza: miau, muuu, trrim-trrim (telefone), fom-fom (buzina), splash (água), bzzz (abelha), ding-dong (campainha), glu-glu (peru), psst (chamar a atenção).',
      'Sentido literal: o significado comum, o do dicionário («Sábado vou à praia»).',
      'Sentido figurado: um significado diferente, que só se percebe pelo contexto («Nunca mais é sábado!» = estou ansioso).',
      'Expressões idiomáticas: expressões de uso comum que se entendem pelo sentido global e não palavra a palavra — «andar nas nuvens» (estar distraído), «abrir o coração» (contar o que se sente), «abandonar o barco» (desistir), «sacudir a água do capote» (fugir às responsabilidades), «acordar com os pés de fora» (acordar mal-disposto).'
    ],
    q: [
      ['Qual destas palavras é uma onomatopeia?', ['splash', 'água', 'molhado', 'mar']],
      ['"Trrim-trrim" imita o som…', ['do telefone', 'da vaca', 'da buzina', 'do peru']],
      ['"Glu-glu" é o som de que animal?', ['peru', 'gato', 'abelha', 'vaca']],
      ['"Ele anda nas nuvens." Quer dizer que…', ['está distraído', 'está a voar de avião', 'está no topo de uma montanha', 'está a chover']],
      ['"Acordei com os pés de fora." Quer dizer que…', ['acordei mal-disposto', 'tive frio nos pés', 'dormi no sofá', 'perdi as meias']],
      ['"Sacudir a água do capote" significa…', ['fugir às responsabilidades', 'secar o casaco', 'ir à chuva', 'arrumar o armário']],
      ['"Abrir o coração" significa…', ['contar o que sentimos', 'fazer uma operação', 'ter medo', 'correr muito']],
      ['Em "Nunca mais é sábado!", a palavra "sábado" está em sentido figurado.', true],
      ['As expressões idiomáticas devem ser entendidas palavra a palavra.', false, 'Percebem-se pelo sentido global.']
    ]
  },
  {
    id: 'pt4_m_textos', t: 'Tipos de texto e leituras do manual', livro: 1,
    k: 'texto descritivo,texto informativo,noticia,entrevista,artigo de revista,artigo de enciclopedia,banda desenhada,texto dramatico,texto narrativo,leituras do manual,pnl,plano nacional de leitura',
    ae: 'Ler textos de diferentes géneros (narrativo, descritivo, informativo, notícia, entrevista, banda desenhada, dramático) e identificar as suas características.',
    r: [
      'Texto narrativo: conta uma história com personagens, espaço, tempo e ação (introdução, desenvolvimento e conclusão).',
      'Texto descritivo: diz como é uma pessoa, animal, lugar ou objeto (aspeto físico, carácter), usando muitos adjetivos.',
      'Texto informativo (artigo de enciclopédia ou de revista): dá informação verdadeira sobre um assunto, com título e às vezes subtítulos e imagens.',
      'Notícia: conta um acontecimento recente e responde a: O quê? Quem? Quando? Onde? Como? Porquê? Tem título e lead (primeiro parágrafo com o essencial).',
      'Entrevista: perguntas do entrevistador e respostas do entrevistado.',
      'Banda desenhada: conta uma história em vinhetas, com balões de fala e de pensamento e onomatopeias.',
      'Texto dramático: escrito para ser representado; tem personagens, falas e didascálias (indicações entre parênteses).',
      'Algumas leituras do PLIM 4: «O menino escritor» (Rosário Alçada Araújo), «A menina que inventava animais» (José Fanha), «As mais belas coisas do mundo» (Valter Hugo Mãe), «As abelhas do velho Paulino» (António Mota), «Os peixes que fugiram da história» (Maria João Freitas), «A prima do Anacleto» (António Torrado e Maria Alberta Menéres), «O bando das cavernas» (Nuno Caravela), «Anna Kadabra» (Pedro Mañas), «Na terra dos animais falantes» (Richard Zimler).'
    ],
    q: [
      ['Que tipo de texto responde a "O quê? Quem? Quando? Onde?" sobre um acontecimento recente?', ['notícia', 'poema', 'texto dramático', 'banda desenhada']],
      ['Num texto dramático, as indicações entre parênteses chamam-se…', ['didascálias', 'vinhetas', 'estrofes', 'balões']],
      ['A banda desenhada organiza-se em…', ['vinhetas', 'estrofes', 'atos e cenas', 'parágrafos de enciclopédia']],
      ['Um texto que diz como é uma pessoa ou um lugar é…', ['descritivo', 'dramático', 'uma notícia', 'uma entrevista']],
      ['Numa entrevista há…', ['perguntas e respostas', 'só rimas', 'vinhetas', 'didascálias']],
      ['Quem escreveu "As abelhas do velho Paulino"?', ['António Mota', 'José Fanha', 'Nuno Caravela', 'Valter Hugo Mãe']],
      ['"A prima do Anacleto" é um texto…', ['dramático', 'informativo', 'notícia', 'poema']],
      ['Quem escreveu "A menina que inventava animais"?', ['José Fanha', 'António Mota', 'Pedro Mañas', 'Richard Zimler']],
      ['"O bando das cavernas", de Nuno Caravela, é uma…', ['banda desenhada', 'notícia', 'entrevista', 'enciclopédia']],
      ['O lead de uma notícia é o primeiro parágrafo, com a informação essencial.', true]
    ]
  }
]);

// ============================================================= MATEMÁTICA (PLIM 4)
TEMAS(4, 'mat', [
  {
    id: 'mat4_m_mult', t: 'Algoritmo da multiplicação', gen: 'mult2alg4', livro: 1,
    k: 'algoritmo da multiplicacao,multiplicar,multiplicacao,multiplicando,multiplicador,produto,fatores,dois algarismos,igualdades aritmeticas,calculo mental',
    ae: 'Multiplicar com o algoritmo (um e dois algarismos no multiplicador) e usar propriedades no cálculo mental.',
    r: [
      'Numa multiplicação: multiplicando × multiplicador = produto. O multiplicando e o multiplicador chamam-se fatores.',
      'O algoritmo usa a decomposição: 485 × 8 = 8×5 + 8×80 + 8×400 = 40 + 640 + 3200 = 3880.',
      'Com dois algarismos no multiplicador (396 × 24): primeiro multiplica-se pelas unidades (396 × 4 = 1584), depois pelas dezenas (396 × 20 = 7920) e somam-se: 9504.',
      'Cálculo mental: multiplicar primeiro os fatores que dão dezenas certas (2 × 7 × 5 = 10 × 7 = 70); 18 × 25 = 9 × 50 = 450.',
      'Igualdades aritméticas: os dois lados do sinal = valem o mesmo (6 × 4 = 3 × 8).'
    ],
    q: [
      ['Numa multiplicação, o resultado chama-se…', ['produto', 'quociente', 'soma', 'diferença']],
      ['Em 396 × 24, o número 24 é o…', ['multiplicador', 'multiplicando', 'produto', 'divisor']],
      ['Qual destas igualdades é verdadeira?', ['6 × 4 = 3 × 8', '6 × 4 = 3 × 9', '5 × 4 = 2 × 9', '7 × 3 = 4 × 5']],
      ['Quanto é 2 × 9 × 5?', ['90', '45', '180', '19'], '2 × 5 = 10; 10 × 9 = 90.'],
      ['Quanto é 485 × 8?', ['3880', '3240', '4880', '3800']],
      ['Quanto é 396 × 24?', ['9504', '9404', '1584', '7920']]
    ]
  },
  {
    id: 'mat4_m_div', t: 'Algoritmo da divisão', gen: 'div2alg4', livro: 1,
    k: 'algoritmo da divisao,dividir,divisao,dividendo,divisor,quociente,resto,dois algarismos no divisor,prova da divisao',
    ae: 'Dividir com o algoritmo, com um e dois algarismos no divisor, e interpretar o resto.',
    r: [
      'Numa divisão: dividendo : divisor = quociente, e pode sobrar um resto.',
      'A divisão está relacionada com a multiplicação: 24 : 4 = 6 porque 6 × 4 = 24.',
      'Com dois algarismos no divisor (138 : 12): 10 × 12 = 120, sobram 18; 1 × 12 = 12, sobram 6. Quociente 11, resto 6.',
      'O resto é sempre menor do que o divisor. Se o resto for 0, a divisão é exata.',
      'Prova: divisor × quociente + resto = dividendo (12 × 11 + 6 = 138).'
    ],
    q: [
      ['Em 138 : 12, qual é o quociente e o resto?', ['11, resto 6', '10, resto 18', '12, resto 0', '11, resto 12']],
      ['O resto de uma divisão é sempre…', ['menor do que o divisor', 'maior do que o divisor', 'igual ao quociente', 'zero']],
      ['Como se faz a prova da divisão?', ['divisor × quociente + resto = dividendo', 'dividendo + divisor = quociente', 'quociente − resto = divisor', 'dividendo × divisor = resto']],
      ['Uma divisão com resto 0 chama-se…', ['exata', 'inteira', 'decimal', 'impossível']],
      ['Quanto é 96 : 12?', ['8', '7', '9', '12']]
    ]
  },
  {
    id: 'mat4_m_decimais', t: 'Décimas, centésimas, milésimas e : 10, 100, 1000', gen: 'dividir10_4', livro: 1,
    k: 'decima,centesima,milesima,decimas,centesimas,milesimas,dividir por 10,dividir por 100,dividir por 1000,multiplicar por 10,reta numerica,ordenar decimais,comparar decimais',
    ae: 'Ler, representar, comparar e ordenar números decimais até às milésimas; multiplicar e dividir por 10, 100 e 1000.',
    r: [
      'Um número decimal tem parte inteira e parte decimal, separadas pela vírgula. 2439,328: 3 décimas, 2 centésimas, 8 milésimas.',
      '1 unidade = 10 décimas = 100 centésimas = 1000 milésimas.',
      'Para comparar decimais, compara-se primeiro a parte inteira, depois as décimas, as centésimas…: 0,85 > 0,735 porque 8 décimas > 7 décimas.',
      'Dividir por 10, 100 ou 1000 torna o número 10, 100 ou 1000 vezes menor: a vírgula anda 1, 2 ou 3 casas para a esquerda (1234 : 100 = 12,34; 4 : 1000 = 0,004).',
      'Multiplicar por 10, 100 ou 1000: a vírgula anda 1, 2 ou 3 casas para a direita (2,5 × 100 = 250).'
    ],
    q: [
      ['Quanto é 5000 : 100?', ['50', '500', '5', '0,5']],
      ['Quanto é 1234 : 1000?', ['1,234', '12,34', '123,4', '0,1234']],
      ['Qual é o maior número?', ['0,85', '0,735', '0,491', '0,8']],
      ['Em 2439,328, qual é o algarismo das centésimas?', ['2', '3', '8', '9']],
      ['1 unidade tem quantas milésimas?', ['1000', '100', '10', '10 000']],
      ['Qual é a ordem crescente certa?', ['0,491 < 0,735 < 0,85', '0,85 < 0,735 < 0,491', '0,735 < 0,491 < 0,85', '0,491 < 0,85 < 0,735']]
    ]
  },
  {
    id: 'mat4_m_opdec', t: 'Adição e subtração de números decimais', gen: 'opdec4', livro: 1,
    k: 'adicao de decimais,subtracao de decimais,somar decimais,subtrair decimais,algoritmo com decimais,compensacao,decomposicao',
    ae: 'Adicionar e subtrair números decimais com cálculo mental e com o algoritmo.',
    r: [
      'No algoritmo, alinham-se as vírgulas: unidades por baixo de unidades, décimas por baixo de décimas, centésimas por baixo de centésimas.',
      'Decomposição: 5,34 + 2,41 = (5 + 2) + (0,3 + 0,4) + (0,04 + 0,01) = 7,75.',
      'Compensação: 20,5 − 9,9 = (20,5 − 10) + 0,1 = 10,6.',
      'Se faltar algarismo, pode-se acrescentar um zero no fim da parte decimal: 3,5 = 3,50.'
    ],
    q: [
      ['Quanto é 5,34 + 2,41?', ['7,75', '7,57', '8,75', '7,65']],
      ['Quanto é 20,5 − 9,9?', ['10,6', '11,6', '10,4', '11,4']],
      ['Quanto é 23,62 − 12,41?', ['11,21', '11,12', '10,21', '36,03']],
      ['No algoritmo com decimais, o mais importante é…', ['alinhar as vírgulas', 'alinhar à esquerda', 'tirar as vírgulas', 'começar pelas unidades de milhar']],
      ['Quanto é 0,5 + 0,25?', ['0,75', '0,30', '0,525', '7,5']]
    ]
  },
  {
    id: 'mat4_m_percent', t: 'Frações, decimais e percentagens', gen: 'percent4', livro: 1,
    k: 'percentagem,percentagens,por cento,%,fracao decimal,frações decimais,fracoes e decimais',
    ae: 'Relacionar frações, números decimais e percentagens (10%, 25%, 50%, 75%, 100%).',
    r: [
      'Percentagem quer dizer "por cento": em cada 100. 25% = 25/100 = 0,25.',
      '10% = 10/100 = 0,10 (a décima parte); 25% = 0,25 (a quarta parte, 1/4); 50% = 0,50 (metade, 1/2); 75% = 0,75 (3/4); 100% = o todo.',
      'Para calcular 50% de 40, faz-se metade: 20. Para 10% de 80, divide-se por 10: 8. Para 25% de 60, divide-se por 4: 15.'
    ],
    q: [
      ['50% corresponde a…', ['metade', 'um quarto', 'o dobro', 'um décimo']],
      ['Como se escreve 25% em número decimal?', ['0,25', '2,5', '25', '0,025']],
      ['Quanto é 10% de 80?', ['8', '80', '0,8', '18']],
      ['Quanto é 25% de 60?', ['15', '25', '6', '30']],
      ['75% corresponde à fração…', ['3/4', '1/4', '7/5', '1/75']],
      ['100% de um bolo é o bolo inteiro.', true]
    ]
  },
  {
    id: 'mat4_m_capacidade', t: 'Capacidade: litro, centilitro e mililitro', gen: 'capacidade4', livro: 1,
    k: 'capacidade,litro,litros,centilitro,centilitros,mililitro,mililitros,cl,ml,meio litro,quarto de litro,medidas de capacidade',
    ae: 'Usar o litro, o centilitro e o mililitro e fazer estimativas de capacidade.',
    r: [
      'Capacidade é a quantidade de líquido que um recipiente consegue conter. A unidade principal é o litro (l).',
      '1 l = 100 cl = 1000 ml; 1 cl = 10 ml.',
      'Meio litro (1/2 l) = 50 cl = 500 ml; um quarto de litro (1/4 l) = 25 cl = 250 ml.',
      'Estimativas: uma colher de chá leva uns 5 ml; um copo cerca de 25 cl; um pacote de leite 1 l; um garrafão 5 l.'
    ],
    q: [
      ['Quantos centilitros tem 1 litro?', ['100 cl', '10 cl', '1000 cl', '50 cl']],
      ['Meio litro tem quantos mililitros?', ['500 ml', '50 ml', '250 ml', '5000 ml']],
      ['1 cl = quantos ml?', ['10 ml', '100 ml', '1 ml', '1000 ml']],
      ['Um quarto de litro é igual a…', ['25 cl', '4 cl', '40 cl', '250 cl']],
      ['Qual é a capacidade mais provável de um pacote de leite?', ['1 l', '1 ml', '100 l', '10 ml']],
      ['Quantos copos de 250 ml enchem 1 litro?', ['4', '2', '10', '25']]
    ]
  },
  {
    id: 'mat4_m_dinheiro', t: 'Dinheiro: orçamento, receita, despesa e saldo', gen: 'saldo4', livro: 1,
    k: 'dinheiro,orcamento,receita,receitas,despesa,despesas,saldo,mesada,educacao para o consumo,euros,euro,rendimentos',
    ae: 'Resolver problemas com dinheiro e usar as noções de orçamento, receita, despesa e saldo.',
    r: [
      'Orçamento: plano que fazemos antes de comprar, para organizar o dinheiro que temos e o que vamos gastar.',
      'Receita (rendimento): dinheiro que se recebe — ordenado, pensão, mesada, prendas…',
      'Despesa: dinheiro que se gasta — alimentação, transporte, renda de casa…',
      'Saldo = receita − despesa. É o dinheiro que ainda fica disponível.',
      'Educação para o consumo: comparar preços, comprar só o necessário e poupar.'
    ],
    q: [
      ['Como se calcula o saldo?', ['receita − despesa', 'receita + despesa', 'despesa − receita', 'despesa × receita']],
      ['A mesada é uma…', ['receita', 'despesa', 'saldo', 'dívida']],
      ['Pagar o bilhete do autocarro é uma…', ['despesa', 'receita', 'poupança', 'saldo']],
      ['A Rita tinha 20 € e gastou 7,50 €. Qual é o saldo?', ['12,50 €', '27,50 €', '13,50 €', '12 €']],
      ['Um orçamento serve para planear o dinheiro antes de o gastar.', true]
    ]
  },
  {
    id: 'mat4_m_quadrilateros', t: 'Quadriláteros, retas e circunferência', livro: 1,
    k: 'quadrilateros,quadrilatero,paralelogramo,losango,retangulo,quadrado,retas paralelas,retas perpendiculares,circulo,circunferencia,raio,diametro,centro',
    ae: 'Classificar quadriláteros; identificar retas paralelas e perpendiculares; distinguir círculo de circunferência, raio e diâmetro.',
    r: [
      'Quadrilátero: figura com 4 lados e 4 ângulos.',
      'Paralelogramo: dois pares de lados opostos paralelos. Retângulo: 4 ângulos retos. Losango: 4 lados iguais. Quadrado: 4 lados iguais e 4 ângulos retos — por isso o quadrado também é retângulo e losango (e todos são paralelogramos).',
      'Retas paralelas: têm a mesma direção, nunca se encontram e estão sempre à mesma distância (as riscas de uma passadeira).',
      'Retas perpendiculares: cruzam-se formando ângulos retos (90°), como as pás de um moinho.',
      'Circunferência: a linha que contorna. Círculo: a circunferência mais o seu interior. O centro está à mesma distância de todos os pontos da circunferência.',
      'O raio vai do centro à circunferência; o diâmetro atravessa o círculo passando pelo centro e mede o dobro do raio.'
    ],
    q: [
      ['O quadrado também é…', ['retângulo e losango', 'só retângulo', 'triângulo', 'trapézio, mas não paralelogramo']],
      ['Um quadrilátero com 4 lados iguais, mas sem ângulos retos, é um…', ['losango', 'quadrado', 'retângulo', 'triângulo']],
      ['As riscas de uma passadeira representam retas…', ['paralelas', 'perpendiculares', 'curvas', 'concorrentes oblíquas']],
      ['Retas perpendiculares formam ângulos de…', ['90°', '45°', '180°', '60°']],
      ['Se o raio mede 4 cm, o diâmetro mede…', ['8 cm', '2 cm', '4 cm', '16 cm']],
      ['A linha que contorna o círculo chama-se…', ['circunferência', 'diâmetro', 'raio', 'centro']],
      ['O círculo é a circunferência mais o seu interior.', true],
      ['Retas paralelas encontram-se num ponto.', false]
    ]
  },
  {
    id: 'mat4_m_simetria', t: 'Simetria de reflexão e de rotação', livro: 1,
    k: 'simetria,simetria de reflexao,simetria de rotacao,eixo de simetria,eixo de reflexao,mira,espelho,rotacao,meia volta,quarto de volta',
    ae: 'Identificar simetrias de reflexão (eixos) e de rotação (centro, amplitude e sentido).',
    r: [
      'Simetria de reflexão: a figura tem pelo menos um eixo de simetria, uma reta que a divide em duas metades iguais, como num espelho. Pode verificar-se com um espelho ou uma mira.',
      'Simetria de rotação: ao rodar a figura à volta de um ponto (o centro), ela coincide consigo mesma antes de dar a volta completa.',
      'Amplitudes de rotação: um quarto de volta = 90°; meia volta = 180°; três quartos de volta = 270°; uma volta = 360°. O sentido pode ser horário ou anti-horário.',
      'Um quadrado tem 4 eixos de simetria e simetria de rotação de 90°, 180° e 270°.'
    ],
    q: [
      ['Meia volta corresponde a uma rotação de…', ['180°', '90°', '270°', '360°']],
      ['Um quarto de volta corresponde a…', ['90°', '45°', '180°', '25°']],
      ['Quantos eixos de simetria tem um quadrado?', ['4', '2', '1', '8']],
      ['Que instrumento podemos usar para verificar uma simetria de reflexão?', ['um espelho ou uma mira', 'uma balança', 'um termómetro', 'uma bússola']],
      ['Na simetria de rotação, o ponto à volta do qual a figura roda chama-se…', ['centro', 'eixo', 'vértice', 'raio']],
      ['Três quartos de volta são 270°.', true]
    ]
  },
  {
    id: 'mat4_m_solidos', t: 'Sólidos e planificações', livro: 1,
    k: 'planificacao,planificacoes,prismas,prisma,piramides,piramide,faces laterais,base,prisma hexagonal,piramide quadrangular',
    ae: 'Identificar prismas e pirâmides pelas planificações e relacionar o nome com a forma da base.',
    r: [
      'A planificação mostra todas as faces de um sólido abertas num plano.',
      'Prismas: têm 2 bases iguais e as faces laterais são retângulos.',
      'Pirâmides: têm 1 base e as faces laterais são triângulos que se juntam num vértice.',
      'O nome vem da forma da base: prisma triangular, quadrangular, pentagonal, hexagonal; pirâmide triangular, quadrangular…',
      'Um prisma hexagonal tem 8 faces (2 bases + 6 laterais); uma pirâmide quadrangular tem 5 faces (1 base + 4 laterais).'
    ],
    q: [
      ['As faces laterais de uma pirâmide são…', ['triângulos', 'retângulos', 'círculos', 'hexágonos']],
      ['Quantas bases tem um prisma?', ['2', '1', '0', '4']],
      ['Um prisma com bases hexagonais chama-se…', ['prisma hexagonal', 'pirâmide hexagonal', 'cubo', 'prisma pentagonal']],
      ['Quantas faces tem uma pirâmide quadrangular?', ['5', '4', '6', '8']],
      ['Quantas faces tem um prisma hexagonal?', ['8', '6', '12', '7']],
      ['O nome do prisma ou da pirâmide depende da forma da base.', true]
    ]
  },
  {
    id: 'mat4_m_algebra', t: 'Sequências de crescimento e relações algébricas', livro: 1,
    k: 'sequencias de crescimento,sequencia de crescimento,relacoes algebricas,relacoes numericas,regularidades,termo,ordem do termo,dobro,triplo,letras',
    ae: 'Descobrir regularidades em sequências de crescimento e representar relações com tabelas e letras.',
    r: [
      'Numa sequência de crescimento, cada figura (termo) tem mais elementos do que a anterior, seguindo uma regra.',
      'Se cada figura tem tantos elementos como o seu número de ordem, a figura 100 tem 100 elementos.',
      'Se a figura n é um quadrado com n de lado, tem n × n quadradinhos: figura 3 → 9; figura 20 → 400.',
      'Podemos usar letras para escrever relações: V = 2 × L (o número de estrelas verdes é o dobro das cor de laranja); T = 3 × L (o total é o triplo).',
      'Uma tabela ajuda a ver a regra: figura 1 → 3, figura 2 → 6, figura 3 → 9… (é sempre o triplo do número da figura).'
    ],
    q: [
      ['Numa sequência em que a figura n tem n × n quadrados, quantos tem a figura 5?', ['25', '10', '5', '20']],
      ['Se T = 3 × L e L = 4, quanto é T?', ['12', '7', '34', '1']],
      ['Se V = 2 × L e L = 50, quanto é V?', ['100', '52', '25', '150']],
      ['Sequência: 3, 6, 9, 12, … Qual é o 10.º termo?', ['30', '15', '33', '27']],
      ['Se cada figura tem tantos triângulos como o seu número, a figura 100 tem…', ['100 triângulos', '101 triângulos', '99 triângulos', '200 triângulos']],
      ['Figura 1: 4 palitos; figura 2: 8; figura 3: 12. Quantos palitos tem a figura 6?', ['24', '16', '20', '18']]
    ]
  },
  {
    id: 'mat4_m_dados', t: 'Caule-e-folhas duplo, barras duplo e probabilidades', livro: 1,
    k: 'caule e folhas duplo,diagrama de caule e folhas,grafico de barras duplo,barras duplo,probabilidades,probabilidade,impossivel,improvavel,provavel,certo,igualmente provavel,acaso',
    ae: 'Ler e construir diagramas de caule-e-folhas duplos e gráficos de barras duplos; usar a linguagem das probabilidades.',
    r: [
      'Diagrama de caule-e-folhas duplo: um só caule no meio, comum a dois conjuntos de dados; as folhas de um conjunto ficam à esquerda e as do outro à direita. Serve para comparar.',
      'Ex.: caule 1 com folha 3 à direita lê-se 13; caule 1 com folha 3 à esquerda também se lê 13 (lê-se sempre caule e depois folha).',
      'Gráfico de barras duplo: duas barras para cada categoria (por exemplo, rapazes e raparigas), com uma legenda de cores.',
      'Probabilidades: um acontecimento pode ser impossível, improvável, provável ou certo. Dois acontecimentos podem ser igualmente prováveis.',
      'Ex.: é impossível fevereiro ter 30 dias; é certo amanhã ter 24 horas; ao lançar uma moeda, face nacional e face europeia são igualmente prováveis.'
    ],
    q: [
      ['Num diagrama de caule-e-folhas duplo, quantos caules há?', ['um, comum aos dois conjuntos', 'dois', 'nenhum', 'um para cada folha']],
      ['Para que serve um gráfico de barras duplo?', ['comparar dois conjuntos de dados', 'medir ângulos', 'fazer contas de dividir', 'desenhar mapas']],
      ['"Fevereiro ter 30 dias" é um acontecimento…', ['impossível', 'certo', 'provável', 'igualmente provável']],
      ['Ao lançar uma moeda, sair face nacional ou face europeia é…', ['igualmente provável', 'impossível', 'certo', 'improvável']],
      ['"Amanhã ter 24 horas" é um acontecimento…', ['certo', 'impossível', 'improvável', 'provável']],
      ['Num saco com 9 bolas azuis e 1 vermelha, tirar uma bola vermelha é…', ['improvável', 'certo', 'impossível', 'mais provável do que azul']],
      ['Num caule-e-folhas, caule 2 e folha 5 lê-se…', ['25', '52', '7', '2,5']]
    ]
  }
]);

// ============================================================= ESTUDO DO MEIO (PLIM 4)
TEMAS(4, 'em', [
  {
    id: 'em4_m_sistemas', t: 'Sistemas do corpo humano', livro: 1,
    k: 'sistema digestivo,sistema respiratorio,sistema circulatorio,sistema excretor,sistema urinario,rins,bexiga,coracao,pulmoes,estomago,intestino,traqueia,bronquios,arterias,veias,capilares,figado,pancreas,esofago,faringe,laringe,pele,adolescencia,puberdade,sistemas do corpo',
    ae: 'Identificar os órgãos e as funções dos sistemas digestivo, respiratório, circulatório, excretor e reprodutor e as mudanças da adolescência.',
    r: [
      'Sistema digestivo — tubo digestivo: boca → faringe → esófago → estômago → intestino delgado → intestino grosso → reto → ânus. Glândulas anexas: glândulas salivares, fígado e pâncreas. Transforma os alimentos em nutrientes.',
      'Sistema respiratório: fossas nasais → faringe → laringe → traqueia → brônquios → bronquíolos → pulmões. Na inspiração entra oxigénio; na expiração sai dióxido de carbono.',
      'Sistema circulatório: o coração bombeia o sangue pelos vasos sanguíneos — artérias (saem do coração), veias (voltam ao coração) e capilares (muito finos).',
      'Sistema excretor (urinário): os rins filtram o sangue e formam a urina, que desce pelos ureteres até à bexiga e sai pela uretra. A pele também elimina substâncias pelo suor.',
      'Sistemas reprodutores: permitem ter filhos; o feminino inclui ovários e útero, o masculino inclui testículos.',
      'Adolescência: começa com a puberdade, com mudanças no corpo e nas emoções — aparecem pelos e por vezes acne; os rapazes ganham barba e a voz muda; as raparigas desenvolvem o peito e começam a ter menstruação.'
    ],
    q: [
      ['Que órgão bombeia o sangue para todo o corpo?', ['o coração', 'os pulmões', 'o estômago', 'os rins']],
      ['Que órgãos filtram o sangue e formam a urina?', ['os rins', 'os pulmões', 'o fígado', 'o coração']],
      ['A urina desce dos rins até à bexiga pelos…', ['ureteres', 'brônquios', 'capilares', 'esófago']],
      ['Qual é a ordem certa no sistema respiratório?', ['fossas nasais, faringe, laringe, traqueia, brônquios, pulmões', 'boca, esófago, estômago, pulmões', 'traqueia, fossas nasais, brônquios, laringe', 'pulmões, traqueia, faringe, boca']],
      ['Que órgão liga a boca/faringe ao estômago?', ['o esófago', 'a traqueia', 'a uretra', 'o pâncreas']],
      ['O fígado e o pâncreas são…', ['glândulas anexas do sistema digestivo', 'partes do sistema respiratório', 'vasos sanguíneos', 'ossos']],
      ['Os vasos que levam o sangue do coração para o corpo chamam-se…', ['artérias', 'veias', 'ureteres', 'brônquios']],
      ['Na inspiração, o ar que entra nos pulmões traz…', ['oxigénio', 'dióxido de carbono', 'urina', 'sangue']],
      ['A adolescência começa com a puberdade.', true],
      ['O intestino delgado vem antes do intestino grosso no tubo digestivo.', true]
    ]
  },
  {
    id: 'em4_m_dinastias', t: 'Portugal: da formação às quatro dinastias', livro: 1,
    k: 'dinastias,dinastia,primeira dinastia,segunda dinastia,terceira dinastia,quarta dinastia,condado portucalense,afonso henriques,sao mamede,zamora,alcanizes,1383,aljubarrota,ceuta,tordesilhas,vasco da gama,pedro alvares cabral,1580,1640,restauracao,terramoto 1755,marques de pombal,muculmanos,reconquista',
    ae: 'Conhecer factos e datas da formação de Portugal e das quatro dinastias.',
    r: [
      '711: os muçulmanos chegam à Península Ibérica. 722: começa a Reconquista cristã nas Astúrias.',
      '1096: D. Henrique recebe o Condado Portucalense por ajudar na Reconquista (veio com D. Raimundo).',
      '1128: Batalha de São Mamede — D. Afonso Henriques vence as tropas da mãe, D. Teresa.',
      '1143: Conferência de Zamora — o rei de Leão e Castela reconhece D. Afonso Henriques como rei. 1179: o Papa reconhece Portugal como reino. Começa a 1.ª dinastia (Afonsina).',
      '1249: D. Afonso III conquista o Algarve. 1297: Tratado de Alcanizes — fixa a fronteira com Castela.',
      '1383–1385: crise de sucessão; D. João I, Mestre de Avis, torna-se rei. Começa a 2.ª dinastia (de Avis).',
      '1415: conquista de Ceuta, início da expansão marítima. 1494: Tratado de Tordesilhas divide o mundo entre Portugal e Castela. 1498: Vasco da Gama chega à Índia por mar. 1500: Pedro Álvares Cabral chega ao Brasil.',
      '1580: Portugal perde a independência (reis de Espanha) — 3.ª dinastia (Filipina). 1640: Restauração da independência, D. João IV — 4.ª dinastia (de Bragança).',
      '1755: o terramoto destrói Lisboa; o Marquês de Pombal, a mando de D. José I, reconstrói a Baixa.'
    ],
    q: [
      ['Em que ano foi a Batalha de São Mamede?', ['1128', '1143', '1179', '1096']],
      ['Na Batalha de São Mamede, D. Afonso Henriques venceu as tropas…', ['da mãe, D. Teresa', 'dos muçulmanos', 'de Castela, em Aljubarrota', 'de Espanha, em 1640']],
      ['Que tratado de 1297 definiu as fronteiras entre Portugal e Castela?', ['Tratado de Alcanizes', 'Tratado de Tordesilhas', 'Conferência de Zamora', 'Tratado de Windsor']],
      ['Que rei conquistou o Algarve em 1249?', ['D. Afonso III', 'D. Dinis', 'D. Afonso Henriques', 'D. João I']],
      ['A 2.ª dinastia começou depois da crise de…', ['1383–1385', '1580', '1640', '1755']],
      ['Em que ano Vasco da Gama chegou à Índia por mar?', ['1498', '1500', '1415', '1494']],
      ['Quem chegou ao Brasil em 1500?', ['Pedro Álvares Cabral', 'Vasco da Gama', 'Bartolomeu Dias', 'Gil Eanes']],
      ['O que aconteceu em 1640?', ['a Restauração da independência', 'a perda da independência', 'o terramoto de Lisboa', 'a conquista de Ceuta']],
      ['A 3.ª dinastia é também chamada…', ['Filipina', 'Afonsina', 'de Avis', 'de Bragança']],
      ['Quem reconstruiu a Baixa de Lisboa depois do terramoto de 1755?', ['o Marquês de Pombal', 'D. Afonso Henriques', 'Vasco da Gama', 'D. João IV']],
      ['A conquista de Ceuta, em 1415, marcou o início da expansão marítima.', true],
      ['Em que ano o Papa reconheceu Portugal como reino?', ['1179', '1143', '1128', '1297']]
    ]
  },
  {
    id: 'em4_m_republica', t: 'Do liberalismo ao 25 de Abril', livro: 1,
    k: 'liberalismo,revolucao liberal,1820,monarquia constitucional,guerra civil,liberais,absolutistas,regicidio,1908,republica,primeira republica,1910,5 de outubro,manuel de arriaga,1926,estado novo,ditadura,salazar,25 de abril,revolucao dos cravos,democracia,liberdade',
    ae: 'Conhecer factos e datas desde a revolução liberal até à democracia.',
    r: [
      '1820: Revolução Liberal. 1822: primeira Constituição — Portugal passa a ser uma monarquia constitucional (o rei tem de cumprir a Constituição).',
      '1832–1834: guerra civil entre liberais (D. Pedro) e absolutistas (D. Miguel); ganham os liberais.',
      '1908: Regicídio — o rei D. Carlos e o príncipe herdeiro D. Luís Filipe são assassinados em Lisboa.',
      '5 de outubro de 1910: implantação da República. Fim da monarquia. Manuel de Arriaga é o primeiro Presidente da República (eleito em 1911).',
      '1926: um golpe militar derruba a Primeira República e começa a ditadura. 1933–1974: Estado Novo, governado por Salazar e depois Marcelo Caetano — sem liberdade de expressão, com censura e polícia política.',
      '25 de Abril de 1974: Revolução dos Cravos. Os militares acabam com a ditadura e Portugal torna-se uma democracia, com liberdade e eleições livres.'
    ],
    q: [
      ['Em que ano foi implantada a República em Portugal?', ['1910', '1908', '1926', '1974']],
      ['O que foi o Regicídio, em 1908?', ['o assassinato do rei D. Carlos e do príncipe herdeiro', 'a fuga do rei para o Brasil', 'a eleição do primeiro presidente', 'o fim do Estado Novo']],
      ['Quem foi o primeiro Presidente da República?', ['Manuel de Arriaga', 'Salazar', 'D. Carlos', 'Marquês de Pombal']],
      ['Como ficou conhecida a revolução de 25 de Abril de 1974?', ['Revolução dos Cravos', 'Revolução Liberal', 'Restauração', 'Regicídio']],
      ['O Estado Novo foi um período de…', ['ditadura, sem liberdade', 'democracia', 'monarquia absoluta', 'guerra com Espanha']],
      ['Em que ano foi a Revolução Liberal?', ['1820', '1910', '1640', '1755']],
      ['A guerra civil de 1832–1834 opôs…', ['liberais e absolutistas', 'portugueses e muçulmanos', 'republicanos e cravos', 'Portugal e Inglaterra']],
      ['Em 1926 um golpe militar derrubou a Primeira República.', true]
    ]
  },
  {
    id: 'em4_m_europa', t: 'União Europeia, migrações e tecnologia', livro: 1,
    k: 'uniao europeia,ue,estados membros,27 paises,euro,fluxos migratorios,migracoes,emigracao,imigracao,emigrante,imigrante,transportes,telecomunicacoes',
    ae: 'Localizar os países da União Europeia; compreender os fluxos migratórios; reconhecer a evolução dos transportes e telecomunicações.',
    r: [
      'A União Europeia (UE) tem 27 Estados-membros, todos no continente europeu. Portugal entrou em 1986.',
      'Alguns países da UE: Portugal, Espanha, França, Itália, Alemanha, Bélgica, Países Baixos, Luxemburgo, Irlanda, Dinamarca, Suécia, Finlândia, Estónia, Letónia, Lituânia, Polónia, Chéquia, Eslováquia, Áustria, Hungria, Eslovénia, Croácia, Roménia, Bulgária, Grécia, Malta e Chipre.',
      'Fluxos migratórios: deslocações de pessoas entre países, temporárias ou longas. Emigrar = sair do país; imigrar = entrar noutro país. As pessoas migram por motivos económicos (trabalho) ou humanitários (guerra, catástrofes).',
      'As migrações têm consequências sociais, económicas e na população dos países de partida e de chegada.',
      'Evolução tecnológica: dos carros de bois e barcos à vela aos comboios, carros, aviões; do correio e telégrafo ao telefone, telemóvel e internet.'
    ],
    q: [
      ['Quantos Estados-membros tem a União Europeia?', ['27', '12', '50', '15']],
      ['Qual destes países NÃO pertence à União Europeia?', ['Suíça', 'Espanha', 'Irlanda', 'Grécia']],
      ['Qual destes países é uma ilha da UE no mar Mediterrâneo?', ['Malta', 'Áustria', 'Hungria', 'Polónia']],
      ['Uma pessoa que sai do seu país para ir viver noutro é…', ['emigrante', 'imigrante no seu país', 'turista', 'refugiada sempre']],
      ['As pessoas migram sobretudo por motivos…', ['económicos ou humanitários', 'só desportivos', 'só de férias', 'escolares apenas']],
      ['Em que ano Portugal entrou para a União Europeia (então CEE)?', ['1986', '1974', '1910', '2002']],
      ['O telemóvel e a internet são exemplos da evolução das telecomunicações.', true]
    ]
  },
  {
    id: 'em4_m_natureza', t: 'Extinção, oceano e qualidade do ambiente', livro: 1,
    k: 'extincao,vias de extincao,especies ameacadas,lince iberico,oceano,plastico,plasticos,poluicao,desflorestacao,especies exoticas,populacao mundial,qualidade do ambiente,sobrepastoreio,biodiversidade',
    ae: 'Identificar causas da extinção de seres vivos, a interferência humana no oceano e o efeito do aumento da população no ambiente.',
    r: [
      'Causas da extinção de animais e plantas: desflorestação e destruição de habitats, poluição (água, ar, solo), uso excessivo de recursos, caça e pesca ilegais, introdução de espécies exóticas, exploração agrícola, florestal e comercial.',
      'Em Portugal, o lince-ibérico e a águia-imperial são exemplos de espécies ameaçadas.',
      'O oceano sofre com a poluição dos mares e rios, com as alterações das zonas costeiras e com o plástico, que destrói habitats e reduz a biodiversidade.',
      'Diz NÃO ao plástico descartável: usa garrafas reutilizáveis, sacos de pano e recipientes laváveis.',
      'O aumento da população mundial obriga a explorar mais recursos. Afetam o solo: desflorestação, sobrepastoreio, agricultura intensiva, construções. Afetam a água: águas residuais sem tratamento, adubos e pesticidas. Afetam o ar: transportes poluentes, queima de resíduos e incêndios.',
      'Proteger a Natureza é tarefa de cada um e de todos.'
    ],
    q: [
      ['Qual destas é uma causa de extinção de seres vivos?', ['destruição de habitats', 'plantar árvores', 'reciclar', 'criar reservas naturais']],
      ['Qual destes animais está ameaçado em Portugal?', ['lince-ibérico', 'pombo', 'gato doméstico', 'galinha']],
      ['O que podemos usar em vez de garrafas de plástico descartáveis?', ['garrafas reutilizáveis ou cantis', 'mais sacos de plástico', 'palhinhas de plástico', 'copos descartáveis']],
      ['O sobrepastoreio afeta sobretudo a qualidade…', ['do solo', 'do Sol', 'da Lua', 'do vento']],
      ['Adubos e pesticidas em excesso poluem sobretudo…', ['a água e o solo', 'só o ar', 'o espaço', 'nada']],
      ['Introduzir espécies exóticas pode pôr em perigo as espécies da região.', true],
      ['O plástico no oceano aumenta a biodiversidade.', false, 'Destrói habitats e reduz a biodiversidade.']
    ]
  },
  {
    id: 'em4_m_orientacao', t: 'Orientação: Sol, Estrela Polar e bússola', livro: 1,
    k: 'orientacao,orientar,estrela polar,bussola,pontos cardeais,sol,nascente,poente,norte,sul,este,oeste,sistema solar,planetas',
    ae: 'Localizar a Terra no Sistema Solar; orientar-se pelo Sol, pela Estrela Polar e pela bússola.',
    r: [
      'A Terra é o 3.º planeta a contar do Sol: Mercúrio, Vénus, Terra, Marte, Júpiter, Saturno, Úrano e Neptuno.',
      'De dia, orientamo-nos pelo Sol: nasce a Este (nascente) e põe-se a Oeste (poente). Em Portugal, ao meio-dia, o Sol está a Sul; se olharmos para ele, o Norte fica atrás de nós.',
      'De noite, orientamo-nos pela Estrela Polar, que indica o Norte. Virados para ela, o Sul fica atrás, o Este à direita e o Oeste à esquerda.',
      'A bússola tem uma agulha magnética que aponta sempre para o Norte, por causa do campo magnético da Terra.'
    ],
    q: [
      ['Que estrela indica o Norte durante a noite?', ['Estrela Polar', 'o Sol', 'Sírio', 'a Lua']],
      ['A agulha da bússola aponta sempre para o…', ['Norte', 'Oeste', 'Sul', 'Este']],
      ['Virados para a Estrela Polar, o que fica atrás de nós?', ['o Sul', 'o Norte', 'o Este', 'o Oeste']],
      ['Virados para a Estrela Polar, o Sol nasce à nossa…', ['direita', 'esquerda', 'frente', 'costas']],
      ['Em Portugal, ao meio-dia, o Sol está a…', ['Sul', 'Norte', 'Este', 'Oeste']],
      ['Qual é o planeta entre a Terra e Júpiter?', ['Marte', 'Vénus', 'Saturno', 'Mercúrio']],
      ['De dia podemos orientar-nos pela posição do Sol.', true]
    ]
  },
  {
    id: 'em4_m_interior', t: 'Interior da Terra, catástrofes e usos do solo', livro: 1,
    k: 'interior da terra,estrutura da terra,crosta,manto,nucleo,placas tectonicas,sismografo,sismografos,magnetometro,catastrofes naturais,usos do solo,uso do solo,ocupacao do solo,florestas,agricultura,matos,pastagens,rochas,minerais',
    ae: 'Conhecer a estrutura interna da Terra, relacioná-la com sismos e vulcões e identificar os principais usos do solo em Portugal.',
    r: [
      'A Terra tem três camadas: crosta (a mais exterior, feita de rochas), manto (intermédia; perto da superfície os materiais estão parcialmente fundidos) e núcleo (a mais interior, responsável pelo campo magnético que orienta a bússola).',
      'A superfície está dividida em placas tectónicas. Onde as placas se encontram há mais sismos e vulcões. Os Açores ficam perto do encontro de três placas.',
      'Sismos e vulcões destroem, mas também moldam a paisagem: formam montanhas, vales e ilhas.',
      'Tecnologia na prevenção: sismógrafos (registam sismos), magnetómetros e satélites ajudam a estudar o interior da Terra e a reduzir os riscos.',
      'As rochas são formadas por um ou mais minerais e agrupam-se por cor, textura, cheiro, dureza e estrutura.',
      'Usos do solo em Portugal: sobretudo florestas (a maior parte), agricultura, matos, pastagens, agroflorestas e áreas de construção (casas, estradas, aeroportos…).'
    ],
    q: [
      ['Qual é a camada mais exterior da Terra?', ['crosta', 'manto', 'núcleo', 'atmosfera interior']],
      ['Que camada é responsável pelo campo magnético da Terra?', ['núcleo', 'crosta', 'manto', 'oceano']],
      ['Que aparelho regista os sismos?', ['sismógrafo', 'termómetro', 'barómetro', 'bússola']],
      ['Onde são mais frequentes os sismos e vulcões?', ['onde as placas tectónicas se encontram', 'no centro dos continentes, sempre', 'só nos polos', 'nos rios']],
      ['Em Portugal, qual é o principal uso do solo?', ['florestas', 'aeroportos', 'campos de golfe', 'praias']],
      ['As rochas são formadas por um ou mais…', ['minerais', 'animais', 'plásticos', 'planetas']],
      ['Os vulcões podem formar ilhas, como nos Açores.', true]
    ]
  },
  {
    id: 'em4_m_mapas', t: 'Mapas, população e património natural', livro: 1,
    k: 'mapa hipsometrico,mapa topografico,escala,escalas,grande escala,pequena escala,distribuicao da populacao,densidade populacional,litoral,interior,patrimonio natural,rede natura 2000,areas protegidas,paisagem natural,paisagem humanizada',
    ae: 'Ler mapas hipsométricos e topográficos e escalas; descrever a distribuição da população em Portugal; valorizar o património natural.',
    r: [
      'Mapa hipsométrico: mostra o relevo por cores (verde para baixas altitudes, amarelos e castanhos para altitudes maiores).',
      'Mapa topográfico: mostra com pormenor o relevo, rios, estradas, caminhos de ferro e casas de uma região.',
      'A escala indica quantas vezes o mapa reduz a realidade. Pequena escala: muito reduzida (planisfério, país). Grande escala: menos reduzida, mais pormenor (cidade, freguesia).',
      'Em Portugal continental, a população concentra-se no litoral, sobretudo nas áreas de Lisboa e do Porto. No interior, sobretudo no sul, há menos pessoas (clima mais seco, menos serviços e emprego).',
      'Nas ilhas, São Miguel (Açores) e a Madeira são as mais povoadas: têm mais bens, serviços e bons acessos (aeroportos internacionais).',
      'Património natural: os bens da Natureza de uma região (paisagens, rios, florestas, animais). As áreas protegidas e a Rede Natura 2000 servem para conservar espécies e habitats ameaçados e travar a perda de biodiversidade.'
    ],
    q: [
      ['Que mapa mostra o relevo através de cores?', ['mapa hipsométrico', 'mapa de estradas', 'planta de uma casa', 'mapa do tempo']],
      ['Um mapa de uma freguesia, com muito pormenor, é de…', ['grande escala', 'pequena escala', 'nenhuma escala', 'escala musical']],
      ['Um planisfério é um mapa de…', ['pequena escala', 'grande escala', 'escala real', 'escala de cores']],
      ['Onde vive a maior parte da população de Portugal continental?', ['no litoral', 'no interior sul', 'nas serras', 'no interior norte']],
      ['Que ilhas são as mais povoadas dos arquipélagos?', ['São Miguel e Madeira', 'Corvo e Flores', 'Porto Santo e Santa Maria', 'Desertas e Selvagens']],
      ['A Rede Natura 2000 serve para…', ['conservar espécies e habitats ameaçados', 'construir estradas', 'aumentar a caça', 'fazer prédios junto ao mar']],
      ['O património natural é o conjunto dos bens da Natureza de uma região.', true],
      ['Num mapa topográfico podemos ver estradas, rios e casas.', true]
    ]
  }
]);

// ============================================================= INGLÊS (Start the Magic! 4 / Smartphone)
TEMAS(4, 'ing', [
  {
    id: 'ing4_m_numbers', t: 'Numbers, ordinals and birthdays', livro: 1,
    k: 'numbers,ordinal numbers,ordinals,cardinal numbers,first,second,third,birthday,how old are you,when is your birthday,numeros em ingles,aniversario',
    ae: 'Usar os números cardinais até 100 e os ordinais; perguntar e dizer a idade e a data de aniversário.',
    r: [
      "Cardinal numbers: 11 eleven, 12 twelve, 13 thirteen, 15 fifteen, 20 twenty, 30 thirty, 40 forty, 50 fifty, 80 eighty, 90 ninety, 100 one hundred.",
      "Ordinal numbers: 1st first, 2nd second, 3rd third, 4th fourth, 5th fifth, 8th eighth, 9th ninth, 12th twelfth, 20th twentieth, 21st twenty-first, 30th thirtieth, 31st thirty-first.",
      "How old are you? — I'm ten years old.",
      "When is your birthday? — It's on 12th June. (twelfth of June)"
    ],
    q: [
      ["How do you say 40 in English?", ['forty', 'fourty', 'fourteen', 'four']],
      ["What is the ordinal of 3?", ['third', 'three', 'threeth', 'thirdy']],
      ["What is the ordinal of 2?", ['second', 'twoth', 'secund', 'two']],
      ["'When is your birthday?' — 'It's on …'", ['12th June', 'ten years old', 'Monday morning', 'in the library']],
      ["'How old are you?' — '…'", ["I'm nine years old.", "It's on 5th May.", "I'm fine, thanks.", "It's two o'clock."]],
      ["How do you write 12th?", ['twelfth', 'twelveth', 'twelf', 'twentieth']],
      ["15 in English is…", ['fifteen', 'fifty', 'fiveteen', 'fifth']]
    ]
  },
  {
    id: 'ing4_m_school', t: 'School places and activities', livro: 1,
    k: 'school,places at school,classroom,gym,canteen,playground,library,activities,present continuous,what are you doing,drawing,reading,writing,escola em ingles',
    ae: 'Identificar espaços da escola e descrever o que alguém está a fazer (present continuous).',
    r: [
      "Places at school: classroom (sala de aula), gym (ginásio), canteen (cantina), playground (recreio), library (biblioteca).",
      "Present continuous — what is happening now: I'm reading. She's drawing. He's writing. They're dancing. They're playing football.",
      "Where is she? — She is in the library.",
      "What are you doing? — I'm playing marbles."
    ],
    q: [
      ["Where do you eat lunch at school?", ['canteen', 'gym', 'library', 'playground']],
      ["Where do you borrow books?", ['library', 'canteen', 'gym', 'classroom']],
      ["'She … drawing.'", ['is', 'are', 'am', 'be']],
      ["'They … playing football.'", ['are', 'is', 'am', 'does']],
      ["'What are you doing?' — '…'", ["I'm reading.", "I read yesterday.", "Yes, I do.", "It's in the gym."]],
      ["'Playground' em português é…", ['recreio', 'ginásio', 'cantina', 'biblioteca']],
      ["Which sentence is correct?", ["He's writing.", "He writing.", "He are writing.", "He's write."]]
    ]
  },
  {
    id: 'ing4_m_time', t: 'Telling the time', livro: 1,
    k: 'time,telling the time,what time is it,o clock,half past,midday,midnight,horas em ingles,que horas sao',
    ae: 'Perguntar e dizer as horas em inglês.',
    r: [
      "What time is it? — It's eight o'clock. (8:00)",
      "It's half past six. = It's six thirty. (6:30)",
      "It's midday. (12:00, meio-dia) — It's midnight. (00:00, meia-noite)",
      "What time is the cinema? — It's at half past five."
    ],
    q: [
      ["6:30 is…", ['half past six', "six o'clock", 'half past seven', 'six fifteen']],
      ["12:00 at noon is…", ['midday', 'midnight', "twelve thirty", 'half past twelve']],
      ["00:00 is…", ['midnight', 'midday', "zero o'clock", 'half past twelve']],
      ["'It's seven thirty.' What time is it?", ['7:30', '7:00', '3:07', '8:30']],
      ["How do you ask the time?", ['What time is it?', 'How old are you?', 'Where is it?', 'What day is it?']],
      ["2:00 is…", ["two o'clock", 'half past two', 'twelve o\'clock', "two thirty"]]
    ]
  },
  {
    id: 'ing4_m_body', t: 'The human body and the five senses', livro: 1,
    k: 'human body,body,face,head,hair,eyes,ears,nose,mouth,teeth,arm,leg,knee,foot,feet,five senses,senses,sight,smell,hearing,taste,touch,have got,corpo em ingles,sentidos',
    ae: 'Nomear partes do corpo e os cinco sentidos; descrever-se com "have got".',
    r: [
      "Face and body: head, hair, eye, ear, nose, mouth, tooth/teeth, neck, shoulder, arm, elbow, hand, finger, stomach, leg, knee, foot/feet, toes.",
      "Irregular plurals: one tooth → two teeth; one foot → two feet.",
      "Five senses: sight (eyes, to see), smell (nose, to smell), hearing (ears, to hear), taste (tongue, to taste), touch (skin, to touch).",
      "Have you got long hair? — Yes, I have. / No, I haven't. I've got blue eyes and a small nose."
    ],
    q: [
      ["What is the plural of 'tooth'?", ['teeth', 'tooths', 'teeths', 'toothes']],
      ["What is the plural of 'foot'?", ['feet', 'foots', 'feets', 'footes']],
      ["We hear with our…", ['ears', 'eyes', 'nose', 'tongue']],
      ["Which sense uses the tongue?", ['taste', 'sight', 'hearing', 'smell']],
      ["'Have you got blue eyes?' — 'Yes, I …'", ['have', 'do', 'am', 'got']],
      ["'Knee' em português é…", ['joelho', 'cotovelo', 'ombro', 'pescoço']],
      ["'Elbow' em português é…", ['cotovelo', 'joelho', 'dedo', 'pé']],
      ["Sight is the sense of the…", ['eyes', 'skin', 'ears', 'nose']]
    ]
  },
  {
    id: 'ing4_m_food', t: 'Fruit, vegetables, food and meals', livro: 1,
    k: 'fruit,vegetables,food,drinks,meals,breakfast,lunch,snack,dinner,apple,banana,pear,grapes,strawberries,lettuce,carrots,peas,broccoli,onions,mushrooms,fish,meat,chicken,bread,cheese,rice,pasta,eggs,water,juice,do you like,comida em ingles,frutas em ingles',
    ae: 'Nomear frutos, legumes, alimentos, bebidas e refeições; perguntar e dizer gostos (Do you like…?).',
    r: [
      "Fruit: apple, orange, banana, pear, peach, grapes (uvas), strawberries (morangos).",
      "Vegetables: lettuce (alface), peas (ervilhas), carrots (cenouras), broccoli (brócolos), onions (cebolas), mushrooms (cogumelos).",
      "Food: fish, meat, chicken, bread, cheese, rice, pasta, eggs. Drinks: water, tea, juice, coffee.",
      "Meals: breakfast (pequeno-almoço), lunch (almoço), snack (lanche), dinner (jantar).",
      "Do you like lettuce? — Yes, I do. / No, I don't. What's your favourite meal? — My favourite meal is breakfast."
    ],
    q: [
      ["'Morangos' in English is…", ['strawberries', 'grapes', 'peaches', 'pears']],
      ["'Cogumelos' in English is…", ['mushrooms', 'onions', 'peas', 'carrots']],
      ["The first meal of the day is…", ['breakfast', 'dinner', 'lunch', 'snack']],
      ["'Do you like fish?' — 'No, I …'", ["don't", "doesn't", "haven't", "am not"]],
      ["Which one is a vegetable?", ['lettuce', 'banana', 'cheese', 'juice']],
      ["Which one is a drink?", ['juice', 'bread', 'rice', 'eggs']],
      ["'Jantar' in English is…", ['dinner', 'lunch', 'breakfast', 'snack']],
      ["'Uvas' in English is…", ['grapes', 'pears', 'apples', 'peas']]
    ]
  },
  {
    id: 'ing4_m_house', t: 'House, town and animals', livro: 1,
    k: 'house,parts of the house,attic,bedroom,bathroom,kitchen,living room,dining room,garage,upstairs,downstairs,town,places in town,hospital,church,museum,cinema,post office,police station,supermarket,animals,farm animals,wild animals,does she like,there is,there are,casa em ingles,animais em ingles',
    ae: 'Nomear divisões da casa, lugares da cidade e animais; usar "there is/there are", "near" e "Does she like…?".',
    r: [
      "Parts of the house: attic (sótão), bedroom, bathroom, kitchen, living room (sala de estar), dining room (sala de jantar), garage. Upstairs (em cima) / downstairs (em baixo).",
      "In my house there is a kitchen and there are three bedrooms. (there is = singular; there are = plural)",
      "Places in town: hospital, church (igreja), museum, cinema, park, post office (correios), police station (esquadra), supermarket, school, café. Where is the hospital? — It's near the park.",
      "Farm animals: cow, horse, sheep, pig, rabbit. Wild animals: monkey, lion, zebra, bear, tiger, elephant, crocodile, eagle, dolphin, hippo.",
      "Does she like dogs? — Yes, she does. / No, she doesn't."
    ],
    q: [
      ["'Sótão' in English is…", ['attic', 'garage', 'kitchen', 'bathroom']],
      ["Where do you cook?", ['kitchen', 'bedroom', 'attic', 'garage']],
      ["'In my house … three bedrooms.'", ['there are', 'there is', 'it is', 'have']],
      ["'Correios' in English is…", ['post office', 'police station', 'church', 'museum']],
      ["'Does she like cats?' — 'Yes, she …'", ['does', 'do', 'is', 'likes']],
      ["Which one is a farm animal?", ['sheep', 'lion', 'crocodile', 'monkey']],
      ["Which one is a wild animal?", ['tiger', 'cow', 'pig', 'rabbit']],
      ["'Where is the hospital?' — 'It's … the park.'", ['near', 'on Monday', 'at eight', 'favourite']],
      ["'Igreja' in English is…", ['church', 'school', 'cinema', 'café']]
    ]
  }
]);

// Perguntas extra dos manuais PLIM em temas que já existiam
(function () {
  const MAIS = {
    mat4_area: [
      ['1 m² é a área de um quadrado com…', ['1 m de lado', '1 cm de lado', '10 m de lado', '100 m de lado']],
      ['Quantos cm² tem 1 m²?', ['10 000 cm²', '100 cm²', '1000 cm²', '1 000 000 cm²'], '1 m² = 100 cm × 100 cm = 10 000 cm².'],
      ['A área do retângulo calcula-se…', ['comprimento × largura', 'comprimento + largura', '4 × lado', '2 × comprimento']]
    ],
    mat4_numeros: [
      ['25 641 lido por classes é…', ['25 milhares e 641 unidades', '256 centenas e 41 unidades', '2 milhões e 5641', '25 centenas e 641 dezenas']],
      ['Em 32 879, qual é o valor posicional do algarismo 2?', ['2000', '200', '20', '2']],
      ['Quantas centenas de milhar tem 1 milhão?', ['10', '100', '1000', '1']]
    ],
    em4_tecnologia: [
      ['Num circuito elétrico, o que abre e fecha a passagem da corrente?', ['o interruptor', 'a lâmpada', 'o fio', 'a pilha']],
      ['Num circuito aberto, a lâmpada…', ['não acende', 'acende mais', 'pisca sempre', 'fica azul']],
      ['A pilha, num circuito, é a…', ['fonte de energia', 'recetor de energia', 'interruptor', 'lâmpada']],
      ['Na internet, devemos partilhar a nossa morada com desconhecidos.', false, 'Nunca partilhes informações pessoais.']
    ],
    em4_historia: [
      ['Em que ano chegaram os muçulmanos à Península Ibérica?', ['711', '722', '1096', '1143']],
      ['O Tratado de Tordesilhas (1494) dividiu o mundo entre…', ['Portugal e Castela', 'Portugal e França', 'Inglaterra e Espanha', 'Roma e Cartago']]
    ],
    pt4_flexao: [
      ['Qual é o plural de "jardim"?', ['jardins', 'jardims', 'jardines', 'jardis']],
      ['Qual é o feminino de "comilão"?', ['comilona', 'comiloa', 'comilã', 'comiladora']]
    ]
  };
  Object.keys(MAIS).forEach((id) => {
    const t = CUR.temas[id];
    if (t) MAIS[id].forEach((q) => t.q.push(q));
  });

  // Os temas que seguem os manuais aparecem primeiro na lista de cada disciplina do 4.º ano
  ['pt', 'mat', 'em', 'ing'].forEach((d) => {
    const l = CUR.porAno[4][d];
    if (!l) return;
    const m = l.filter((t) => t.livro), o = l.filter((t) => !t.livro);
    l.length = 0; m.concat(o).forEach((t) => l.push(t));
  });
})();
