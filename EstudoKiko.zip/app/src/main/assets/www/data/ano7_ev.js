/* 7.º ano — temas que faltavam, seguindo o plano de estudo da Escola Virtual 2026/2027
   (domínios e subtemas). Resumos e perguntas escritos de raiz para a app. */

// ============================================================= PORTUGUÊS
TEMAS(7, 'pt', [
  {
    id: 'pt7_ev_conjuncoes', t: 'Conjunções e orações coordenadas e subordinadas',
    k: 'conjuncoes,conjuncao,locucao conjuncional,coordenativa,coordenativas,subordinativa,subordinativas,oracoes coordenadas,oracoes subordinadas,disjuntiva,conclusiva,explicativa,final,condicional,completiva,copulativa,adversativa,temporal,causal',
    ae: 'Identificar conjunções e locuções conjuncionais coordenativas e subordinativas e classificar orações coordenadas e subordinadas adverbiais e substantivas completivas.',
    r: [
      'Conjunções coordenativas ligam orações independentes: copulativas (e, nem), adversativas (mas, porém, contudo), disjuntivas (ou, ou… ou), conclusivas (logo, portanto, por isso) e explicativas (pois, porque, que — no sentido de "dado que se afirma").',
      'Conjunções subordinativas introduzem uma oração que depende de outra: causais (porque, visto que, uma vez que), temporais (quando, enquanto, logo que), finais (para que, a fim de que), condicionais (se, caso, desde que) e completivas (que, se).',
      'Oração subordinada adverbial final: indica a finalidade. «Estudo para que tenhas boas notas.»',
      'Oração subordinada adverbial condicional: indica uma condição. «Se chover, ficamos em casa.»',
      'Oração subordinada substantiva completiva: completa o sentido do verbo, como um complemento direto. «Ele disse que vinha.» «Não sei se vens.»',
      'Locução conjuncional: duas ou mais palavras com valor de conjunção (visto que, a fim de que, logo que, ou seja).'
    ],
    q: [
      ['"Estuda muito, logo terá boas notas." A oração "logo terá boas notas" é coordenada…', ['conclusiva', 'disjuntiva', 'adversativa', 'copulativa']],
      ['"Queres sumo ou preferes água?" A oração "ou preferes água" é coordenada…', ['disjuntiva', 'explicativa', 'conclusiva', 'causal']],
      ['"Leva o casaco, que está frio." A oração "que está frio" é coordenada…', ['explicativa', 'disjuntiva', 'final', 'condicional']],
      ['"Se fizer sol, vamos à praia." A oração "Se fizer sol" é subordinada adverbial…', ['condicional', 'final', 'temporal', 'causal']],
      ['"Trouxe o livro para que o leias." A oração "para que o leias" é subordinada adverbial…', ['final', 'condicional', 'causal', 'concessiva']],
      ['"A professora disse que o teste era fácil." A oração "que o teste era fácil" é subordinada…', ['substantiva completiva', 'adjetiva relativa', 'adverbial causal', 'coordenada explicativa']],
      ['"Visto que" é uma locução conjuncional…', ['subordinativa causal', 'coordenativa disjuntiva', 'subordinativa final', 'coordenativa copulativa']],
      ['Qual destas é uma conjunção coordenativa adversativa?', ['porém', 'portanto', 'quando', 'caso']],
      ['"Caso" pode introduzir uma oração subordinada condicional.', true]
    ]
  },
  {
    id: 'pt7_ev_modos', t: 'Modos verbais: conjuntivo, condicional e imperativo',
    k: 'modo conjuntivo,conjuntivo,modo condicional,condicional,modo imperativo,imperativo,modos verbais,presente do conjuntivo,imperfeito do conjuntivo,futuro do conjuntivo',
    ae: 'Conjugar e identificar o modo conjuntivo (presente, pretérito imperfeito e futuro), o modo condicional e o modo imperativo.',
    r: [
      'Indicativo: apresenta factos como certos (canto, cantei, cantava, cantarei).',
      'Conjuntivo: exprime dúvida, desejo, possibilidade ou hipótese; aparece muitas vezes depois de "que", "se", "quando". Presente: que eu cante; pretérito imperfeito: se eu cantasse; futuro: quando eu cantar.',
      'Condicional: exprime uma ação que depende de uma condição ou um pedido delicado. Eu cantaria, tu comerias. «Se tivesse tempo, iria ao cinema.»',
      'Imperativo: ordem, conselho ou pedido. Afirmativo: canta (tu), cantai (vós). Na negativa usa-se o presente do conjuntivo: não cantes, não canteis.',
      'Para formas de cortesia (você, vocês) usa-se o presente do conjuntivo: cante, cantem.'
    ],
    q: [
      ['"Espero que tu venhas." "Venhas" está no…', ['presente do conjuntivo', 'presente do indicativo', 'condicional', 'imperativo']],
      ['"Se eu soubesse, dizia-te." "Soubesse" está no…', ['pretérito imperfeito do conjuntivo', 'futuro do conjuntivo', 'pretérito perfeito do indicativo', 'condicional']],
      ['"Quando acabares, chama-me." "Acabares" está no…', ['futuro do conjuntivo', 'infinitivo', 'presente do conjuntivo', 'futuro do indicativo']],
      ['"Eu gostaria de ir contigo." "Gostaria" está no…', ['condicional', 'conjuntivo', 'imperativo', 'pretérito imperfeito do indicativo']],
      ['Qual é a forma negativa de "Fala!" (tu)?', ['Não fales!', 'Não fala!', 'Não falas!', 'Não falai!']],
      ['O modo conjuntivo exprime sobretudo factos certos e reais.', false, 'Exprime dúvida, desejo ou hipótese; os factos certos ficam no indicativo.'],
      ['"Abram os livros, por favor." Para "vocês" usa-se…', ['o presente do conjuntivo com valor de imperativo', 'o futuro do indicativo', 'o condicional', 'o infinitivo pessoal']]
    ]
  },
  {
    id: 'pt7_ev_recursos', t: 'Recursos expressivos e versificação',
    k: 'recursos expressivos,recurso expressivo,comparacao,personificacao,anafora,metafora,enumeracao,pleonasmo,hiperbole,verso,versos,estrofe,estrofes,rima,esquema rimatico,metrica,silabas metricas,quadra,terceto,quintilha,soneto',
    ae: 'Identificar recursos expressivos (comparação, personificação, anáfora, metáfora, enumeração, pleonasmo, hipérbole) e analisar versos, estrofes, rima e métrica.',
    r: [
      'Comparação: aproxima duas realidades com uma palavra comparativa (como, tal como, parece). «Os olhos brilham como estrelas.»',
      'Metáfora: comparação sem palavra comparativa. «Os teus olhos são estrelas.»',
      'Personificação: dá características humanas a animais, objetos ou ideias. «O vento cantava na janela.»',
      'Anáfora: repetição da mesma palavra ou expressão no início de versos ou frases.',
      'Enumeração: sequência de elementos. Pleonasmo: repetição de uma ideia já dita, para dar ênfase («subir lá para cima», «vi com os meus olhos»). Hipérbole: exagero («chorei rios de lágrimas»).',
      'Versificação: cada linha do poema é um verso; um conjunto de versos é uma estrofe (dístico 2, terceto 3, quadra 4, quintilha 5, sextilha 6, oitava 8). O soneto tem 14 versos: duas quadras e dois tercetos.',
      'Rima: repetição de sons no fim dos versos. Esquema rimático: emparelhada (AABB), cruzada (ABAB), interpolada ou abraçada (ABBA).',
      'Métrica: contagem das sílabas métricas até à última sílaba tónica do verso. Verso de 10 sílabas = decassílabo; de 7 = redondilha maior; de 5 = redondilha menor.'
    ],
    q: [
      ['"Chorei rios de lágrimas." Que recurso expressivo é?', ['hipérbole', 'personificação', 'anáfora', 'comparação']],
      ['"A lua sorria lá no alto." Que recurso expressivo é?', ['personificação', 'pleonasmo', 'enumeração', 'hipérbole']],
      ['"A vida é uma viagem." Que recurso expressivo é?', ['metáfora', 'comparação', 'anáfora', 'pleonasmo']],
      ['"Ele é forte como um touro." Que recurso expressivo é?', ['comparação', 'metáfora', 'hipérbole', 'anáfora']],
      ['"Vi com os meus próprios olhos." Que recurso expressivo é?', ['pleonasmo', 'personificação', 'metáfora', 'enumeração']],
      ['Uma estrofe com quatro versos chama-se…', ['quadra', 'terceto', 'quintilha', 'dístico']],
      ['Um soneto tem…', ['14 versos (duas quadras e dois tercetos)', '10 versos', '4 quadras', '12 versos em tercetos']],
      ['O esquema rimático ABAB chama-se rima…', ['cruzada', 'emparelhada', 'interpolada', 'solta']],
      ['A redondilha maior tem…', ['7 sílabas métricas', '5 sílabas métricas', '10 sílabas métricas', '12 sílabas métricas']],
      ['A anáfora é a repetição de palavras no início de versos ou frases.', true]
    ]
  },
  {
    id: 'pt7_ev_lingua', t: 'Variação da língua, pontuação, preposições e advérbios relativos',
    k: 'variacao da lingua,variacao geografica,variedades do portugues,portugues do brasil,portugues europeu,pontuacao,virgula,dois pontos,locucao prepositiva,preposicao,adverbio relativo,determinante relativo,onde,cujo',
    ae: 'Reconhecer a variação geográfica do português; usar corretamente a pontuação; identificar locuções prepositivas, determinantes e advérbios relativos.',
    r: [
      'O português varia de região para região (variação geográfica): português europeu, português do Brasil, variedades africanas e asiáticas. Há diferenças de pronúncia, vocabulário e construção (ex.: "autocarro" / "ônibus"; "estou a ler" / "estou lendo").',
      'Dentro de Portugal também há variedades regionais (dialetos): do norte, do centro-sul, insulares (Açores e Madeira).',
      'Vírgula: separa elementos de uma enumeração, isola o vocativo («Rui, anda cá») e expressões intercaladas; nunca separa o sujeito do predicado.',
      'Dois pontos: antes de uma enumeração, de uma explicação ou do discurso direto. Ponto e vírgula: separa partes longas de uma frase.',
      'Locução prepositiva: duas ou mais palavras com valor de preposição: ao lado de, em frente de, por causa de, através de, apesar de, junto a.',
      'Advérbio relativo "onde": retoma um lugar («A casa onde nasci»). Determinante relativo "cujo/cuja/cujos/cujas": indica posse e concorda com o que vem a seguir («O rapaz cujo pai é médico»).'
    ],
    q: [
      ['"Ônibus" (Brasil) corresponde em Portugal a…', ['autocarro', 'comboio', 'elétrico', 'táxi']],
      ['A diferença entre "estou a ler" e "estou lendo" é um exemplo de variação…', ['geográfica', 'temporal', 'de registo formal', 'de género']],
      ['Em qual das frases a vírgula está mal usada?', ['O meu irmão, gosta de futebol.', 'Rui, anda cá.', 'Comprei pão, leite e fruta.', 'Lisboa, a capital, é bonita.'], 'Não se separa o sujeito do predicado com vírgula.'],
      ['"Em frente de" é uma…', ['locução prepositiva', 'conjunção', 'locução adverbial de tempo', 'interjeição']],
      ['"A vila onde vivo é pequena." "Onde" é um…', ['advérbio relativo', 'pronome pessoal', 'determinante relativo', 'advérbio interrogativo']],
      ['"A menina cujos livros caíram chorou." "Cujos" é um…', ['determinante relativo', 'pronome possessivo', 'advérbio relativo', 'pronome demonstrativo']],
      ['Os dois pontos podem introduzir uma enumeração ou o discurso direto.', true]
    ]
  },
  {
    id: 'pt7_ev_textos', t: 'Biografia, artigo de opinião, crítica e texto publicitário',
    k: 'biografia,autobiografia,artigo de opiniao,opiniao,critica,texto critico,texto publicitario,publicidade,slogan,anuncio,argumento,argumentos',
    ae: 'Ler e escrever textos de diferentes géneros: biografia, artigo de opinião, crítica e texto publicitário.',
    r: [
      'Biografia: relato da vida de uma pessoa feito por outra, na 3.ª pessoa e por ordem cronológica (nascimento, formação, obras, factos marcantes). Autobiografia: a própria pessoa conta, na 1.ª pessoa.',
      'Artigo de opinião: o autor defende um ponto de vista com argumentos e exemplos; tem introdução (tese), desenvolvimento (argumentos) e conclusão; vai assinado.',
      'Crítica: apreciação de um livro, filme, espetáculo ou exposição — apresenta a obra, descreve-a brevemente e avalia-a com argumentos (pontos fortes e fracos).',
      'Texto publicitário: quer convencer o público a comprar um produto ou a mudar um comportamento. Usa slogan curto e fácil de lembrar, imagem, cores, apelos (imperativo, 2.ª pessoa) e recursos expressivos.',
      'Os argumentos servem para justificar uma opinião; os conectores (em primeiro lugar, além disso, no entanto, em suma) organizam-nos.'
    ],
    q: [
      ['Um texto que conta a vida de uma pessoa na 3.ª pessoa e por ordem cronológica é uma…', ['biografia', 'autobiografia', 'crítica', 'notícia']],
      ['Num artigo de opinião, a ideia que o autor defende chama-se…', ['tese', 'slogan', 'lead', 'didascália']],
      ['A frase curta e fácil de lembrar de um anúncio chama-se…', ['slogan', 'título de notícia', 'refrão', 'legenda']],
      ['A crítica de um filme serve para…', ['apresentar e avaliar a obra com argumentos', 'contar a vida do realizador', 'vender bilhetes a qualquer custo', 'dar uma notícia urgente']],
      ['O texto publicitário usa muitas vezes o imperativo para convencer.', true],
      ['Numa autobiografia, o narrador escreve na…', ['1.ª pessoa', '3.ª pessoa', '2.ª pessoa do plural', 'forma de diálogo']]
    ]
  },
  {
    id: 'pt7_ev_obras', t: 'Obras e autores do 7.º ano',
    k: 'obras do 7 ano,leandro rei da heliria,alice vieira,cavaleiro da dinamarca,sophia,dentes de rato,agustina,sexta feira ou a vida selvagem,tournier,ladino,miguel torga,bichos,mestre finezas,manuel da fonseca,caldo de pedra,teofilo braga,a pirata,luisa costa gomes,agualusa,florbela espanca,jose regio,antonio gedeao,eugenio de andrade,sebastiao da gama,alexandre o neill,david mourao ferreira,a beira do lago dos encantos',
    ae: 'Ler e interpretar obras e textos do Plano de Educação Literária do 7.º ano.',
    r: [
      'Texto dramático: «Leandro, Rei da Helíria», de Alice Vieira — um rei pede às três filhas que digam quanto gostam dele; a mais nova, que diz gostar dele "como a comida gosta do sal", é castigada injustamente. «À Beira do Lago dos Encantos», de Maria Alberta Menéres.',
      'Narrativas: «O Cavaleiro da Dinamarca», de Sophia de Mello Breyner Andresen (um cavaleiro viaja até à Terra Santa e promete voltar a casa na noite de Natal); «Dentes de Rato», de Agustina Bessa-Luís (a infância de uma menina alcunhada "Dentes de Rato"); «Sexta-Feira ou a Vida Selvagem», de Michel Tournier (Robinson numa ilha deserta e o amigo Sexta-Feira).',
      'Contos: «Ladino», de Miguel Torga (do livro «Bichos», a vida de um pardal); «Mestre Finezas», de Manuel da Fonseca; «O caldo de pedra», recolhido por Teófilo Braga (conto tradicional sobre a esperteza); «A Pirata», de Luísa Costa Gomes; crónicas de José Eduardo Agualusa.',
      'Poetas do 7.º ano: Florbela Espanca, José Régio, António Ramos Rosa, António Gedeão, Miguel Torga, Manuel da Fonseca, Eugénio de Andrade, Sebastião da Gama, Alexandre O\'Neill e David Mourão-Ferreira.',
      'Ao interpretar: identifica personagens (principal, secundárias), espaço, tempo, narrador (participante ou não participante), ação (introdução, desenvolvimento, conclusão) e a mensagem.'
    ],
    q: [
      ['Quem escreveu «Leandro, Rei da Helíria»?', ['Alice Vieira', 'Sophia de Mello Breyner Andresen', 'Agustina Bessa-Luís', 'Miguel Torga']],
      ['«O Cavaleiro da Dinamarca» é de…', ['Sophia de Mello Breyner Andresen', 'Alice Vieira', 'Manuel da Fonseca', 'Teófilo Braga']],
      ['«Ladino», de Miguel Torga, pertence ao livro…', ['Bichos', 'Contos Exemplares', 'Os Lusíadas', 'Mensagem']],
      ['Quem escreveu «Dentes de Rato»?', ['Agustina Bessa-Luís', 'Luísa Costa Gomes', 'Florbela Espanca', 'Alice Vieira']],
      ['Em «Sexta-Feira ou a Vida Selvagem», a história passa-se…', ['numa ilha deserta', 'num castelo da Dinamarca', 'numa aldeia do Alentejo', 'no reino da Helíria']],
      ['«Leandro, Rei da Helíria» é um texto…', ['dramático', 'poético', 'informativo', 'de opinião']],
      ['«O caldo de pedra» é um conto tradicional recolhido por…', ['Teófilo Braga', 'José Régio', 'Eugénio de Andrade', 'Michel Tournier']],
      ['Florbela Espanca e Eugénio de Andrade são poetas portugueses.', true]
    ]
  }
]);

// ============================================================= MATEMÁTICA
TEMAS(7, 'mat', [
  {
    id: 'mat7_ev_inteiros', t: 'Números inteiros: valor absoluto, simétricos e comparação', gen: 'simetricos7',
    k: 'numeros inteiros,inteiros,valor absoluto,modulo,simetricos,simetrico,numeros negativos,numeros positivos,reta numerica,comparar inteiros,elemento neutro,propriedade comutativa,propriedade associativa',
    ae: 'Reconhecer números inteiros, valor absoluto e simétricos; comparar e ordenar; adicionar e subtrair com propriedades.',
    r: [
      'Números inteiros (ℤ): …, −3, −2, −1, 0, 1, 2, 3, … Os negativos ficam à esquerda do zero na reta numérica.',
      'Valor absoluto (ou módulo) de um número: a sua distância ao zero. |−7| = 7 e |7| = 7.',
      'Números simétricos: têm o mesmo valor absoluto e sinais contrários (5 e −5). A soma de dois simétricos é 0.',
      'Comparar: na reta numérica, o maior está mais à direita. Qualquer positivo é maior do que qualquer negativo; entre negativos, é maior o que tem menor valor absoluto (−2 > −9).',
      'Propriedades da adição: comutativa (a + b = b + a), associativa ((a + b) + c = a + (b + c)), elemento neutro (a + 0 = a) e existência de simétrico (a + (−a) = 0).',
      'Subtrair é adicionar o simétrico: 4 − (−3) = 4 + 3 = 7.'
    ],
    q: [
      ['Qual é o valor absoluto de −12?', ['12', '−12', '0', '1/12']],
      ['Qual é o maior número?', ['−2', '−9', '−15', '−100']],
      ['Quanto é 4 − (−3)?', ['7', '1', '−7', '−1']],
      ['A soma de um número com o seu simétrico é…', ['0', '1', 'o dobro do número', 'sempre negativa']],
      ['O elemento neutro da adição é…', ['0', '1', '−1', '10']],
      ['−5 < 2 porque qualquer número negativo é menor do que qualquer positivo.', true]
    ]
  },
  {
    id: 'mat7_ev_notacao', t: 'Notação científica e percentagens', gen: 'notacao7',
    k: 'notacao cientifica,potencias de base 10,numeros grandes,percentagem,percentagens,por cento,desconto,aumento,iva',
    ae: 'Escrever números em notação científica e resolver problemas com percentagens.',
    r: [
      'Notação científica: a × 10ⁿ, com 1 ≤ a < 10. Ex.: 300 000 = 3 × 10⁵; 45 000 000 = 4,5 × 10⁷.',
      'Para passar para notação científica, conta quantas casas a vírgula anda para a esquerda até ficar só um algarismo (não nulo) antes dela: esse número é o expoente.',
      'Percentagem: x% = x/100. Para calcular 15% de 80: 0,15 × 80 = 12.',
      'Desconto de 20% num preço de 50 €: 50 − 0,20 × 50 = 40 € (ou 0,80 × 50). Aumento de 10% em 30 €: 1,10 × 30 = 33 €.',
      'Que percentagem é 9 de 36? 9 : 36 = 0,25 = 25%.'
    ],
    q: [
      ['Qual destes está em notação científica?', ['6,2 × 10⁸', '62 × 10⁷', '0,62 × 10⁹', '620 × 10⁶']],
      ['Como se escreve 45 000 000 em notação científica?', ['4,5 × 10⁷', '45 × 10⁶', '4,5 × 10⁶', '0,45 × 10⁸']],
      ['Quanto é 15% de 80?', ['12', '15', '8', '65']],
      ['Um jogo custa 50 € e tem 20% de desconto. Quanto se paga?', ['40 €', '30 €', '48 €', '10 €']],
      ['Que percentagem é 9 de 36?', ['25%', '9%', '36%', '4%']],
      ['Um preço de 30 € aumenta 10%. Qual é o novo preço?', ['33 €', '40 €', '31 €', '27 €']]
    ]
  },
  {
    id: 'mat7_ev_angulos', t: 'Ângulos em polígonos, alternos e verticalmente opostos',
    k: 'angulos internos,soma dos angulos internos,poligonos convexos,angulos externos,angulos alternos internos,angulos verticalmente opostos,retas paralelas,secante',
    ae: 'Calcular a soma dos ângulos internos e externos de polígonos convexos; reconhecer ângulos alternos internos e verticalmente opostos.',
    r: [
      'Soma dos ângulos internos de um polígono convexo com n lados: (n − 2) × 180°. Triângulo: 180°; quadrilátero: 360°; pentágono: 540°; hexágono: 720°.',
      'Num polígono regular, cada ângulo interno mede (n − 2) × 180° : n (hexágono regular: 120°).',
      'A soma dos ângulos externos de qualquer polígono convexo é sempre 360°.',
      'Ângulos verticalmente opostos: formados por duas retas que se cruzam; são iguais.',
      'Duas retas paralelas cortadas por uma secante formam ângulos alternos internos, que são iguais.'
    ],
    q: [
      ['Quanto mede a soma dos ângulos internos de um pentágono?', ['540°', '360°', '720°', '180°']],
      ['Quanto mede cada ângulo interno de um hexágono regular?', ['120°', '108°', '90°', '135°']],
      ['A soma dos ângulos externos de um polígono convexo é…', ['360°', '180°', 'depende do número de lados', '540°']],
      ['Dois ângulos verticalmente opostos são…', ['iguais', 'suplementares sempre', 'complementares', 'sempre retos']],
      ['Retas paralelas cortadas por uma secante formam ângulos alternos internos iguais.', true],
      ['Qual é a fórmula da soma dos ângulos internos de um polígono com n lados?', ['(n − 2) × 180°', 'n × 180°', '(n + 2) × 90°', 'n × 360°']]
    ]
  },
  {
    id: 'mat7_ev_areas', t: 'Quadriláteros: classificação e áreas', gen: 'areas7',
    k: 'quadrilateros,classificacao de quadrilateros,trapezio,losango,papagaio,paralelogramo,area do trapezio,area do losango,area do paralelogramo,area do triangulo,propriedades dos quadrilateros,diagonais',
    ae: 'Classificar quadriláteros e as suas propriedades; calcular áreas de paralelogramos, triângulos, trapézios, losangos e papagaios.',
    r: [
      'Paralelogramos (dois pares de lados paralelos): retângulo, losango, quadrado e paralelogramo obliquângulo. Trapézio: pelo menos um par de lados paralelos (as bases). Papagaio: dois pares de lados consecutivos iguais.',
      'Nos paralelogramos, lados opostos e ângulos opostos são iguais e as diagonais bissetam-se. No losango as diagonais são perpendiculares; no retângulo são iguais.',
      'Área do paralelogramo: base × altura. Área do triângulo: (base × altura) : 2.',
      'Área do trapézio: (base maior + base menor) : 2 × altura.',
      'Área do losango e do papagaio: (diagonal maior × diagonal menor) : 2.'
    ],
    q: [
      ['A área de um trapézio calcula-se…', ['(B + b) : 2 × altura', 'B × b', '(B + b) × altura', 'B × altura : 2']],
      ['A área de um losango com diagonais 10 cm e 6 cm é…', ['30 cm²', '60 cm²', '16 cm²', '32 cm²']],
      ['Num losango, as diagonais são…', ['perpendiculares', 'sempre iguais', 'paralelas', 'iguais aos lados']],
      ['Um quadrilátero com dois pares de lados consecutivos iguais (e não paralelogramo) chama-se…', ['papagaio', 'trapézio', 'retângulo', 'losango']],
      ['Um quadrado é também um losango e um retângulo.', true],
      ['Área de um paralelogramo com base 8 cm e altura 5 cm?', ['40 cm²', '20 cm²', '26 cm²', '13 cm²']]
    ]
  },
  {
    id: 'mat7_ev_triangulos', t: 'Semelhança de triângulos e homotetias',
    k: 'semelhanca de triangulos,criterios de semelhanca,criterio aa,criterio lal,criterio lll,homotetia,homoteticas,razao de semelhanca,perimetros e areas de figuras semelhantes',
    ae: 'Aplicar os critérios de semelhança de triângulos (AA, LAL, LLL), reconhecer homotetias e relacionar perímetros e áreas de figuras semelhantes.',
    r: [
      'Critério AA: dois triângulos com dois ângulos iguais são semelhantes.',
      'Critério LAL: dois lados proporcionais e o ângulo entre eles igual. Critério LLL: os três lados proporcionais.',
      'Razão de semelhança r: quociente entre comprimentos correspondentes (figura nova : figura original). r > 1 é ampliação; r < 1 é redução.',
      'Homotetia: transformação a partir de um centro que amplia ou reduz uma figura; as figuras homotéticas são semelhantes e os lados correspondentes ficam paralelos.',
      'Se a razão de semelhança é r, a razão dos perímetros é r e a razão das áreas é r². Ex.: r = 3 → a área fica 9 vezes maior.'
    ],
    q: [
      ['Dois triângulos com dois ângulos iguais são semelhantes pelo critério…', ['AA', 'LLL', 'LAL', 'LLA']],
      ['Se a razão de semelhança é 2, a área da figura ampliada fica…', ['4 vezes maior', '2 vezes maior', '8 vezes maior', 'igual']],
      ['Se a razão de semelhança é 3, o perímetro fica…', ['3 vezes maior', '9 vezes maior', '6 vezes maior', 'igual']],
      ['Lados 3, 4, 5 e 6, 8, 10: os triângulos são semelhantes pelo critério…', ['LLL', 'AA', 'LAL', 'não são semelhantes']],
      ['Uma razão de semelhança menor do que 1 indica uma…', ['redução', 'ampliação', 'translação', 'rotação']],
      ['Figuras homotéticas são sempre semelhantes.', true]
    ]
  },
  {
    id: 'mat7_ev_poliedros', t: 'Poliedros e relação de Euler', gen: 'euler7',
    k: 'poliedros,poliedro,faces,arestas,vertices,relacao de euler,euler,prismas,piramides,solidos geometricos,nao poliedros',
    ae: 'Identificar poliedros e relacionar o número de faces, vértices e arestas (relação de Euler).',
    r: [
      'Poliedro: sólido limitado só por superfícies planas (polígonos). Prismas e pirâmides são poliedros; cilindro, cone e esfera não são (têm superfícies curvas).',
      'Relação de Euler: F + V = A + 2 (faces + vértices = arestas + 2).',
      'Prisma com base de n lados: n + 2 faces, 2n vértices e 3n arestas.',
      'Pirâmide com base de n lados: n + 1 faces, n + 1 vértices e 2n arestas.',
      'Ex.: cubo — 6 faces, 8 vértices, 12 arestas: 6 + 8 = 12 + 2.'
    ],
    q: [
      ['Qual é a relação de Euler?', ['F + V = A + 2', 'F + A = V + 2', 'F × V = A', 'F + V + A = 2']],
      ['Quantas arestas tem um prisma pentagonal?', ['15', '10', '7', '12']],
      ['Quantos vértices tem uma pirâmide hexagonal?', ['7', '6', '12', '8']],
      ['Qual destes sólidos NÃO é um poliedro?', ['cilindro', 'cubo', 'pirâmide triangular', 'prisma hexagonal']],
      ['Uma pirâmide com base de n lados tem n + 1 faces.', true]
    ]
  },
  {
    id: 'mat7_ev_estatistica', t: 'Estatística: amostras, variáveis, gráficos e probabilidade',
    k: 'populacao,amostra,variavel estatistica,variavel qualitativa,variavel quantitativa,discreta,continua,histograma,grafico de linha,barras justapostas,barras sobrepostas,amplitude,probabilidade,acontecimentos compostos,lei de laplace',
    ae: 'Distinguir população e amostra e tipos de variáveis; ler histogramas e outros gráficos; calcular a amplitude; determinar probabilidades de acontecimentos compostos.',
    r: [
      'População: conjunto de todos os elementos em estudo. Amostra: parte da população que é observada; deve ser representativa.',
      'Variável qualitativa: não é número (cor preferida). Quantitativa: é um número — discreta (n.º de irmãos) ou contínua (altura, peso).',
      'Histograma: barras encostadas para dados contínuos agrupados em classes. Gráfico de linha: evolução ao longo do tempo. Barras justapostas/sobrepostas: comparar dois conjuntos.',
      'Amplitude: maior valor − menor valor; mostra a dispersão dos dados.',
      'Probabilidade (lei de Laplace) = casos favoráveis : casos possíveis. Para acontecimentos compostos (duas moedas, dois dados), usa uma tabela de dupla entrada ou um diagrama de árvore para contar os casos.',
      'Ex.: lançar duas moedas tem 4 casos (FF, FE, EF, EE); a probabilidade de saírem duas faces iguais é 2/4 = 1/2.'
    ],
    q: [
      ['A altura dos alunos é uma variável…', ['quantitativa contínua', 'qualitativa', 'quantitativa discreta', 'nominal']],
      ['O número de irmãos é uma variável…', ['quantitativa discreta', 'quantitativa contínua', 'qualitativa', 'temporal']],
      ['Qual é a amplitude dos dados 4, 9, 2, 15, 7?', ['13', '15', '7,4', '11']],
      ['Ao lançar duas moedas, quantos casos possíveis há?', ['4', '2', '3', '6']],
      ['Ao lançar dois dados, qual é a probabilidade de a soma ser 12?', ['1/36', '1/12', '1/6', '2/36']],
      ['Para dados contínuos agrupados em classes usa-se um…', ['histograma', 'gráfico circular de palavras', 'pictograma de ícones', 'diagrama de Venn']],
      ['Uma amostra é uma parte da população.', true]
    ]
  }
]);

// ============================================================= CIÊNCIAS NATURAIS
TEMAS(7, 'cn', [
  {
    id: 'cn7_ev_falhas', t: 'Deformação das rochas: falhas e dobras',
    k: 'falhas,falha,dobras,dobra,deformacao das rochas,comportamento fragil,comportamento ductil,falha normal,falha inversa,desligamento,anticlinal,sinclinal,forcas compressivas,distensivas',
    ae: 'Explicar a formação de falhas e dobras como consequência das forças que atuam nas rochas.',
    r: [
      'As rochas sofrem forças (tensões) por causa do movimento das placas: compressivas (apertam), distensivas (esticam) e de cisalhamento (deslizam lado a lado).',
      'Dobra: deformação contínua, sem rutura — comportamento dúctil (as rochas dobram, sobretudo em profundidade e com calor). Anticlinal: dobra com a curvatura para cima; sinclinal: para baixo.',
      'Falha: fratura com deslocamento dos blocos — comportamento frágil. Elementos: plano de falha, teto e muro, rejeito.',
      'Falha normal: forças distensivas (o teto desce). Falha inversa: forças compressivas (o teto sobe). Desligamento: os blocos deslizam na horizontal.',
      'Os movimentos ao longo das falhas podem provocar sismos.'
    ],
    q: [
      ['Uma deformação das rochas sem rutura chama-se…', ['dobra', 'falha', 'diáclase', 'erupção']],
      ['Uma falha resulta de um comportamento…', ['frágil', 'dúctil', 'plástico', 'líquido']],
      ['Que forças originam uma falha inversa?', ['compressivas', 'distensivas', 'magnéticas', 'gravíticas apenas']],
      ['Uma dobra com a curvatura voltada para cima chama-se…', ['anticlinal', 'sinclinal', 'falha normal', 'cratera']],
      ['O movimento brusco ao longo de uma falha pode provocar um sismo.', true],
      ['Nas falhas normais, as forças são…', ['distensivas', 'compressivas', 'de rotação', 'inexistentes']]
    ]
  },
  {
    id: 'cn7_ev_riscos', t: 'Riscos vulcânicos e sísmicos: prevenção e proteção',
    k: 'riscos vulcanicos,beneficios do vulcanismo,riscos sismicos,protecao sismica,prevencao,sismografo,escala de richter,escala de mercalli,intensidade,magnitude,epicentro,hipocentro,construcao antissismica,geotermia,termalismo',
    ae: 'Relacionar a atividade vulcânica e sísmica com riscos e benefícios; conhecer medidas de prevenção e proteção.',
    r: [
      'Riscos do vulcanismo: escoadas de lava, nuvens ardentes, cinzas, gases tóxicos, destruição de casas e culturas.',
      'Benefícios do vulcanismo: solos férteis, energia geotérmica (Açores), águas termais, minerais e rochas usados na construção, turismo.',
      'Sismo: vibração do terreno provocada pela libertação súbita de energia. Hipocentro (foco) é o ponto no interior; epicentro é o ponto à superfície por cima do foco.',
      'Magnitude (escala de Richter): energia libertada, medida com sismógrafos (sismogramas). Intensidade (escala de Mercalli, I a XII): efeitos observados nas pessoas e construções.',
      'Prevenção: construção antissísmica, ordenamento do território, planos de emergência e kit de emergência. Durante um sismo: baixar, proteger e aguardar, longe de janelas.'
    ],
    q: [
      ['O ponto à superfície, por cima do foco de um sismo, chama-se…', ['epicentro', 'hipocentro', 'cratera', 'magnitude']],
      ['A escala de Mercalli mede…', ['a intensidade (efeitos do sismo)', 'a energia libertada', 'a temperatura do magma', 'a profundidade do mar']],
      ['O aparelho que regista as ondas sísmicas chama-se…', ['sismógrafo', 'barómetro', 'termómetro', 'anemómetro']],
      ['Qual destes é um benefício da atividade vulcânica?', ['energia geotérmica', 'nuvens ardentes', 'gases tóxicos', 'destruição de colheitas']],
      ['Durante um sismo deves…', ['baixar, proteger e aguardar', 'correr para as escadas', 'usar o elevador', 'ficar junto às janelas']],
      ['A magnitude de um sismo está relacionada com a energia libertada.', true]
    ]
  },
  {
    id: 'cn7_ev_tempo', t: 'Tempo geológico, datação e eras',
    k: 'tempo geologico,datacao relativa,datacao absoluta,principio da sobreposicao,estratos,eras geologicas,paleozoico,mesozoico,cenozoico,precambrico,fosseis de idade,fossil de idade,extincao dos dinossauros,escala do tempo geologico',
    ae: 'Compreender a escala do tempo geológico, a datação relativa e absoluta e os principais acontecimentos de cada era.',
    r: [
      'A Terra tem cerca de 4600 milhões de anos. A escala do tempo geológico divide esse tempo em éons, eras e períodos.',
      'Datação relativa: ordena acontecimentos sem dar a idade em anos. Princípio da sobreposição: numa sequência de estratos não deformada, os de baixo são mais antigos.',
      'Fósseis de idade: viveram pouco tempo e em muitos lugares (ex.: trilobites, amonites) — permitem datar os estratos.',
      'Datação absoluta (radiométrica): dá a idade em anos, usando elementos radioativos.',
      'Pré-Câmbrico: primeiros seres vivos (bactérias). Paleozoico: trilobites, peixes, primeiros anfíbios e florestas. Mesozoico: dinossauros e amonites, termina com uma extinção em massa há cerca de 66 milhões de anos. Cenozoico: expansão dos mamíferos e aparecimento do ser humano.'
    ],
    q: [
      ['Qual é a idade aproximada da Terra?', ['4600 milhões de anos', '6000 anos', '66 milhões de anos', '100 mil anos']],
      ['Segundo o princípio da sobreposição, os estratos mais antigos estão…', ['por baixo', 'por cima', 'no meio', 'à superfície']],
      ['Em que era viveram os dinossauros?', ['Mesozoico', 'Paleozoico', 'Cenozoico', 'Pré-Câmbrico']],
      ['Em que era apareceu o ser humano?', ['Cenozoico', 'Mesozoico', 'Paleozoico', 'Pré-Câmbrico']],
      ['A datação que indica a idade em anos chama-se…', ['absoluta', 'relativa', 'estratigráfica', 'fóssil']],
      ['As trilobites são fósseis do…', ['Paleozoico', 'Cenozoico', 'Mesozoico tardio', 'Quaternário']],
      ['Um fóssil de idade viveu pouco tempo e numa área geográfica grande.', true]
    ]
  },
  {
    id: 'cn7_ev_sustentabilidade', t: 'Recursos geológicos e sustentabilidade',
    k: 'recursos geologicos,sustentabilidade,recursos minerais,recursos energeticos,combustiveis fosseis,pedreiras,minas,impactes ambientais,reciclagem,recursos renovaveis,nao renovaveis,patrimonio geologico,geossitio,geoparque',
    ae: 'Identificar recursos geológicos e os impactes da sua exploração e propor medidas de sustentabilidade.',
    r: [
      'Recursos geológicos: minerais (ferro, cobre, volfrâmio, sal-gema), rochas (granito, mármore, calcário), energéticos (carvão, petróleo, gás natural, geotermia) e hidrogeológicos (águas subterrâneas e termais).',
      'Os combustíveis fósseis formaram-se ao longo de milhões de anos: não são renováveis à escala humana.',
      'Exploração de pedreiras e minas: impactes na paisagem, poeiras, ruído, contaminação de águas e solos.',
      'Sustentabilidade: reduzir, reutilizar e reciclar; recuperar pedreiras abandonadas; usar energias renováveis; proteger o património geológico (geossítios e geoparques, como o Geoparque Arouca).',
      'O conhecimento geológico ajuda a prever riscos (sismos, deslizamentos, cheias) e a ordenar o território.'
    ],
    q: [
      ['Qual destes é um recurso energético geológico?', ['petróleo', 'granito', 'sal de cozinha reciclado', 'madeira']],
      ['Os combustíveis fósseis são recursos…', ['não renováveis', 'renováveis', 'inesgotáveis', 'biológicos atuais']],
      ['Um impacte da exploração de pedreiras é…', ['alteração da paisagem e poeiras', 'aumento da biodiversidade', 'água mais limpa', 'diminuição do ruído']],
      ['O Geoparque Arouca é um exemplo de proteção do…', ['património geológico', 'património musical', 'oceano profundo', 'clima']],
      ['Reciclar metais reduz a necessidade de abrir novas minas.', true]
    ]
  }
]);

// ============================================================= FÍSICO-QUÍMICA
TEMAS(7, 'fq', [
  {
    id: 'fq7_ev_estacoes', t: 'Rotação, translação, estações do ano, fases da Lua e eclipses',
    k: 'rotacao,translacao,dia e noite,estacoes do ano,solsticio,equinocio,eixo da terra,inclinacao,fases da lua,lua cheia,lua nova,quarto crescente,quarto minguante,eclipse,eclipse do sol,eclipse da lua,constelacoes,estrela polar,big bang',
    ae: 'Explicar a sucessão dos dias e das noites, as estações do ano, as fases da Lua e os eclipses; conhecer constelações e a origem do Universo.',
    r: [
      'Rotação: a Terra gira sobre o seu eixo em cerca de 24 h — origina o dia e a noite e o movimento aparente do Sol (nasce a Este, põe-se a Oeste).',
      'Translação: a Terra gira à volta do Sol em cerca de 365 dias e 6 horas (daí os anos bissextos).',
      'As estações do ano devem-se à inclinação do eixo da Terra (cerca de 23,5°) durante a translação: os raios solares chegam mais ou menos inclinados. Solstícios (junho e dezembro) e equinócios (março e setembro).',
      'Fases da Lua (ciclo de cerca de 29,5 dias): Lua Nova, Quarto Crescente, Lua Cheia, Quarto Minguante. A Lua não tem luz própria: reflete a do Sol.',
      'Eclipse do Sol: a Lua fica entre o Sol e a Terra (só em Lua Nova). Eclipse da Lua: a Terra fica entre o Sol e a Lua (só em Lua Cheia).',
      'Constelações: grupos de estrelas que, vistos da Terra, parecem formar figuras (Ursa Maior, Ursa Menor, Orionte, Cassiopeia). A Estrela Polar, na Ursa Menor, indica o Norte.',
      'Teoria do Big Bang: o Universo teve origem há cerca de 13 800 milhões de anos e continua a expandir-se.'
    ],
    q: [
      ['O que origina o dia e a noite?', ['a rotação da Terra', 'a translação da Terra', 'as fases da Lua', 'a distância ao Sol']],
      ['As estações do ano devem-se sobretudo…', ['à inclinação do eixo da Terra', 'à distância da Terra ao Sol', 'às fases da Lua', 'aos eclipses']],
      ['Um eclipse do Sol acontece quando…', ['a Lua fica entre o Sol e a Terra', 'a Terra fica entre o Sol e a Lua', 'o Sol fica entre a Terra e a Lua', 'há Lua Cheia']],
      ['Em que fase da Lua pode haver um eclipse da Lua?', ['Lua Cheia', 'Lua Nova', 'Quarto Crescente', 'Quarto Minguante']],
      ['Em que constelação fica a Estrela Polar?', ['Ursa Menor', 'Orionte', 'Cassiopeia', 'Escorpião']],
      ['O solstício de verão no hemisfério norte acontece em…', ['junho', 'março', 'setembro', 'janeiro']],
      ['Qual é a idade aproximada do Universo segundo a teoria do Big Bang?', ['13 800 milhões de anos', '4600 milhões de anos', '10 mil anos', '1 milhão de anos']],
      ['A Lua tem luz própria.', false, 'A Lua reflete a luz do Sol.']
    ]
  },
  {
    id: 'fq7_ev_laboratorio', t: 'Material de laboratório, segurança e preparação de soluções',
    k: 'material de laboratorio,regras de seguranca,pictogramas,simbolos de perigo,gobele,copo,proveta,balao volumetrico,balanca,vareta,pipeta,funil,erlenmeyer,tubo de ensaio,preparar solucao,concentracao massica',
    ae: 'Identificar material de laboratório, regras de segurança e pictogramas de perigo; preparar uma solução com uma dada concentração.',
    r: [
      'Material comum: copo (gobelé), proveta (medir volumes), balão volumétrico (preparar soluções com volume exato), balão de Erlenmeyer, tubo de ensaio, vareta de vidro (agitar), funil, pipeta, espátula, vidro de relógio e balança.',
      'Regras de segurança: usar bata, óculos e luvas quando indicado; não comer nem beber; ler o rótulo; nunca cheirar diretamente; prender o cabelo; seguir as instruções do professor.',
      'Pictogramas de perigo (losango vermelho): inflamável (chama), corrosivo, tóxico (caveira), nocivo/irritante (ponto de exclamação), perigoso para o ambiente.',
      'Concentração mássica: Cm = massa de soluto : volume de solução (em g/dm³ ou g/L).',
      'Preparar uma solução: calcular a massa de soluto, pesá-la, dissolvê-la num pouco de solvente, transferir para o balão volumétrico e completar até ao traço (aferir), agitar e rotular.'
    ],
    q: [
      ['Que material se usa para preparar uma solução com volume exato?', ['balão volumétrico', 'tubo de ensaio', 'funil', 'vidro de relógio']],
      ['O pictograma com uma caveira indica uma substância…', ['tóxica', 'inflamável', 'corrosiva', 'inofensiva']],
      ['Dissolveram-se 20 g de açúcar em água até 0,5 L de solução. Qual é a concentração mássica?', ['40 g/L', '10 g/L', '20,5 g/L', '0,025 g/L']],
      ['Para medir volumes de líquidos com rigor razoável usa-se a…', ['proveta', 'espátula', 'vareta', 'cápsula de porcelana']],
      ['No laboratório nunca se deve cheirar diretamente uma substância.', true],
      ['A vareta de vidro serve para…', ['agitar', 'aquecer', 'pesar', 'medir volumes']]
    ]
  },
  {
    id: 'fq7_ev_reacoes', t: 'Reações químicas e equações de palavras',
    k: 'reacoes quimicas,reacao quimica,reagentes,produtos,equacao de palavras,combustao,fatores que desencadeiam reacoes,acao do calor,acao da luz,acao da eletricidade,acao mecanica,juncao de substancias,evidencias de reacao,testes quimicos,sulfato de cobre anidro,agua de cal',
    ae: 'Distinguir reações químicas, representá-las por equações de palavras e identificar os fatores que as desencadeiam.',
    r: [
      'Numa reação química, os reagentes transformam-se em produtos (novas substâncias). Representa-se por uma equação de palavras: carbono + oxigénio → dióxido de carbono.',
      'Sinais de que ocorreu uma reação: mudança de cor, libertação de gás (efervescência), formação de um sólido (precipitado), libertação ou absorção de energia (calor, luz), cheiro.',
      'Fatores que desencadeiam reações: aquecimento (cozinhar um ovo), luz (fotossíntese, revelar fotografias), corrente elétrica (eletrólise da água), ação mecânica (riscar um fósforo) e junção de substâncias (vinagre + bicarbonato).',
      'Combustão: reação de um combustível com o oxigénio (comburente), iniciada por uma energia de ativação — o triângulo do fogo.',
      'Testes químicos: o sulfato de cobre anidro (branco) fica azul na presença de água; a água de cal turva na presença de dióxido de carbono.'
    ],
    q: [
      ['Numa reação química, as substâncias iniciais chamam-se…', ['reagentes', 'produtos', 'soluções', 'catalisadores']],
      ['Qual destes é sinal de reação química?', ['libertação de um gás', 'derreter gelo', 'dissolver açúcar', 'partir um copo']],
      ['A fotossíntese é desencadeada pela…', ['luz', 'eletricidade', 'ação mecânica', 'temperatura negativa']],
      ['Riscar um fósforo é um exemplo de reação desencadeada por…', ['ação mecânica', 'luz', 'corrente elétrica', 'junção de soluções']],
      ['Que substância deteta a presença de água, ficando azul?', ['sulfato de cobre anidro', 'água de cal', 'sal de cozinha', 'vinagre']],
      ['A água de cal turva na presença de…', ['dióxido de carbono', 'oxigénio', 'azoto', 'hidrogénio']],
      ['Na combustão, o oxigénio é o comburente.', true]
    ]
  },
  {
    id: 'fq7_ev_calor', t: 'Temperatura, calor e transferências de energia',
    k: 'temperatura,calor,transferencia de energia,conducao,conveccao,radiacao,condutores termicos,isoladores termicos,equilibrio termico,joule,caloria,quilowatt hora,kwh,conversao de unidades de energia,sistema fisico,fonte e recetor',
    ae: 'Distinguir temperatura de calor; identificar os processos de transferência de energia como calor; converter unidades de energia.',
    r: [
      'Temperatura: indica se um corpo está mais quente ou mais frio (mede-se em °C com o termómetro). Calor: energia transferida de um corpo a temperatura mais alta para outro a temperatura mais baixa, até ao equilíbrio térmico.',
      'Condução: a energia passa de partícula em partícula, sobretudo nos sólidos (colher numa sopa quente). Os metais são bons condutores; madeira, plástico, cortiça, lã e ar são isoladores.',
      'Convecção: nos líquidos e gases, o fluido quente sobe e o frio desce, formando correntes de convecção (água a ferver, aquecedor).',
      'Radiação: a energia propaga-se sem precisar de matéria, até no vazio (a energia do Sol que chega à Terra).',
      'Unidades de energia: joule (J) é a unidade do SI; 1 kJ = 1000 J; 1 cal ≈ 4,18 J; 1 kWh = 3 600 000 J (3,6 × 10⁶ J).',
      'Num sistema físico há uma fonte (cede energia) e um recetor (recebe energia).'
    ],
    q: [
      ['A energia do Sol chega à Terra por…', ['radiação', 'condução', 'convecção', 'evaporação']],
      ['Numa panela de água ao lume, a água quente sobe e a fria desce. Isto é…', ['convecção', 'condução', 'radiação', 'condensação']],
      ['Qual destes materiais é um bom condutor térmico?', ['cobre', 'cortiça', 'lã', 'madeira']],
      ['Qual é a unidade de energia do Sistema Internacional?', ['joule', 'caloria', 'watt', 'grau Celsius']],
      ['Quantos joules tem 1 kJ?', ['1000 J', '100 J', '4,18 J', '3600 J']],
      ['O calor transfere-se espontaneamente do corpo mais quente para o mais frio.', true],
      ['Temperatura e calor são exatamente a mesma coisa.', false, 'A temperatura mede o estado de um corpo; o calor é energia em transferência.']
    ]
  }
]);

// ============================================================= HISTÓRIA
TEMAS(7, 'hist', [
  {
    id: 'hist7_ev_contributos', t: 'Contributos das primeiras civilizações: hebreus, fenícios e sumérios',
    k: 'hebreus,fenicios,sumerios,alfabeto,alfabeto fenicio,monoteismo,judaismo,escrita cuneiforme,hieroglifos,codigo de hamurabi,contributos das civilizacoes,mesopotamia',
    ae: 'Identificar os contributos culturais e científicos de sumérios, egípcios, fenícios e hebreus.',
    r: [
      'Sumérios (Mesopotâmia): criaram a escrita cuneiforme (em placas de barro), a roda, o sistema de contagem de base 60 (60 minutos numa hora). Na Babilónia, o Código de Hamurabi foi um dos primeiros conjuntos de leis escritas.',
      'Egípcios: hieróglifos, calendário solar de 365 dias, conhecimentos de medicina, matemática e geometria (pirâmides).',
      'Fenícios: povo de comerciantes e navegadores do Mediterrâneo; criaram um alfabeto com cerca de 22 sinais, que deu origem ao alfabeto grego e latino; fundaram colónias (Cartago).',
      'Hebreus: primeiro povo monoteísta (acreditavam num só Deus, Javé). Os seus livros sagrados formam a Bíblia hebraica (Antigo Testamento), base do judaísmo e do cristianismo.'
    ],
    q: [
      ['Que povo criou o alfabeto que deu origem ao alfabeto grego e latino?', ['fenícios', 'hebreus', 'egípcios', 'romanos']],
      ['Os hebreus foram o primeiro povo…', ['monoteísta', 'a usar a roda', 'a construir pirâmides', 'a criar a democracia']],
      ['A escrita cuneiforme foi criada pelos…', ['sumérios', 'gregos', 'fenícios', 'celtas']],
      ['O Código de Hamurabi é um conjunto de…', ['leis', 'poemas', 'mapas', 'orações']],
      ['Os fenícios eram sobretudo…', ['comerciantes e navegadores', 'pastores nómadas', 'construtores de pirâmides', 'agricultores do Nilo']],
      ['A divisão da hora em 60 minutos vem do sistema de contagem dos sumérios.', true]
    ]
  },
  {
    id: 'hist7_ev_igreja', t: 'Europa dos séculos VI a IX: reinos bárbaros, Igreja e mosteiros',
    k: 'queda do imperio romano,476,reinos barbaros,povos barbaros,invasoes,visigodos,suevos,francos,igreja catolica,mosteiros,monges,copistas,alta idade media,idade media,carlos magno,vikings',
    ae: 'Explicar a queda do Império Romano do Ocidente, a formação dos reinos bárbaros e o papel da Igreja e dos mosteiros.',
    r: [
      'Em 476, o último imperador romano do Ocidente foi deposto: começa a Idade Média.',
      'Os povos germânicos (chamados "bárbaros" pelos romanos) formaram reinos: visigodos e suevos na Península Ibérica, francos na Gália, ostrogodos em Itália.',
      'A Igreja Católica manteve a unidade e a cultura: converteu os povos germânicos, organizou-se em dioceses (bispos) e o Papa ganhou autoridade.',
      'Os mosteiros eram centros de oração, trabalho e cultura; os monges copistas copiavam livros à mão, preservando o saber antigo.',
      'Nos séculos VIII a X houve novas invasões (muçulmanos, vikings, magiares), que criaram insegurança e levaram ao feudalismo. Carlos Magno, rei dos francos, foi coroado imperador em 800.'
    ],
    q: [
      ['Em que ano caiu o Império Romano do Ocidente?', ['476', '711', '1143', '313']],
      ['Que povos germânicos se fixaram na Península Ibérica?', ['visigodos e suevos', 'vikings e magiares', 'fenícios e gregos', 'francos e anglos']],
      ['Quem copiava livros à mão nos mosteiros?', ['monges copistas', 'cavaleiros', 'servos', 'mercadores']],
      ['Quem foi coroado imperador no ano 800?', ['Carlos Magno', 'Júlio César', 'D. Afonso Henriques', 'Augusto']],
      ['Na Alta Idade Média, os mosteiros foram importantes centros de cultura.', true],
      ['Os vikings vinham do…', ['norte da Europa (Escandinávia)', 'norte de África', 'Médio Oriente', 'sul de Itália']]
    ]
  },
  {
    id: 'hist7_ev_feudal', t: 'Sociedade feudal e relações feudo-vassálicas',
    k: 'feudalismo,feudal,senhorio,feudo,vassalo,suserano,homenagem,ordens sociais,clero,nobreza,povo,servos,terceiro estado,sociedade medieval,trinitaria,oradores,defensores,trabalhadores',
    ae: 'Caracterizar a sociedade medieval em ordens e as relações feudo-vassálicas.',
    r: [
      'A sociedade medieval dividia-se em três ordens: clero (os que rezam), nobreza (os que combatem) e povo ou terceiro estado (os que trabalham). Clero e nobreza eram privilegiados.',
      'Relação feudo-vassálica: o suserano (senhor) dava um feudo (terras) e proteção ao vassalo; o vassalo jurava fidelidade, numa cerimónia de homenagem, e devia ajuda militar e conselho.',
      'O senhorio era o domínio de um senhor: reserva (cultivada pelos servos para o senhor) e mansos (parcelas que os camponeses cultivavam para si).',
      'Os servos estavam presos à terra e pagavam rendas e impostos; tinham de trabalhar gratuitamente nas terras do senhor (corveias) e pagar banalidades (usar o moinho, o forno ou o lagar do senhor).'
    ],
    q: [
      ['Quais eram as três ordens da sociedade medieval?', ['clero, nobreza e povo', 'reis, burgueses e escravos', 'patrícios, plebeus e escravos', 'monges, cavaleiros e reis']],
      ['Quem dava um feudo ao vassalo?', ['o suserano', 'o servo', 'o mercador', 'o monge copista']],
      ['A cerimónia em que o vassalo jurava fidelidade chamava-se…', ['homenagem', 'foral', 'cortes', 'cruzada']],
      ['Os servos estavam…', ['presos à terra do senhor', 'livres de pagar impostos', 'na ordem privilegiada', 'dispensados de trabalhar']],
      ['As banalidades eram pagamentos pelo uso do moinho, forno ou lagar do senhor.', true],
      ['O clero era a ordem dos…', ['que rezam', 'que combatem', 'que trabalham', 'que comerciam']]
    ]
  },
  {
    id: 'hist7_ev_cidades', t: 'Comércio, cidades, burguesia e concelhos medievais',
    k: 'crescimento das cidades,burguesia,burgueses,comercio medieval,feiras,rotas comerciais,liga hanseatica,mercadores,artesaos,corporacoes,mesteres,concelhos,carta de foral,foral,cortes,poder regio,portugal medieval',
    ae: 'Explicar o desenvolvimento económico dos séculos XI a XIII, o crescimento das cidades e da burguesia, e a organização dos concelhos.',
    r: [
      'A partir do século XI, com novas técnicas agrícolas (charrua, rotação trienal, moinhos) houve mais alimentos e a população cresceu.',
      'O comércio reanimou-se: feiras (como as de Champagne), rotas do Mediterrâneo (cidades italianas) e do Mar do Norte e Báltico (Liga Hanseática).',
      'As cidades (burgos) cresceram e surgiu a burguesia: mercadores e artesãos, organizados em corporações (mesteres).',
      'Em Portugal, os concelhos eram comunidades com alguma autonomia, organizada por uma carta de foral dada pelo rei ou por um senhor (direitos e deveres dos moradores).',
      'O poder do rei fortaleceu-se: os reis criaram leis gerais, inquirições e confirmações para controlar a nobreza e o clero, e reuniam as Cortes (clero, nobreza e representantes dos concelhos).'
    ],
    q: [
      ['O documento que dava direitos e deveres aos moradores de um concelho era a…', ['carta de foral', 'bula papal', 'carta de privilégio de guerra', 'constituição']],
      ['Os mercadores e artesãos das cidades formavam a…', ['burguesia', 'nobreza', 'ordem do clero', 'servidão']],
      ['Que associação de cidades comerciais dominava o Mar do Norte e o Báltico?', ['Liga Hanseática', 'União Europeia', 'Ordem de Avis', 'Império Romano']],
      ['As Cortes medievais reuniam…', ['clero, nobreza e representantes dos concelhos', 'só os reis europeus', 'só os mercadores', 'apenas os bispos']],
      ['A rotação trienal ajudou a aumentar a produção agrícola.', true],
      ['As associações de artesãos do mesmo ofício chamavam-se…', ['corporações ou mesteres', 'concelhos', 'feiras', 'mosteiros']]
    ]
  },
  {
    id: 'hist7_ev_cultura', t: 'Cultura medieval: românico, gótico e universidades',
    k: 'arte romanica,romanico,arte gotica,gotico,universidades,universidade de coimbra,estudo geral,d dinis,ordens mendicantes,franciscanos,dominicanos,cultura medieval,catedrais,vitrais,arco de volta perfeita,arco ogival,trovadores,cantigas',
    ae: 'Caracterizar a arte românica e gótica e a cultura medieval (universidades, ordens mendicantes, trovadores).',
    r: [
      'Românico (séculos XI-XII): igrejas com paredes grossas, poucas e pequenas janelas, arco de volta perfeita (semicircular), aspeto de fortaleza e interior escuro. Ex.: Sé de Coimbra (Sé Velha), Sé de Lisboa.',
      'Gótico (séculos XII-XV): edifícios altos e luminosos, arco ogival (em bico), abóbadas de cruzaria, grandes janelas com vitrais e rosáceas. Ex.: Mosteiro da Batalha, Mosteiro de Alcobaça.',
      'Universidades: centros de saber; em Portugal, D. Dinis fundou o Estudo Geral em 1290 (Lisboa, depois Coimbra).',
      'Ordens mendicantes (franciscanos e dominicanos): frades que viviam na pobreza, nas cidades, a pregar e ajudar os pobres.',
      'Literatura: cantigas de amigo, de amor e de escárnio e maldizer, dos trovadores; D. Dinis foi também trovador.'
    ],
    q: [
      ['O arco de volta perfeita é típico da arte…', ['românica', 'gótica', 'barroca', 'manuelina']],
      ['O arco ogival e os vitrais são típicos da arte…', ['gótica', 'românica', 'grega', 'romana']],
      ['O Mosteiro da Batalha é um exemplo de arte…', ['gótica', 'românica', 'renascentista', 'muçulmana']],
      ['Que rei fundou o Estudo Geral (universidade) em 1290?', ['D. Dinis', 'D. Afonso Henriques', 'D. João I', 'D. Manuel I']],
      ['Franciscanos e dominicanos eram ordens…', ['mendicantes', 'militares', 'de comerciantes', 'de nobres guerreiros']],
      ['As igrejas românicas costumam ser escuras, com paredes grossas e poucas janelas.', true]
    ]
  },
  {
    id: 'hist7_ev_crise', t: 'A crise do século XIV e a revolução de 1383-1385',
    k: 'crise do seculo xiv,peste negra,guerra dos cem anos,fome,revoltas camponesas,1383,1385,crise de 1383,aljubarrota,batalha de aljubarrota,cortes de coimbra,joao das regras,nuno alvares pereira,mestre de avis,d joao i,d fernando,d leonor teles,d beatriz',
    ae: 'Explicar a crise do século XIV na Europa e em Portugal e a revolução de 1383-1385.',
    r: [
      'No século XIV a Europa sofreu fomes (más colheitas), a Peste Negra (1348, matou cerca de um terço da população europeia), guerras (Guerra dos Cem Anos entre França e Inglaterra) e revoltas camponesas.',
      'Em Portugal, D. Fernando morreu em 1383 sem filho varão. A filha, D. Beatriz, era casada com o rei de Castela — havia o perigo de Portugal perder a independência. Governava a regente D. Leonor Teles.',
      'O povo de Lisboa e parte da burguesia apoiaram D. João, Mestre de Avis, que se tornou Regedor e Defensor do Reino.',
      'Nas Cortes de Coimbra (1385), com os argumentos do jurista João das Regras, D. João foi aclamado rei: D. João I, início da 2.ª dinastia (de Avis).',
      'Na Batalha de Aljubarrota (14 de agosto de 1385), as tropas portuguesas, comandadas por D. Nuno Álvares Pereira (com a tática do quadrado), venceram os castelhanos. Para a comemorar, foi construído o Mosteiro da Batalha.',
      'Depois da crise, a burguesia ganhou importância e parte da velha nobreza perdeu poder.'
    ],
    q: [
      ['Que epidemia matou cerca de um terço da população europeia em 1348?', ['Peste Negra', 'gripe espanhola', 'varíola', 'cólera']],
      ['Quem morreu em 1383 sem deixar filho varão?', ['D. Fernando', 'D. Dinis', 'D. João I', 'D. Afonso IV']],
      ['Em que Cortes foi D. João, Mestre de Avis, aclamado rei?', ['Cortes de Coimbra, 1385', 'Cortes de Lamego', 'Cortes de Lisboa, 1640', 'Cortes de Leiria, 1254']],
      ['Quem comandou as tropas portuguesas em Aljubarrota?', ['D. Nuno Álvares Pereira', 'João das Regras', 'D. Leonor Teles', 'Vasco da Gama']],
      ['Que mosteiro foi construído para comemorar a vitória de Aljubarrota?', ['Mosteiro da Batalha', 'Mosteiro dos Jerónimos', 'Mosteiro de Alcobaça', 'Mosteiro de Tibães']],
      ['A Guerra dos Cem Anos opôs…', ['França e Inglaterra', 'Portugal e Castela', 'Roma e Cartago', 'cristãos e vikings']],
      ['D. João I iniciou a 2.ª dinastia, a dinastia de Avis.', true]
    ]
  }
]);

// ============================================================= GEOGRAFIA
TEMAS(7, 'geo', [
  {
    id: 'geo7_ev_paisagem', t: 'A Geografia e a paisagem',
    k: 'geografia,o que e a geografia,paisagem,tipos de paisagem,paisagem natural,paisagem humanizada,paisagem rural,paisagem urbana,elementos naturais,elementos humanos,geografo',
    ae: 'Compreender o objeto de estudo da Geografia e distinguir tipos de paisagem.',
    r: [
      'A Geografia estuda a superfície da Terra, a distribuição dos fenómenos físicos e humanos e as relações entre o ser humano e o meio. Procura responder a: Onde? Porquê aí? Como? Que consequências?',
      'Paisagem: a parte da superfície terrestre que se observa a partir de um lugar, com elementos naturais (relevo, rios, vegetação, clima) e humanos (casas, estradas, campos cultivados).',
      'Paisagem natural: quase sem intervenção humana (alta montanha, deserto). Paisagem humanizada: transformada pelo ser humano — rural (campos, aldeias) ou urbana (cidades, prédios, indústria, serviços).',
      'As paisagens mudam ao longo do tempo por causas naturais e humanas.'
    ],
    q: [
      ['Uma paisagem com prédios, avenidas e muitos serviços é…', ['urbana', 'rural', 'natural', 'polar']],
      ['Qual destes é um elemento humano da paisagem?', ['estrada', 'rio', 'montanha', 'floresta natural']],
      ['Uma paisagem quase sem intervenção humana chama-se…', ['natural', 'humanizada', 'urbana', 'industrial']],
      ['A Geografia estuda as relações entre o ser humano e o meio.', true],
      ['Campos cultivados e pequenas aldeias formam uma paisagem…', ['rural', 'urbana', 'desértica', 'natural']]
    ]
  },
  {
    id: 'geo7_ev_portugal', t: 'Portugal na Europa e no mundo; clima e vegetação de Portugal',
    k: 'portugal na europa,portugal na uniao europeia,uniao europeia,localizacao de portugal,peninsula iberica,clima de portugal,clima mediterranico,clima temperado maritimo,vegetacao de portugal,sobreiro,azinheira,montado,carvalho,pinheiro,acores,madeira,arquipelagos',
    ae: 'Localizar Portugal na Europa, na União Europeia e no mundo e caracterizar o clima e a vegetação de Portugal.',
    r: [
      'Portugal fica no sudoeste da Europa, na Península Ibérica, com fronteira terrestre só com Espanha. Inclui os arquipélagos dos Açores e da Madeira, no oceano Atlântico.',
      'Portugal entrou na CEE (hoje União Europeia) em 1986 e adotou o euro em 2002. A UE tem 27 Estados-membros.',
      'Portugal continental tem clima temperado mediterrânico: verões quentes e secos, invernos suaves e chuvosos. O noroeste é mais chuvoso (influência marítima); o interior tem maiores amplitudes térmicas.',
      'Vegetação natural: no norte, florestas de carvalhos (caducifólias); no sul, montado de sobreiros e azinheiras (perenifólias, adaptadas à secura); matos mediterrânicos (esteva, alecrim). O pinheiro e o eucalipto foram muito plantados.',
      'A Madeira tem a floresta Laurissilva (Património Mundial); os Açores têm clima temperado marítimo, húmido.'
    ],
    q: [
      ['Em que ano Portugal aderiu à CEE (atual União Europeia)?', ['1986', '1974', '2002', '1910']],
      ['Como é o verão no clima mediterrânico?', ['quente e seco', 'frio e chuvoso', 'quente e muito chuvoso', 'gelado']],
      ['Que árvores formam o montado alentejano?', ['sobreiros e azinheiras', 'pinheiros e eucaliptos', 'palmeiras', 'abetos e bétulas']],
      ['A floresta Laurissilva fica…', ['na Madeira', 'no Algarve', 'em Trás-os-Montes', 'nos Açores apenas']],
      ['Que região de Portugal continental é mais chuvosa?', ['o noroeste (Minho)', 'o Alentejo', 'o Algarve', 'o interior sul']],
      ['Portugal só tem fronteira terrestre com Espanha.', true]
    ]
  },
  {
    id: 'geo7_ev_topografia', t: 'Mapas topográficos, perfis e agentes erosivos',
    k: 'mapa topografico,curvas de nivel,equidistancia,perfil topografico,altitude,cota,vertente,erosao,agentes erosivos,agua,vento,gelo,mar,meteorizacao,transporte,sedimentacao,temperatura,amplitude termica,variacao diurna,precipitacao',
    ae: 'Ler mapas topográficos e construir perfis; explicar o processo erosivo e os seus agentes; analisar a variação da temperatura e da precipitação.',
    r: [
      'Curvas de nível: linhas que unem pontos com a mesma altitude. Equidistância: diferença de altitude entre duas curvas seguidas. Curvas muito juntas = declive acentuado; afastadas = declive suave.',
      'Perfil topográfico: corte que mostra a forma do relevo ao longo de uma linha do mapa.',
      'Processo erosivo: meteorização (desagregação das rochas), erosão (remoção), transporte e sedimentação (deposição).',
      'Agentes erosivos: água corrente (rios), mar (ondas), vento, gelo (glaciares), variações de temperatura e seres vivos (incluindo o ser humano).',
      'Amplitude térmica = temperatura máxima − temperatura mínima. Durante o dia, a temperatura mais alta é no início da tarde e a mais baixa pouco antes do nascer do Sol.',
      'Formas de precipitação: chuva, neve, granizo; orvalho e geada formam-se junto ao solo.'
    ],
    q: [
      ['Num mapa topográfico, curvas de nível muito juntas indicam…', ['declive acentuado', 'terreno plano', 'um rio', 'uma cidade']],
      ['As linhas que unem pontos com a mesma altitude chamam-se…', ['curvas de nível', 'paralelos', 'meridianos', 'isóbaras']],
      ['A deposição de materiais transportados chama-se…', ['sedimentação', 'meteorização', 'erosão', 'evaporação']],
      ['Máxima 24 °C e mínima 9 °C: qual é a amplitude térmica?', ['15 °C', '33 °C', '16,5 °C', '9 °C']],
      ['Qual destes é um agente erosivo?', ['o vento', 'o sol nascente sem variação', 'a latitude', 'o meridiano']],
      ['Num dia normal, a temperatura mínima regista-se pouco antes do nascer do Sol.', true]
    ]
  }
]);

// ============================================================= INGLÊS
TEMAS(7, 'ing', [
  {
    id: 'ing7_ev_aboutme', t: 'About me: routines, chores, feelings and family',
    k: 'about me,personal identity,feelings,moods,daily routines,routines,household chores,chores,family members,family,relationships,adverbs of frequency,always,usually,often,sometimes,never',
    ae: 'Talk about personal identity, feelings, daily routines, household chores and family, using adverbs of frequency.',
    r: [
      "Feelings and moods: happy, sad, angry, bored, excited, scared, worried, tired, nervous, proud.",
      "Daily routines: wake up, get up, have a shower, get dressed, have breakfast, go to school, do homework, go to bed.",
      "Household chores: make the bed, do the washing-up, lay the table, tidy my room, take out the rubbish, do the laundry, vacuum.",
      "Adverbs of frequency (before the main verb, after 'to be'): always (100%), usually, often, sometimes, rarely, never (0%). 'I always make my bed.' 'She is never late.'",
      "Family: grandparents, parents, uncle, aunt, cousin, nephew, niece, stepmother, stepfather, only child, twins."
    ],
    q: [
      ["'Lavar a loiça' in English is…", ['do the washing-up', 'make the bed', 'lay the table', 'take out the rubbish']],
      ["Choose the correct sentence.", ['I always get up at 7.', 'I get always up at 7.', 'Always I get up at 7.', 'I get up at 7 always am.']],
      ["Choose the correct sentence with 'to be'.", ['She is never late.', 'She never is late.', 'Never she is late.', 'She is late never always.']],
      ["Your mother's sister is your…", ['aunt', 'niece', 'cousin', 'grandmother']],
      ["Your uncle's son is your…", ['cousin', 'nephew', 'brother', 'stepfather']],
      ["'Never' means…", ['0% of the time', '100% of the time', '50% of the time', 'every day']],
      ["'Aborrecido' (sem nada para fazer) in English is…", ['bored', 'angry', 'proud', 'excited']]
    ]
  },
  {
    id: 'ing7_ev_pastcont', t: 'Past continuous, when and while',
    k: 'past continuous,was doing,were doing,past simple and past continuous,when,while,interrupted action',
    ae: 'Use the past continuous to describe actions in progress in the past and contrast it with the past simple using when and while.',
    r: [
      "Past continuous = was/were + verb-ing: 'I was reading.' 'They were playing.'",
      "Negative: wasn't / weren't + -ing. Questions: Was she sleeping? Were you watching TV?",
      "Use it for an action in progress at a moment in the past: 'At 8 p.m. I was having dinner.'",
      "Past continuous + past simple: a longer action interrupted by a shorter one. 'I was walking home when it started to rain.'",
      "While + past continuous for two actions at the same time: 'While I was cooking, my brother was studying.'"
    ],
    q: [
      ["Yesterday at 9 p.m. I … TV.", ['was watching', 'were watching', 'watched always', 'am watching']],
      ["They … football when it started to rain.", ['were playing', 'was playing', 'are playing', 'played was']],
      ["I was sleeping … the phone rang.", ['when', 'while', 'during', 'because']],
      ["… I was studying, my sister was listening to music.", ['While', 'When then', 'So', 'Because of']],
      ["Choose the question form.", ['Were you sleeping?', 'Was you sleeping?', 'Did you sleeping?', 'You were sleeping?']],
      ["The past continuous is formed with was/were + verb-ing.", true]
    ]
  },
  {
    id: 'ing7_ev_ifclauses', t: 'If clauses, indefinite pronouns and connectors',
    k: 'if clauses,zero conditional,first conditional,type 0,type 1,indefinite pronouns,somebody,anybody,nobody,something,anything,nothing,somewhere,anywhere,nowhere,connectors,so,because,and,but,or,first,then,finally,word formation,prefixes,suffixes,compound words',
    ae: 'Use zero and first conditional, indefinite pronouns, connectors and word formation.',
    r: [
      "Zero conditional (general truths): If + present simple, present simple. 'If you heat ice, it melts.'",
      "First conditional (possible future): If + present simple, will + verb. 'If it rains, I will stay at home.'",
      "Indefinite pronouns: some- (affirmative: somebody, something, somewhere), any- (questions and negatives: anybody, anything), no- (negative meaning, with an affirmative verb: nobody, nothing, nowhere).",
      "Connectors: and (addition), but (contrast), or (alternative), because (reason), so (result); sequence: first, then, next, after that, finally.",
      "Word formation: prefixes change the meaning (unhappy, impossible, rewrite); suffixes change the word class (teach → teacher, care → careful, quick → quickly). Compound words: football, classroom, toothbrush."
    ],
    q: [
      ["If it rains tomorrow, we … at home.", ['will stay', 'stayed', 'stays', 'would stayed']],
      ["If you heat water to 100 °C, it …", ['boils', 'will boiled', 'boiled', 'is boil']],
      ["Is there … in the box?", ['anything', 'something not', 'nothing', 'nobody']],
      ["I can't find my keys … !", ['anywhere', 'somewhere', 'nowhere', 'everywhere not']],
      ["I was tired, … I went to bed early.", ['so', 'because', 'but', 'or']],
      ["Which word has a prefix that means 'not'?", ['unhappy', 'teacher', 'careful', 'quickly']],
      ["'Nobody' is used with an affirmative verb: 'Nobody came.'", true]
    ]
  },
  {
    id: 'ing7_ev_culture', t: 'Culture: UK, USA, festivities and The Happy Prince',
    k: 'culture,united kingdom,great britain,england,scotland,wales,northern ireland,united states,usa,british english,american english,halloween,christmas,st patrick s day,independence day,4th of july,thanksgiving,the happy prince,oscar wilde,european union',
    ae: 'Know cultural aspects of English-speaking countries, festivities, British and American English and the extensive reading.',
    r: [
      "Great Britain = England + Scotland + Wales. United Kingdom = Great Britain + Northern Ireland. Capitals: London, Edinburgh, Cardiff, Belfast.",
      "The USA has 50 states; the capital is Washington, D.C. Independence Day is on the 4th of July (1776).",
      "British vs American English: flat / apartment, lift / elevator, holiday / vacation, autumn / fall, biscuit / cookie, football / soccer, colour / color.",
      "Festivities: Halloween (31st October — trick or treat), Christmas (25th December), St Patrick's Day (17th March — Ireland's patron saint, green and shamrocks), Thanksgiving (USA, fourth Thursday of November).",
      "'The Happy Prince', by Oscar Wilde: a golden statue of a prince asks a swallow to give his jewels and gold to the poor of the city."
    ],
    q: [
      ["Great Britain is formed by…", ['England, Scotland and Wales', 'England and Ireland', 'England only', 'the UK and the USA']],
      ["What is the capital of Scotland?", ['Edinburgh', 'Cardiff', 'Belfast', 'Dublin']],
      ["Independence Day in the USA is on…", ['the 4th of July', 'the 25th of December', 'the 17th of March', 'the 31st of October']],
      ["'Elevator' (American English) in British English is…", ['lift', 'flat', 'holiday', 'biscuit']],
      ["St Patrick's Day is the national day of…", ['Ireland', 'Scotland', 'Wales', 'Canada']],
      ["Who wrote 'The Happy Prince'?", ['Oscar Wilde', 'Charles Dickens', 'Roald Dahl', 'J. K. Rowling']],
      ["In 'The Happy Prince', which bird helps the prince?", ['a swallow', 'an eagle', 'a parrot', 'an owl']]
    ]
  },
  {
    id: 'ing7_ev_city', t: 'Houses, places in a city and directions',
    k: 'types of houses,cottage,detached house,semi detached,terraced house,flat,houseboat,rooms in a house,places in a city,public buildings,directions,turn left,turn right,go straight on,next to,opposite,between,behind,in front of,prepositions of movement,into,onto',
    ae: 'Describe houses and neighbourhoods, places in a city, and ask for and give directions.',
    r: [
      "Types of houses: detached house, semi-detached house, terraced house, cottage, flat (block of flats), bungalow, houseboat, igloo, tree house.",
      "Places in a city: town hall, library, hospital, police station, fire station, post office, bank, shopping centre, bus station, train station, chemist's.",
      "Prepositions of place: next to, opposite, between, behind, in front of, near, at the corner of. Prepositions of movement: to, into, onto, along, across, past.",
      "Directions: 'Excuse me, how can I get to the museum?' — 'Go straight on, turn left at the traffic lights, take the second street on the right. It's opposite the bank.'",
      "Polite requests: Could you tell me…? Can I…? Would you mind…?"
    ],
    q: [
      ["A house joined to another house on one side is…", ['semi-detached', 'detached', 'a cottage', 'a houseboat']],
      ["Where can you buy medicine?", ["at the chemist's", 'at the fire station', 'at the town hall', 'at the library']],
      ["'Em frente de' (do outro lado da rua) in English is…", ['opposite', 'behind', 'between', 'next to']],
      ["'Siga sempre em frente' in English is…", ['Go straight on.', 'Turn left.', 'Turn right.', 'Go back.']],
      ["The cat jumped … the table.", ['onto', 'into', 'across', 'under to']],
      ["Choose the polite request.", ['Could you tell me where the station is?', 'Tell me the station now!', 'Where station?', 'You tell me station.']]
    ]
  }
]);

// ============================================================= FRANCÊS
TEMAS(7, 'fr', [
  {
    id: 'fr7_ev_alimentation', t: "L'alimentation et les repas",
    k: 'alimentation,les repas,petit dejeuner,dejeuner,gouter,diner,aliments,fruits,legumes,boissons,articles partitifs,du,de la,des,au restaurant,j ai faim',
    ae: "Parler de l'alimentation, des repas et des goûts, en utilisant les articles partitifs.",
    r: [
      "Les repas: le petit-déjeuner (manhã), le déjeuner (almoço), le goûter (lanche), le dîner (jantar).",
      "Aliments: le pain, le fromage, le lait, les œufs, le poisson, la viande, le poulet, les pâtes, le riz, la salade, les légumes, les fruits (une pomme, une banane, une orange, des fraises).",
      "Boissons: l'eau, le jus d'orange, le lait, le chocolat chaud.",
      "Articles partitifs (quantité indéfinie): du (masculin), de la (féminin), de l' (voyelle), des (pluriel). « Je mange du pain, de la salade et des fruits. » À la forme négative: pas de — « Je ne mange pas de viande. »",
      "Exprimer les goûts: j'aime, j'adore, je préfère, je n'aime pas, je déteste. J'ai faim (fome), j'ai soif (sede)."
    ],
    q: [
      ["'Pequeno-almoço' em francês é…", ['le petit-déjeuner', 'le dîner', 'le goûter', 'le déjeuner']],
      ["Je mange … pain.", ['du', 'de la', 'des', 'le de']],
      ["Je bois … eau.", ["de l'", 'du', 'de la', 'des']],
      ["Na negativa: « Je ne mange pas … viande. »", ['de', 'de la', 'du', 'des']],
      ["'Tenho sede' em francês é…", ["J'ai soif.", "J'ai faim.", 'Je suis soif.', "J'ai chaud."]],
      ["'Le goûter' é a refeição da…", ['tarde (lanche)', 'manhã cedo', 'noite', 'meia-noite']]
    ]
  },
  {
    id: 'fr7_ev_ville', t: 'La ville, les transports et les vacances',
    k: 'la ville,les transports,moyens de transport,en bus,en voiture,a pied,a velo,en train,en avion,les vacances,les voyages,la gare,la boulangerie,la pharmacie,indiquer le chemin,tourner a gauche,tout droit,a cote de,en face de',
    ae: 'Parler de la ville, des moyens de transport et des vacances; demander et indiquer le chemin.',
    r: [
      "Lieux de la ville: la boulangerie (padaria), la pharmacie, la poste, la gare (estação de comboios), l'hôpital, le musée, le parc, la bibliothèque, le supermarché.",
      "Moyens de transport: en bus, en voiture, en train, en avion, en bateau, en métro — mais à pied, à vélo, à cheval.",
      "Indiquer le chemin: allez tout droit, tournez à gauche / à droite, prenez la deuxième rue; à côté de, en face de, entre, derrière, devant.",
      "Les vacances: à la plage, à la montagne, à la campagne; voyager, nager, faire du ski, visiter un musée. « Pendant les vacances, je vais à la plage. »",
      "Prépositions avec les pays: en France, en Espagne (féminin), au Portugal (masculin), aux États-Unis (pluriel); à Paris (ville)."
    ],
    q: [
      ["'La boulangerie' é a…", ['padaria', 'farmácia', 'biblioteca', 'estação']],
      ["Je vais à l'école … vélo.", ['à', 'en', 'au', 'par']],
      ["Je vais à Paris … avion.", ['en', 'à', 'au', 'sur']],
      ["'Siga em frente' em francês é…", ['Allez tout droit.', 'Tournez à gauche.', 'Tournez à droite.', 'Retournez.']],
      ["J'habite … Portugal.", ['au', 'en', 'à', 'aux']],
      ["'La gare' é a…", ['estação de comboios', 'garagem', 'praia', 'loja']]
    ]
  },
  {
    id: 'fr7_ev_quotidien', t: 'Les activités quotidiennes et les verbes pronominaux',
    k: 'activites quotidiennes,la routine,verbes pronominaux,se lever,se reveiller,se laver,s habiller,se coucher,l heure,quelle heure est il,la maison,les pieces,la chambre,la cuisine,le salon,la salle de bains',
    ae: 'Décrire la routine quotidienne avec les verbes pronominaux et dire l\'heure; nommer les pièces de la maison.',
    r: [
      "Verbes pronominaux: je me réveille, tu te lèves, il/elle se lave, nous nous habillons, vous vous brossez les dents, ils/elles se couchent.",
      "Routine: je me réveille à 7 heures, je prends le petit-déjeuner, je vais à l'école, je fais mes devoirs, je me couche à 22 heures.",
      "L'heure: Quelle heure est-il? Il est huit heures. Il est huit heures et demie (8h30). Il est midi / minuit. Il est neuf heures moins le quart (8h45).",
      "La maison: la cuisine, le salon, la salle à manger, la chambre, la salle de bains, le jardin, le garage."
    ],
    q: [
      ["Je … à 7 heures. (acordar)", ['me réveille', 'se réveille', 'te réveilles', 'nous réveillons']],
      ["Nous … à 22 heures. (deitar-se)", ['nous couchons', 'se couchent', 'me couche', 'vous couchez']],
      ["'Il est huit heures et demie' são…", ['8h30', '8h15', '7h30', '8h45']],
      ["'Quelle heure est-il?' quer dizer…", ['Que horas são?', 'Que dia é hoje?', 'Quantos anos tens?', 'Onde estás?']],
      ["'La salle de bains' é a…", ['casa de banho', 'sala de jantar', 'cozinha', 'garagem']],
      ["'Il est midi' quer dizer que é…", ['meio-dia', 'meia-noite', 'uma hora', 'manhã cedo']]
    ]
  }
]);
