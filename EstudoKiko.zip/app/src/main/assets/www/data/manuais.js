/*
 * Complementos alinhados com os manuais adotados (2026/2027):
 * 4.º ano — PLIM Português, PLIM Matemática, PLIM Estudo do Meio (Texto/LeYa), Start the Magic! 4
 * 7.º ano — O Mundo em Palavras 7, Espiral 7, GEOCienTIC 7, FQ 7, Manual de História 7, GEO+ 7,
 *            Engaging 7, Ça Marche ! 7, TecnIC 7, Novo Visual 7/8/9
 * Conteúdos escritos de raiz, seguindo os temas e a sequência destes manuais e das planificações
 * das escolas que os adotam; onde o índice não é público, seguem as Aprendizagens Essenciais.
 */

// ================================================================ 4.º ANO — acrescentos aos temas existentes
(function () {
  const dados = CUR.temas.mat4_dados;
  dados.r.push('Diagrama de caule-e-folhas: o caule são as dezenas e as folhas são as unidades. Ex.: caule 2 | folhas 3 5 8 representa 23, 25 e 28.');
  dados.q.push(
    ['Num diagrama de caule-e-folhas, a linha "3 | 1 4 6" representa…', ['31, 34 e 36', '3, 1, 4 e 6', '314 e 6', '13, 14 e 16']],
    ['No diagrama de caule-e-folhas, as folhas representam normalmente as…', ['unidades', 'dezenas', 'centenas', 'frações']]
  );
  dados.k += ',caule-e-folhas,caule e folhas';

  const amb = CUR.temas.em4_ambiente;
  amb.r.push('Espécies em vias de extinção em Portugal: lince-ibérico, lobo-ibérico, águia-imperial-ibérica, saramugo. Causas: destruição dos habitats, caça, poluição e incêndios. Proteção: reservas e parques naturais.');
  amb.q.push(
    ['Qual destes animais é uma espécie ameaçada que vive em Portugal?', ['lince-ibérico', 'pardal', 'gaivota', 'coelho doméstico']],
    ['A destruição dos habitats é uma das causas da extinção de espécies.', true]
  );
  amb.k += ',especies em vias de extincao,extincao,lince iberico';
})();

TEMAS(4, 'pt', [
  {
    id: 'pt4_obras', t: 'Obras de Educação Literária',
    k: 'obras,livros,educacao literaria,a maior flor do mundo,saramago,o segredo do rio,o gigante egoista,oscar wilde,bojador,sophia,a mata dos medos,versos de cacaraca,teatro as tres pancadas,antonio torrado',
    ae: 'Ler integralmente obras literárias do Plano de Educação Literária do 4.º ano e identificar autores, personagens e temas.',
    r: [
      '"A Maior Flor do Mundo" — José Saramago: um menino parte numa aventura, encontra uma flor quase a morrer e vai buscar água muito longe para a salvar. Fala de coragem e generosidade.',
      '"O Gigante Egoísta" — Oscar Wilde: um gigante não deixa as crianças brincar no seu jardim e o inverno não acaba; quando abre o jardim, aprende a partilhar.',
      '"O Segredo do Rio" — Miguel Sousa Tavares: a amizade secreta entre um rapaz do campo e uma carpa que vive no rio.',
      '"O Bojador" — Sophia de Mello Breyner Andresen: os navegadores portugueses e o medo de passar o Cabo Bojador.',
      '"A Mata dos Medos" — Álvaro de Magalhães; "Versos de Cacaracá" — António Manuel Couto Viana (poesia); "Teatro às Três Pancadas" — António Torrado (pequenas peças de teatro).',
      'Ao ler uma obra, identifica: título, autor, ilustrador, personagens, espaço, tempo, a mensagem principal e o que mais gostaste.'
    ],
    q: [
      ['Quem escreveu "A Maior Flor do Mundo"?', ['José Saramago', 'Sophia de Mello Breyner Andresen', 'Oscar Wilde', 'António Torrado']],
      ['Quem escreveu "O Gigante Egoísta"?', ['Oscar Wilde', 'José Saramago', 'Miguel Sousa Tavares', 'Álvaro de Magalhães']],
      ['Em "O Segredo do Rio", o rapaz torna-se amigo de…', ['uma carpa', 'um gigante', 'um lobo', 'uma flor']],
      ['Em "O Gigante Egoísta", o que acontece no jardim enquanto o gigante não deixa entrar as crianças?', ['o inverno não acaba', 'nasce uma flor gigante', 'o rio seca', 'chega um navio']],
      ['Quem escreveu "O Bojador"?', ['Sophia de Mello Breyner Andresen', 'José Saramago', 'Couto Viana', 'Oscar Wilde']],
      ['"Teatro às Três Pancadas" tem textos para representar.', true],
      ['Em "A Maior Flor do Mundo", o menino salva a flor dando-lhe…', ['água', 'sol', 'terra nova', 'um vaso']]
    ]
  }
]);

TEMAS(4, 'em', [
  {
    id: 'em4_terra', t: 'Sismos, vulcões, rochas, lagos e lagoas',
    k: 'sismos,sismo,terramoto,vulcoes,vulcao,rochas,rocha,granito,calcario,marmore,basalto,xisto,lagos,lagoas,lagoa,sete cidades,obidos,lagoa de obidos',
    ae: 'Identificar sismos e vulcões e as suas consequências; reconhecer rochas de Portugal e as suas utilizações; localizar lagos e lagoas.',
    r: [
      'Um sismo (terramoto) é um tremor de terra. Em 1755, um grande sismo destruiu grande parte de Lisboa.',
      'Durante um sismo: baixar, proteger e aguardar — abrigar-se debaixo de uma mesa resistente, longe de janelas.',
      'Um vulcão é uma abertura por onde sai lava (rocha derretida), cinzas e gases. Nos Açores há vulcões; a ilha do Pico é um vulcão.',
      'Rochas de Portugal: granito (norte e centro, usado em construções e calçada), calcário (usado na calçada portuguesa e no cimento), mármore (Estremoz, para estátuas e bancadas), xisto (aldeias de xisto) e basalto (nos Açores, rocha escura).',
      'Um lago é uma porção de água rodeada de terra. Uma lagoa é mais pequena e pouco profunda, por vezes ligada ao mar (Lagoa de Óbidos).',
      'A Lagoa das Sete Cidades, nos Açores, fica dentro da cratera de um antigo vulcão e tem uma parte azul e outra verde.'
    ],
    q: [
      ['O que é um sismo?', ['um tremor de terra', 'uma erupção de lava', 'uma tempestade', 'uma cheia']],
      ['Em que ano um grande sismo destruiu grande parte de Lisboa?', ['1755', '1910', '1143', '1974']],
      ['Que rocha escura existe muito nos Açores?', ['basalto', 'mármore', 'calcário', 'granito']],
      ['O mármore de Estremoz é usado para…', ['estátuas e bancadas', 'fazer papel', 'combustível', 'vidro']],
      ['Durante um sismo deves abrigar-te debaixo de uma mesa resistente.', true],
      ['A Lagoa das Sete Cidades fica…', ['nos Açores', 'no Alentejo', 'na Madeira', 'no Minho']],
      ['O material que sai de um vulcão em erupção chama-se…', ['lava', 'areia', 'neve', 'argila']]
    ]
  },
  {
    id: 'em4_defesas', t: 'Defesas do corpo e crescimento',
    k: 'defesas do corpo,mecanismos de defesa,vacinas,vacina,microbios,doencas,higiene,crescimento,reproducao,sistema reprodutor,puberdade,modificacoes do corpo,primeiros socorros',
    ae: 'Reconhecer mecanismos de defesa do organismo, a importância das vacinas e da higiene, e as modificações do corpo ao longo do crescimento.',
    r: [
      'O corpo tem defesas contra micróbios: a pele (barreira), as lágrimas, a saliva, os pelos do nariz, a tosse e o espirro.',
      'Quando os micróbios entram, o sangue tem glóbulos brancos que os combatem.',
      'As vacinas ajudam o corpo a criar defesas contra doenças. Em Portugal há o Plano Nacional de Vacinação.',
      'Lavar as mãos, tapar a boca ao tossir e não partilhar copos ajuda a evitar doenças.',
      'O sistema reprodutor permite que os seres humanos tenham filhos. Os rapazes e as raparigas têm órgãos reprodutores diferentes.',
      'Na puberdade (por volta dos 10 aos 14 anos) o corpo muda: cresce mais depressa, a voz muda, aparecem pelos. É normal cada pessoa ter o seu ritmo.'
    ],
    q: [
      ['Qual destas é uma defesa natural do corpo?', ['a pele', 'o cabelo comprido', 'as unhas pintadas', 'os sapatos']],
      ['Para que servem as vacinas?', ['ajudar o corpo a defender-se de doenças', 'fazer crescer', 'tirar a fome', 'curar fraturas']],
      ['Que células do sangue combatem os micróbios?', ['glóbulos brancos', 'glóbulos vermelhos', 'plaquetas', 'neurónios']],
      ['Lavar as mãos ajuda a evitar doenças.', true],
      ['As mudanças do corpo na adolescência chamam-se…', ['puberdade', 'digestão', 'respiração', 'circulação']],
      ['Todas as crianças crescem exatamente ao mesmo ritmo.', false, 'Cada pessoa tem o seu ritmo de crescimento.']
    ]
  },
  {
    id: 'em4_direitos', t: 'Direitos Humanos, União Europeia e migrações',
    k: 'direitos humanos,declaracao universal dos direitos humanos,direitos da crianca,uniao europeia,europa,euro,migracoes,emigracao,imigracao,emigrantes,imigrantes,fluxos migratorios,populacao mundial',
    ae: 'Reconhecer a Declaração Universal dos Direitos Humanos e os direitos da criança; identificar a União Europeia; compreender os movimentos migratórios.',
    r: [
      'A Declaração Universal dos Direitos Humanos foi aprovada pela ONU em 1948: todas as pessoas nascem livres e iguais em dignidade e direitos.',
      'A Convenção sobre os Direitos da Criança (1989) protege, por exemplo, o direito à educação, à saúde, a brincar e a ser protegida.',
      'A União Europeia é uma organização de países europeus que cooperam entre si. Muitos usam a mesma moeda, o euro. Portugal aderiu em 1986.',
      'Emigrar é sair do seu país para ir viver para outro; imigrar é chegar a um país para lá viver.',
      'Muitos portugueses emigraram (por exemplo, para França, Suíça, Luxemburgo, Brasil). Portugal também recebe imigrantes de muitos países.',
      'As pessoas migram por trabalho, estudo, guerra, catástrofes ou para se juntarem à família.'
    ],
    q: [
      ['Em que ano foi aprovada a Declaração Universal dos Direitos Humanos?', ['1948', '1974', '1986', '1910']],
      ['Qual é a moeda usada em Portugal e em muitos países da União Europeia?', ['euro', 'dólar', 'libra', 'escudo']],
      ['Uma pessoa que sai de Portugal para ir viver para França é um…', ['emigrante', 'imigrante', 'turista', 'deputado']],
      ['Todas as crianças têm direito à educação.', true],
      ['Em que ano Portugal entrou na atual União Europeia?', ['1986', '1974', '2002', '1143']],
      ['Uma pessoa que vem de outro país viver para Portugal é, em Portugal, um…', ['imigrante', 'emigrante', 'navegador', 'refugiado sempre']]
    ]
  },
  {
    id: 'em4_tecnologia', t: 'Tecnologia, património e internet segura',
    k: 'tecnologia,objetos tecnologicos,evolucao tecnologica,passado e presente,patrimonio,patrimonio cultural,vestigios do passado,internet segura,seguranca na internet,tic,computador,telemovel',
    ae: 'Comparar objetos tecnológicos do passado e do presente; reconhecer o património cultural; usar as TIC de forma segura.',
    r: [
      'Os objetos tecnológicos foram evoluindo: do telefone fixo ao telemóvel, da máquina de escrever ao computador, da carta ao correio eletrónico.',
      'A tecnologia ajuda a reduzir os efeitos das catástrofes naturais (sismógrafos, alertas meteorológicos, construções mais seguras).',
      'Património cultural: monumentos, tradições, festas, gastronomia e vestígios do passado que devemos preservar (ex.: Torre de Belém, Mosteiro dos Jerónimos, o fado).',
      'Na internet: nunca partilhar dados pessoais (morada, escola, palavras-passe), não falar com desconhecidos e contar a um adulto se algo te deixar desconfortável.',
      'Palavras-passe seguras são secretas e misturam letras, números e símbolos.'
    ],
    q: [
      ['Qual destes objetos é mais antigo?', ['máquina de escrever', 'tablet', 'telemóvel com câmara', 'computador portátil']],
      ['Na internet, podes dar a tua morada a um desconhecido?', ['Não, nunca', 'Sim, se for simpático', 'Sim, se pedir com educação', 'Só ao fim de semana']],
      ['O Mosteiro dos Jerónimos é um exemplo de…', ['património cultural', 'objeto tecnológico', 'catástrofe natural', 'recurso energético']],
      ['Se algo na internet te deixar desconfortável, deves contar a um adulto.', true],
      ['Uma boa palavra-passe deve…', ['ser secreta e misturar letras, números e símbolos', 'ser o teu nome', 'ser 1234', 'ser partilhada com os amigos']]
    ]
  }
]);

TEMAS(4, 'ing', [
  {
    id: 'ing4_festivities', t: 'Festivities and celebrations',
    k: 'festivities,festividades,halloween,christmas,natal em ingles,easter,pascoa em ingles,birthday,carnival,valentines day,mothers day,fathers day,thanksgiving',
    ae: 'Identificar vocabulário de festividades e tradições de países de língua inglesa e de Portugal.',
    r: [
      'Halloween (31st October): pumpkin, witch, ghost, bat, "Trick or treat!".',
      'Christmas (25th December): Father Christmas / Santa Claus, Christmas tree, presents, reindeer, stocking. "Merry Christmas!"',
      'Easter: Easter egg, Easter bunny, chocolate. "Happy Easter!"',
      'Birthday: cake, candles, balloons, presents. "Happy birthday!"',
      'Thanksgiving (USA, November): families eat turkey and give thanks.',
      'Bonfire Night (UK, 5th November): fireworks and bonfires.'
    ],
    q: [
      ['When is Halloween?', ['31st October', '25th December', '1st January', '14th February']],
      ['"Pumpkin" significa…', ['abóbora', 'morcego', 'bruxa', 'fantasma']],
      ['What do children say on Halloween at the door?', ['Trick or treat!', 'Happy Easter!', 'Merry Christmas!', 'Good night!']],
      ['"Reindeer" significa…', ['rena', 'coelho', 'peru', 'cão']],
      ['What do people eat at Thanksgiving in the USA?', ['turkey', 'pizza', 'sushi', 'bacalhau']],
      ['"Merry Christmas!" is a Christmas greeting.', true]
    ]
  }
]);

// ================================================================ 7.º ANO — Português (O Mundo em Palavras 7)
TEMAS(7, 'pt', [
  {
    id: 'pt7_obras', t: 'Obras de Educação Literária',
    k: 'obras,livros,educacao literaria,o cavaleiro da dinamarca,cavaleiro da dinamarca,leandro rei da heliria,leandro,alice vieira,mestre finezas,manuel da fonseca,a volta ao mundo em 80 dias,julio verne,romeu e julieta,shakespeare,bojador,sophia',
    ae: 'Ler e interpretar obras do Plano de Educação Literária do 7.º ano (narrativa, poesia e texto dramático).',
    r: [
      '"O Cavaleiro da Dinamarca" — Sophia de Mello Breyner Andresen: um cavaleiro dinamarquês faz uma peregrinação à Terra Santa e, no regresso, passa por Itália e ouve histórias (Vanina, Giotto, Dante e Beatriz, Pêro Dias). Promete voltar a casa no Natal e consegue, guiado por uma luz.',
      '"Leandro, Rei da Helíria" — Alice Vieira (texto dramático): o rei Leandro divide o reino pelas filhas Hortênsia e Amarílis, que o lisonjeiam; expulsa Violeta, a mais nova, que diz gostar dele "como a comida gosta do sal". Mais tarde percebe que Violeta era a mais sincera.',
      '"Mestre Finezas" — Manuel da Fonseca: conto passado no Alentejo, com uma personagem marcante da vila.',
      '"A Volta ao Mundo em 80 Dias" — Júlio Verne: Phileas Fogg aposta que consegue dar a volta ao mundo em 80 dias, com o criado Passepartout.',
      '"Romeu e Julieta" — William Shakespeare: o amor de dois jovens de famílias inimigas (Montéquios e Capuletos) em Verona.',
      'Poesia estudada no 7.º ano inclui autores como Sophia de Mello Breyner, Eugénio de Andrade, Florbela Espanca, António Gedeão e Miguel Torga.'
    ],
    q: [
      ['Quem escreveu "O Cavaleiro da Dinamarca"?', ['Sophia de Mello Breyner Andresen', 'Alice Vieira', 'Manuel da Fonseca', 'José Saramago']],
      ['Quem escreveu "Leandro, Rei da Helíria"?', ['Alice Vieira', 'Sophia de Mello Breyner Andresen', 'William Shakespeare', 'Júlio Verne']],
      ['"Leandro, Rei da Helíria" é um texto…', ['dramático', 'narrativo', 'poético', 'expositivo']],
      ['Como diz Violeta que gosta do pai?', ['como a comida gosta do sal', 'como o sol gosta da lua', 'mais do que o ouro', 'como o mar gosta do rio']],
      ['Para onde vai em peregrinação o Cavaleiro da Dinamarca?', ['Terra Santa (Jerusalém)', 'Roma', 'Santiago de Compostela', 'Lisboa']],
      ['Quem é o protagonista de "A Volta ao Mundo em 80 Dias"?', ['Phileas Fogg', 'Romeu', 'Leandro', 'Passepartout']],
      ['Em "Romeu e Julieta", os jovens pertencem a famílias inimigas.', true],
      ['O Cavaleiro da Dinamarca prometeu voltar a casa…', ['no Natal', 'na Páscoa', 'no verão seguinte', 'ao fim de dez anos']]
    ]
  },
  {
    id: 'pt7_relativas', t: 'Orações relativas, completivas e pronome átono',
    k: 'oracoes relativas,oracao relativa,subordinadas adjetivas,relativas restritivas,relativas explicativas,completivas,subordinadas substantivas,condicionais,pronome atono,colocacao do pronome,mesoclise,variacao geografica,variedades do portugues',
    ae: 'Identificar orações subordinadas adjetivas relativas (restritivas e explicativas), substantivas completivas e adverbiais condicionais; colocar corretamente o pronome átono; reconhecer a variação geográfica do português.',
    r: [
      'Relativa restritiva: limita o nome, sem vírgulas (Os alunos que estudaram tiveram boa nota — só esses).',
      'Relativa explicativa: acrescenta informação, entre vírgulas (Os alunos, que estudaram, tiveram boa nota — todos estudaram).',
      'Completiva: completa o verbo e funciona como complemento direto (Disse que vinha → disse-o).',
      'Condicional: indica uma condição — se, caso, desde que (Se chover, fico em casa).',
      'Pronome átono: normalmente depois do verbo (Vi-o). Vem antes do verbo com palavras negativas, alguns advérbios, pronomes relativos e conjunções subordinativas (Não o vi; Já o vi; Disse que o viu).',
      'No futuro e no condicional, o pronome fica no meio do verbo (mesóclise): Dar-te-ei; Dir-lhe-ia.',
      'Variação geográfica: o português varia de região para região e de país para país (português europeu, do Brasil, de Angola, de Moçambique…). Ex.: autocarro (PT) / ônibus (BR).'
    ],
    q: [
      ['"O livro, que é muito antigo, está na estante." A oração destacada é…', ['relativa explicativa', 'relativa restritiva', 'completiva', 'condicional']],
      ['"Os bolos que a avó fez desapareceram." A oração "que a avó fez" é…', ['relativa restritiva', 'relativa explicativa', 'coordenada', 'completiva']],
      ['"O professor disse que havia teste." "que havia teste" é uma oração…', ['subordinada substantiva completiva', 'relativa', 'causal', 'final']],
      ['"Se estudares, passas." A oração "Se estudares" é…', ['subordinada adverbial condicional', 'causal', 'temporal', 'final']],
      ['Qual está correta?', ['Não o vi ontem.', 'Não vi-o ontem.', 'Não vi o ontem.', 'Não o-vi ontem.']],
      ['Qual é a forma correta do futuro com pronome?', ['Dar-te-ei um presente.', 'Darei-te um presente.', 'Te darei um presente.', 'Dar-ei-te um presente.']],
      ['"Autocarro" e "ônibus" mostram variação geográfica do português.', true]
    ]
  }
]);

// ================================================================ 7.º ANO — Francês (Ça Marche ! 7 — nível A1, 1.º ano de LE II)
TEMAS(7, 'fr', [
  {
    id: 'fr7_saluer', t: 'Saluer et se présenter',
    k: 'saluer,cumprimentar,apresentar,se presenter,bonjour,salut,au revoir,comment tu tappelles,je mappelle,ca va,tu e vous,alfabeto frances',
    ae: 'Cumprimentar, despedir-se, apresentar-se e apresentar alguém em francês.',
    r: [
      'Cumprimentar: Bonjour! (bom dia / olá formal), Salut! (olá, informal), Bonsoir! (boa noite, ao chegar). Despedir: Au revoir!, Salut!, À bientôt! (até breve), Bonne nuit! (ao deitar).',
      'Comment tu t\'appelles? — Je m\'appelle Ana. / Comment vous appelez-vous? (formal).',
      'Ça va? — Ça va bien, merci! / Comme ci, comme ça. / Ça ne va pas.',
      'Tu é informal (amigos, família); vous é formal ou plural.',
      'Où habites-tu? — J\'habite à Lisbonne, au Portugal. Tu as quel âge? — J\'ai douze ans.',
      'Expressões de cortesia: s\'il te plaît / s\'il vous plaît (por favor), merci (obrigado), de rien (de nada), pardon (desculpa).'
    ],
    q: [
      ['Como se diz "Como te chamas?" em francês?', ['Comment tu t\'appelles?', 'Quel âge as-tu?', 'Où habites-tu?', 'Ça va?']],
      ['"Au revoir" significa…', ['adeus', 'olá', 'obrigado', 'por favor']],
      ['"Merci" significa…', ['obrigado', 'desculpa', 'de nada', 'bom dia']],
      ['Para falar com um professor usa-se normalmente…', ['vous', 'tu', 'il', 'on']],
      ['Como respondes a "Ça va?" se estás bem?', ['Ça va bien, merci!', 'Je m\'appelle Ana.', 'J\'ai douze ans.', 'De rien.']],
      ['"J\'ai douze ans" significa "tenho doze anos".', true],
      ['"S\'il te plaît" significa…', ['por favor', 'obrigado', 'com licença', 'até logo']]
    ]
  },
  {
    id: 'fr7_nombres', t: 'Les nombres, les jours et les mois',
    k: 'nombres,numeros em frances,jours de la semaine,dias da semana em frances,mois,meses em frances,la date,data em frances,les couleurs,cores em frances',
    ae: 'Usar números, dias da semana, meses, datas e cores em francês.',
    r: [
      'Números: un, deux, trois, quatre, cinq, six, sept, huit, neuf, dix; onze, douze, treize, quatorze, quinze, seize; vingt (20), trente (30), quarante (40), cinquante (50), soixante (60).',
      'Dias (sem maiúscula!): lundi, mardi, mercredi, jeudi, vendredi, samedi, dimanche.',
      'Meses: janvier, février, mars, avril, mai, juin, juillet, août, septembre, octobre, novembre, décembre.',
      'A data: Aujourd\'hui, c\'est le 25 octobre. O dia 1 diz-se "le premier": le 1er mai.',
      'Cores: rouge, bleu, jaune, vert, blanc, noir, orange, rose, gris, marron, violet. Variam em género: vert / verte, blanc / blanche.'
    ],
    q: [
      ['Como se diz 15 em francês?', ['quinze', 'cinq', 'cinquante', 'douze']],
      ['"Mercredi" é…', ['quarta-feira', 'terça-feira', 'quinta-feira', 'sábado']],
      ['Qual é o mês de "août"?', ['agosto', 'abril', 'outubro', 'junho']],
      ['Como se diz "vermelho" em francês?', ['rouge', 'rose', 'jaune', 'noir']],
      ['Em francês, os dias da semana escrevem-se com letra minúscula.', true],
      ['"Soixante" é…', ['60', '70', '16', '6']],
      ['Como se diz o dia 1 de maio?', ['le premier mai', 'le un mai', 'le premier de mai sempre com maiúscula', 'le une mai']]
    ]
  },
  {
    id: 'fr7_famille', t: 'La famille, la description et les nationalités',
    k: 'famille,familia em frances,description,descricao,nationalites,nacionalidades,pays,paises em frances,adjectifs,feminino em frances,il est,elle est',
    ae: 'Apresentar a família, descrever pessoas (aspeto físico e carácter) e indicar nacionalidades.',
    r: [
      'Família: le père, la mère, les parents, le frère, la sœur, le grand-père, la grand-mère, l\'oncle, la tante, le cousin, la cousine.',
      'Possessivos: mon frère, ma sœur, mes parents; ton / ta / tes; son / sa / ses.',
      'Descrição: grand(e), petit(e), blond(e), brun(e), sympa, gentil(le), timide. Il a les yeux bleus et les cheveux courts.',
      'Feminino: geralmente acrescenta-se -e (petit → petite, portugais → portugaise). Adjetivos em -e não mudam (sympathique, timide).',
      'Nacionalidades: portugais(e), français(e), espagnol(e), anglais(e), brésilien(ne), italien(ne).',
      'Países: au Portugal, en France, en Espagne, au Brésil.'
    ],
    q: [
      ['"La sœur" significa…', ['a irmã', 'a mãe', 'a tia', 'a prima']],
      ['Qual é o feminino de "portugais"?', ['portugaise', 'portugaisse', 'portugaisé', 'portugais']],
      ['Completa: … mère est gentille. (minha)', ['Ma', 'Mon', 'Mes', 'Ta']],
      ['"Il a les cheveux courts" significa…', ['ele tem o cabelo curto', 'ele tem os olhos azuis', 'ele é alto', 'ele tem cabelo comprido']],
      ['Como se diz "em França"?', ['en France', 'au France', 'à France', 'dans France']],
      ['"L\'oncle" significa o tio.', true],
      ['Completa: J\'habite … Portugal.', ['au', 'en', 'à la', 'aux']]
    ]
  },
  {
    id: 'fr7_ecole', t: 'L\'école, les objets et les articles',
    k: 'ecole,escola em frances,objets scolaires,material escolar em frances,matieres,disciplinas em frances,articles,artigos em frances,il y a,un une des,le la les,emploi du temps,horario',
    ae: 'Identificar o material escolar, as disciplinas e o horário; usar artigos definidos e indefinidos e "il y a".',
    r: [
      'Material: le cahier (caderno), le livre, le stylo (caneta), le crayon (lápis), la gomme (borracha), la règle (régua), la trousse (estojo), le cartable (mochila), les ciseaux (tesoura).',
      'Disciplinas: le français, l\'anglais, les maths, l\'histoire, la géographie, les sciences, l\'éducation physique (EPS), la musique.',
      'Artigos definidos: le (masc.), la (fem.), l\' (antes de vogal ou h mudo), les (plural).',
      'Artigos indefinidos: un (masc.), une (fem.), des (plural).',
      'Il y a = há: Dans ma trousse, il y a un crayon et deux stylos.',
      'Horas: Il est huit heures. Il est dix heures et demie.'
    ],
    q: [
      ['"La gomme" significa…', ['a borracha', 'a cola', 'a régua', 'o lápis']],
      ['"Le cahier" significa…', ['o caderno', 'o livro', 'o estojo', 'a mochila']],
      ['Completa: … école (artigo definido)', ['l\'', 'le', 'la', 'un']],
      ['Qual é o artigo indefinido plural?', ['des', 'les', 'une', 'le']],
      ['"Il y a" significa…', ['há', 'ele tem', 'ele vai', 'aqui está']],
      ['"La trousse" é o estojo.', true],
      ['Como se diz "São oito horas"?', ['Il est huit heures.', 'Il a huit heures.', 'C\'est huit.', 'Il y a huit heures.']]
    ]
  },
  {
    id: 'fr7_verbes', t: 'Verbes être, avoir et verbes en -er',
    k: 'verbos em frances,verbes,etre,avoir,verbes en er,primeiro grupo,parler,aimer,habiter,negacao em frances,ne pas,present frances',
    ae: 'Conjugar no presente os verbos être, avoir e verbos regulares em -er; construir frases negativas e interrogativas.',
    r: [
      'Être (ser/estar): je suis, tu es, il/elle/on est, nous sommes, vous êtes, ils/elles sont.',
      'Avoir (ter): j\'ai, tu as, il/elle/on a, nous avons, vous avez, ils/elles ont.',
      'Verbos em -er (parler): je parle, tu parles, il parle, nous parlons, vous parlez, ils parlent. Também: aimer, habiter, jouer, regarder, écouter.',
      'Negação: ne … pas, à volta do verbo: Je ne parle pas allemand. Antes de vogal: Je n\'aime pas les épinards.',
      'Interrogação: Tu aimes le foot? / Est-ce que tu aimes le foot?',
      'Gostos: J\'aime / J\'adore / Je déteste + le/la/les (J\'aime le chocolat).'
    ],
    q: [
      ['Completa: Nous … portugais. (être)', ['sommes', 'êtes', 'sont', 'avons']],
      ['Completa: Elle … un chat. (avoir)', ['a', 'as', 'est', 'ont']],
      ['Completa: Vous … français? (parler)', ['parlez', 'parlons', 'parlent', 'parles']],
      ['Qual é a frase negativa correta?', ['Je ne joue pas au tennis.', 'Je ne pas joue au tennis.', 'Je joue ne pas au tennis.', 'Ne je joue pas au tennis.']],
      ['Completa: Ils … la télé. (regarder)', ['regardent', 'regardons', 'regardez', 'regarde']],
      ['"J\'ai" é a forma de "avoir" na 1.ª pessoa do singular.', true],
      ['Como se diz "Eu adoro chocolate"?', ['J\'adore le chocolat.', 'Je suis chocolat.', 'J\'ai le chocolat.', 'Je adore chocolat.']]
    ]
  }
]);

// ================================================================ 7.º ANO — TIC (TecnIC 7)
TEMAS(7, 'tic', [
  {
    id: 'tic7_seguranca', t: 'Segurança e cidadania digital',
    k: 'seguranca digital,seguranca na internet,cidadania digital,privacidade,dados pessoais,palavra-passe,passwords,ciberbullying,fake news,noticias falsas,pegada digital,phishing,virus,redes sociais',
    ae: 'Adotar comportamentos seguros e responsáveis em ambientes digitais: proteção de dados e privacidade, palavras-passe, ciberbullying, veracidade da informação.',
    r: [
      'Dados pessoais (nome completo, morada, escola, telefone, fotografias) não devem ser partilhados com desconhecidos.',
      'Palavra-passe forte: longa (pelo menos 12 caracteres), com maiúsculas, minúsculas, números e símbolos, diferente em cada conta e nunca partilhada.',
      'Pegada digital: tudo o que publicamos fica registado e pode ser visto por outros durante muito tempo.',
      'Ciberbullying: ofender, ameaçar ou humilhar alguém através da internet. Não responder, guardar provas, bloquear e contar a um adulto. Linha Internet Segura: 800 21 90 90.',
      'Phishing: mensagens falsas que tentam roubar dados (ex.: "ganhaste um prémio, clica aqui"). Nunca clicar em ligações suspeitas.',
      'Notícias falsas: verificar a fonte, a data, o autor e confirmar noutros sites fiáveis antes de partilhar.',
      'Antivírus e atualizações protegem o computador contra vírus e outro software malicioso (malware).'
    ],
    q: [
      ['Qual é a palavra-passe mais segura?', ['M@r3s_Az0re$2026', '123456', 'ana2014', 'password']],
      ['O que é phishing?', ['mensagens falsas para roubar dados', 'um jogo online', 'um tipo de antivírus', 'uma rede social']],
      ['O que deves fazer se fores vítima de ciberbullying?', ['guardar provas, bloquear e contar a um adulto', 'responder com insultos', 'apagar tudo e não dizer nada', 'partilhar com toda a gente']],
      ['A pegada digital é…', ['o registo do que fazemos e publicamos na internet', 'um vírus', 'um tipo de rato', 'uma impressora']],
      ['Antes de partilhar uma notícia, deves verificar a fonte.', true],
      ['Deves usar a mesma palavra-passe em todas as contas.', false, 'Cada conta deve ter uma palavra-passe diferente.']
    ]
  },
  {
    id: 'tic7_pesquisa', t: 'Pesquisa de informação e direitos de autor',
    k: 'pesquisa,pesquisar,motor de pesquisa,palavras-chave,fontes,fontes fiaveis,direitos de autor,plagio,creative commons,citar,referencias,marcadores,pastas e ficheiros',
    ae: 'Pesquisar, selecionar e organizar informação de forma crítica, respeitando os direitos de autor.',
    r: [
      'Usar palavras-chave curtas e específicas. Aspas procuram a expressão exata ("Cavaleiro da Dinamarca").',
      'Avaliar a fiabilidade: quem é o autor? o site é conhecido (.gov.pt, .edu.pt, enciclopédias, jornais)? a informação é recente? confirma-se noutras fontes?',
      'Direitos de autor: textos, imagens, músicas e vídeos pertencem a quem os criou. Copiar sem indicar o autor é plágio.',
      'Licenças Creative Commons permitem usar certas obras se se respeitarem as condições (ex.: indicar o autor).',
      'Para citar, indica o autor, o título, o site e a data de consulta.',
      'Organizar a informação: criar pastas com nomes claros, guardar marcadores (favoritos) no navegador.'
    ],
    q: [
      ['Para procurar a expressão exata num motor de pesquisa usa-se…', ['aspas', 'parênteses', 'asteriscos sempre', 'pontos de interrogação']],
      ['Copiar um trabalho da internet e apresentá-lo como teu chama-se…', ['plágio', 'citação', 'pesquisa', 'resumo']],
      ['Qual destas fontes tende a ser mais fiável?', ['um site oficial (.gov.pt)', 'um comentário anónimo', 'uma mensagem reencaminhada', 'um vídeo sem autor']],
      ['As licenças Creative Commons permitem usar obras respeitando certas condições.', true],
      ['Ao citar uma página web deves indicar…', ['autor, título, site e data de consulta', 'só a cor do site', 'apenas a primeira frase', 'nada']]
    ]
  },
  {
    id: 'tic7_multimedia', t: 'Imagem, vídeo, som, 3D e apresentações',
    k: 'edicao de imagem,imagem digital,pixel,resolucao,formatos,jpg,png,camadas,edicao de video,video,som,audio,mp3,mp4,linha de tempo,modelacao 3d,3d,apresentacoes,apresentacao multimedia,diapositivos,transicoes,animacoes',
    ae: 'Criar e editar produtos multimédia (imagem, vídeo, som, modelos 3D e apresentações), escolhendo os formatos adequados.',
    r: [
      'Uma imagem digital é formada por pixéis. Quanto mais pixéis (resolução), mais pormenor e maior o ficheiro.',
      'Formatos de imagem: JPG (fotografias, comprime), PNG (permite fundo transparente), GIF (pequenas animações).',
      'Na edição de imagem, as camadas permitem trabalhar cada elemento separadamente.',
      'Vídeo e som: os elementos organizam-se numa linha de tempo; formatos comuns MP4 (vídeo) e MP3 (áudio).',
      'Modelação 3D: criar objetos com três dimensões (comprimento, largura e altura), juntando e manipulando formas básicas; pode exportar-se para impressão 3D (ex.: formato STL).',
      'Apresentações: pouco texto por diapositivo, letra legível, imagens de qualidade, transições e animações com moderação.'
    ],
    q: [
      ['Que formato de imagem permite fundo transparente?', ['PNG', 'JPG', 'MP3', 'DOCX']],
      ['Os pequenos pontos que formam uma imagem digital chamam-se…', ['pixéis', 'camadas', 'diapositivos', 'bytes de som']],
      ['Qual é um formato de vídeo?', ['MP4', 'MP3', 'PNG', 'TXT']],
      ['Na edição de vídeo, os clips organizam-se na…', ['linha de tempo', 'barra de tarefas', 'folha de cálculo', 'camada de fundo']],
      ['Num bom diapositivo deve haver muito texto e letras pequenas.', false, 'Deve ter pouco texto e letra legível.'],
      ['Um modelo 3D tem comprimento, largura e altura.', true]
    ]
  },
  {
    id: 'tic7_computador', t: 'Computador, sistema operativo e ficheiros',
    k: 'computador,hardware,software,sistema operativo,windows,android,perifericos,entrada,saida,memoria,ram,disco,ficheiros,pastas,extensoes,bit,byte,kilobyte,megabyte,gigabyte,instalar aplicacoes,nuvem',
    ae: 'Identificar componentes do computador e funções do sistema operativo; gerir ficheiros e pastas; instalar e desinstalar aplicações.',
    r: [
      'Hardware: a parte física (ecrã, teclado, processador). Software: os programas (sistema operativo, aplicações).',
      'Periféricos de entrada (teclado, rato, microfone, câmara), de saída (monitor, colunas, impressora) e de entrada/saída (ecrã tátil, pen USB).',
      'O sistema operativo (Windows, macOS, Linux, Android, iOS) gere o computador e permite usar as aplicações.',
      'Ficheiros guardam-se em pastas. A extensão indica o tipo: .docx (texto), .xlsx (folha de cálculo), .pptx (apresentação), .jpg (imagem), .mp3 (som).',
      'Unidades: 1 byte = 8 bits; 1 KB ≈ 1000 bytes; 1 MB ≈ 1000 KB; 1 GB ≈ 1000 MB; 1 TB ≈ 1000 GB.',
      'A "nuvem" guarda ficheiros em servidores na internet, acessíveis de vários dispositivos.'
    ],
    q: [
      ['Qual destes é um periférico de saída?', ['impressora', 'teclado', 'rato', 'microfone']],
      ['O Windows e o Android são…', ['sistemas operativos', 'periféricos', 'antivírus', 'redes sociais']],
      ['Quantos bits tem 1 byte?', ['8', '10', '100', '1000']],
      ['Que extensão tem normalmente uma apresentação?', ['.pptx', '.mp3', '.jpg', '.xlsx']],
      ['O teclado é hardware.', true],
      ['Qual é a maior unidade?', ['gigabyte', 'megabyte', 'kilobyte', 'byte']]
    ]
  }
]);

// ================================================================ 7.º ANO — Educação Visual (Novo Visual 7/8/9)
TEMAS(7, 'ev', [
  {
    id: 'ev7_cor', t: 'A cor',
    k: 'cor,cores,circulo cromatico,cores primarias,cores secundarias,cores complementares,cores quentes,cores frias,cor luz,cor pigmento,rgb,cmyk,luz,contraste',
    ae: 'Compreender a cor-luz e a cor-pigmento, o círculo cromático e os contrastes de cor, aplicando-os em composições.',
    r: [
      'Cor-pigmento (tintas, impressão): primárias ciano, magenta e amarelo (CMY); a mistura de todas tende para o preto — síntese subtrativa. Na escola usa-se também azul, vermelho e amarelo.',
      'Cor-luz (ecrãs): primárias vermelho, verde e azul (RGB); juntas dão o branco — síntese aditiva.',
      'Cores secundárias resultam da mistura de duas primárias (ex.: amarelo + azul = verde).',
      'Cores complementares ficam opostas no círculo cromático e criam o contraste mais forte (ex.: vermelho e verde; azul e laranja; amarelo e violeta).',
      'Cores quentes (vermelhos, laranjas, amarelos) transmitem energia e parecem aproximar-se; cores frias (azuis, verdes, violetas) transmitem calma e parecem afastar-se.',
      'Juntar branco a uma cor clareia-a; juntar preto escurece-a (gradações de valor/tom).'
    ],
    q: [
      ['Quais são as cores primárias da cor-luz (ecrãs)?', ['vermelho, verde e azul', 'ciano, magenta e amarelo', 'preto, branco e cinzento', 'laranja, verde e violeta']],
      ['Amarelo + azul (pigmentos) dá…', ['verde', 'laranja', 'violeta', 'castanho']],
      ['Qual é a cor complementar do azul?', ['laranja', 'verde', 'violeta', 'amarelo']],
      ['O vermelho é uma cor…', ['quente', 'fria', 'neutra', 'secundária']],
      ['Na cor-luz, juntar as três primárias dá branco.', true],
      ['Cores opostas no círculo cromático chamam-se…', ['complementares', 'análogas', 'primárias', 'neutras']]
    ]
  },
  {
    id: 'ev7_comunicacao', t: 'Elementos da comunicação visual',
    k: 'comunicacao visual,elementos visuais,ponto,linha,plano,textura,forma,composicao,simetria,ritmo,escala,sinaletica,logotipo,design,perspetiva,desenho',
    ae: 'Identificar e aplicar os elementos estruturais da linguagem visual (ponto, linha, plano, forma, textura, cor) e princípios de composição na comunicação visual.',
    r: [
      'Elementos visuais: ponto, linha (reta, curva, quebrada, mista), plano/forma, textura (visual ou tátil), cor e volume.',
      'Composição: organização dos elementos no espaço — equilíbrio, simetria, ritmo (repetição), contraste e ponto de interesse.',
      'Comunicação visual: emissor, mensagem, código, canal e recetor.',
      'Sinalética e pictogramas comunicam rapidamente com imagens simples (ex.: sinais de trânsito, casa de banho, saída de emergência).',
      'Um logótipo é a imagem gráfica que identifica uma marca ou instituição; deve ser simples, memorável e legível em vários tamanhos.',
      'Perspetiva: técnica para representar profundidade num plano; as linhas paralelas parecem convergir num ponto de fuga.'
    ],
    q: [
      ['Qual destes é um elemento visual?', ['a textura', 'o volume do som', 'o cheiro', 'a temperatura']],
      ['Os sinais de trânsito são exemplos de…', ['sinalética', 'perspetiva', 'textura', 'logótipos']],
      ['Na perspetiva, as linhas paralelas parecem convergir num…', ['ponto de fuga', 'eixo de simetria', 'pictograma', 'logótipo']],
      ['A repetição organizada de elementos numa composição cria…', ['ritmo', 'perspetiva', 'cor-luz', 'sombra própria']],
      ['Um bom logótipo deve ser simples e fácil de reconhecer.', true],
      ['Quem recebe a mensagem na comunicação visual é o…', ['recetor', 'emissor', 'código', 'canal']]
    ]
  }
]);
