/* Mais perguntas de prática para o 7.º ano, escritas a partir dos resumos já cuidados de cada
   tema (alinhados com as Aprendizagens Essenciais da DGE) — reforçam os temas com menos
   perguntas de Português, Matemática, Ciências Naturais, Físico-Química, História, Geografia,
   Inglês, Francês, TIC e Educação Visual, sem repetir as já existentes. */
(function () {
  'use strict';
  const MAIS = {
    cn7_ev_sustentabilidade: [
      ['A água subterrânea e as águas termais são recursos geológicos do tipo…', ['hidrogeológico', 'energético', 'mineral metálico', 'biológico']],
      ['Qual destas é uma rocha usada como recurso geológico?', ['mármore', 'volfrâmio', 'petróleo', 'carvão']],
      ['O conhecimento geológico ajuda a prever riscos como sismos e deslizamentos.', true]
    ],
    geo7_ev_paisagem: [
      ['Uma das perguntas a que a Geografia procura responder é…', ['Onde?', 'Quanto custa?', 'De quem é?', 'Quando nasceu?']],
      ['As paisagens podem mudar ao longo do tempo por causas naturais e humanas.', true],
      ['O relevo, os rios e a vegetação são elementos… da paisagem.', ['naturais', 'humanos', 'urbanos', 'económicos']]
    ],
    tic7_pesquisa: [
      ['Para pesquisar melhor na internet deves usar…', ['palavras-chave curtas e específicas', 'frases muito longas', 'só emojis', 'apenas números']],
      ['Guardar as páginas mais importantes no navegador para as encontrar depois chama-se…', ['marcadores (favoritos)', 'plágio', 'licença', 'citação']],
      ['Um site com domínio .gov.pt costuma ser mais fiável do que um comentário anónimo.', true]
    ],
    pt7_drama: [
      ['Uma conversa entre duas ou mais personagens chama-se…', ['diálogo', 'monólogo', 'aparte', 'didascália']],
      ['As grandes partes em que se divide uma peça de teatro chamam-se…', ['atos', 'cenas', 'versos', 'estrofes']],
      ['O texto dramático destina-se a ser representado em palco.', true]
    ],
    pt7_textos: [
      ['Um texto que explica um tema de forma clara e objetiva é um texto…', ['expositivo', 'poético', 'dramático', 'publicitário']],
      ['Numa carta formal, o destinatário costuma ser tratado por…', ['"Exmo. Senhor"', '"Olá amigo"', '"Querido"', 'sem nenhum tratamento']],
      ['O lead de uma notícia costuma responder a…', ['o quê, quem, quando, onde, como e porquê', 'só ao título', 'apenas à opinião do autor', 'só à data']]
    ],
    pt7_ev_textos: [
      ['Numa crítica, o autor costuma apontar…', ['pontos fortes e fracos da obra', 'só elogios', 'só defeitos', 'apenas o preço do bilhete']],
      ['O conector "no entanto" serve sobretudo para…', ['introduzir uma ideia que contrasta', 'dar um exemplo', 'indicar o tempo', 'concluir']],
      ['Um artigo de opinião costuma terminar com uma…', ['conclusão', 'didascália', 'legenda', 'rubrica']]
    ],
    mat7_semelhanca: [
      ['Dois triângulos com os três lados proporcionais são semelhantes pelo critério…', ['LLL', 'AA', 'LAL', 'LLA']],
      ['Todos os círculos são semelhantes entre si.', true],
      ['Se dois lados são proporcionais e o ângulo entre eles é igual, o critério chama-se…', ['LAL', 'AA', 'LLL', 'LLA']]
    ],
    mat7_areas: [
      ['Área de um paralelogramo com base 7 cm e altura 3 cm?', ['21 cm²', '10 cm²', '14 cm²', '24 cm²']],
      ['Um círculo tem diâmetro 10 cm. Qual é o seu raio?', ['5 cm', '10 cm', '20 cm', '2,5 cm']],
      ['O valor de π é aproximadamente…', ['3,14', '2,14', '4,14', '1,41']]
    ],
    mat7_ev_angulos: [
      ['Quanto mede a soma dos ângulos internos de um quadrilátero?', ['360°', '180°', '540°', '720°']],
      ['Quanto mede cada ângulo interno de um triângulo equilátero?', ['60°', '90°', '180°', '120°']],
      ['Quanto mede a soma dos ângulos internos de um octógono (8 lados)?', ['1080°', '720°', '900°', '540°']]
    ],
    mat7_ev_triangulos: [
      ['Uma homotetia com centro O amplia ou reduz uma figura.', true],
      ['Nas figuras homotéticas, os lados correspondentes ficam…', ['paralelos', 'perpendiculares', 'iguais sempre', 'sem relação']],
      ['Se a razão de semelhança é 1/2, a área da nova figura fica…', ['1/4 da área original', 'a metade', 'o dobro', 'igual']]
    ],
    cn7_ev_falhas: [
      ['O "teto" e o "muro" são elementos de uma…', ['falha', 'dobra', 'cratera', 'nuvem ardente']],
      ['Numa falha, o deslocamento dos blocos é na horizontal numa falha de…', ['desligamento', 'falha normal', 'falha inversa', 'dobra sinclinal']],
      ['As forças de cisalhamento fazem os blocos deslizar lado a lado.', true]
    ],
    cn7_ev_riscos: [
      ['O ponto no interior da Terra onde se liberta a energia de um sismo chama-se…', ['hipocentro (foco)', 'epicentro', 'cratera', 'magnitude']],
      ['Ter um kit de emergência e um plano de emergência são medidas de…', ['prevenção', 'escoada de lava', 'erupção', 'rejeito']],
      ['As águas termais podem resultar da atividade vulcânica.', true]
    ],
    fq7_ev_laboratorio: [
      ['O balão de Erlenmeyer é usado sobretudo para…', ['conter e misturar líquidos', 'pesar sólidos', 'medir a temperatura', 'cortar vidro']],
      ['O pictograma com uma chama indica uma substância…', ['inflamável', 'tóxica', 'corrosiva', 'inofensiva']],
      ['Depois de preparar uma solução no balão volumétrico, deves…', ['agitar e rotular', 'cheirar diretamente', 'deixar destapado', 'guardar sem identificar']]
    ],
    hist7_cristianismo: [
      ['S. Paulo foi um dos apóstolos que ajudou a…', ['expandir o Cristianismo', 'fundar Roma', 'escrever o Código de Hamurabi', 'conquistar a Grécia']],
      ['O Cristianismo defende a igualdade de todos perante Deus.', true],
      ['As estradas romanas e o uso do latim e do grego ajudaram a…', ['expandir o Cristianismo pelo Império', 'isolar a Palestina', 'destruir Roma', 'acabar com o latim']]
    ],
    hist7_portugal: [
      ['D. Teresa era…', ['mãe de D. Afonso Henriques', 'filha de D. Afonso Henriques', 'rainha de Castela', 'irmã do Papa']],
      ['Depois da Batalha de Ourique (1139), D. Afonso Henriques…', ['passou a intitular-se rei', 'perdeu o Condado Portucalense', 'rendeu-se a Leão e Castela', 'tornou-se Papa']],
      ['A conquista de Lisboa em 1147 fez parte da…', ['expansão do território para sul', 'perda de território para o Norte', 'fundação do Condado Portucalense', 'Batalha de São Mamede']]
    ],
    hist7_legado: [
      ['O Pártenon é um exemplo de arquitetura…', ['grega', 'romana', 'egípcia', 'medieval']],
      ['Pitágoras e Euclides são conhecidos pelos seus contributos para a…', ['matemática', 'medicina', 'democracia', 'arquitetura românica']],
      ['As estradas, pontes e aquedutos são heranças da engenharia…', ['romana', 'grega', 'egípcia', 'sumério']]
    ],
    hist7_ev_contributos: [
      ['Os egípcios criaram um calendário solar com…', ['365 dias', '60 dias', '100 dias', '12 dias']],
      ['A Bíblia hebraica é também conhecida como…', ['Antigo Testamento', 'Novo Testamento', 'Código de Hamurabi', 'Alcorão']],
      ['Os fenícios fundaram a colónia de…', ['Cartago', 'Roma', 'Atenas', 'Babilónia']]
    ],
    hist7_ev_igreja: [
      ['Quem organizou a Igreja em dioceses geridas por bispos?', ['a Igreja Católica', 'os vikings', 'os romanos pagãos', 'os muçulmanos']],
      ['As invasões dos séculos VIII a X contribuíram para o surgimento do…', ['feudalismo', 'império romano', 'cristianismo', 'alfabeto fenício']],
      ['Carlos Magno, coroado imperador em 800, era rei dos…', ['francos', 'visigodos', 'suevos', 'vikings']]
    ],
    hist7_ev_feudal: [
      ['O domínio de um senhor, dividido em reserva e mansos, chamava-se…', ['senhorio', 'concelho', 'foral', 'burgo']],
      ['O trabalho gratuito que os servos faziam nas terras do senhor chamava-se…', ['corveia', 'banalidade', 'homenagem', 'dízima']],
      ['Nobreza e clero eram ordens…', ['privilegiadas', 'populares', 'escravizadas', 'estrangeiras']]
    ],
    hist7_ev_cidades: [
      ['As feiras de Champagne eram importantes para o…', ['comércio medieval', 'ensino universitário', 'culto religioso', 'treino militar']],
      ['As inquirições e confirmações eram usadas pelos reis para…', ['controlar a nobreza e o clero', 'organizar as cruzadas', 'fundar mosteiros', 'criar a democracia']],
      ['A charrua e a rotação trienal são exemplos de…', ['novas técnicas agrícolas', 'armas medievais', 'instrumentos musicais', 'edifícios religiosos']]
    ],
    hist7_ev_cultura: [
      ['As cantigas de amor, de amigo e de escárnio e maldizer eram compostas pelos…', ['trovadores', 'monges copistas', 'mesteirais', 'cavaleiros templários']],
      ['D. Dinis foi, além de rei, também…', ['trovador', 'bispo', 'cruzado', 'arquiteto gótico']],
      ['Franciscanos e dominicanos, que viviam na pobreza e pregavam nas cidades, pertenciam às ordens…', ['mendicantes', 'militares', 'comerciais', 'nobres']]
    ],
    geo7_litoral: [
      ['A destruição de dunas é uma ameaça à proteção do litoral.', true],
      ['Uma restinga é uma…', ['faixa de areia formada por acumulação', 'escarpa a pique sobre o mar', 'zona de água doce', 'cidade costeira']],
      ['Um esporão é uma construção usada para…', ['proteger a costa da erosão', 'aumentar as ondas', 'poluir a água', 'destruir praias']]
    ],
    geo7_mundo: [
      ['Em que continente se encontra o deserto do Saara?', ['África', 'Ásia', 'América', 'Oceânia']],
      ['O Canal do Suez separa…', ['a África da Ásia', 'a Europa da América', 'a Ásia da América', 'a Oceânia da Antártida']],
      ['Os arquipélagos dos Açores e da Madeira pertencem a…', ['Portugal', 'Espanha', 'França', 'Marrocos']]
    ],
    geo7_ev_portugal: [
      ['Em que ano Portugal adotou o euro?', ['2002', '1986', '1974', '2010']],
      ['Quantos Estados-membros tem a União Europeia, segundo o texto?', ['27', '15', '50', '12']],
      ['A esteva e o alecrim são exemplos de…', ['matos mediterrânicos', 'florestas caducifólias', 'floresta Laurissilva', 'montado de sobreiros']]
    ],
    geo7_ev_topografia: [
      ['A equidistância é a diferença de altitude entre…', ['duas curvas de nível seguidas', 'dois meridianos', 'dois paralelos', 'duas cidades vizinhas']],
      ['A meteorização é a…', ['desagregação das rochas', 'deposição de sedimentos', 'formação de nuvens', 'medição da temperatura']],
      ['A geada e o orvalho formam-se…', ['junto ao solo', 'nas nuvens altas', 'no mar', 'no interior da Terra']]
    ],
    ing7_ev_pastcont: [
      ['"She … dinner at 8 p.m. yesterday." (jantar, em curso)', ['was having', 'is having', 'had', 'has']],
      ['Negative: "They … watching TV when I called."', ["weren't", "wasn't", "didn't", "don't"]],
      ['"While I was cooking, my brother was studying." shows…', ['two actions happening at the same time', 'one action before another', 'a future plan', 'a repeated habit']]
    ],
    ing7_ev_city: [
      ['"Entre" in English is…', ['between', 'opposite', 'behind', 'next to']],
      ['Where do you post a letter?', ['at the post office', 'at the chemist\'s', 'at the town hall', 'at the library']],
      ['"Would you mind…?" is used to…', ['make a polite request', 'give an order', 'say goodbye', 'complain']]
    ],
    fr7_loisirs: [
      ['Como se diz "Não gosto de desporto"?', ["Je n'aime pas le sport.", "J'adore le sport.", 'Je joue au sport.', 'Je fais le sport.']],
      ['"Faire du judo" significa…', ['praticar judo', 'jogar futebol', 'andar de bicicleta', 'nadar']],
      ['"L\'oiseau" significa…', ['o pássaro', 'o peixe', 'o cão', 'o coelho']]
    ],
    fr7_ev_alimentation: [
      ['"J\'ai faim" significa…', ['Tenho fome.', 'Tenho sede.', 'Tenho frio.', 'Tenho sono.']],
      ['Je mange … légumes. (quantidade indefinida, plural)', ['des', 'du', 'de la', "de l'"]],
      ['"Le dîner" é a refeição…', ['da noite (jantar)', 'da manhã', 'da tarde (lanche)', 'do meio-dia']]
    ],
    fr7_ev_ville: [
      ['"L\'hôpital" é o…', ['hospital', 'museu', 'parque', 'supermercado']],
      ['Je voyage … train.', ['en', 'à', 'au', 'sur']],
      ['"Tournez à droite" significa…', ['Vire à direita.', 'Vire à esquerda.', 'Siga em frente.', 'Pare aqui.']]
    ],
    fr7_ev_quotidien: [
      ['Tu … à 7 heures. (levantar-se)', ['te lèves', 'me lève', 'se lève', 'nous levons']],
      ['"Il est minuit" significa…', ['meia-noite', 'meio-dia', 'uma hora', 'oito horas']],
      ['Vous … les dents. (lavar)', ['vous brossez', 'te brosses', 'se brossent', 'me brosse']]
    ],
    tic7_seguranca: [
      ['Qual é o número da Linha Internet Segura?', ['800 21 90 90', '112', '808 24 24 24', '117']],
      ['Atualizar o antivírus e o sistema ajuda a proteger contra…', ['malware (software malicioso)', 'cortes de luz', 'ciberbullying apenas', 'spam apenas']],
      ['Uma palavra-passe forte deve ter, pelo menos, quantos caracteres?', ['12', '4', '6', '20 letras iguais']]
    ],
    tic7_multimedia: [
      ['O formato GIF é usado sobretudo para…', ['pequenas animações', 'documentos de texto', 'folhas de cálculo', 'modelos 3D']],
      ['Qual destes é um formato de áudio comum?', ['MP3', 'PNG', 'GIF', 'PPTX']],
      ['Numa modelação 3D, que formato se usa frequentemente para impressão 3D?', ['STL', 'MP4', 'DOCX', 'JPG']]
    ],
    tic7_computador: [
      ['Uma pen USB é um periférico de…', ['entrada/saída', 'só entrada', 'só saída', 'nenhum dos dois']],
      ['Quantos megabytes (MB) tem aproximadamente 1 gigabyte (GB)?', ['1000', '100', '8', '1 000 000']],
      ['Guardar ficheiros "na nuvem" significa guardá-los…', ['em servidores na internet', 'só no disco do computador', 'numa pen USB', 'na impressora']]
    ],
    ev7_cor: [
      ['Juntar branco a uma cor torna-a mais…', ['clara', 'escura', 'quente', 'fria']],
      ['A síntese subtrativa ocorre sobretudo nas…', ['tintas (cor-pigmento)', 'telas e ecrãs', 'lâmpadas de LED', 'estrelas']],
      ['As cores frias transmitem geralmente uma sensação de…', ['calma', 'energia', 'perigo', 'calor']]
    ],
    ev7_comunicacao: [
      ['O emissor, na comunicação visual, é quem…', ['envia a mensagem', 'recebe a mensagem', 'desenha o logótipo', 'escolhe as cores']],
      ['A textura de um elemento visual pode ser…', ['visual ou tátil', 'só sonora', 'só digital', 'só tridimensional']],
      ['Um bom logótipo deve ser…', ['simples, memorável e legível em vários tamanhos', 'muito detalhado e colorido', 'ilegível de propósito', 'apenas texto sem imagem']]
    ]
  };
  Object.keys(MAIS).forEach((id) => {
    const t = CUR.temas[id];
    if (t) MAIS[id].forEach((q) => t.q.push(q));
  });
})();
