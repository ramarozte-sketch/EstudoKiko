/* 1.º ano — 1.º ciclo do ensino básico (Aprendizagens Essenciais da DGE) */

// ============================================================= PORTUGUÊS
TEMAS(1, 'pt', [
  {
    id: 'pt1_alfabeto', t: 'O alfabeto e os sons das letras',
    k: 'alfabeto,letras,vogais,consoantes,maiuscula,minuscula,digrafo,digrafos,lh,nh,ch,rr,ss,qu,gu',
    ae: 'Identificar as letras do alfabeto, maiúsculas e minúsculas, pela ordem convencional, e associar letras e dígrafos aos sons que representam.',
    r: [
      'O alfabeto português tem 26 letras: a b c d e f g h i j k l m n o p q r s t u v w x y z.',
      'Vogais: a, e, i, o, u. As restantes letras são consoantes.',
      'Letra maiúscula usa-se no início de frase e em nomes próprios (Ana); letra minúscula no resto da palavra.',
      'Dígrafos: duas letras para um só som — lh (folha), nh (ninho), ch (chuva), rr (carro), ss (massa), qu (quero), gu (guitarra).',
      'Cada letra ou dígrafo representa um som (fonema).'
    ],
    q: [
      ['Quantas letras tem o alfabeto português?', ['26', '24', '20', '30']],
      ['Qual destas é uma vogal?', ['a', 'b', 'c', 'd']],
      ['Em "Ana", a primeira letra é maiúscula porque é…', ['um nome próprio', 'uma vogal', 'uma consoante', 'um dígrafo']],
      ['Que dígrafo aparece em "chuva"?', ['ch', 'nh', 'lh', 'rr']],
      ['Qual destas palavras tem o dígrafo "nh"?', ['ninho', 'carro', 'massa', 'quero']],
      ['As letras b, c, d e f são consoantes.', true]
    ]
  },
  {
    id: 'pt1_silabas', t: 'Sílabas e rimas',
    k: 'silabas,silaba,rima,rimas,trava-linguas,consciencia fonologica,dividir palavras',
    ae: 'Dividir palavras em sílabas e reconhecer rimas e outras repetições sonoras em poemas e trava-línguas.',
    r: [
      'As palavras dividem-se em sílabas: bo-la, ja-ne-la.',
      'Rima é quando duas palavras terminam com o mesmo som: gato / sapato.',
      'Trava-línguas e poemas usam sons parecidos para serem divertidos de dizer.',
      'Contar as sílabas ajuda a perceber o tamanho das palavras: "pé" tem 1 sílaba; "sapato" tem 3.'
    ],
    q: [
      ['Quantas sílabas tem a palavra "bola"?', ['duas', 'uma', 'três', 'quatro']],
      ['Qual destas palavras rima com "gato"?', ['sapato', 'mesa', 'flor', 'livro']],
      ['"Pé" tem quantas sílabas?', ['uma', 'duas', 'três', 'nenhuma']],
      ['Os trava-línguas usam sons parecidos.', true],
      ['Quantas sílabas tem "janela"?', ['três', 'duas', 'uma', 'quatro']],
      ['Qual destas palavras rima com "flor"?', ['calor', 'gato', 'mesa', 'livro']]
    ]
  },
  {
    id: 'pt1_frase', t: 'Frases e pontuação',
    k: 'frase,frases,ponto final,ponto de interrogacao,ponto de exclamacao,pergunta,afirmacao,ordem,pedido',
    ae: 'Reconhecer frases com diferentes intenções (perguntar, afirmar, exclamar, pedir) e usar os sinais de pontuação básicos.',
    r: [
      'Uma frase que conta algo termina com ponto final: "O cão corre."',
      'Uma frase que pergunta termina com ponto de interrogação: "Queres brincar?"',
      'Uma frase que mostra uma emoção forte termina com ponto de exclamação: "Que alegria!"',
      'Um pedido ou uma ordem também pode ser uma frase: "Fecha a porta."',
      'A vírgula separa palavras numa lista: "Comprei maçãs, peras e uvas."'
    ],
    q: [
      ['"Queres brincar?" termina com…', ['ponto de interrogação', 'ponto final', 'ponto de exclamação', 'vírgula']],
      ['"Que alegria!" é uma frase que…', ['mostra uma emoção', 'faz uma pergunta', 'dá uma ordem', 'conta uma receita']],
      ['"O cão corre." é uma frase que…', ['conta algo', 'pergunta algo', 'pede algo', 'grita algo']],
      ['Qual sinal se usa no fim de uma pergunta?', ['?', '!', '.', ',']],
      ['A vírgula separa palavras numa lista.', true],
      ['"Fecha a porta." é um exemplo de…', ['um pedido', 'uma pergunta', 'uma emoção', 'um nome']]
    ]
  },
  {
    id: 'pt1_nomes', t: 'Nomes e adjetivos',
    k: 'nomes,nome,nome proprio,nome comum,adjetivo,adjetivos,genero,numero,singular,plural,masculino,feminino',
    ae: 'Identificar nomes próprios e comuns e adjetivos qualificativos; flexionar nomes e adjetivos em género e número.',
    r: [
      'Nome: palavra que dá nome a pessoas, animais e coisas (Rui, cão, bola).',
      'Nome próprio escreve-se com letra maiúscula (Rui, Lisboa); nome comum com minúscula (cão, casa).',
      'Adjetivo: diz como é alguém ou alguma coisa (bonito, pequeno, feliz).',
      'Masculino/feminino: o menino / a menina. Singular/plural: a flor / as flores.'
    ],
    q: [
      ['Qual destas é uma palavra que dá nome a algo?', ['cão', 'correr', 'bonito', 'rapidamente']],
      ['Qual destas palavras é um nome próprio?', ['Rui', 'menino', 'gato', 'bonito']],
      ['Na frase "O gato preto dorme.", qual é o adjetivo?', ['preto', 'gato', 'dorme', 'O']],
      ['Qual é o feminino de "menino"?', ['menina', 'meninoa', 'menine', 'meninos']],
      ['Qual é o plural de "flor"?', ['flores', 'flors', 'floris', 'flor']],
      ['Os nomes comuns escrevem-se com letra minúscula.', true]
    ]
  },
  {
    id: 'pt1_historias', t: 'Histórias e poemas',
    k: 'historia,historias,personagens,poema,poesia,recontar,trava-linguas,lengalengas,contos de fadas',
    ae: 'Compreender narrativas e poemas ouvidos ou lidos, reconhecer rimas e recontar histórias.',
    r: [
      'Uma história tem personagens (quem?) e conta o que aconteceu, por ordem.',
      'Os contos de fadas costumam começar com "Era uma vez…".',
      'Um poema tem versos (linhas) que muitas vezes rimam.',
      'As lengalengas são textos tradicionais, cantados ou ditos, com ritmo e repetição.',
      'Recontar uma história é contá-la outra vez, com as nossas palavras.'
    ],
    q: [
      ['Um conto de fadas costuma começar com…', ['Era uma vez…', 'Fim.', 'Fico à espera.', 'Olá, tudo bem?']],
      ['As personagens de uma história respondem a…', ['quem?', 'quanto custa?', 'onde fica a loja?', 'que cor é?']],
      ['Um poema é feito de…', ['versos', 'parágrafos', 'capítulos', 'contas']],
      ['Recontar uma história é…', ['contá-la outra vez com as nossas palavras', 'copiá-la do livro', 'desenhá-la', 'cantá-la só']],
      ['As lengalengas têm ritmo e repetição.', true]
    ]
  }
]);

// ============================================================= MATEMÁTICA
TEMAS(1, 'mat', [
  {
    id: 'mat1_numeros20', t: 'Números até 20', gen: 'numeros1',
    k: 'numeros,contar,pares,impares,ordinais,numero',
    ae: 'Ler, contar, comparar e ordenar números até 20; reconhecer números pares e ímpares e ordinais até ao 10.º.',
    r: [
      'Contamos: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12… até 20.',
      'Números pares: 2, 4, 6, 8, 10… Números ímpares: 1, 3, 5, 7, 9…',
      'Números ordinais: 1.º primeiro, 2.º segundo, 3.º terceiro… até 10.º décimo.',
      'Comparar números: 8 é maior do que 5; 3 é menor do que 7.'
    ],
    q: [
      ['Qual destes números é par?', ['8', '7', '9', '11']],
      ['Qual destes números é ímpar?', ['5', '4', '10', '2']],
      ['Como se lê o número 1.º?', ['primeiro', 'um', 'último', 'dez']],
      ['Qual é maior: 9 ou 6?', ['9', '6', 'são iguais', 'não se sabe']],
      ['Depois de 12 vem o…', ['13', '11', '14', '10']],
      ['O número 10 é par.', true]
    ]
  },
  {
    id: 'mat1_numeros100', t: 'Números até 100', gen: 'dezenas1',
    k: 'numeros,contar de 10 em 10,contar de 2 em 2,contar de 5 em 5,dezenas,unidades,valor posicional,comparar',
    ae: 'Contar de 2 em 2, de 5 em 5 e de 10 em 10; ler, representar e comparar números até 100 usando dezenas e unidades.',
    r: [
      'Contar de 10 em 10: 10, 20, 30, 40… até 100.',
      'Contar de 5 em 5: 5, 10, 15, 20…',
      'Em 34, há 3 dezenas e 4 unidades.',
      '10 unidades formam 1 dezena.',
      'Comparar: 45 é maior do que 38 porque tem mais dezenas.'
    ],
    q: [
      ['Contando de 10 em 10: 10, 20, 30, … qual é o número seguinte?', ['40', '35', '50', '25']],
      ['Quantas dezenas tem o número 34?', ['3', '4', '34', '7']],
      ['Contando de 5 em 5: 5, 10, 15, … qual é o próximo?', ['20', '25', '16', '21']],
      ['Qual é maior: 45 ou 38?', ['45', '38', 'são iguais', 'não se sabe']],
      ['Quantas unidades tem 1 dezena?', ['10', '1', '100', '5']],
      ['O número 100 tem 10 dezenas.', true]
    ]
  },
  {
    id: 'mat1_adicao', t: 'Adição e subtração até 20', gen: 'adicao1',
    k: 'adicao,somar,juntar,acrescentar,subtracao,subtrair,retirar,tirar,contas',
    ae: 'Resolver problemas de adição (juntar, acrescentar) e de subtração (retirar, comparar) com números até 20.',
    r: [
      'Adicionar é juntar: 5 + 3 = 8.',
      'Subtrair é retirar: 9 − 4 = 5.',
      'Também se pode subtrair para comparar: quantos mais tem um do que o outro.',
      'A adição e a subtração estão relacionadas: se 5 + 3 = 8, então 8 − 3 = 5.',
      '0 juntado a um número não o altera: 6 + 0 = 6.'
    ],
    q: [
      ['Quanto é 5 + 3?', ['8', '7', '9', '6']],
      ['Quanto é 9 − 4?', ['5', '4', '6', '13']],
      ['A Rita tinha 6 bolachas e comeu 2. Com quantas ficou?', ['4', '8', '2', '6']],
      ['Se 5 + 3 = 8, então 8 − 3 = …', ['5', '3', '8', '11']],
      ['Quanto é 6 + 0?', ['6', '0', '7', '60']],
      ['Quanto é 10 − 10?', ['0', '10', '1', '100']]
    ]
  },
  {
    id: 'mat1_geometria', t: 'Figuras, sólidos e posição',
    k: 'figuras geometricas,triangulo,quadrado,circulo,retangulo,solidos,cubo,esfera,cilindro,cone,posicao,em frente,a esquerda,a direita',
    ae: 'Reconhecer figuras planas e sólidos comuns, e descrever a posição de objetos (em frente, ao lado, à esquerda, à direita).',
    r: [
      'Figuras planas: triângulo (3 lados), quadrado (4 lados iguais), retângulo (4 lados), círculo (nenhum lado reto).',
      'Sólidos: cubo, esfera, cilindro, cone, pirâmide — têm volume, não são planos.',
      'A esfera e o cilindro podem rolar; o cubo não rola.',
      'Posição: em frente, atrás, ao lado, à esquerda, à direita, em cima, em baixo.'
    ],
    q: [
      ['Quantos lados tem um triângulo?', ['3', '4', '2', '5']],
      ['Qual destas figuras não tem lados retos?', ['círculo', 'quadrado', 'triângulo', 'retângulo']],
      ['Uma bola tem a forma de uma…', ['esfera', 'cubo', 'cone', 'pirâmide']],
      ['Qual destes sólidos pode rolar?', ['esfera', 'cubo', 'pirâmide', 'nenhum']],
      ['O quadrado tem 4 lados…', ['iguais', 'diferentes', 'curvos', 'só 2']],
      ['Se o livro está à minha esquerda, ele está…', ['do lado esquerdo', 'em cima', 'atrás', 'do lado direito']]
    ]
  },
  {
    id: 'mat1_dados', t: 'Tabelas e contagens',
    k: 'tabelas,contagens,pictograma,contar,organizar dados',
    ae: 'Recolher e organizar dados simples em tabelas de contagem e pictogramas.',
    r: [
      'Para recolher dados perguntamos algo a um grupo de pessoas (por exemplo, a fruta preferida).',
      'Uma tabela de contagem regista quantas vezes cada resposta aparece.',
      'Num pictograma, cada desenho representa uma unidade (por exemplo, 1 maçã = 1 voto).',
      'Depois de contar, vemos qual é a resposta mais escolhida.'
    ],
    q: [
      ['Para saber a fruta preferida da turma, o que fazemos primeiro?', ['perguntamos e registamos as respostas', 'desenhamos logo um gráfico', 'inventamos os números', 'não fazemos nada']],
      ['Numa tabela de contagem registamos…', ['quantas vezes cada resposta aparece', 'só os nomes dos alunos', 'as cores preferidas sempre', 'nada']],
      ['Se 1 🍎 = 1 voto, e há 5 🍎, quantos votos são?', ['5', '1', '10', '4']],
      ['A resposta mais escolhida é a que…', ['aparece mais vezes', 'aparece só uma vez', 'vem primeiro na lista', 'é mais bonita']],
      ['Um pictograma usa…', ['desenhos para representar quantidades', 'só números', 'só letras', 'nada']],
      ['Contar é importante para organizar os dados.', true]
    ]
  }
]);

// ============================================================= ESTUDO DO MEIO
TEMAS(1, 'em', [
  {
    id: 'em1_corpo', t: 'O meu corpo e a saúde',
    k: 'corpo,corpo humano,saude,higiene,seguranca,112,emergencia',
    ae: 'Identificar partes do corpo e cuidados de higiene; conhecer comportamentos seguros e o número de emergência 112.',
    r: [
      'O corpo humano muda à medida que crescemos: bebé, criança, adulto, idoso.',
      'Cuidar da higiene (lavar as mãos, os dentes, tomar banho) e vestir roupa adequada ao tempo ajuda a manter a saúde.',
      'Em casa, na rua e na água há situações de perigo que devemos saber evitar.',
      'O número de emergência europeu é o 112; deve usar-se em caso de perigo, com ajuda de um adulto.'
    ],
    q: [
      ['Qual é o número europeu de emergência?', ['112', '911', '100', '119']],
      ['Lavar as mãos antes de comer é um cuidado de…', ['higiene', 'geografia', 'matemática', 'desporto']],
      ['As fases da vida de uma pessoa são: bebé, criança, …', ['adulto e idoso', 'só criança', 'só bebé', 'nenhuma']],
      ['Se vires uma situação de perigo, deves…', ['pedir ajuda a um adulto', 'ignorar', 'fazer sozinho', 'esconder-te sem dizer nada']],
      ['Vestir roupa adequada ao tempo ajuda a manter a saúde.', true]
    ]
  },
  {
    id: 'em1_familia', t: 'A minha família',
    k: 'familia,arvore genealogica,pais,avos,irmaos,profissoes,simbolos nacionais,bandeira,hino',
    ae: 'Construir uma árvore genealógica simples, identificar profissões da família e reconhecer os símbolos nacionais.',
    r: [
      'A minha família pode ter pais, irmãos, avós e outros familiares.',
      'Uma árvore genealógica simples mostra quem são os membros da família.',
      'Cada família tem a sua organização: algumas têm muitos irmãos, outras não têm; isso é normal.',
      'As pessoas da minha família podem ter profissões diferentes (professor, médico, agricultor…).',
      'Portugal tem símbolos nacionais: a bandeira e o hino.'
    ],
    q: [
      ['Uma árvore genealógica mostra…', ['os membros da família', 'as árvores da floresta', 'os números', 'as cores']],
      ['Qual destes é um símbolo nacional de Portugal?', ['a bandeira', 'a roda dos alimentos', 'o alfabeto', 'o termómetro']],
      ['Os pais dos meus pais são os meus…', ['avós', 'tios', 'primos', 'irmãos']],
      ['Todas as famílias são organizadas exatamente da mesma forma.', false, 'Cada família é diferente: algumas têm mais irmãos, outras menos.'],
      ['Uma pessoa da minha família pode ser médica, professora ou agricultora.', true]
    ]
  },
  {
    id: 'em1_escola', t: 'A escola e a comunidade',
    k: 'escola,comunidade,regras,cooperacao,respeito,colegas,professores',
    ae: 'Reconhecer a função da escola e da comunidade, e praticar o respeito, a cooperação e a responsabilidade.',
    r: [
      'A escola é um lugar onde aprendemos e convivemos com colegas e professores.',
      'Na escola há regras que ajudam todos a estar bem (respeitar a vez de falar, arrumar o material).',
      'Cooperar é ajudar os outros a fazer uma tarefa.',
      'A comunidade é o conjunto de pessoas e lugares perto de nós (a escola, o centro de saúde, a junta de freguesia).'
    ],
    q: [
      ['A escola é um lugar onde…', ['aprendemos e convivemos', 'só se brinca', 'não há regras', 'se dorme']],
      ['Cooperar significa…', ['ajudar os outros', 'competir sempre', 'trabalhar sozinho', 'ignorar os colegas']],
      ['Respeitar a vez de falar é uma regra importante na escola.', true],
      ['Qual destes faz parte da comunidade perto da escola?', ['o centro de saúde', 'a Lua', 'o oceano Pacífico', 'um país estrangeiro']]
    ]
  },
  {
    id: 'em1_seres', t: 'Seres vivos e não vivos',
    k: 'seres vivos,seres nao vivos,animais,plantas,necessidades,sol,ar,agua',
    ae: 'Distinguir seres vivos de objetos não vivos e reconhecer as necessidades básicas dos seres vivos.',
    r: [
      'Os seres vivos nascem, crescem, reproduzem-se e morrem: animais e plantas.',
      'Os objetos não vivos (uma pedra, um brinquedo) não nascem nem crescem.',
      'Os seres vivos precisam de ar, água, alimento e, no caso das plantas, de luz do Sol.',
      'O Sol é muito importante para a vida na Terra.'
    ],
    q: [
      ['Uma pedra é um ser…', ['não vivo', 'vivo', 'animal', 'vegetal']],
      ['Qual destes é um ser vivo?', ['uma árvore', 'uma pedra', 'um brinquedo', 'uma colher']],
      ['Os seres vivos precisam de…', ['ar, água e alimento', 'só de brinquedos', 'só de dinheiro', 'nada']],
      ['O Sol é importante para a vida na Terra.', true],
      ['Um carro de brinquedo…', ['não é um ser vivo', 'é um animal', 'é uma planta', 'cresce']]
    ]
  },
  {
    id: 'em1_materiais', t: 'Materiais e objetos',
    k: 'materiais,objetos,texturas,cores,flutua,afunda,dissolve,solubilidade',
    ae: 'Usar objetos do dia a dia com segurança e identificar propriedades simples dos materiais (textura, cor, flutuação, solubilidade).',
    r: [
      'Os objetos do dia a dia são feitos de diferentes materiais: madeira, plástico, metal, papel, vidro.',
      'Cada material tem propriedades: textura (liso ou rugoso), cor, se flutua ou afunda na água.',
      'Algumas coisas dissolvem-se na água (o açúcar) e outras não (a areia).',
      'Devemos usar os objetos com cuidado, sobretudo os que têm bordos afiados ou são elétricos.'
    ],
    q: [
      ['Uma mesa de madeira é feita de um material…', ['sólido', 'líquido', 'gasoso', 'invisível']],
      ['O açúcar, posto em água e agitado, …', ['dissolve-se', 'afunda sem se dissolver', 'desaparece sem deixar sabor', 'transforma-se em pedra']],
      ['Uma bola de plástico, na água, costuma…', ['flutuar', 'afundar sempre', 'derreter', 'desaparecer']],
      ['Devemos ter cuidado com objetos com bordos afiados.', true]
    ]
  },
  {
    id: 'em1_espaco', t: 'O espaço à minha volta',
    k: 'espaco,mapa,planta,casa,escola,percurso,continentes,oceanos,globo',
    ae: 'Localizar a casa e a escola num mapa simples, descrever percursos e reconhecer continentes e oceanos num globo.',
    r: [
      'Um mapa ou planta simples mostra onde fica a minha casa, a minha escola e o percurso entre elas.',
      'Para fazer um percurso simples, usamos pontos de referência (a loja, o parque).',
      'O globo mostra a Terra: tem partes de terra (continentes) e partes de água (oceanos).',
      'Os continentes são grandes extensões de terra; os oceanos são grandes extensões de água salgada.'
    ],
    q: [
      ['Um mapa simples pode mostrar…', ['onde fica a minha casa e a escola', 'só números', 'só cores', 'nada de útil']],
      ['O globo representa…', ['a Terra', 'só Portugal', 'só o céu', 'só o mar']],
      ['Os continentes são…', ['grandes extensões de terra', 'grandes extensões de água', 'pequenas ilhas só', 'nuvens']],
      ['Um ponto de referência ajuda a…', ['fazer um percurso', 'adivinhar números', 'desenhar sem rigor', 'nada']],
      ['Os oceanos são extensões de água salgada.', true]
    ]
  }
]);
