/* Substituído na compilação pelo GitHub Actions se existir o segredo CLAUDE_KEY. Não pôr chaves aqui. */
window.KIKO_IA_PADRAO = null;
