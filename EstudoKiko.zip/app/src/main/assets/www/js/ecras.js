/* Ecrãs da app e navegação */
(function () {
  'use strict';

  const raiz = () => U.$('#app');
  const pilha = [];
  const ECRAS = {};
  const NAV = [
    { id: 'inicio', i: '🦉', n: 'Kiko' },
    { id: 'materias', i: '📚', n: 'Matérias' },
    { id: 'testes', i: '📅', n: 'Testes' },
    { id: 'progresso', i: '⭐', n: 'Progresso' }
  ];
  const CORES = ['#FF9F1C', '#FF5A5F', '#4D96FF', '#2EC4A0', '#9B5DE5', '#F15BB5', '#00BBF9', '#A8714A'];
  const ANIMAIS = ['🦊', '🐼', '🐯', '🐸', '🦄', '🐶', '🐱', '🐵', '🐨', '🐙'];

  const APP = (window.APP = {});

  APP.ir = function (nome, params, substituir) {
    VOZ.parar(); MIC.parar();
    if (substituir && pilha.length) pilha.pop();
    if (NAV.some((n) => n.id === nome) && !params) pilha.length = 0;
    pilha.push({ nome, params: params || {} });
    desenhar();
  };
  APP.voltar = function () {
    VOZ.parar(); MIC.parar();
    pilha.pop();
    while (pilha.length && ['quiz', 'resultado', 'carregar'].indexOf(pilha[pilha.length - 1].nome) >= 0) pilha.pop();
    if (!pilha.length) pilha.push({ nome: S.perfil() ? 'inicio' : 'perfis', params: {} });
    desenhar();
  };
  APP.carregar = function (msg) {
    pilha.push({ nome: 'carregar', params: { msg } });
    desenhar();
  };
  function desenhar() {
    const e = pilha[pilha.length - 1];
    const r = raiz();
    r.innerHTML = '';
    r.setAttribute('data-ecra', e.nome);
    window.scrollTo(0, 0);
    (ECRAS[e.nome] || ECRAS.inicio)(r, e.params);
    const tab = NAV.find((n) => n.id === e.nome) || (['disciplina', 'tema', 'cartoes'].indexOf(e.nome) >= 0 ? NAV[1] : null);
    if (tab && S.perfil()) {
      const nav = document.createElement('div');
      nav.className = 'nav';
      nav.innerHTML = '<div class="nav-in">' + NAV.map((n) => `<button data-n="${n.id}" class="${n.id === tab.id ? 'on' : ''}"><span class="i">${n.i}</span>${n.n}</button>`).join('') + '</div>';
      r.appendChild(nav);
      U.$$('button', nav).forEach((b) => (b.onclick = () => { SOM.clique(); APP.ir(b.dataset.n); }));
    }
  }
  APP.redesenhar = desenhar;

  window.kikoBack = function () {
    if (MODAL.aberto()) { MODAL.fechar(); return true; }
    const e = pilha[pilha.length - 1];
    if (e && e.nome === 'quiz') { QUIZ.sair(); return true; }
    if (pilha.length > 1) { APP.voltar(); return true; }
    if (e && e.nome !== 'inicio' && e.nome !== 'perfis' && S.perfil()) { APP.ir('inicio'); return true; }
    return false;
  };

  function topo(titulo, extra) {
    return `<div class="topbar"><button class="iconbtn" data-voltar>←</button><h2>${U.esc(titulo)}</h2>${extra || ''}</div>`;
  }
  function ligarVoltar(r) { U.$$('[data-voltar]', r).forEach((b) => (b.onclick = () => APP.voltar())); }
  function estrelas(n) { return `<span class="stars">${'★'.repeat(n)}<span class="off">${'★'.repeat(3 - n)}</span></span>`; }
  function disc(p, id) { return CUR.disciplinas[p.ano].find((d) => d.id === id) || { nome: id, cor: '#999', emo: '📘' }; }

  // ================================================================== PERFIS
  ECRAS.perfis = function (r) {
    const ps = S.data.perfis;
    r.innerHTML = `
      <div class="topbar"><h2>Quem vai estudar?</h2><button class="iconbtn" id="pais">🔒</button></div>
      <div class="hero"><div class="bubble" id="bolha">${ps.length ? 'Olá! Toca no teu nome.' : 'Olá! Eu sou o Kiko. Vamos criar o teu perfil?'}</div>${KIKO.html('small')}</div>
      <div class="profiles">
        ${ps.map((p) => `<button class="profile" data-id="${p.id}"><div class="avatar" style="background:${p.cor}">${p.emo}</div><div class="name">${U.esc(p.nome)}</div><div class="muted small" style="font-weight:800">${p.ano}.º ano · ⭐ ${S.saldo(p)}</div></button>`).join('')}
        <button class="profile add" id="novo"><div style="font-size:40px">＋</div><div class="name">Novo perfil</div></button>
      </div>
      <p class="center muted small pad">Conteúdos organizados pelas Aprendizagens Essenciais<br>do 4.º e do 7.º ano (ano letivo 2026/2027).</p>`;
    KIKO.ligar(r);
    U.$$('.profile[data-id]', r).forEach((b) => (b.onclick = () => { S.data.atual = b.dataset.id; S.save(); CONVERSA.limpar(); APP._saudou = false; APP.ir('inicio'); }));
    U.$('#novo').onclick = novoPerfil;
    U.$('#pais').onclick = () => APP.ir('pais');
    if (!ps.length) setTimeout(() => KIKO.dizer('Olá! Eu sou o Kiko, o teu amigo de estudo. Vamos criar o teu perfil?'), 400);
  };

  function novoPerfil() {
    let cor = U.pick(CORES), emo = U.pick(ANIMAIS), ano = 4;
    MODAL.abrir(`
      <h2>Novo perfil</h2>
      <div class="stack" style="margin-top:14px">
        <div class="field"><label>Nome</label><input class="input" id="nnome" maxlength="18" placeholder="Como te chamas?"></div>
        <div class="field"><label>Ano</label><div class="seg" id="nano"><button data-a="4" class="on">4.º ano</button><button data-a="7">7.º ano</button></div></div>
        <div class="field"><label>Cor</label><div class="colors" id="ncor">${CORES.map((c) => `<button data-c="${c}" style="background:${c}" class="${c === cor ? 'on' : ''}"></button>`).join('')}</div></div>
        <div class="field"><label>Animal</label><div class="chips" id="nemo">${ANIMAIS.map((e) => `<button class="chip ${e === emo ? 'on' : ''}" data-e="${e}" style="font-size:22px;padding:6px 10px">${e}</button>`).join('')}</div></div>
        <button class="btn" id="ncriar">Criar perfil</button>
      </div>`, (m) => {
      U.$$('#nano button', m).forEach((b) => (b.onclick = () => { ano = +b.dataset.a; U.$$('#nano button', m).forEach((x) => x.classList.toggle('on', x === b)); }));
      U.$$('#ncor button', m).forEach((b) => (b.onclick = () => { cor = b.dataset.c; U.$$('#ncor button', m).forEach((x) => x.classList.toggle('on', x === b)); }));
      U.$$('#nemo button', m).forEach((b) => (b.onclick = () => { emo = b.dataset.e; U.$$('#nemo button', m).forEach((x) => x.classList.toggle('on', x === b)); }));
      U.$('#ncriar', m).onclick = () => {
        const nome = U.$('#nnome', m).value.trim();
        if (!nome) return toast('Escreve o teu nome 🙂');
        S.novoPerfil(nome, ano, cor, emo);
        MODAL.fechar(); CONVERSA.limpar(); APP._saudou = false;
        APP.ir('inicio');
      };
    });
  }

  // ================================================================== INÍCIO (conversa com o Kiko)
  ECRAS.inicio = function (r) {
    const p = S.perfil();
    if (!p) return ECRAS.perfis(r);
    const hoje = S.dia(p);
    const meta = S.cfg().meta;
    const pct = Math.min(1, hoje.r / meta);
    const seq = S.sequencia(p);
    const errosN = QUIZ.errosPendentes(p).length;
    const prox = proximoTeste(p);
    r.innerHTML = `
      <div class="topbar">
        <button class="avatar" id="trocar" style="width:44px;height:44px;font-size:22px;background:${p.cor}">${p.emo}</button>
        <h2>Olá, ${U.esc(p.nome)}!</h2>
        <span class="pill">🔥 ${seq}</span><span class="pill">⭐ ${S.saldo(p)}</span>
      </div>
      <div class="hero">
        <div class="bubble" id="bolha">O que queres estudar hoje?</div>
        ${KIKO.html('', p.veste)}
        <div class="microw">
          <button class="mic" id="mic">🎤</button>
          <div class="typebox"><input id="txt" placeholder="Ou escreve aqui…" enterkeyhint="send"><button id="enviar">➤</button></div>
        </div>
      </div>
      <div class="actions" id="acoes"></div>
      <div class="chat" id="chat"></div>
      <div class="section stack">
        ${prox ? `<button class="banner" id="bteste" style="background:${disc(p, prox.disc).cor}"><span class="big">📅</span><span class="grow">Teste de ${U.esc(disc(p, prox.disc).nome)}<br><span class="small">${prox.dias === 0 ? 'é hoje!' : prox.dias === 1 ? 'é amanhã!' : 'daqui a ' + prox.dias + ' dias'} · toca para treinar</span></span><span>➜</span></button>` : ''}
        ${errosN ? `<button class="banner" id="berros" style="background:var(--bad)"><span class="big">🩹</span><span class="grow">Tens ${errosN} ${errosN === 1 ? 'erro' : 'erros'} para corrigir<br><span class="small">Corrigir dá estrelas!</span></span><span>➜</span></button>` : ''}
        <div class="card goal">
          <svg class="ringc" viewBox="0 0 36 36"><circle cx="18" cy="18" r="15" fill="none" stroke="#F0E2CF" stroke-width="5"/><circle cx="18" cy="18" r="15" fill="none" stroke="#2EC4A0" stroke-width="5" stroke-linecap="round" stroke-dasharray="${(94.2 * pct).toFixed(1)} 94.2" transform="rotate(-90 18 18)"/></svg>
          <div class="grow"><h3>Meta de hoje</h3><p class="muted small" style="font-weight:800">${hoje.r} de ${meta} perguntas ${pct >= 1 ? '✅' : ''}</p></div>
        </div>
        <div class="row">
          <button class="btn grow" id="bsurpresa">🎲 Quiz surpresa</button>
          <button class="btn blue grow" id="bmaterias">📚 Matérias</button>
        </div>
      </div>`;
    KIKO.ligar(r);
    CONVERSA.historico.slice(-6).forEach((m) => {
      const d = document.createElement('div'); d.className = 'msg ' + (m.quem === 'eu' ? 'me' : 'kiko'); d.textContent = m.texto; U.$('#chat').appendChild(d);
    });
    U.$('#trocar').onclick = () => { S.data.atual = null; S.save(); APP.ir('perfis'); };
    U.$('#bsurpresa').onclick = () => QUIZ.iniciarSurpresa();
    U.$('#bmaterias').onclick = () => APP.ir('materias');
    if (U.$('#berros')) U.$('#berros').onclick = () => QUIZ.iniciarErros();
    if (U.$('#bteste')) U.$('#bteste').onclick = () => APP.ir('testes');
    const enviar = () => { const v = U.$('#txt').value.trim(); if (!v) return; U.$('#txt').value = ''; U.$('#txt').blur(); CONVERSA.processar(v); };
    U.$('#enviar').onclick = enviar;
    U.$('#txt').addEventListener('keydown', (e) => { if (e.key === 'Enter') enviar(); });
    U.$('#mic').onclick = () => ouvirConversa();

    if (!APP._saudou) {
      APP._saudou = true;
      let s = U.pick(['Olá ' + p.nome + '! ', 'Viva, ' + p.nome + '! ', 'Que bom ver-te, ' + p.nome + '! ']);
      if (prox && prox.dias <= 7) s += 'Tens teste de ' + disc(p, prox.disc).nome + (prox.dias === 0 ? ' hoje' : prox.dias === 1 ? ' amanhã' : ' daqui a ' + prox.dias + ' dias') + '. Vamos treinar? ';
      else if (errosN) s += 'Tens ' + errosN + (errosN === 1 ? ' erro' : ' erros') + ' para corrigir. ';
      s += 'Carrega no microfone e diz-me o que queres estudar.';
      setTimeout(() => { KIKO.balao(U.esc(s)); VOZ.falar(s); }, 350);
    }
  };

  function ouvirConversa() {
    const btn = U.$('#mic');
    if (MIC.ativo) { MIC.parar(); btn.classList.remove('on'); KIKO.limpar(); KIKO.balao('O que queres estudar hoje?'); return; }
    btn.classList.add('on');
    KIKO.estado('listening', true);
    KIKO.balao('Estou a ouvir… 👂');
    U.$('#acoes').innerHTML = '';
    MIC.ouvir({
      nivel: (v) => btn.style.setProperty('--lvl', Math.round(v * 16) + 'px'),
      parcial: (t) => KIKO.balao('<span class="partial">' + U.esc(t) + '…</span>'),
      estado: (e) => { if (e === 'pensar') { KIKO.estado('listening', false); KIKO.estado('thinking', true); } },
      resultado: (textos) => {
        btn.classList.remove('on'); KIKO.limpar();
        if (!textos.length) return KIKO.dizer('Não ouvi nada. Tenta outra vez!');
        CONVERSA.processar(textos[0]);
      },
      erro: (m) => { btn.classList.remove('on'); KIKO.limpar(); KIKO.dizer(m); }
    });
  }

  function proximoTeste(p) {
    const hoje = U.today();
    const fut = (p.testes || []).filter((t) => t.data >= hoje).sort((a, b) => (a.data < b.data ? -1 : 1));
    if (!fut.length) return null;
    const d = U.daysBetween(hoje, fut[0].data);
    return d <= 30 ? Object.assign({ dias: d }, fut[0]) : null;
  }

  // ================================================================== MATÉRIAS
  ECRAS.materias = function (r) {
    const p = S.perfil();
    r.innerHTML = `
      <div class="topbar"><h2>Matérias do ${p.ano}.º ano</h2></div>
      <div class="section"><div class="subjects">
        ${CUR.disciplinas[p.ano].map((d) => {
          const n = (CUR.porAno[p.ano][d.id] || []).length;
          const lv = S.nivelDisc(p, d.id);
          return `<button class="subject" data-d="${d.id}" style="background:${d.cor}"><span class="emo">${d.emo}</span><span><span class="nm">${d.nome}</span><br><span class="small" style="font-weight:800;opacity:.9">${n} temas</span><span class="bar" style="display:block"><i style="width:${lv}%"></i></span></span></button>`;
        }).join('')}
      </div></div>
      <div class="section"><button class="btn sec" id="msurp">🎲 Quiz surpresa de tudo</button></div>`;
    U.$$('.subject', r).forEach((b) => (b.onclick = () => APP.ir('disciplina', { disc: b.dataset.d })));
    U.$('#msurp').onclick = () => QUIZ.iniciarSurpresa();
  };

  ECRAS.disciplina = function (r, params) {
    const p = S.perfil();
    const d = disc(p, params.disc);
    const temas = CUR.porAno[p.ano][params.disc] || [];
    r.innerHTML = topo(d.emo + ' ' + d.nome) + `
      ${(CUR.manuais[p.ano] || {})[params.disc] ? `<p class="small muted" style="font-weight:800;padding:0 16px">📘 Manual: ${U.esc(CUR.manuais[p.ano][params.disc])}</p>` : ''}
      <div class="section row">
        <button class="btn grow small" id="dquiz" style="background:${d.cor};box-shadow:0 5px 0 rgba(0,0,0,.18)">🎲 Quiz de ${U.esc(d.nome)}</button>
        ${IA.ativa() ? '<button class="btn purple small" id="dlivre">✨ Outro tema</button>' : ''}
      </div>
      <div class="section topics">
        ${temas.map((t) => {
          const nv = S.nivelTema(p, t.id);
          return `<button class="topic" data-t="${t.id}"><div class="grow"><div class="tt">${U.esc(t.t)}</div>
            <div class="sub">${nv < 0 ? 'Ainda não treinado' : 'Domínio ' + nv + '%'}</div>
            <div class="tbar"><i style="width:${Math.max(0, nv)}%;background:${d.cor}"></i></div></div>${estrelas(S.estrelasTema(p, t.id))}</button>`;
        }).join('')}
      </div>`;
    ligarVoltar(r);
    U.$$('.topic', r).forEach((b) => (b.onclick = () => APP.ir('tema', { id: b.dataset.t })));
    U.$('#dquiz').onclick = () => QUIZ.iniciarSurpresa(params.disc);
    const dl = U.$('#dlivre');
    if (dl) dl.onclick = () => {
      MODAL.abrir(`<h2>✨ Quiz sobre outro tema</h2><p class="muted" style="font-weight:700;margin:8px 0 12px">Escreve o tema da aula ou do manual (ex.: "página 45 – os sólidos geométricos"). A IA cria perguntas do ${p.ano}.º ano.</p>
        <div class="stack"><input class="input" id="ltema" placeholder="Tema"><button class="btn purple" id="lok">Criar quiz</button></div>`, (m) => {
        U.$('#lok', m).onclick = () => { const v = U.$('#ltema', m).value.trim(); if (!v) return; MODAL.fechar(); QUIZ.iniciarIA(params.disc, v, null); };
      });
    };
  };

  // ================================================================== TEMA (resumo)
  ECRAS.tema = function (r, params) {
    const p = S.perfil();
    const t = CUR.temas[params.id];
    if (!t) return APP.voltar();
    const d = disc(p, t.disc);
    r.innerHTML = topo(t.t) + `
      <div class="row" style="padding:4px 16px 8px">
        ${KIKO.html('small', p.veste)}
        <div class="bubble grow" id="bolha" style="margin:0;text-align:left;font-size:15px">Aqui tens o resumo. Posso ler para ti!</div>
      </div>
      <div class="section" style="padding-top:0">
        <p class="small muted" style="font-weight:800;margin-bottom:10px">${d.emo} ${U.esc(d.nome)} · ${p.ano}.º ano${t.ae ? ' — ' + U.esc(t.ae) : ''}</p>
        <div class="points">${t.r.map((x, i) => `<div class="point" data-i="${i}"><span class="n" style="background:${d.cor}">${i + 1}</span><span>${U.esc(x)}</span></div>`).join('')}</div>
      </div>
      <div id="iabox" class="section hidden"></div>
      <div class="section stack">
        <button class="btn sec" id="tler">🔊 Ouvir o resumo</button>
        <div class="row"><button class="btn grow" id="tquiz">❓ Quiz</button><button class="btn blue grow" id="tcart">🃏 Cartões</button></div>
        <div class="row">
          <button class="btn purple grow small" id="tperg">💬 Perguntar</button>
          ${IA.ativa() ? '<button class="btn purple grow small" id="texp">✨ Explica melhor</button>' : ''}
        </div>
      </div>`;
    ligarVoltar(r); KIKO.ligar(r);
    let lendo = false;
    U.$('#tler').onclick = async () => {
      if (lendo) { lendo = false; VOZ.parar(); U.$('#tler').textContent = '🔊 Ouvir o resumo'; U.$$('.point').forEach((x) => x.classList.remove('reading')); return; }
      lendo = true; U.$('#tler').textContent = '⏹️ Parar';
      const pts = U.$$('.point', r);
      for (let i = 0; i < t.r.length && lendo; i++) {
        pts.forEach((x) => x.classList.remove('reading')); pts[i].classList.add('reading');
        pts[i].scrollIntoView({ behavior: 'smooth', block: 'center' });
        await VOZ.falar(U.mathForSpeech(t.r[i]));
      }
      if (lendo) { pts.forEach((x) => x.classList.remove('reading')); lendo = false; U.$('#tler').textContent = '🔊 Ouvir o resumo'; KIKO.dizer('Já está! Queres fazer o quiz para ver se percebeste?'); }
    };
    U.$('#tquiz').onclick = () => QUIZ.iniciarTema(t.id);
    U.$('#tcart').onclick = () => APP.ir('cartoes', { id: t.id });
    U.$('#tperg').onclick = () => perguntarSobreTema(p, t);
    const te = U.$('#texp');
    if (te) te.onclick = async () => {
      const box = U.$('#iabox'); box.classList.remove('hidden');
      box.innerHTML = '<div class="ai-box"><span class="spinner"></span> O Kiko está a pensar…</div>';
      KIKO.estado('thinking', true);
      try {
        const txt = await IA.explicar(p, t);
        KIKO.estado('thinking', false);
        box.innerHTML = '<div class="ai-box">' + U.esc(txt) + '</div>';
        KIKO.dizer(txt, false);
        U.$('#bolha').textContent = 'Ouve com atenção!';
      } catch (e) { KIKO.estado('thinking', false); box.innerHTML = '<div class="ai-box">' + U.esc(e.message) + '</div>'; }
    };
    if (params.falar) setTimeout(() => KIKO.dizer('Vamos estudar ' + t.t + '. Toca em "Ouvir o resumo" e eu leio para ti, ou faz já o quiz!'), 300);
  };

  function perguntarSobreTema(p, t) {
    MODAL.abrir(`<h2>💬 Pergunta ao Kiko</h2><p class="muted" style="font-weight:700;margin:6px 0 12px">Sobre: ${U.esc(t.t)}</p>
      <div class="microw" style="margin:0"><button class="mic smallmic" id="pmic">🎤</button><div class="typebox"><input id="ptxt" placeholder="Escreve a tua dúvida"><button id="pok">➤</button></div></div>
      <div id="presp" style="margin-top:14px"></div>`, (m) => {
      const responder = async (perg) => {
        const box = U.$('#presp', m);
        if (IA.ativa()) {
          box.innerHTML = '<div class="ai-box"><span class="spinner"></span> A pensar…</div>';
          try { const txt = await IA.explicar(p, t, perg); box.innerHTML = '<div class="ai-box">' + U.esc(txt) + '</div>'; VOZ.falar(txt); }
          catch (e) { box.innerHTML = '<div class="ai-box">' + U.esc(e.message) + '</div>'; }
        } else {
          // sem IA: procura o ponto do resumo mais parecido com a pergunta
          const ws = U.norm(perg).split(' ').filter((w) => w.length > 3);
          let melhor = null, pont = 0;
          t.r.concat((t.q || []).map((q) => q[0] + ' ' + (typeof q[1] === 'boolean' ? (q[1] ? 'Verdadeiro.' : 'Falso.') : q[1][0]) + (q[2] ? '. ' + q[2] : ''))).forEach((x) => {
            const n = U.norm(x); const s = ws.filter((w) => n.indexOf(w.slice(0, Math.max(4, w.length - 2))) >= 0).length;
            if (s > pont) { pont = s; melhor = x; }
          });
          const txt = melhor ? 'Encontrei isto no resumo: ' + melhor : 'Não encontrei no resumo. Pergunta ao teu professor ou pede a um adulto para ligar a IA.';
          box.innerHTML = '<div class="ai-box">' + U.esc(txt) + '</div>'; VOZ.falar(txt);
        }
      };
      U.$('#pok', m).onclick = () => { const v = U.$('#ptxt', m).value.trim(); if (v) responder(v); };
      U.$('#pmic', m).onclick = () => {
        const b = U.$('#pmic', m); b.classList.add('on');
        MIC.ouvir({
          parcial: (x) => (U.$('#ptxt', m).value = x),
          resultado: (tx) => { b.classList.remove('on'); if (tx[0]) { U.$('#ptxt', m).value = tx[0]; responder(tx[0]); } },
          erro: (e) => { b.classList.remove('on'); toast(e); }
        });
      };
    });
  }

  // ================================================================== CARTÕES
  ECRAS.cartoes = function (r, params) {
    const p = S.perfil();
    const t = CUR.temas[params.id];
    const cartas = U.shuffle((t.q || []).map((raw) => QUIZ.daTabela(t, raw))).slice(0, 12);
    if (!cartas.length) { toast('Ainda não há cartões neste tema'); return APP.voltar(); }
    let i = 0, sei = 0;
    const naoSei = [];
    function mostrar() {
      if (i >= cartas.length) return fim();
      const c = cartas[i];
      r.innerHTML = topo('🃏 ' + t.t, `<span class="pill">${i + 1}/${cartas.length}</span>`) + `
        <div class="flash" id="fc"><div class="flash-in">
          <div class="face front"><span>${U.esc(c.p)}${c.tf ? '<br><span class="small">Verdadeiro ou falso?</span>' : ''}</span><span class="hint">Toca para virar</span></div>
          <div class="face back"><span>${U.esc(c.certa)}</span>${c.exp ? `<span style="font-size:15px;font-weight:700;opacity:.95">${U.esc(c.exp)}</span>` : ''}</div>
        </div></div>
        <div class="section row" id="fbt" style="visibility:hidden">
          <button class="btn danger grow" id="fno">😕 Ainda não</button><button class="btn ok grow" id="fsim">😃 Já sei</button>
        </div>
        <div class="center"><button class="btn sec small inline" id="fler" style="display:inline-flex">🔊 Ler</button></div>`;
      ligarVoltar(r);
      const fc = U.$('#fc');
      fc.onclick = () => {
        fc.classList.toggle('flip');
        U.$('#fbt').style.visibility = 'visible';
        if (fc.classList.contains('flip')) VOZ.falar(U.mathForSpeech(c.certa + '. ' + (c.exp || '')));
      };
      U.$('#fler').onclick = () => VOZ.falar(U.mathForSpeech(fc.classList.contains('flip') ? c.certa : c.p));
      U.$('#fsim').onclick = () => { sei++; SOM.certo(); i++; mostrar(); };
      U.$('#fno').onclick = () => { naoSei.push(c); i++; mostrar(); };
      if (S.cfg().lerAuto) VOZ.falar(U.mathForSpeech(c.p));
    }
    function fim() {
      // o que ainda não sabe vai para a revisão
      naoSei.forEach((c) => {
        const k = c.tema + '|' + U.hash(c.p + '#' + c.certa);
        p.erros[k] = { tema: c.tema, q: { p: c.p, certa: c.certa, erradas: c.erradas, exp: c.exp, tf: c.tf }, vezes: 2, prox: U.today() };
      });
      p.estrelas += Math.ceil(sei / 2);
      S.save();
      r.innerHTML = topo('🃏 ' + t.t) + `
        <div class="hero"><div class="bubble" id="bolha">Sabias ${sei} de ${cartas.length}!</div>${KIKO.html('', p.veste)}</div>
        <p class="center" style="font-weight:900">+${Math.ceil(sei / 2)} ⭐</p>
        <div class="section stack">
          ${naoSei.length ? `<p class="center muted" style="font-weight:800">${naoSei.length} ${naoSei.length === 1 ? 'cartão foi' : 'cartões foram'} para a tua revisão de erros.</p>` : ''}
          <button class="btn" id="fq">❓ Fazer o quiz</button><button class="btn sec" id="fv">Voltar</button>
        </div>`;
      ligarVoltar(r); KIKO.ligar(r);
      KIKO.reagir(sei >= cartas.length / 2 ? 'happy' : 'sad');
      KIKO.dizer(sei === cartas.length ? 'Uau, sabias todos!' : 'Boa! Os que ainda não sabes vou guardá-los para revermos.');
      U.$('#fq').onclick = () => QUIZ.iniciarTema(t.id);
      U.$('#fv').onclick = () => APP.voltar();
    }
    mostrar();
  };

  // ================================================================== QUIZ / RESULTADO / CARREGAR
  ECRAS.quiz = (r) => QUIZ.render(r);
  ECRAS.resultado = (r, params) => QUIZ.renderResultado(r, params);
  ECRAS.carregar = function (r, params) {
    const p = S.perfil();
    r.innerHTML = `<div class="hero" style="padding-top:60px"><div class="bubble" id="bolha">${U.esc(params.msg || 'A preparar…')}</div>${KIKO.html('thinking', p && p.veste)}</div>
      <div class="center"><span class="spinner" style="width:40px;height:40px;border-width:5px"></span></div>`;
  };

  // ================================================================== PROGRESSO + LOJA + MEDALHAS
  const MEDALHAS = [
    { id: 'primeiro', e: '🐣', n: 'Primeiro quiz', t: (p) => p.historico.length >= 1 },
    { id: 'perfeito', e: '💯', n: 'Quiz perfeito', t: (p) => p.historico.some((h) => h.n >= 5 && h.c === h.n) },
    { id: 'seq3', e: '🔥', n: '3 dias seguidos', t: (p) => S.sequencia(p) >= 3 },
    { id: 'seq7', e: '🚀', n: '7 dias seguidos', t: (p) => S.sequencia(p) >= 7 },
    { id: 'c100', e: '💪', n: '100 certas', t: (p) => totalCertas(p) >= 100 },
    { id: 'c500', e: '🏆', n: '500 certas', t: (p) => totalCertas(p) >= 500 },
    { id: 'explor', e: '🧭', n: 'Explorador', t: (p) => Object.keys(p.dominio).length >= 5 },
    { id: 'mestre', e: '🎓', n: 'Mestre de um tema', t: (p) => Object.keys(p.dominio).some((k) => p.dominio[k].n >= 10 && S.nivelTema(p, k) === 100) },
    { id: 'revisor', e: '🩹', n: 'Corrigiu 10 erros', t: (p) => (p.corrigidos || 0) >= 10 },
    { id: 'todas', e: '📚', n: 'Todas as disciplinas', t: (p) => CUR.disciplinas[p.ano].every((d) => (CUR.porAno[p.ano][d.id] || []).some((t) => p.dominio[t.id])) },
    { id: 'exame', e: '📝', n: 'Simulou um teste', t: (p) => p.historico.some((h) => h.modo === 'exame') },
    { id: 'estilo', e: '🦉', n: 'Kiko com estilo', t: (p) => p.loja.length >= 1 }
  ];
  function totalCertas(p) { return Object.keys(p.dias).reduce((s, d) => s + p.dias[d].c, 0); }
  APP.verMedalhas = function (p) {
    const novas = [];
    MEDALHAS.forEach((m) => { if (!p.medalhas[m.id] && m.t(p)) { p.medalhas[m.id] = U.today(); novas.push(m); } });
    if (novas.length) S.save();
    return novas;
  };

  ECRAS.progresso = function (r) {
    const p = S.perfil();
    const tot = Object.keys(p.dias).reduce((s, d) => s + p.dias[d].r, 0);
    const cer = totalCertas(p);
    const dias7 = [];
    for (let i = 6; i >= 0; i--) { const d = U.addDays(U.today(), -i); dias7.push({ d, r: (p.dias[d] || {}).r || 0 }); }
    const max7 = Math.max(10, ...dias7.map((x) => x.r));
    APP.verMedalhas(p);
    r.innerHTML = `
      <div class="topbar"><h2>O meu progresso</h2><span class="pill">⭐ ${S.saldo(p)}</span></div>
      <div class="section statgrid">
        <div class="stat"><b>${S.sequencia(p)}🔥</b><span>dias seguidos</span></div>
        <div class="stat"><b>${tot}</b><span>respostas</span></div>
        <div class="stat"><b>${tot ? Math.round((100 * cer) / tot) : 0}%</b><span>certas</span></div>
      </div>
      <div class="section"><div class="card">
        <h3>Últimos 7 dias</h3>
        <div style="display:flex;align-items:flex-end;gap:8px;height:110px;margin-top:12px">
          ${dias7.map((x) => `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;height:100%;justify-content:flex-end">
            <span class="small" style="font-weight:800">${x.r || ''}</span>
            <div style="width:100%;border-radius:8px;background:${x.d === U.today() ? 'var(--pri)' : 'var(--blue)'};height:${Math.max(4, (80 * x.r) / max7)}px"></div>
            <span class="small muted" style="font-weight:800">${new Date(x.d + 'T12:00').toLocaleDateString('pt-PT', { weekday: 'narrow' })}</span></div>`).join('')}
        </div>
      </div></div>
      <div class="section"><div class="card stack">
        <h3>Disciplinas</h3>
        ${CUR.disciplinas[p.ano].map((d) => { const v = S.nivelDisc(p, d.id); return `<div class="hbar"><span class="lbl">${d.emo} ${d.nome}</span><span class="tr"><i style="width:${v}%;background:${d.cor}"></i></span><span class="v">${v}%</span></div>`; }).join('')}
      </div></div>
      <div class="section"><div class="section-title"><h3>🦉 Loja do Kiko</h3><span class="muted small" style="font-weight:800">Usa as tuas estrelas</span></div>
        <div class="row" style="justify-content:center">${KIKO.html('small', p.veste)}</div>
        <div class="shop" style="margin-top:10px">
          ${KIKO.ACESSORIOS.map((a) => { const tem = p.loja.indexOf(a.id) >= 0, veste = p.veste.indexOf(a.id) >= 0; return `<button class="item ${veste ? 'on' : ''} ${!tem && S.saldo(p) < a.preco ? 'locked' : ''}" data-a="${a.id}"><span class="e">${a.emo}</span>${a.nome}<span class="muted">${tem ? (veste ? 'A usar' : 'Usar') : '⭐ ' + a.preco}</span></button>`; }).join('')}
        </div>
      </div>
      <div class="section"><h3 style="margin-bottom:10px">🏅 Medalhas</h3>
        <div class="badges">${MEDALHAS.map((m) => `<div class="badge ${p.medalhas[m.id] ? 'on' : 'off'}"><span class="e">${m.e}</span>${m.n}</div>`).join('')}</div>
      </div>`;
    KIKO.ligar(r);
    U.$$('.item', r).forEach((b) => (b.onclick = () => {
      const a = KIKO.ACESSORIOS.find((x) => x.id === b.dataset.a);
      if (p.loja.indexOf(a.id) < 0) {
        if (S.saldo(p) < a.preco) return toast('Faltam ' + (a.preco - S.saldo(p)) + ' ⭐ para ' + a.nome);
        p.gastas += a.preco; p.loja.push(a.id); p.veste.push(a.id); SOM.festa(); toast(a.emo + ' Compraste: ' + a.nome + '!');
      } else {
        const i = p.veste.indexOf(a.id);
        if (i >= 0) p.veste.splice(i, 1); else p.veste.push(a.id);
      }
      S.save(); APP.redesenhar();
    }));
  };

  // ================================================================== TESTES MARCADOS + PLANO DE ESTUDO
  ECRAS.testes = function (r, params) {
    const p = S.perfil();
    const hoje = U.today();
    const fut = p.testes.filter((t) => t.data >= hoje).sort((a, b) => (a.data < b.data ? -1 : 1));
    const pass = p.testes.filter((t) => t.data < hoje).sort((a, b) => (a.data < b.data ? 1 : -1));
    r.innerHTML = `
      <div class="topbar"><h2>Testes e fichas</h2><button class="iconbtn" id="tnovo">＋</button></div>
      <div class="section stack">
        ${fut.length ? fut.map((t) => cartaoTeste(p, t)).join('') : `<div class="card center stack"><div style="font-size:44px">📅</div><h3>Nenhum teste marcado</h3><p class="muted" style="font-weight:700">Marca os teus testes e o Kiko faz-te um plano de estudo até ao dia.</p><button class="btn" id="tnovo2">＋ Marcar teste</button></div>`}
      </div>
      ${pass.length ? `<div class="section"><h3 class="muted" style="margin-bottom:8px">Passados</h3><div class="stack">${pass.slice(0, 8).map((t) => `<div class="card tight row"><span class="grow" style="font-weight:800">${disc(p, t.disc).emo} ${U.esc(disc(p, t.disc).nome)} · ${U.fmtDate(t.data)}</span><button class="iconbtn" data-del="${t.id}">🗑️</button></div>`).join('')}</div></div>` : ''}`;
    U.$('#tnovo').onclick = () => formTeste(p, null);
    if (U.$('#tnovo2')) U.$('#tnovo2').onclick = () => formTeste(p, null);
    U.$$('[data-treino]', r).forEach((b) => (b.onclick = () => { const t = p.testes.find((x) => x.id === b.dataset.treino); APP._testeAtual = t; QUIZ.iniciarTeste(t, false); }));
    U.$$('[data-exame]', r).forEach((b) => (b.onclick = () => { const t = p.testes.find((x) => x.id === b.dataset.exame); APP._testeAtual = t; QUIZ.iniciarTeste(t, true); }));
    U.$$('[data-edit]', r).forEach((b) => (b.onclick = () => formTeste(p, p.testes.find((x) => x.id === b.dataset.edit))));
    U.$$('[data-tema]', r).forEach((b) => (b.onclick = () => APP.ir('tema', { id: b.dataset.tema })));
    U.$$('[data-del]', r).forEach((b) => (b.onclick = () => { p.testes = p.testes.filter((x) => x.id !== b.dataset.del); S.save(); APP.redesenhar(); }));
    if (params && params.novo) { params.novo = false; formTeste(p, null, params.disc); }
  };

  function planoEstudo(p, t) {
    const hoje = U.today();
    const dias = U.daysBetween(hoje, t.data);
    const temas = t.temas.map((id) => CUR.temas[id]).filter(Boolean)
      .sort((a, b) => S.nivelTema(p, a.id) - S.nivelTema(p, b.id));
    const plano = [];
    if (dias <= 1) { plano.push({ data: hoje, temas, txt: 'Revisão geral e simulação do teste' }); return plano; }
    const nDias = Math.min(dias - 1, 14);
    for (let i = 0; i < nDias; i++) plano.push({ data: U.addDays(hoje, i), temas: [], txt: '' });
    temas.forEach((tm, i) => plano[i % nDias].temas.push(tm));
    // os temas mais fracos voltam a aparecer
    if (nDias > temas.length) temas.slice(0, nDias - temas.length).forEach((tm, i) => plano[temas.length + i].temas.push(tm));
    plano.forEach((d) => { if (!d.temas.length) d.txt = 'Corrigir erros e quiz de treino'; });
    plano.push({ data: U.addDays(t.data, -1), temas: [], txt: 'Véspera: simulação do teste e descanso 😴' });
    return plano;
  }

  function cartaoTeste(p, t) {
    const d = disc(p, t.disc);
    const dias = U.daysBetween(U.today(), t.data);
    const prontidao = t.temas.length ? Math.round(t.temas.reduce((s, id) => s + Math.max(0, S.nivelTema(p, id)), 0) / t.temas.length) : 0;
    const plano = planoEstudo(p, t);
    return `<div class="card stack">
      <div class="row"><span style="font-size:32px">${d.emo}</span><div class="grow"><h3>${U.esc(d.nome)}</h3><p class="muted small" style="font-weight:800">${U.fmtDate(t.data)} · ${dias === 0 ? 'HOJE' : dias === 1 ? 'amanhã' : 'faltam ' + dias + ' dias'}</p></div><button class="iconbtn" data-edit="${t.id}">✏️</button></div>
      ${t.nota ? `<p class="small" style="font-weight:700">📝 ${U.esc(t.nota)}</p>` : ''}
      <div class="hbar"><span class="lbl">Preparação</span><span class="tr"><i style="width:${prontidao}%;background:${d.cor}"></i></span><span class="v">${prontidao}%</span></div>
      <div class="chips">${t.temas.map((id) => CUR.temas[id] ? `<button class="chip" data-tema="${id}">${U.esc(CUR.temas[id].t)} ${estrelas(S.estrelasTema(p, id))}</button>` : '').join('')}</div>
      <details><summary style="font-weight:900;cursor:pointer">🗓️ Plano de estudo</summary>
        <div style="margin-top:8px">${plano.map((x) => `<div class="plan-day ${x.data === U.today() ? 'today' : ''}"><span class="d">${U.fmtCurto(x.data)}</span><span class="small" style="font-weight:800">${x.temas.length ? x.temas.map((tm) => U.esc(tm.t)).join(' + ') + ' — resumo + quiz' : U.esc(x.txt)}</span></div>`).join('')}</div>
      </details>
      <div class="row"><button class="btn grow small" data-treino="${t.id}">💪 Treinar</button><button class="btn purple grow small" data-exame="${t.id}">📝 Simular teste</button></div>
    </div>`;
  }

  function formTeste(p, t, discInicial) {
    const novo = !t;
    t = t || { id: U.uid(), data: U.addDays(U.today(), 7), disc: discInicial || CUR.disciplinas[p.ano][0].id, temas: [], nota: '' };
    let dsel = t.disc, sel = new Set(t.temas);
    function corpo() {
      const temas = CUR.porAno[p.ano][dsel] || [];
      return `<h2>${novo ? 'Marcar teste' : 'Editar teste'}</h2>
        <div class="stack" style="margin-top:12px">
          <div class="field"><label>Disciplina</label><div class="chips" id="fd">${CUR.disciplinas[p.ano].map((d) => `<button class="chip ${d.id === dsel ? 'on' : ''}" data-d="${d.id}">${d.emo} ${d.nome}</button>`).join('')}</div></div>
          <div class="field"><label>Data</label><input type="date" class="input" id="fdata" value="${t.data}" min="${U.today()}"></div>
          <div class="field"><label>Temas que saem no teste</label><div class="chips" id="ft">${temas.map((x) => `<button class="chip ${sel.has(x.id) ? 'on' : ''}" data-t="${x.id}">${U.esc(x.t)}</button>`).join('')}</div></div>
          <div class="field"><label>Notas (opcional)</label><input class="input" id="fnota" value="${U.esc(t.nota)}" placeholder="ex.: páginas 30 a 52"></div>
          <button class="btn" id="fguardar">Guardar</button>
          ${novo ? '' : '<button class="btn danger" id="fapagar">Apagar teste</button>'}
        </div>`;
    }
    function ligar(m) {
      U.$$('#fd .chip', m).forEach((b) => (b.onclick = () => { t.data = U.$('#fdata', m).value || t.data; t.nota = U.$('#fnota', m).value; dsel = b.dataset.d; sel = new Set(); m.innerHTML = corpo(); ligar(m); }));
      U.$$('#ft .chip', m).forEach((b) => (b.onclick = () => { const id = b.dataset.t; if (sel.has(id)) sel.delete(id); else sel.add(id); b.classList.toggle('on'); }));
      U.$('#fguardar', m).onclick = () => {
        const data = U.$('#fdata', m).value;
        if (!data) return toast('Escolhe a data');
        if (!sel.size) return toast('Escolhe pelo menos um tema');
        Object.assign(t, { data, disc: dsel, temas: Array.from(sel), nota: U.$('#fnota', m).value.trim() });
        if (novo) p.testes.push(t);
        S.save(); MODAL.fechar(); APP.ir('testes');
        toast('Teste guardado! O plano de estudo está pronto 📅');
      };
      const ap = U.$('#fapagar', m);
      if (ap) ap.onclick = () => { p.testes = p.testes.filter((x) => x.id !== t.id); S.save(); MODAL.fechar(); APP.redesenhar(); };
    }
    MODAL.abrir(corpo(), ligar);
  }

  // ================================================================== ÁREA DOS PAIS
  function pedirPin(titulo, aoConfirmar) {
    let v = '';
    MODAL.abrir(`<h2 class="center">${U.esc(titulo)}</h2><div class="pindots" id="pd">${'<i></i>'.repeat(4)}</div>
      <div class="pinpad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, '⌫'].map((k) => `<button data-k="${k}">${k}</button>`).join('')}</div>`, (m) => {
      U.$$('.pinpad button', m).forEach((b) => (b.onclick = () => {
        const k = b.dataset.k;
        if (k === '⌫') v = v.slice(0, -1); else if (k !== '' && v.length < 4) v += k;
        U.$$('#pd i', m).forEach((d, i) => d.classList.toggle('f', i < v.length));
        if (v.length === 4) setTimeout(() => { const x = v; v = ''; U.$$('#pd i', m).forEach((d) => d.classList.remove('f')); aoConfirmar(x); }, 150);
      }));
    });
  }

  ECRAS.pais = function (r, params) {
    const cfg = S.cfg();
    if (!params.ok) {
      r.innerHTML = topo('Área dos pais') + `<div class="hero" style="padding-top:30px"><div class="bubble" id="bolha">Esta área é só para adultos 🔒</div>${KIKO.html('small')}</div>`;
      ligarVoltar(r); KIKO.ligar(r);
      if (!cfg.pin) {
        pedirPin('Cria um código de 4 números', (a) => pedirPin('Repete o código', (b) => {
          if (a !== b) { toast('Os códigos não coincidem'); return APP.voltar(); }
          cfg.pin = a; S.save(); MODAL.fechar(); params.ok = true; APP.redesenhar();
        }));
      } else {
        pedirPin('Código dos pais', (x) => {
          if (x !== cfg.pin) { toast('Código errado'); return; }
          MODAL.fechar(); params.ok = true; APP.redesenhar();
        });
      }
      return;
    }
    const ps = S.data.perfis;
    r.innerHTML = topo('Área dos pais') + `
      <div class="section stack">
        <h3>👨‍👩‍👧‍👦 Relatórios</h3>
        ${ps.length ? ps.map(relatorioPerfil).join('') : '<p class="muted">Ainda não há perfis.</p>'}
      </div>
      <div class="section"><div class="card stack">
        <h3>✨ Inteligência artificial (opcional)</h3>
        <p class="small muted" style="font-weight:700;line-height:1.45">Sem IA a app funciona offline com o banco de perguntas. Com IA, o Kiko responde a dúvidas livres, cria quizzes novos sobre qualquer tema do ano e explica a matéria por outras palavras. Para o Gemini, cria uma chave gratuita em aistudio.google.com (botão "Get API key").</p>
        <div class="seg" id="iaf"><button data-f="gemini" class="${cfg.ia.fornecedor !== 'claude' ? 'on' : ''}">Google Gemini</button><button data-f="claude" class="${cfg.ia.fornecedor === 'claude' ? 'on' : ''}">Anthropic Claude</button></div>
        <div class="field"><label>Chave API</label><input class="input" id="iak" type="password" value="${U.esc(cfg.ia.chave)}" placeholder="cola aqui a chave"></div>
        <div class="field"><label>Modelo (opcional)</label><input class="input" id="iam" value="${U.esc(cfg.ia.modelo)}" placeholder="${U.esc(cfg.ia.fornecedor === 'claude' ? 'claude-haiku-5-5' : 'gemini-2.5-flash')}"></div>
        <div class="row"><button class="btn grow small" id="iag">Guardar</button><button class="btn sec grow small" id="iat">Testar</button></div>
        <p class="small" id="iares" style="font-weight:800"></p>
      </div></div>
      <div class="section"><div class="card stack">
        <h3>🔊 Voz e sons</h3>
        <div class="field"><label>Velocidade da voz do Kiko: <span id="vv">${cfg.vel.toFixed(1)}</span></label><input type="range" min="0.6" max="1.4" step="0.1" value="${cfg.vel}" id="vel"></div>
        <div class="field"><label>Tom da voz: <span id="tv">${cfg.tom.toFixed(1)}</span></label><input type="range" min="0.8" max="1.6" step="0.05" value="${cfg.tom}" id="tom"></div>
        <label class="row" style="font-weight:800"><input type="checkbox" id="ler" ${cfg.lerAuto ? 'checked' : ''}> Ler as perguntas em voz alta automaticamente</label>
        <label class="row" style="font-weight:800"><input type="checkbox" id="som" ${cfg.som ? 'checked' : ''}> Efeitos sonoros</label>
        <button class="btn sec small" id="vtest">Ouvir exemplo</button>
      </div></div>
      <div class="section"><div class="card stack">
        <h3>🎯 Rotina</h3>
        <div class="field"><label>Meta diária de perguntas</label><div class="seg" id="meta">${[10, 15, 20, 30].map((n) => `<button data-n="${n}" class="${cfg.meta === n ? 'on' : ''}">${n}</button>`).join('')}</div></div>
        <div class="field"><label>Limite de tempo por dia</label><div class="seg" id="lim">${[0, 30, 45, 60, 90].map((n) => `<button data-n="${n}" class="${cfg.limiteMin === n ? 'on' : ''}">${n ? n + 'm' : 'Sem'}</button>`).join('')}</div></div>
      </div></div>
      <div class="section"><div class="card stack">
        <h3>📚 Sobre os conteúdos</h3>
        <p class="small" style="font-weight:700;line-height:1.5">Os temas, resumos e perguntas seguem as Aprendizagens Essenciais da DGE em vigor em 2026/2027 (4.º ano e 7.º ano; Matemática segundo as AE de 2021) e a terminologia dos manuais escolares. As novas AE em revisão só entram em vigor a partir de 2027/2028. Cada professor pode dar a matéria por outra ordem: use "Testes" para escolher exatamente os temas de cada teste, e o botão "Outro tema" (com IA) para matérias específicas do manual.</p>
      </div></div>
      <div class="section stack"><button class="btn sec" id="npin">Mudar código</button></div>`;
    ligarVoltar(r);
    U.$$('#iaf button', r).forEach((b) => (b.onclick = () => { cfg.ia.fornecedor = b.dataset.f; S.save(); APP.redesenhar(); }));
    const guardarIA = () => { cfg.ia.chave = U.$('#iak').value.trim(); cfg.ia.modelo = U.$('#iam').value.trim(); S.save(); };
    U.$('#iag').onclick = () => { guardarIA(); toast(cfg.ia.chave ? 'IA ligada ✨' : 'IA desligada'); };
    U.$('#iat').onclick = async () => {
      guardarIA();
      const el = U.$('#iares');
      if (!cfg.ia.chave) { el.textContent = 'Cola primeiro a chave.'; return; }
      el.innerHTML = '<span class="spinner"></span>';
      try { await IA.testar(); el.textContent = '✅ A IA está a funcionar (' + IA.modelo() + ')'; el.style.color = '#137A62'; }
      catch (e) { el.textContent = '❌ ' + e.message; el.style.color = '#B3262B'; }
    };
    U.$('#vel').oninput = (e) => { cfg.vel = +e.target.value; U.$('#vv').textContent = cfg.vel.toFixed(1); S.save(); };
    U.$('#tom').oninput = (e) => { cfg.tom = +e.target.value; U.$('#tv').textContent = cfg.tom.toFixed(1); S.save(); };
    U.$('#ler').onchange = (e) => { cfg.lerAuto = e.target.checked; S.save(); };
    U.$('#som').onchange = (e) => { cfg.som = e.target.checked; S.save(); };
    U.$('#vtest').onclick = () => VOZ.falar('Olá! Eu sou o Kiko. Vamos estudar juntos?');
    U.$$('#meta button', r).forEach((b) => (b.onclick = () => { cfg.meta = +b.dataset.n; S.save(); APP.redesenhar(); }));
    U.$$('#lim button', r).forEach((b) => (b.onclick = () => { cfg.limiteMin = +b.dataset.n; S.save(); APP.redesenhar(); }));
    U.$('#npin').onclick = () => pedirPin('Novo código', (a) => { cfg.pin = a; S.save(); MODAL.fechar(); toast('Código alterado'); });
    U.$$('[data-partilha]', r).forEach((b) => (b.onclick = () => partilhar(ps.find((x) => x.id === b.dataset.partilha))));
    U.$$('[data-apaga]', r).forEach((b) => (b.onclick = () => confirmar('Apagar o perfil e todo o progresso?', () => {
      S.data.perfis = S.data.perfis.filter((x) => x.id !== b.dataset.apaga);
      if (S.data.atual === b.dataset.apaga) S.data.atual = null;
      S.save(); APP.redesenhar();
    })));
    U.$$('[data-ano]', r).forEach((b) => (b.onclick = () => {
      const pf = ps.find((x) => x.id === b.dataset.ano);
      confirmar('Mudar ' + pf.nome + ' para o ' + (pf.ano === 4 ? 7 : 4) + '.º ano?', () => { pf.ano = pf.ano === 4 ? 7 : 4; S.save(); APP.redesenhar(); });
    }));
  };

  function confirmar(msg, sim) {
    MODAL.abrir(`<h2>${U.esc(msg)}</h2><div class="stack" style="margin-top:16px"><button class="btn danger" id="csim">Sim</button><button class="btn sec" id="cnao">Cancelar</button></div>`, (m) => {
      U.$('#csim', m).onclick = () => { MODAL.fechar(); sim(); };
      U.$('#cnao', m).onclick = MODAL.fechar;
    });
  }

  function resumoPerfil(p) {
    const semana = [];
    for (let i = 0; i < 7; i++) semana.push(p.dias[U.addDays(U.today(), -i)] || { r: 0, c: 0, seg: 0 });
    const r = semana.reduce((s, d) => s + d.r, 0), c = semana.reduce((s, d) => s + d.c, 0), seg = semana.reduce((s, d) => s + (d.seg || 0), 0);
    const temas = Object.keys(p.dominio).filter((k) => CUR.temas[k] && p.dominio[k].n >= 3).map((k) => ({ t: CUR.temas[k], v: S.nivelTema(p, k) }));
    const fracos = temas.filter((x) => x.v < 70).sort((a, b) => a.v - b.v).slice(0, 4);
    const fortes = temas.filter((x) => x.v >= 85).sort((a, b) => b.v - a.v).slice(0, 4);
    return { r, c, min: Math.round(seg / 60), fracos, fortes };
  }

  function relatorioPerfil(p) {
    const x = resumoPerfil(p);
    return `<div class="card stack">
      <div class="row"><div class="avatar" style="width:46px;height:46px;font-size:22px;background:${p.cor}">${p.emo}</div><div class="grow"><h3>${U.esc(p.nome)}</h3><p class="small muted" style="font-weight:800">${p.ano}.º ano · ⭐ ${S.saldo(p)} · 🔥 ${S.sequencia(p)} dias</p></div></div>
      <div class="statgrid"><div class="stat"><b>${x.r}</b><span>perguntas (7 dias)</span></div><div class="stat"><b>${x.r ? Math.round((100 * x.c) / x.r) : 0}%</b><span>certas</span></div><div class="stat"><b>${x.min}m</b><span>tempo (7 dias)</span></div></div>
      ${CUR.disciplinas[p.ano].map((d) => { const v = S.nivelDisc(p, d.id); return `<div class="hbar"><span class="lbl">${d.emo} ${d.nome}</span><span class="tr"><i style="width:${v}%;background:${d.cor}"></i></span><span class="v">${v}%</span></div>`; }).join('')}
      ${x.fracos.length ? `<p class="small" style="font-weight:800">⚠️ A precisar de treino: ${x.fracos.map((f) => U.esc(f.t.t) + ' (' + f.v + '%)').join(', ')}</p>` : ''}
      ${x.fortes.length ? `<p class="small" style="font-weight:800">✅ Domina: ${x.fortes.map((f) => U.esc(f.t.t)).join(', ')}</p>` : ''}
      <div class="row wrap"><button class="btn small grow" data-partilha="${p.id}">📤 Partilhar</button><button class="btn sec small grow" data-ano="${p.id}">Mudar ano</button><button class="btn danger small grow" data-apaga="${p.id}">Apagar</button></div>
    </div>`;
  }

  function partilhar(p) {
    const x = resumoPerfil(p);
    const linhas = [
      'Relatório de estudo — ' + p.nome + ' (' + p.ano + '.º ano)',
      'Últimos 7 dias: ' + x.r + ' perguntas, ' + (x.r ? Math.round((100 * x.c) / x.r) : 0) + '% certas, ' + x.min + ' minutos.',
      'Sequência: ' + S.sequencia(p) + ' dias. Estrelas: ' + S.saldo(p) + '.',
      '', 'Domínio por disciplina:'
    ].concat(CUR.disciplinas[p.ano].map((d) => '• ' + d.nome + ': ' + S.nivelDisc(p, d.id) + '%'));
    if (x.fracos.length) linhas.push('', 'A precisar de treino: ' + x.fracos.map((f) => f.t.t + ' (' + f.v + '%)').join(', '));
    const prox = p.testes.filter((t) => t.data >= U.today());
    if (prox.length) linhas.push('', 'Testes marcados: ' + prox.map((t) => disc(p, t.disc).nome + ' a ' + U.fmtDate(t.data)).join('; '));
    const txt = linhas.join('\n');
    if (NATIVO.ok) window.Android.shareText('Relatório de ' + p.nome, txt);
    else { try { navigator.clipboard.writeText(txt); } catch (e) { } toast('Relatório copiado'); }
  }

  // ================================================================== PAUSA (limite de tempo)
  ECRAS.pausa = function (r) {
    const p = S.perfil();
    r.innerHTML = `<div class="hero" style="padding-top:50px"><div class="bubble" id="bolha">Hoje já estudaste muito, ${U.esc(p.nome)}! Agora vai brincar e descansar. Amanhã há mais! 🌙</div>${KIKO.html('', p.veste)}</div>
      <div class="section stack"><button class="btn sec" id="pmais">🔒 Mais 15 minutos (adulto)</button><button class="btn" id="ptroca">Trocar de perfil</button></div>`;
    KIKO.ligar(r);
    setTimeout(() => KIKO.dizer('Hoje já estudaste muito! Agora vai descansar. Amanhã há mais!'), 300);
    U.$('#ptroca').onclick = () => { S.data.atual = null; S.save(); APP.ir('perfis'); };
    U.$('#pmais').onclick = () => pedirPin('Código dos pais', (x) => {
      if (x !== S.cfg().pin) return toast('Código errado');
      MODAL.fechar(); const d = S.dia(p); d.extra = (d.extra || 0) + 15; S.save(); APP.ir('inicio');
    });
  };
})();
