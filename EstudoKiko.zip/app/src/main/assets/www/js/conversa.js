/* Conversa com o Kiko: interpreta o que a criança diz (offline) e, se preciso, pergunta à IA */
(function () {
  'use strict';

  const historico = [];   // { quem: 'eu'|'kiko', texto }

  const PAL = {
    quiz: ['quiz', 'quizz', 'kiss', 'perguntas', 'pergunta me', 'pergunta-me', 'desafio', 'testa me', 'testa-me', 'testar', 'treinar', 'exercicios', 'praticar', 'fazer perguntas', 'jogo'],
    cartoes: ['cartoes', 'cartas', 'flashcards', 'flash cards', 'cartao'],
    resumo: ['resumo', 'explica', 'explicar', 'ensina', 'ensinar', 'aprender', 'aprende', 'rever', 'revisao', 'estudar', 'lembrar', 'o que e', 'o que sao'],
    erros: ['meus erros', 'os erros', 'errei', 'enganei', 'corrigir erros', 'rever erros'],
    surpresa: ['surpresa', 'qualquer coisa', 'aleatorio', 'tanto faz', 'escolhe tu'],
    progresso: ['estrelas', 'progresso', 'pontos', 'medalhas', 'loja'],
    teste: ['tenho teste', 'tenho um teste', 'vou ter teste', 'vou ter um teste', 'ficha de avaliacao', 'teste marcado', 'marcar teste', 'tenho uma ficha']
  };
  const VAZIAS = new Set('a o as os um uma uns umas de do da dos das e em no na nos nas para por com quero queria gostava vamos kiko eu me te se que sobre isso esta este essa esse ola favor podes pode fazer agora hoje'.split(' '));

  function contem(frase, lista) { return lista.some((p) => (' ' + frase + ' ').indexOf(' ' + p + ' ') >= 0); }

  function detetarDisc(frase, ano) {
    let melhor = null;
    (CUR.disciplinas[ano] || []).forEach((d) => {
      (CUR.palavrasDisc[d.id] || []).forEach((p) => {
        if ((' ' + frase + ' ').indexOf(' ' + p + ' ') >= 0 && (!melhor || p.length > melhor.len)) melhor = { id: d.id, len: p.length };
      });
    });
    return melhor && melhor.id;
  }

  function procurarTema(frase, ano, disc) {
    const palavras = frase.split(' ').filter((w) => w.length > 2 && !VAZIAS.has(w));
    let melhor = null, pont = 0;
    (CUR.disciplinas[ano] || []).forEach((d) => {
      if (disc && d.id !== disc) return;
      (CUR.porAno[ano][d.id] || []).forEach((t) => {
        let s = 0;
        const chaves = (t.k || '').split(',').map((x) => U.norm(x)).filter(Boolean);
        chaves.forEach((c) => { if ((' ' + frase + ' ').indexOf(' ' + c + ' ') >= 0) s += 2 + c.split(' ').length; });
        const tit = U.norm(t.t).split(' ').filter((w) => w.length > 3 && !VAZIAS.has(w));
        palavras.forEach((w) => {
          if (tit.indexOf(w) >= 0) s += 1.5;
          else if (w.length > 4 && tit.some((x) => x.slice(0, 5) === w.slice(0, 5))) s += 1;
        });
        if (s > pont) { pont = s; melhor = t; }
      });
    });
    return pont >= 2.5 ? melhor : null;
  }

  function nomeTema(t) { return t.t; }

  const C = (window.CONVERSA = {});
  C.historico = historico;
  C.limpar = () => { historico.length = 0; };

  C.registar = function (quem, texto) {
    historico.push({ quem, texto });
    if (historico.length > 30) historico.shift();
    const box = U.$('#chat');
    if (box) {
      const d = document.createElement('div');
      d.className = 'msg ' + (quem === 'eu' ? 'me' : 'kiko');
      d.textContent = texto;
      box.appendChild(d);
      box.scrollTop = box.scrollHeight;
    }
  };

  function botoes(lista) {
    const a = U.$('#acoes');
    if (!a) return;
    a.innerHTML = lista.map((b, i) => `<button class="chip" data-i="${i}">${b.txt}</button>`).join('');
    U.$$('button', a).forEach((el) => el.addEventListener('click', () => { a.innerHTML = ''; lista[+el.dataset.i].fn(); }));
  }
  C.botoes = botoes;

  function oferecerTema(t, msg) {
    KIKO.reagir('happy');
    KIKO.dizer(msg || ('Boa! Vamos estudar ' + nomeTema(t) + '. Queres um resumo, um quiz ou cartões?'));
    botoes([
      { txt: '📚 Resumo', fn: () => APP.ir('tema', { id: t.id }) },
      { txt: '❓ Quiz', fn: () => QUIZ.iniciarTema(t.id) },
      { txt: '🃏 Cartões', fn: () => APP.ir('cartoes', { id: t.id }) }
    ]);
  }

  function agir(acao, t) {
    if (acao === 'quiz') { KIKO.dizer('Vamos a isso! Quiz de ' + nomeTema(t) + '.'); setTimeout(() => QUIZ.iniciarTema(t.id), 900); }
    else if (acao === 'cartoes') { KIKO.dizer('Cartões de ' + nomeTema(t) + '! Tenta lembrar antes de virar.'); setTimeout(() => APP.ir('cartoes', { id: t.id }), 900); }
    else { APP.ir('tema', { id: t.id, falar: true }); }
  }

  /** Ponto de entrada: a criança disse/escreveu algo. */
  C.processar = async function (textoOriginal) {
    const p = S.perfil();
    if (!p || !textoOriginal) return;
    C.registar('eu', textoOriginal);
    const f = U.norm(textoOriginal);
    const acao = contem(f, PAL.quiz) ? 'quiz' : contem(f, PAL.cartoes) ? 'cartoes' : contem(f, PAL.resumo) ? 'resumo' : null;

    // comandos diretos
    if (contem(f, PAL.erros)) {
      const n = QUIZ.errosPendentes(p).length;
      if (!n) { KIKO.reagir('happy'); return KIKO.dizer('Não tens erros para rever. Estás a ir muito bem!'); }
      KIKO.dizer('Vamos corrigir ' + n + (n === 1 ? ' erro' : ' erros') + '. Tu consegues!');
      return setTimeout(() => QUIZ.iniciarErros(), 900);
    }
    if (contem(f, PAL.teste)) {
      const d = detetarDisc(f, p.ano);
      KIKO.dizer('Vamos marcar esse teste para eu te ajudar a preparar. Escolhe a data e os temas.');
      return setTimeout(() => APP.ir('testes', { novo: true, disc: d }), 900);
    }
    if (contem(f, PAL.progresso) && !acao) { return APP.ir('progresso'); }

    const disc = detetarDisc(f, p.ano);
    const t = procurarTema(f, p.ano, disc) || (disc ? null : procurarTema(f, p.ano, null));

    if (t) { if (acao) return agir(acao, t); return oferecerTema(t); }

    if (contem(f, PAL.surpresa) || (acao === 'quiz' && !disc && !IA.ativa())) {
      KIKO.dizer('Quiz surpresa! Vou misturar temas do teu ano.');
      return setTimeout(() => QUIZ.iniciarSurpresa(disc), 900);
    }

    // IA para o resto
    if (IA.ativa()) {
      KIKO.estado('thinking', true);
      KIKO.balao('<span class="spinner"></span>');
      try {
        const r = await IA.conversar(p, historico.slice(0, -1), textoOriginal);
        KIKO.estado('thinking', false);
        const tema = r.tema && CUR.temas[r.tema] && CUR.temas[r.tema].ano === p.ano ? CUR.temas[r.tema] : null;
        if (r.acao && r.acao !== 'nenhuma' && tema && r.acao !== 'quiz_livre') {
          await KIKO.dizer(r.fala || ('Vamos estudar ' + tema.t + '.'));
          return agir(r.acao === 'resumo' ? null : r.acao, tema);
        }
        if (r.acao === 'quiz_livre' && r.tema_livre) {
          await KIKO.dizer(r.fala || ('Vou criar um quiz sobre ' + r.tema_livre + '.'));
          const dd = (CUR.disciplinas[p.ano] || []).find((x) => x.id === r.disciplina) ? r.disciplina : (disc || CUR.disciplinas[p.ano][0].id);
          return QUIZ.iniciarIA(dd, r.tema_livre, null);
        }
        KIKO.dizer(r.fala || 'Hum... não sei bem. Podes perguntar de outra forma?');
        if (disc) botoes([{ txt: 'Ver temas de ' + (CUR.disciplinas[p.ano].find((x) => x.id === disc) || {}).nome, fn: () => APP.ir('disciplina', { disc }) }]);
        return;
      } catch (e) {
        KIKO.estado('thinking', false);
        toast(e.message);
      }
    }

    if (disc) {
      const dn = CUR.disciplinas[p.ano].find((x) => x.id === disc);
      KIKO.dizer('Boa, ' + dn.nome + '! Que tema queres estudar? Escolhe aqui.');
      return setTimeout(() => APP.ir('disciplina', { disc }), 900);
    }
    KIKO.reagir('sad', 1500);
    KIKO.dizer('Hum, não encontrei esse tema. Experimenta dizer, por exemplo: "quero estudar ' + exemplo(p.ano) + '", ou escolhe uma disciplina.');
  };

  function exemplo(ano) {
    return ano === 4 ? U.pick(['as frações', 'os rios de Portugal', 'os verbos', 'o sistema solar']) : U.pick(['as equações', 'os vulcões', 'a Grécia antiga', 'as misturas']);
  }

  // usado pelos testes e pela voz durante o quiz
  C._procurarTema = procurarTema;
  C._detetarDisc = detetarDisc;
})();
