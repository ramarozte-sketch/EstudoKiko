/* Motivação: níveis, missões do dia com baú, sequências de respostas certas e jogos de aprender */
(function () {
  'use strict';

  const topo = (titulo) => `<div class="topbar"><button class="iconbtn" data-voltar>←</button><h2>${U.esc(titulo)}</h2></div>`;
  const voltar = (r) => U.$$('[data-voltar]', r).forEach((b) => (b.onclick = () => APP.voltar()));

  // ------------------------------------------------------------ níveis (pelas respostas certas acumuladas)
  const NIVEIS = [
    { n: 0, e: '🥚', t: 'Ovo curioso' }, { n: 30, e: '🐣', t: 'Pintainho' }, { n: 80, e: '🐤', t: 'Passarinho' },
    { n: 160, e: '🦜', t: 'Caturra esperta' }, { n: 280, e: '🧭', t: 'Explorador' }, { n: 450, e: '🔭', t: 'Cientista' },
    { n: 700, e: '🦉', t: 'Sábio' }, { n: 1000, e: '🏆', t: 'Campeão' }, { n: 1400, e: '🚀', t: 'Astronauta do saber' },
    { n: 2000, e: '👑', t: 'Génio' }
  ];
  const certasTotal = (p) => Object.values(p.dias || {}).reduce((a, d) => a + (d.c || 0), 0);
  const J = (window.JOGOS = {});
  J.nivel = function (p) {
    const c = certasTotal(p);
    let i = 0; while (i + 1 < NIVEIS.length && c >= NIVEIS[i + 1].n) i++;
    const atual = NIVEIS[i], prox = NIVEIS[i + 1];
    return { i: i + 1, e: atual.e, t: atual.t, c, prox, pct: prox ? Math.round((100 * (c - atual.n)) / (prox.n - atual.n)) : 100 };
  };

  // ------------------------------------------------------------ missões do dia
  const MISSOES = [
    { id: 'r10', e: '❓', t: 'Responde a 10 perguntas', alvo: 10, v: (p, d) => d.r || 0 },
    { id: 'c8', e: '✅', t: 'Acerta 8 respostas', alvo: 8, v: (p, d) => d.c || 0 },
    { id: 'seq5', e: '🔥', t: 'Acerta 5 seguidas num quiz', alvo: 5, v: (p, d) => d.melhorSeq || 0 },
    { id: 'resumo', e: '📖', t: 'Ouve um resumo até ao fim', alvo: 1, v: (p, d) => d.resumos || 0 },
    { id: 'jogo', e: '🎮', t: 'Joga um jogo de aprender', alvo: 1, v: (p, d) => d.jogos || 0 },
    { id: 'disc2', e: '📚', t: 'Estuda 2 disciplinas diferentes', alvo: 2, v: (p, d) => (d.discs || []).length },
    { id: 'erros', e: '🩹', t: 'Corrige 2 erros antigos', alvo: 2, v: (p, d) => d.corr || 0, so: (p) => Object.keys(p.erros || {}).length >= 2 },
    { id: 'kiko', e: '🌻', t: 'Dá sementes ao ' + 'Kiko', alvo: 1, v: (p, d) => d.comeu || 0 },
    { id: 'relampago', e: '⚡', t: 'Faz 8 pontos no Desafio relâmpago', alvo: 8, v: (p, d) => d.relampago || 0 }
  ];
  J.missoes = function (p) {
    const d = S.dia(p);
    if (!d.missoes) {
      const seed = U.hash(U.today() + (p.id || p.nome));
      let n = parseInt(seed, 36) || 7;
      const pool = MISSOES.filter((m) => !m.so || m.so(p));
      const esc = [];
      // a primeira missão é sempre de responder perguntas; as outras variam todos os dias
      esc.push(pool.find((m) => m.id === 'r10'));
      const resto = pool.filter((m) => m.id !== 'r10');
      while (esc.length < 3 && resto.length) { const k = n % resto.length; esc.push(resto.splice(k, 1)[0]); n = Math.floor(n / 7) + 13; }
      d.missoes = esc.map((m) => m.id);
      S.save();
    }
    return d.missoes.map((id) => MISSOES.find((m) => m.id === id)).filter(Boolean).map((m) => {
      const v = Math.min(m.alvo, m.v(p, d));
      return { id: m.id, e: m.e, t: m.id === 'kiko' ? 'Dá sementes ' + (KIKO.o() === 'a' ? 'à ' : 'ao ') + KIKO.nome() : m.t, v, alvo: m.alvo, ok: v >= m.alvo };
    });
  };
  J.html = function (p) {
    const ms = J.missoes(p), d = S.dia(p), todas = ms.every((m) => m.ok), nv = J.nivel(p);
    return `<div class="card missoes">
      <div class="row" style="justify-content:space-between;align-items:center"><h3>🎯 Missões de hoje</h3>
        <span class="pill nivel" title="Nível">${nv.e} Nível ${nv.i}</span></div>
      ${ms.map((m) => `<div class="missao ${m.ok ? 'ok' : ''}"><span class="me">${m.ok ? '✅' : m.e}</span><span class="grow">${U.esc(m.t)}</span>
        <span class="mv">${m.alvo > 1 ? m.v + '/' + m.alvo : ''}</span><span class="mbar"><i style="width:${Math.round((100 * m.v) / m.alvo)}%"></i></span></div>`).join('')}
      ${d.bau ? '<p class="small muted" style="font-weight:800;margin-top:6px">🎉 Baú aberto! Volta amanhã para novas missões.</p>'
        : `<button class="btn ${todas ? '' : 'sec'} small" id="bbau" ${todas ? '' : 'disabled'} style="margin-top:8px">${todas ? '🎁 Abrir o baú!' : '🔒 Baú: completa as 3 missões'}</button>`}
    </div>`;
  };
  J.ligar = function (r, p) {
    const b = U.$('#bbau', r);
    if (b) b.onclick = () => {
      const d = S.dia(p);
      if (d.bau || !J.missoes(p).every((m) => m.ok)) return;
      d.bau = true;
      const n = 10 + Math.floor(Math.random() * 11);
      p.estrelas += n; S.save();
      confettis(); SOM.festa();
      MODAL.abrir(`<div style="text-align:center"><div class="bau-anim">🧰</div><h2>Baú do dia</h2><p style="font-weight:900;font-size:22px;margin:10px 0">+${n} ⭐</p>
        <p class="muted" style="font-weight:700">Completaste todas as missões de hoje!</p><button class="btn" id="bok" style="margin-top:12px">Boa! 🎉</button></div>`,
      (m) => { U.$('#bok', m).onclick = () => { MODAL.fechar(); APP.redesenhar(); }; });
      VOZ.falar('Abriste o baú! Ganhaste ' + n + ' estrelas. És incrível!');
    };
    U.$$('[data-jogos]', r).forEach((x) => (x.onclick = () => APP.ir('jogos')));
  };

  // ------------------------------------------------------------ chamado pelo quiz a cada resposta
  J.registar = function (q, certa, sess) {
    const p = S.perfil(), d = S.dia(p);
    const t = CUR.temas[q.tema];
    if (t && t.disc && t.disc !== 'festa') { d.discs = d.discs || []; if (d.discs.indexOf(t.disc) < 0) d.discs.push(t.disc); }
    sess.seq = certa ? (sess.seq || 0) + 1 : 0;
    d.melhorSeq = Math.max(d.melhorSeq || 0, sess.seq);
    let msg = null;
    if (certa && [3, 5, 10, 15, 20].indexOf(sess.seq) >= 0) {
      const bonus = sess.seq >= 10 ? 3 : sess.seq >= 5 ? 1 : 0;
      if (bonus) { p.estrelas += bonus; sess.ganhas += bonus; }
      msg = '🔥 ' + sess.seq + ' seguidas!' + (bonus ? ' +' + bonus + ' ⭐' : '');
    }
    // subir de nível
    const antes = p._nivel || J.nivel(p).i;
    const agora = J.nivel(p);
    p._nivel = agora.i;
    if (agora.i > antes) setTimeout(() => {
      confettis(); SOM.festa();
      toast(agora.e + ' Subiste para o nível ' + agora.i + ': ' + agora.t + '!');
      VOZ.falar('Uau! Subiste para o nível ' + agora.i + '. Agora és ' + agora.t + '!');
    }, 900);
    return msg;
  };
  J.mostrarSeq = function (msg) {
    if (!msg) return;
    const el = document.createElement('div');
    el.className = 'combo'; el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1600);
  };

  // ------------------------------------------------------------ banco de perguntas para os jogos
  function banco(p, disc, filtro) {
    const out = [];
    (CUR.disciplinas[p.ano] || []).forEach((d) => {
      if (disc && d.id !== disc) return;
      (CUR.porAno[p.ano][d.id] || []).forEach((t) => {
        (t.q || []).forEach((raw) => { const q = QUIZ.daTabela(t, raw); q.disc = d.id; if (!filtro || filtro(q)) out.push(q); });
        if (t.gen && GERADORES[t.gen] && (!filtro || filtro.gerar)) GERADORES[t.gen](3).forEach((q) => { q.tema = t.id; q.disc = d.id; if (!filtro || filtro(q)) out.push(q); });
      });
    });
    return U.shuffle(out);
  }
  function escolherDisc(p, sel) {
    return `<div class="chips" id="jdisc"><button class="chip ${!sel ? 'on' : ''}" data-d="">🌈 Tudo</button>${CUR.disciplinas[p.ano].map((d) => `<button class="chip ${sel === d.id ? 'on' : ''}" data-d="${d.id}">${d.emo} ${U.esc(d.nome)}</button>`).join('')}</div>`;
  }
  function premiar(p, n, motivo) {
    const d = S.dia(p);
    d.jogos = (d.jogos || 0) + 1;
    if (n > 0) p.estrelas += n;
    S.save();
    if (n > 0) toast('⭐ +' + n + ' ' + motivo);
  }

  // ------------------------------------------------------------ ecrã dos jogos
  ECRAS.jogos = function (r) {
    const p = S.perfil();
    const rec = p.recordes || {};
    const nv = J.nivel(p);
    r.innerHTML = topo('🎮 Jogos de aprender') + `
      <div class="section"><div class="card nivelcard"><div class="row" style="align-items:center;gap:12px"><span style="font-size:44px">${nv.e}</span>
        <div class="grow"><b style="font-size:18px">Nível ${nv.i} · ${U.esc(nv.t)}</b><div class="tbar" style="margin-top:6px"><i style="width:${nv.pct}%;background:var(--pri)"></i></div>
        <span class="small muted" style="font-weight:800">${nv.prox ? 'Faltam ' + (nv.prox.n - nv.c) + ' respostas certas para ' + nv.prox.e + ' ' + nv.prox.t : 'Nível máximo! 🎉'}</span></div></div></div></div>
      <div class="section jogos-lista">
        <button class="jogo" data-j="relampago" style="--jc:#FF9F1C"><span class="je">⚡</span><b>Desafio relâmpago</b><span>60 segundos para acertar o máximo!</span><span class="jr">🏅 Recorde: ${rec.relampago || 0}</span></button>
        <button class="jogo" data-j="memoria" style="--jc:#9B5DE5"><span class="je">🧠</span><b>Jogo da memória</b><span>Encontra os pares pergunta ↔ resposta.</span><span class="jr">🏅 Melhor: ${rec.memoria ? rec.memoria + ' jogadas' : '—'}</span></button>
        <button class="jogo" data-j="vf" style="--jc:#2EC4A0"><span class="je">✅</span><b>Verdadeiro ou falso?</b><span>Decide depressa: 10 afirmações.</span><span class="jr">🏅 Recorde: ${rec.vf || 0}/10</span></button>
      </div>`;
    voltar(r);
    U.$$('.jogo', r).forEach((b) => (b.onclick = () => APP.ir('jogo_' + b.dataset.j)));
    KIKO.ligar(r);
  };

  // ------------------------------------------------------------ ⚡ desafio relâmpago
  ECRAS.jogo_relampago = function (r, params) {
    const p = S.perfil();
    const disc = (params && params.disc) || '';
    r.innerHTML = topo('⚡ Desafio relâmpago') + `<div class="section stack">
      <p class="muted" style="font-weight:800">Tens 60 segundos. Cada resposta certa vale 1 ponto e as seguidas dão bónus de tempo!</p>
      ${escolherDisc(p, disc)}<button class="btn" id="rgo">▶️ Começar</button></div>`;
    voltar(r);
    U.$$('#jdisc .chip', r).forEach((b) => (b.onclick = () => APP.ir('jogo_relampago', { disc: b.dataset.d }, true)));
    U.$('#rgo', r).onclick = () => jogar();

    function jogar() {
      const f = (q) => q.p.length <= 130 && [q.certa].concat(q.erradas).every((o) => String(o).length <= 45);
      f.gerar = true;
      const lista = banco(p, disc, f);
      if (!lista.length) return toast('Ainda não há perguntas para isto.');
      let i = 0, pts = 0, seq = 0, fim = Date.now() + 60000, timer = null, bloqueado = false;
      VOZ.parar();
      const desenhar = () => {
        const q = lista[i % lista.length];
        const ops = q.tf ? ['Verdadeiro', 'Falso'] : U.shuffle([q.certa].concat(U.shuffle(q.erradas).slice(0, 3)));
        r.innerHTML = `<div class="topbar"><button class="iconbtn" data-voltar>✕</button><h2>⚡ ${pts} pts</h2><span class="pill timer" id="rt">60</span></div>
          <div class="section"><div class="tbar relbar"><i id="rbar" style="width:100%"></i></div>
          <div class="qcard card" style="margin-top:12px"><div style="font-weight:900;font-size:19px;line-height:1.35">${U.esc(q.p)}</div></div>
          <div class="opts" style="margin-top:12px">${ops.map((o, k) => `<button class="opt" data-k="${k}"><span class="l">${'ABCD'[k]}</span><span>${U.esc(o)}</span></button>`).join('')}</div></div>`;
        U.$$('[data-voltar]', r).forEach((b) => (b.onclick = () => { clearInterval(timer); APP.voltar(); }));
        U.$$('.opt', r).forEach((b) => (b.onclick = () => {
          if (bloqueado) return;
          bloqueado = true;
          const certa = ops[+b.dataset.k] === q.certa;
          if (certa) { pts++; seq++; SOM.certo(); b.classList.add('right'); if (seq % 4 === 0) { fim += 5000; J.mostrarSeq('🔥 ' + seq + ' seguidas! +5 s'); } }
          else { seq = 0; SOM.errado(); b.classList.add('wrong'); U.$$('.opt', r)[ops.indexOf(q.certa)].classList.add('right'); }
          setTimeout(() => { bloqueado = false; i++; desenhar(); }, certa ? 350 : 900);
        }));
        if (window.TV && TV.ativo) TV.focoInicial(r);
      };
      const tic = () => {
        const el = U.$('#rt');
        if (!el) { clearInterval(timer); return; }
        const rest = Math.max(0, Math.ceil((fim - Date.now()) / 1000));
        el.textContent = rest + ' s';
        const bar = U.$('#rbar'); if (bar) bar.style.width = Math.min(100, (100 * rest) / 60) + '%';
        if (rest <= 0) { clearInterval(timer); acabar(); }
      };
      const acabar = () => {
        const d = S.dia(p);
        d.relampago = Math.max(d.relampago || 0, pts);
        p.recordes = p.recordes || {};
        const recorde = pts > (p.recordes.relampago || 0);
        if (recorde) p.recordes.relampago = pts;
        premiar(p, Math.floor(pts / 3), 'no Desafio relâmpago');
        r.innerHTML = topo('⚡ Desafio relâmpago') + `<div class="hero"><div class="bubble" id="bolha">${recorde ? 'Novo recorde! 🏅' : 'Muito bem!'} Fizeste ${pts} ${pts === 1 ? 'ponto' : 'pontos'}.</div>${KIKO.html('', p.veste)}</div>
          <div class="section stack"><button class="btn" id="rmais">🔁 Jogar outra vez</button><button class="btn sec" data-voltar>Voltar aos jogos</button></div>`;
        voltar(r); KIKO.ligar(r);
        if (recorde && pts) { confettis(); SOM.festa(); KIKO.reagir('happy', 2500); }
        KIKO.dizer((recorde && pts ? 'Novo recorde! ' : 'Muito bem! ') + 'Fizeste ' + pts + ' pontos.');
        U.$('#rmais', r).onclick = () => APP.ir('jogo_relampago', { disc }, true);
      };
      desenhar(); timer = setInterval(tic, 250);
    }
  };

  // ------------------------------------------------------------ 🧠 jogo da memória
  ECRAS.jogo_memoria = function (r, params) {
    const p = S.perfil();
    const disc = (params && params.disc) || '';
    const f = (q) => !q.tf && q.p.length <= 70 && String(q.certa).length <= 26;
    const pares = banco(p, disc, f).filter((q, i, a) => a.findIndex((x) => x.certa === q.certa) === i).slice(0, 6);
    if (pares.length < 3) { r.innerHTML = topo('🧠 Jogo da memória') + '<div class="section"><p>Ainda não há pares suficientes para esta disciplina.</p></div>'; voltar(r); return; }
    const cartas = U.shuffle(pares.flatMap((q, i) => [{ par: i, txt: q.p, tipo: 'p' }, { par: i, txt: q.certa, tipo: 'r' }]));
    let abertas = [], feitos = 0, jogadas = 0, bloq = false;
    r.innerHTML = topo('🧠 Jogo da memória') + `<div class="section stack">${escolherDisc(p, disc)}
      <p class="muted small" style="font-weight:800">Vira duas cartas: uma pergunta e a sua resposta. <span id="mj">Jogadas: 0</span></p>
      <div class="memoria">${cartas.map((c, i) => `<button class="mcarta ${c.tipo}" data-i="${i}"><span class="frente">${c.tipo === 'p' ? '❓' : '💡'}</span><span class="verso">${U.esc(c.txt)}</span></button>`).join('')}</div></div>`;
    voltar(r);
    U.$$('#jdisc .chip', r).forEach((b) => (b.onclick = () => APP.ir('jogo_memoria', { disc: b.dataset.d }, true)));
    U.$$('.mcarta', r).forEach((b) => (b.onclick = () => {
      const i = +b.dataset.i;
      if (bloq || b.classList.contains('aberta') || b.classList.contains('feita')) return;
      b.classList.add('aberta'); SOM.clique();
      abertas.push({ b, c: cartas[i] });
      if (abertas.length < 2) return;
      jogadas++; U.$('#mj').textContent = 'Jogadas: ' + jogadas;
      const [a1, a2] = abertas; abertas = [];
      if (a1.c.par === a2.c.par && a1.c.tipo !== a2.c.tipo) {
        [a1, a2].forEach((x) => { x.b.classList.add('feita'); x.b.classList.remove('aberta'); });
        feitos++; SOM.certo();
        if (feitos === pares.length) setTimeout(() => {
          p.recordes = p.recordes || {};
          const melhor = !p.recordes.memoria || jogadas < p.recordes.memoria;
          if (melhor) p.recordes.memoria = jogadas;
          const n = jogadas <= pares.length + 2 ? 6 : jogadas <= pares.length * 2 ? 4 : 2;
          premiar(p, n, 'no Jogo da memória');
          confettis(); SOM.festa();
          MODAL.abrir(`<div style="text-align:center"><div style="font-size:56px">🧠</div><h2>Conseguiste!</h2><p style="font-weight:800;margin:8px 0">${jogadas} jogadas${melhor ? ' — novo recorde! 🏅' : ''}</p><p style="font-weight:900">+${n} ⭐</p>
            <div class="row" style="gap:8px;margin-top:12px"><button class="btn" id="mm">🔁 Outra vez</button><button class="btn sec" id="mv">Sair</button></div></div>`, (m) => {
            U.$('#mm', m).onclick = () => { MODAL.fechar(); APP.ir('jogo_memoria', { disc }, true); };
            U.$('#mv', m).onclick = () => { MODAL.fechar(); APP.voltar(); };
          });
          VOZ.falar('Encontraste todos os pares em ' + jogadas + ' jogadas!');
        }, 500);
      } else {
        bloq = true; SOM.errado();
        setTimeout(() => { [a1, a2].forEach((x) => x.b.classList.remove('aberta')); bloq = false; }, 1100);
      }
    }));
  };

  // ------------------------------------------------------------ ✅ verdadeiro ou falso
  ECRAS.jogo_vf = function (r, params) {
    const p = S.perfil();
    const disc = (params && params.disc) || '';
    // afirmações: as V/F do banco e outras feitas com pergunta + resposta (certa ou errada)
    const base = banco(p, disc, (q) => q.p.length <= 110);
    const lista = [];
    base.forEach((q) => {
      if (lista.length >= 10) return;
      if (q.tf) lista.push({ txt: q.p, v: q.certa === 'Verdadeiro', exp: q.exp, disc: q.disc });
      else if (/[?…]$/.test(q.p.trim()) && String(q.certa).length <= 40) {
        const verdade = Math.random() < 0.5;
        const resp = verdade ? q.certa : U.pick(q.erradas);
        lista.push({ txt: q.p.replace(/\s*[?…]$/, '') + ' → ' + resp, v: verdade, exp: 'Resposta certa: ' + q.certa, disc: q.disc });
      }
    });
    let i = 0, pts = 0;
    const desenhar = () => {
      if (i >= lista.length) return acabar();
      const a = lista[i];
      r.innerHTML = topo('✅ Verdadeiro ou falso?') + `<div class="section stack">${i === 0 ? escolherDisc(p, disc) : ''}
        <div class="qprog"><i style="width:${(100 * i) / lista.length}%"></i></div>
        <div class="card vfcard"><div class="small muted" style="font-weight:800">Afirmação ${i + 1} de ${lista.length}</div><div style="font-weight:900;font-size:20px;margin-top:6px;line-height:1.35">${U.esc(a.txt)}</div></div>
        <div class="row" style="gap:10px"><button class="btn ok grow" id="vv">👍 Verdadeiro</button><button class="btn danger grow" id="vfx">👎 Falso</button></div>
        <div id="vfb"></div></div>`;
      voltar(r);
      U.$$('#jdisc .chip', r).forEach((b) => (b.onclick = () => APP.ir('jogo_vf', { disc: b.dataset.d }, true)));
      const resp = (v) => {
        const ok = v === a.v;
        if (ok) { pts++; SOM.certo(); } else SOM.errado();
        U.$('#vv').disabled = U.$('#vfx').disabled = true;
        U.$('#vfb').innerHTML = `<div class="feedback ${ok ? 'ok' : 'bad'} fade-in">${ok ? '✅ Boa!' : '❌ Era ' + (a.v ? 'verdadeiro' : 'falso') + '.'}${!ok && a.exp ? '<div style="margin-top:6px;font-weight:700">💡 ' + U.esc(a.exp) + '</div>' : ''}</div>
          <button class="btn" id="vnext" style="margin-top:10px">${i + 1 < lista.length ? 'Seguinte ➜' : 'Ver resultado 🏁'}</button>`;
        U.$('#vnext').onclick = () => { i++; desenhar(); };
        if (window.TV && TV.ativo) U.$('#vnext').focus();
      };
      U.$('#vv').onclick = () => resp(true);
      U.$('#vfx').onclick = () => resp(false);
      VOZ.falarAuto(a.txt.replace('→', ': '), a.disc);
    };
    const acabar = () => {
      p.recordes = p.recordes || {};
      const recorde = pts > (p.recordes.vf || 0);
      if (recorde) p.recordes.vf = pts;
      premiar(p, Math.floor(pts / 2), 'no Verdadeiro ou falso');
      r.innerHTML = topo('✅ Verdadeiro ou falso?') + `<div class="hero"><div class="bubble" id="bolha">Acertaste ${pts} de ${lista.length}!${recorde ? ' Novo recorde! 🏅' : ''}</div>${KIKO.html('', p.veste)}</div>
        <div class="section stack"><button class="btn" id="vmais">🔁 Jogar outra vez</button><button class="btn sec" data-voltar>Voltar aos jogos</button></div>`;
      voltar(r); KIKO.ligar(r);
      if (pts >= 7) { confettis(); SOM.festa(); KIKO.reagir('happy', 2500); }
      KIKO.dizer(pts >= 7 ? 'Fantástico! ' + pts + ' em ' + lista.length + '!' : 'Boa! Fizeste ' + pts + ' pontos. Vamos outra vez?');
      U.$('#vmais', r).onclick = () => APP.ir('jogo_vf', { disc }, true);
    };
    if (!lista.length) { r.innerHTML = topo('✅ Verdadeiro ou falso?') + '<div class="section"><p>Ainda não há afirmações para isto.</p></div>'; voltar(r); return; }
    desenhar();
  };
})();
