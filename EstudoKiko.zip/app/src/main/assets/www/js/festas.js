/* Festas do calendário português, aniversário e brincadeiras com o Kiko */
(function () {
  'use strict';

  // ------------------------------------------------------------ datas
  function pascoa(ano) { // algoritmo de Meeus/Jones/Butcher (calendário gregoriano)
    const a = ano % 19, b = Math.floor(ano / 100), c = ano % 100, d = Math.floor(b / 4), e = b % 4;
    const f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
    const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451);
    const mes = Math.floor((h + l - 7 * m + 114) / 31), dia = ((h + l - 7 * m + 114) % 31) + 1;
    return new Date(ano, mes - 1, dia, 12);
  }
  const dia = (ano, mes, d) => new Date(ano, mes - 1, d, 12);
  const mais = (dt, n) => new Date(dt.getFullYear(), dt.getMonth(), dt.getDate() + n, 12);
  function primeiroDomingoMaio(ano) { let d = dia(ano, 5, 1); while (d.getDay() !== 0) d = mais(d, 1); return d; }

  // cada festa: janela de dias (de, ate), presente (itens + estrelas), decoração e um pequeno quiz
  const FESTAS = [
    {
      id: 'halloween', nome: 'Halloween e Pão-por-Deus', emo: '🎃', deco: '🎃 👻 🦇 🍬 🕸️', cor: '#7B3FC4',
      janela: (a) => [dia(a, 10, 25), dia(a, 11, 1)], itens: ['bruxa', 'abobora'],
      fala: (n) => 'Buuu! Assustei-te? É tempo de Halloween e, a 1 de novembro, de Pão-por-Deus! Abre o presente que tenho para ti, ' + n + '!',
      q: [
        ['No dia do Pão-por-Deus, o que fazem as crianças em Portugal?', ['vão de porta em porta pedir doces, frutos secos ou pão', 'cantam as Janeiras', 'saltam fogueiras', 'comem 12 passas'], 'O Pão-por-Deus é a 1 de novembro, Dia de Todos os Santos.'],
        ['Em que dia é o Pão-por-Deus?', ['1 de novembro', '31 de dezembro', '6 de janeiro', '11 de novembro']],
        ['Com que legume se fazem as lanternas de Halloween?', ['abóbora', 'cenoura', 'couve', 'batata']],
        ['O Halloween celebra-se na noite de…', ['31 de outubro', '24 de dezembro', '13 de junho', '1 de junho']],
        ['O dia 1 de novembro é o Dia de Todos os Santos.', true]
      ]
    },
    {
      id: 'smartinho', nome: 'São Martinho', emo: '🌰', deco: '🌰 🔥 🍂 ☀️ 🍁', cor: '#8E4B24',
      janela: (a) => [dia(a, 11, 7), dia(a, 11, 11)], itens: ['castanhas'],
      fala: (n) => 'Cheira a castanhas assadas! Dia 11 é São Martinho. Toma, ' + n + ', um cartucho quentinho para ti!',
      q: [
        ['Em que dia se celebra o São Martinho?', ['11 de novembro', '1 de novembro', '25 de dezembro', '24 de junho']],
        ['O que se come no magusto de São Martinho?', ['castanhas assadas', 'bolo-rei', 'sardinhas', 'amêndoas']],
        ['Segundo a lenda, o que fez Martinho ao pobre que tinha frio?', ['cortou a capa ao meio e deu-lhe metade', 'deu-lhe um cavalo', 'levou-o para casa', 'ofereceu-lhe castanhas'], 'E o Sol apareceu: é o "Verão de São Martinho".'],
        ['Os dias de sol e calor perto do dia 11 de novembro chamam-se…', ['Verão de São Martinho', 'Primavera de outono', 'Dias de Reis', 'Santos Populares']],
        ['As castanhas são o fruto do castanheiro.', true]
      ]
    },
    {
      id: 'natal', nome: 'Natal', emo: '🎄', deco: '🎄 ⭐ 🎁 ❄️ 🦌', cor: '#C62F3B',
      janela: (a) => [dia(a, 12, 1), dia(a, 12, 26)], itens: ['natal', 'arvore'],
      fala: (n) => 'Hohoho! Já cheira a Natal! Preparei-te um presente, ' + n + '. Abre-o!',
      q: [
        ['Como se chama a ceia de dia 24 de dezembro, em Portugal?', ['Consoada', 'Magusto', 'Janeiras', 'Arraial']],
        ['Que prato é tradicional na Consoada?', ['bacalhau com couves e batatas', 'sardinhas assadas', 'castanhas', 'caracóis']],
        ['O que representa o presépio?', ['o nascimento de Jesus', 'a chegada do Pai Natal', 'a passagem de ano', 'o Carnaval']],
        ['Qual destes é um doce de Natal português?', ['rabanadas', 'pastel de nata gelado', 'farturas de verão', 'gaspacho']],
        ['O Natal celebra-se a 25 de dezembro.', true]
      ]
    },
    {
      id: 'anonovo', nome: 'Ano Novo', emo: '🥳', deco: '🎆 🥳 🎉 ✨ 🕛', cor: '#2B6FD6',
      janela: (a) => [dia(a, 12, 30), dia(a + 1, 1, 1)], itens: ['festa'],
      fala: (n) => 'Feliz Ano Novo, ' + n + '! Um ano cheio de descobertas. Toma um chapéu de festa!',
      q: [
        ['Na passagem de ano, muitas famílias comem 12…', ['passas', 'castanhas', 'sardinhas', 'amêndoas'], 'Uma por cada badalada da meia-noite, pedindo um desejo.'],
        ['Quantos meses tem um ano?', ['12', '10', '52', '365']],
        ['Quantos dias tem um ano bissexto?', ['366', '365', '364', '360']],
        ['O primeiro dia do ano é 1 de…', ['janeiro', 'dezembro', 'setembro', 'março']],
        ['Num ano há 52 semanas e mais um ou dois dias.', true]
      ]
    },
    {
      id: 'reis', nome: 'Dia de Reis', emo: '👑', deco: '👑 ⭐ 🐫 🎶 🍰', cor: '#B07A00',
      janela: (a) => [dia(a, 1, 5), dia(a, 1, 6)], itens: [],
      fala: (n) => 'Hoje é Dia de Reis! Vamos cantar as Janeiras? Tenho estrelas para ti, ' + n + '!',
      q: [
        ['Como se chamam os três Reis Magos?', ['Belchior, Gaspar e Baltasar', 'Pedro, Paulo e João', 'Afonso, Dinis e Sancho', 'Martinho, António e José']],
        ['Que presentes levaram os Reis Magos ao Menino Jesus?', ['ouro, incenso e mirra', 'castanhas, pão e mel', 'brinquedos e doces', 'flores e frutos']],
        ['Que bolo se come na época de Reis?', ['bolo-rei', 'bolo de bolacha', 'pão de ló', 'bola de Berlim']],
        ['As canções que se cantam de porta em porta no início do ano chamam-se…', ['Janeiras', 'Marchas', 'Fados', 'Quadras de São João']],
        ['O Dia de Reis é a 6 de janeiro.', true]
      ]
    },
    {
      id: 'carnaval', nome: 'Carnaval', emo: '🎭', deco: '🎭 🎉 🤡 🎊 🪅', cor: '#9B5DE5',
      janela: (a) => { const p = pascoa(a); return [mais(p, -52), mais(p, -47)]; }, itens: ['mascara'],
      fala: (n) => 'É Carnaval, ninguém leva a mal! De que te vais mascarar, ' + n + '? Eu já tenho uma máscara para ti!',
      q: [
        ['O Carnaval acaba na terça-feira antes da…', ['Quarta-feira de Cinzas', 'Páscoa', 'Sexta-feira Santa', 'noite de São João']],
        ['Os Caretos, com máscaras e trajes coloridos, são de que região?', ['Trás-os-Montes (Podence)', 'Algarve', 'Madeira', 'Lisboa']],
        ['Que provérbio se diz no Carnaval?', ['"É Carnaval, ninguém leva a mal!"', '"Natal é quando um homem quiser"', '"Em abril, águas mil"', '"Pelo São Martinho, prova o vinho"']],
        ['O dia de Carnaval muda de data todos os anos porque depende da Páscoa.', true],
        ['No Carnaval é costume…', ['mascarar-se', 'comer castanhas', 'cantar as Janeiras', 'apanhar ovos de chocolate']]
      ]
    },
    {
      id: 'pai', nome: 'Dia do Pai', emo: '👨', deco: '👨 💙 🛠️ ⚽ 🎁', cor: '#2B6FD6',
      janela: (a) => [dia(a, 3, 18), dia(a, 3, 19)], itens: ['gravata'],
      fala: (n) => 'Dia 19 de março é o Dia do Pai! Que tal fazeres um desenho ou dares-lhe um abraço gigante, ' + n + '?',
      q: [
        ['Em Portugal, o Dia do Pai é a…', ['19 de março', '1 de junho', '25 de abril', '1 de maio']],
        ['O Dia do Pai coincide com o dia de…', ['São José', 'São Martinho', 'Santo António', 'São Pedro']],
        ['Uma boa prenda de Dia do Pai feita por ti pode ser…', ['um desenho ou um postal', 'um quiz de matemática', 'uma fatura', 'um trabalho de casa']],
        ['Dar um abraço também é um presente.', true]
      ]
    },
    {
      id: 'pascoa', nome: 'Páscoa', emo: '🐰', deco: '🐰 🥚 🌷 🐣 🍫', cor: '#E05FA0',
      janela: (a) => { const p = pascoa(a); return [mais(p, -3), mais(p, 1)]; }, itens: ['coelho', 'ovos'],
      fala: (n) => 'Feliz Páscoa, ' + n + '! Escondi uns ovos coloridos para ti. Abre o presente!',
      q: [
        ['Que pão doce, muitas vezes com um ovo cozido, se oferece na Páscoa?', ['folar', 'bolo-rei', 'broa de milho', 'pão de forma']],
        ['Que doces se oferecem tradicionalmente na Páscoa, em Portugal?', ['amêndoas', 'castanhas', 'filhoses de Natal', 'gelados']],
        ['A Páscoa é sempre a um…', ['domingo', 'sábado', 'segunda-feira', 'dia fixo do calendário']],
        ['Que animal é símbolo da Páscoa e "traz" os ovos?', ['o coelho', 'a rena', 'o peru', 'o galo']],
        ['A data da Páscoa muda de ano para ano.', true]
      ]
    },
    {
      id: 'abril', nome: '25 de Abril', emo: '🌹', deco: '🌹 🇵🇹 🕊️ 🌹 🎶', cor: '#C62F3B',
      janela: (a) => [dia(a, 4, 24), dia(a, 4, 25)], itens: ['cravo'],
      fala: (n) => '25 de Abril, Dia da Liberdade! Em 1974, os cravos vermelhos encheram as ruas. Tenho um para ti, ' + n + '.',
      q: [
        ['Em que ano foi a Revolução do 25 de Abril?', ['1974', '1910', '1640', '1986']],
        ['Que flor é o símbolo do 25 de Abril?', ['o cravo vermelho', 'a rosa amarela', 'o girassol', 'o manjerico']],
        ['O 25 de Abril acabou com…', ['a ditadura do Estado Novo', 'a monarquia', 'a 1.ª dinastia', 'a União Europeia']],
        ['Que canção foi uma das senhas da revolução?', ['"Grândola, Vila Morena"', '"A Portuguesa"', '"Parabéns a você"', '"Noite Feliz"']],
        ['O 25 de Abril também se chama Dia da Liberdade.', true]
      ]
    },
    {
      id: 'mae', nome: 'Dia da Mãe', emo: '💐', deco: '💐 💖 🌷 🌸 🎁', cor: '#E05FA0',
      janela: (a) => { const d = primeiroDomingoMaio(a); return [mais(d, -1), d]; }, itens: ['flores'],
      fala: (n) => 'É Dia da Mãe! Já lhe disseste o quanto gostas dela, ' + n + '? Toma uma coroa de flores para a festa!',
      q: [
        ['Em Portugal, o Dia da Mãe é…', ['no primeiro domingo de maio', 'a 19 de março', 'a 1 de junho', 'a 8 de dezembro']],
        ['Uma boa surpresa para a mãe pode ser…', ['um desenho, um poema ou ajudar em casa', 'deixar o quarto desarrumado', 'esconder os trabalhos de casa', 'acordá-la às 5 da manhã']],
        ['O mês de maio é o…', ['5.º mês do ano', '3.º mês do ano', '7.º mês do ano', '12.º mês do ano']],
        ['Escrever um postal para a mãe é uma prenda especial.', true]
      ]
    },
    {
      id: 'crianca', nome: 'Dia da Criança', emo: '🎈', deco: '🎈 🧸 🪁 🎠 🍭', cor: '#2EC4A0',
      janela: (a) => [dia(a, 5, 31), dia(a, 6, 1)], itens: [], estrelas: 30,
      fala: (n) => 'Feliz Dia da Criança, ' + n + '! Hoje a festa é tua. Tenho uma chuva de estrelas para ti!',
      q: [
        ['Em que dia se celebra o Dia Mundial da Criança, em Portugal?', ['1 de junho', '25 de dezembro', '10 de junho', '1 de novembro']],
        ['Qual destes é um direito de todas as crianças?', ['ir à escola e brincar', 'trabalhar numa fábrica', 'não ter nome', 'não ter casa']],
        ['O documento que protege os direitos das crianças chama-se…', ['Convenção sobre os Direitos da Criança', 'Constituição dos Pais', 'Livro de Reclamações', 'Código da Estrada']],
        ['Todas as crianças têm direito a ser protegidas e a brincar.', true]
      ]
    },
    {
      id: 'portugal', nome: 'Dia de Portugal', emo: '🇵🇹', deco: '🇵🇹 📜 ⛵ 🇵🇹 🎉', cor: '#1E8E4E',
      janela: (a) => [dia(a, 6, 10), dia(a, 6, 10)], itens: [],
      fala: (n) => 'Hoje é Dia de Portugal, de Camões e das Comunidades Portuguesas! Viva Portugal, ' + n + '!',
      q: [
        ['O Dia de Portugal é a 10 de junho e lembra o poeta…', ['Luís Vaz de Camões', 'Fernando Pessoa', 'José Saramago', 'Gil Vicente']],
        ['Que obra famosa escreveu Camões?', ['Os Lusíadas', 'A Maior Flor do Mundo', 'Mensagem', 'O Gigante Egoísta']],
        ['Quais são as cores da bandeira de Portugal?', ['verde e vermelho', 'azul e branco', 'amarelo e vermelho', 'verde e azul']],
        ['O hino nacional de Portugal chama-se "A Portuguesa".', true]
      ]
    },
    {
      id: 'santos', nome: 'Santos Populares', emo: '🌿', deco: '🌿 🐟 🎉 🏮 🎶', cor: '#1E9E80',
      janela: (a) => [dia(a, 6, 12), dia(a, 6, 29)], itens: ['manjerico'],
      fala: (n) => 'Arraial! São os Santos Populares: Santo António, São João e São Pedro. Toma um manjerico, ' + n + '!',
      q: [
        ['O Santo António é a 13 de junho e é a grande festa de que cidade?', ['Lisboa', 'Porto', 'Faro', 'Braga']],
        ['A noite de São João, a 23 para 24 de junho, é muito festejada no…', ['Porto', 'Funchal', 'Évora', 'Faro']],
        ['Que planta, com uma quadra num papel, se oferece no Santo António?', ['o manjerico', 'o cravo', 'o girassol', 'o pinheiro']],
        ['Que peixe se come muito nos arraiais dos Santos Populares?', ['sardinha', 'bacalhau', 'salmão', 'atum']],
        ['No São João do Porto há martelinhos de plástico.', true]
      ]
    },
    {
      id: 'verao', nome: 'Férias de verão', emo: '😎', deco: '☀️ 🏖️ 🌊 🍉 🐚', cor: '#FF9F1C',
      janela: (a) => [dia(a, 7, 1), dia(a, 8, 31)], itens: ['sol'],
      fala: (n) => 'Chegou o verão! Boas férias, ' + n + '! Não te esqueças do protetor solar e de beber água. Toma uns óculos de sol!',
      q: [
        ['Na praia, a bandeira vermelha quer dizer…', ['é proibido ir à água', 'pode-se nadar à vontade', 'só se pode ir à água com boia', 'há gelados'], 'Verde: pode nadar. Amarela: não nadar, só molhar os pés. Vermelha: não ir à água.'],
        ['E a bandeira amarela?', ['não se pode nadar, mas pode-se molhar os pés', 'pode-se nadar à vontade', 'a praia está fechada para sempre', 'é hora do almoço']],
        ['Qual é a melhor hora para evitar o sol forte?', ['entre as 11 e as 17 horas', 'às 9 da manhã', 'ao fim do dia', 'nunca é preciso evitar']],
        ['Na praia devemos nadar perto do…', ['nadador-salvador', 'barco de pesca', 'farol', 'pontão proibido']],
        ['No verão devemos beber muita água.', true]
      ]
    }
  ];

  const ANOS = {
    id: 'anos', nome: 'Aniversário', emo: '🎂', deco: '🎂 🎈 🎉 🎁 🥳', cor: '#F15BB5', itens: ['bolo', 'festa'], estrelas: 50,
    fala: (n) => 'Muitos parabéns, ' + n + '! Hoje é o teu dia! Que tenhas um ano cheio de alegria e de coisas novas para aprender. Abre o teu presente!',
    q: [
      ['Quantos meses faltam para o teu próximo aniversário, se fizeste anos hoje?', ['12', '1', '6', '0']],
      ['Quantos dias tem uma semana?', ['7', '5', '10', '12']],
      ['Se hoje fazes 10 anos, quantos anos terás daqui a 5 anos?', ['15', '50', '10', '5']],
      ['Num aniversário, apagamos as velas e pedimos um desejo.', true]
    ]
  };

  // cada festa tem um "tema" de quiz próprio (fora das listas das disciplinas)
  FESTAS.concat([ANOS]).forEach((f) => {
    CUR.temas['festa_' + f.id] = { id: 'festa_' + f.id, t: 'Quiz: ' + f.nome, disc: 'festa', ano: 0, k: '', ae: '', r: [], q: f.q };
  });

  const ymd = (d) => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');

  const F = (window.FESTAS = { LISTA: FESTAS, ANOS, pascoa });
  F.hoje = () => (F._hoje ? new Date(F._hoje + 'T12:00') : new Date());

  /** festa de hoje (o aniversário tem prioridade) */
  F.atual = function (p) {
    const h = F.hoje(), hs = ymd(h);
    if (p && p.anos && p.anos === hs.slice(5)) return Object.assign({ chave: 'anos:' + h.getFullYear() }, ANOS);
    for (const ano of [h.getFullYear() - 1, h.getFullYear()]) {
      for (const f of FESTAS) {
        const [de, ate] = f.janela(ano);
        if (hs >= ymd(de) && hs <= ymd(ate)) return Object.assign({ chave: f.id + ':' + ymd(de) }, f);
      }
    }
    return null;
  };

  F.abriu = (p, f) => !!(p.festas && p.festas[f.chave]);

  F.abrirPresente = function (p, f) {
    p.festas = p.festas || {};
    if (p.festas[f.chave]) return;
    p.festas[f.chave] = U.today();
    const n = f.estrelas || 15;
    p.estrelas += n;
    const novos = (f.itens || []).filter((id) => p.loja.indexOf(id) < 0);
    novos.forEach((id) => { p.loja.push(id); F.vestir(p, id); });
    S.save();
    confettis(); SOM.festa();
    const nomes = novos.map((id) => { const a = KIKO.ACESSORIOS.find((x) => x.id === id); return a ? a.emo + ' ' + a.nome : ''; }).filter(Boolean);
    MODAL.abrir(`<div style="text-align:center"><div style="font-size:64px">🎁</div><h2>${U.esc(f.emo + ' ' + f.nome)}</h2>
      <p style="font-weight:800;margin:10px 0">Ganhaste ⭐ ${n} estrelas${nomes.length ? ' e:' : '!'}</p>
      ${nomes.length ? `<p style="font-weight:900;font-size:20px;margin-bottom:12px">${nomes.map(U.esc).join('<br>')}</p>` : ''}
      <button class="btn" id="fok">Que fixe! 🎉</button></div>`, (m) => { U.$('#fok', m).onclick = () => { MODAL.fechar(); APP.redesenhar(); }; });
    VOZ.falar('Ganhaste ' + n + ' estrelas' + (nomes.length ? ' e uma surpresa para eu vestir!' : '!'));
  };

  /** veste um acessório, tirando o que estiver na mesma zona */
  F.vestir = function (p, id) {
    const a = KIKO.ACESSORIOS.find((x) => x.id === id);
    if (!a) return;
    p.veste = p.veste.filter((v) => { const o = KIKO.ACESSORIOS.find((x) => x.id === v); return !o || o.zona !== a.zona; });
    p.veste.push(id);
  };

  F.html = function (p) {
    const f = F.atual(p);
    if (!f) return '';
    const aberto = F.abriu(p, f);
    return `<div class="festa" style="--fc:${f.cor}">
      <div class="festa-deco" aria-hidden="true">${f.deco}</div>
      <div class="festa-row"><span class="festa-emo">${f.emo}</span><b class="grow">${U.esc(f.id === 'anos' ? 'Parabéns, ' + p.nome + '!' : f.nome)}</b></div>
      <div class="row" style="gap:8px;margin-top:8px">
        ${aberto ? '' : '<button class="btn small grow" id="fpres">🎁 Abrir presente</button>'}
        <button class="btn sec small grow" id="fquiz">❓ Quiz da festa</button>
      </div></div>`;
  };

  F.ligar = function (r, p) {
    const f = F.atual(p);
    if (!f) return;
    const b = U.$('#fpres', r);
    if (b) b.onclick = () => F.abrirPresente(p, f);
    U.$('#fquiz', r).onclick = () => QUIZ.iniciarTema('festa_' + f.id, f.q.length);
  };

  F.saudacao = function (p) { const f = F.atual(p); return f ? f.fala(p.nome) : null; };

  // ------------------------------------------------------------ brincadeiras
  const PIADAS = [
    ['O que é que o zero disse ao oito?', 'Que cinto tão giro!'],
    ['Qual é o animal que anda com as patas?', 'O pato!'],
    ['O que é que está sempre à frente mas nunca se vê?', 'O futuro!'],
    ['Porque é que o livro de matemática estava triste?', 'Porque tinha muitos problemas!'],
    ['O que é que tem dentes mas não morde?', 'O pente!'],
    ['O que é que sobe e desce mas não sai do lugar?', 'A escada!'],
    ['Qual é o mar que não tem água?', 'O mar… melada!'],
    ['O que é que tem pescoço mas não tem cabeça?', 'A garrafa!'],
    ['O que é que quanto mais se tira, maior fica?', 'O buraco!'],
    ['O que é que tem olhos mas não vê?', 'A batata!'],
    ['O que é que corre mas não tem pernas?', 'O rio!'],
    ['Porque é que a vaca foi para o espaço?', 'Para ver a Via Láctea!'],
    ['O que é que anda sem pernas e chora sem olhos?', 'A nuvem!'],
    ['O que é que tem cauda e cabeça, mas não tem corpo?', 'A moeda!'],
    ['O que diz uma caturra quando está com frio?', 'Piu… brrr… piu!'],
    ['O que é que o lápis disse à borracha?', 'Tu apagas tudo o que eu digo!'],
    ['O que é que se parte quando dizemos o seu nome?', 'O silêncio!'],
    ['O que é que está no meio do ovo?', 'A letra V!'],
    ['O que é que tem muitas folhas mas não é árvore?', 'O livro!'],
    ['O que é que nasce grande e morre pequeno?', 'O lápis!']
  ];
  const SABIAS = [
    'As caturras vêm da Austrália e vivem em bandos.',
    'Quando uma caturra está contente ou curiosa, levanta a poupa amarela.',
    'As caturras conseguem imitar assobios e algumas aprendem palavras!',
    'O coração humano bate cerca de 100 mil vezes por dia.',
    'Um polvo tem três corações e sangue azul.',
    'O Sol é tão grande que caberia lá dentro mais de um milhão de Terras.',
    'As abelhas comunicam umas com as outras dançando.',
    'O rio mais comprido de Portugal é o Tejo, que nasce em Espanha.',
    'O ponto mais alto de Portugal é a montanha do Pico, nos Açores.',
    'Os golfinhos dormem com metade do cérebro de cada vez.',
    'A girafa tem o mesmo número de ossos no pescoço que nós: sete!',
    'As caturras gostam de tomar banho e de se sacudir como cães molhados!',
    'A Lua afasta-se da Terra cerca de 4 centímetros por ano.',
    'As formigas conseguem carregar muitas vezes o seu próprio peso.',
    'O lince-ibérico é um dos felinos mais ameaçados do mundo e vive em Portugal.',
    'Os ossos das aves são ocos, por isso são leves para voar.',
    'Há mais estrelas no Universo do que grãos de areia em todas as praias da Terra.',
    'Os flamingos são cor-de-rosa por causa do que comem.',
    'Ler um bocadinho todos os dias faz o cérebro crescer mais forte!',
    'Quando dormes, o teu cérebro arruma tudo o que aprendeste durante o dia.'
  ];
  const MIMOS = ['Que bom! Adoro miminhos!', 'Hihi, isso faz cócegas!', 'Gosto muito de ti!', 'Piu piu! Estou tão feliz!', 'És o meu melhor amigo!'];
  const COMER = ['Nham nham! Sementes de girassol, as minhas preferidas!', 'Que delícia! Obrigado!', 'Crunch crunch! Agora tenho energia para estudar!', 'Mmm! Estava mesmo com fome!'];
  const CHEIO = ['Já estou cheiinho! Agora vamos estudar?', 'Não consigo comer mais! A minha barriga vai rebentar!'];

  function coracoes(r, emo) {
    const h = U.$('.hero', r) || r;
    for (let i = 0; i < 6; i++) {
      const s = document.createElement('span');
      s.className = 'flutua'; s.textContent = emo || '💖';
      s.style.left = 35 + Math.random() * 30 + '%';
      s.style.animationDelay = i * 0.12 + 's';
      h.appendChild(s);
      setTimeout(() => s.remove(), 2200);
    }
  }
  function animar(cls, ms) {
    const k = U.$('#kiko'); if (!k) return;
    k.classList.remove(cls); void k.offsetWidth; k.classList.add(cls);
    setTimeout(() => k.classList.remove(cls), ms);
  }
  function melodia() {
    if (!S.cfg().som) return;
    try {
      const A = window.AudioContext || window.webkitAudioContext; const c = F._ac = F._ac || new A();
      [523, 659, 784, 659, 880, 784, 659, 523, 587, 659, 523].forEach((fq, i) => {
        const o = c.createOscillator(), g = c.createGain(), t = c.currentTime + i * 0.18;
        o.type = 'triangle'; o.frequency.value = fq;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.15, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.17);
        o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + 0.2);
      });
    } catch (e) { }
  }

  F.melodia = melodia;  // usada também na celebração de fim de quiz
  F.brincarHtml = () => `<div class="brincar" id="brincar">
      <button class="chip" data-b="comer">🌻 Sementes</button>
      <button class="chip" data-b="danca">💃 Dançar</button>
      <button class="chip" data-b="mimo">🤗 Miminhos</button>
      <button class="chip" data-b="piada">😂 Adivinha</button>
      <button class="chip" data-b="sabias">💡 Sabias que…</button>
    </div>`;

  F.ligarBrincar = function (r, p) {
    U.$$('#brincar button', r).forEach((b) => (b.onclick = () => {
      if (MIC.ativo) return;
      VOZ.parar();
      const tipo = b.dataset.b;
      const d = S.dia(p);
      if (tipo === 'comer') {
        d.comeu = (d.comeu || 0) + 1; S.save();
        if (d.comeu > 4) { KIKO.reagir('happy'); return KIKO.dizer(U.pick(CHEIO)); }
        animar('come', 1200); coracoes(r, '🌻'); KIKO.reagir('happy');
        return KIKO.dizer(U.pick(COMER).replace('Obrigado', KIKO.tipo() === 'kika' ? 'Obrigada' : 'Obrigado').replace('cheiinho', KIKO.tipo() === 'kika' ? 'cheiinha' : 'cheiinho'));
      }
      if (tipo === 'danca') { animar('danca', 2200); melodia(); coracoes(r, '🎵'); return KIKO.dizer('Olha só os meus passos de dança!'); }
      if (tipo === 'mimo') { animar('mimo', 1500); coracoes(r, '💖'); KIKO.reagir('happy'); return KIKO.dizer(U.pick(MIMOS)); }
      if (tipo === 'piada') {
        const pd = U.pick(PIADAS);
        KIKO.reagir('happy');
        return KIKO.dizer(pd[0]).then(() => setTimeout(() => {
          if (U.$('#app').getAttribute('data-ecra') !== 'inicio') return;
          KIKO.dizer(pd[1]); animar('mimo', 1200); coracoes(r, '😂');
        }, 2500));
      }
      if (tipo === 'sabias') { animar('mimo', 900); return KIKO.dizer('Sabias que… ' + U.pick(SABIAS)); }
    }));
  };
})();
