/* Android TV: navegação com as setas do comando (D-pad), OK para escolher, foco bem visível */
(function () {
  'use strict';

  const SEL = 'button:not([disabled]), input:not([type=hidden]), select, textarea, summary, [tabindex]:not([tabindex="-1"])';
  const TV = (window.TV = { ativo: false });

  let eTV = false;
  try { eTV = !!(window.Android && window.Android.isTv && window.Android.isTv()); } catch (e) { }
  if (/[?&]tv=1/.test(location.search)) eTV = true;     // para testes no computador
  if (eTV) document.documentElement.classList.add('tv');

  function visivel(el) {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none' && (el.offsetParent !== null || st.position === 'fixed');
  }

  function raiz() {
    const m = document.getElementById('modal');
    return m && !m.classList.contains('hidden') ? document.getElementById('modalCard') : document;
  }

  function focaveis(r) {
    return Array.from((r || raiz()).querySelectorAll(SEL)).filter(visivel);
  }

  TV.focoInicial = function (r) {
    if (!TV.ativo) return;
    const lista = focaveis(r);
    if (!lista.length) return;
    // preferir o microfone, uma opção do quiz ou o primeiro botão principal
    const pref = (r || document).querySelector('#mic, .opt, #qnext, .btn, .subject, .topic, .profile') || lista[0];
    (visivel(pref) ? pref : lista[0]).focus({ preventScroll: false });
  };

  function centro(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }

  function mover(dir) {
    const atual = document.activeElement && document.activeElement !== document.body ? document.activeElement : null;
    const lista = focaveis();
    if (!lista.length) return false;
    if (!atual || lista.indexOf(atual) < 0) { lista[0].focus(); return true; }
    const ra = atual.getBoundingClientRect(), ca = centro(ra);
    let melhor = null, pont = Infinity;
    lista.forEach((el) => {
      if (el === atual) return;
      const r = el.getBoundingClientRect(), c = centro(r);
      let prim, orto;
      if (dir === 'up') { if (r.bottom > ra.top + 4) return; prim = ca.y - c.y; orto = Math.abs(c.x - ca.x); }
      if (dir === 'down') { if (r.top < ra.bottom - 4) return; prim = c.y - ca.y; orto = Math.abs(c.x - ca.x); }
      if (dir === 'left') { if (r.right > ra.left + 4) return; prim = ca.x - c.x; orto = Math.abs(c.y - ca.y); }
      if (dir === 'right') { if (r.left < ra.right - 4) return; prim = c.x - ca.x; orto = Math.abs(c.y - ca.y); }
      const s = prim + orto * 2.2;
      if (s < pont) { pont = s; melhor = el; }
    });
    if (melhor) {
      melhor.focus({ preventScroll: true });
      melhor.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
      return true;
    }
    // sem nada nessa direção: desliza a página
    if (dir === 'up' || dir === 'down') window.scrollBy({ top: dir === 'up' ? -200 : 200, behavior: 'smooth' });
    return true;
  }

  const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };

  document.addEventListener('keydown', (e) => {
    const dir = DIRS[e.key];
    if (!dir) {
      if ((e.key === 'Enter' || e.key === ' ') && TV.ativo) {
        const a = document.activeElement;
        // o OK do comando ativa qualquer elemento focado (também cartões e Kiko)
        if (a && a.tagName !== 'INPUT' && a.tagName !== 'TEXTAREA' && a.tagName !== 'SELECT' && a.tagName !== 'BUTTON' && a.tagName !== 'SUMMARY') { a.click(); e.preventDefault(); }
      }
      return;
    }
    const a = document.activeElement;
    // dentro de uma caixa de texto, esquerda/direita mexem o cursor
    if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') && (dir === 'left' || dir === 'right')) {
      const v = a.value || '', pos = a.selectionStart;
      if (a.type !== 'range' && !((dir === 'left' && pos === 0) || (dir === 'right' && pos === v.length))) return;
    }
    if (a && a.type === 'range' && (dir === 'left' || dir === 'right')) return;
    TV.ativo = true;
    document.documentElement.classList.add('kbd');
    if (mover(dir)) e.preventDefault();
  }, true);

  // ao tocar no ecrã, esconde o anel de foco
  document.addEventListener('pointerdown', () => { if (!eTV) { TV.ativo = false; document.documentElement.classList.remove('kbd'); } }, true);

  TV.ativo = eTV;
  if (eTV) document.documentElement.classList.add('kbd');

  // cartões que se viram e o Kiko também podem receber foco
  new MutationObserver(() => {
    document.querySelectorAll('#fc, #kiko').forEach((el) => { if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0'); });
  }).observe(document.getElementById('app'), { childList: true, subtree: true });
})();
