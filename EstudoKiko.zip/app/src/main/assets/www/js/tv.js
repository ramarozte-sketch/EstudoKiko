/* Android TV: navegação com as setas do comando (D-pad), OK para escolher, foco bem visível.
 * No telemóvel/TV Android as setas chegam aqui SÓ através de TV.tecla() (vindo do Kotlin),
 * por isso cada carregar na seta move o foco exatamente uma vez. */
(function () {
  'use strict';

  const SEL = 'button:not([disabled]), input:not([type=hidden]):not([disabled]), select, textarea, summary, [tabindex]:not([tabindex="-1"])';
  const TV = (window.TV = { ativo: false });

  let eTV = false;
  try { eTV = !!(window.Android && window.Android.isTv && window.Android.isTv()); } catch (e) { }
  if (/[?&]tv=1/.test(location.search)) eTV = true;     // para testes no computador
  if (eTV) document.documentElement.classList.add('tv');

  function visivel(el) {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(el);
    if (st.visibility === 'hidden' || st.display === 'none' || parseFloat(st.opacity) < 0.35) return false;
    return el.offsetParent !== null || st.position === 'fixed';
  }

  function raiz() {
    const m = document.getElementById('modal');
    return m && !m.classList.contains('hidden') ? document.getElementById('modalCard') : document;
  }

  function focaveis(r) {
    return Array.from((r || raiz()).querySelectorAll(SEL)).filter(visivel);
  }

  // retângulo "real" do elemento (sem contar com a escala/realce do foco)
  function caixa(el) {
    const r = el.getBoundingClientRect();
    return { left: r.left, right: r.right, top: r.top, bottom: r.bottom, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 };
  }

  TV.focoInicial = function (r) {
    if (!TV.ativo) return;
    const lista = focaveis(r);
    if (!lista.length) return;
    // numa janela (ex.: novo perfil) começa no primeiro campo; nos ecrãs, no elemento principal
    const pref = r ? lista[0] : document.querySelector('#mic, .opt:not([disabled]), #qnext, .btn, .subject, .topic, .profile');
    const alvo = pref && visivel(pref) ? pref : lista[0];
    focar(alvo);
  };

  function focar(el) {
    el.focus({ preventScroll: true });
    el.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
  }

  function sobrepoe(a1, a2, b1, b2) { return Math.min(a2, b2) - Math.max(a1, b1); }

  function pontuar(a, b, dir) {
    let dist, pen;
    if (dir === 'up' || dir === 'down') {
      dist = dir === 'up' ? a.top - b.bottom : b.top - a.bottom;
      if (dist < -Math.min(a.h, b.h) / 2) return Infinity;            // não está nessa direção
      if (dir === 'up' ? b.cy >= a.cy : b.cy <= a.cy) return Infinity;
      const ov = sobrepoe(a.left, a.right, b.left, b.right);
      pen = ov > 0 ? Math.abs(b.cx - a.cx) * 0.02 : (-ov) * 3 + 40;    // a mesma coluna ganha sempre
    } else {
      dist = dir === 'left' ? a.left - b.right : b.left - a.right;
      if (dist < -Math.min(a.w, b.w) / 2) return Infinity;
      if (dir === 'left' ? b.cx >= a.cx : b.cx <= a.cx) return Infinity;
      const ov = sobrepoe(a.top, a.bottom, b.top, b.bottom);
      pen = ov > 0 ? Math.abs(b.cy - a.cy) * 0.02 : 2000 + (-ov) * 3;  // esquerda/direita: a mesma linha primeiro
    }
    return Math.max(0, dist) + pen;
  }

  function melhorDe(cands, a, dir) {
    let melhor = null, pont = Infinity;
    cands.forEach((el) => { const s = pontuar(a, caixa(el), dir); if (s < pont) { pont = s; melhor = el; } });
    return melhor;
  }

  function mover(dir) {
    const lista = focaveis();
    if (!lista.length) return;
    const atual = document.activeElement;
    if (!atual || atual === document.body || lista.indexOf(atual) < 0) { focar(lista[0]); return; }
    const a = caixa(atual);
    const navEl = document.querySelector('.nav');
    const naNav = (el) => !!(navEl && navEl.contains(el));
    const outros = lista.filter((el) => el !== atual && !atual.contains(el) && !el.contains(atual));
    let melhor = null;
    if (naNav(atual)) {
      if (dir === 'left' || dir === 'right') melhor = melhorDe(outros.filter(naNav), a, dir);
      else if (dir === 'up') {
        // sair da barra de baixo para o conteúdo visível mais próximo
        const topoNav = navEl.getBoundingClientRect().top;
        const vis = outros.filter((el) => { const r = el.getBoundingClientRect(); return !naNav(el) && r.bottom <= topoNav + 2 && r.top >= 0; });
        melhor = melhorDe(vis, { left: a.left, right: a.right, top: topoNav, bottom: topoNav, w: a.w, h: 1, cx: a.cx, cy: topoNav }, 'up') ||
          melhorDe(outros.filter((el) => !naNav(el)), a, 'up');
      }
    } else {
      // primeiro o conteúdo; a barra de baixo só quando já não há mais nada abaixo
      melhor = melhorDe(outros.filter((el) => !naNav(el)), a, dir);
      if (!melhor && dir === 'down') {
        const app = document.getElementById('app');
        const fim = app.scrollTop + app.clientHeight >= app.scrollHeight - 4;
        if (!fim) { app.scrollBy({ top: 240, behavior: 'smooth' }); return; }
        melhor = melhorDe(outros.filter(naNav), { left: a.left, right: a.right, top: a.top, bottom: -1e6, w: a.w, h: a.h, cx: a.cx, cy: -1e6 }, 'down');
      }
    }
    if (melhor) focar(melhor);
    else if (dir === 'up') document.getElementById('app').scrollBy({ top: -240, behavior: 'smooth' });
  }

  /** Trata uma seta. Devolve true se a usou. */
  function tratar(dir) {
    TV.ativo = true;
    document.documentElement.classList.add('kbd');
    const a = document.activeElement;
    // caixas de texto: esquerda/direita mexem o cursor até ao fim do texto
    if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') && (dir === 'left' || dir === 'right')) {
      if (a.type === 'range') {
        const st = parseFloat(a.step) || 1, v = parseFloat(a.value) + (dir === 'right' ? st : -st);
        a.value = Math.min(parseFloat(a.max), Math.max(parseFloat(a.min), v));
        a.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      }
      const v = a.value || '';
      let pos = a.selectionStart == null ? v.length : a.selectionStart;
      if ((dir === 'left' && pos > 0) || (dir === 'right' && pos < v.length)) {
        pos += dir === 'left' ? -1 : 1;
        try { a.setSelectionRange(pos, pos); } catch (e) { }
        return true;
      }
    }
    mover(dir);
    return true;
  }

  // chamado pelo Kotlin (comando da TV / teclado do telemóvel)
  TV.tecla = function (dir) { tratar(dir); };

  // no computador (testes) as setas chegam como teclas normais
  const DIRS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
  document.addEventListener('keydown', (e) => {
    const dir = DIRS[e.key];
    if (dir) {
      const a = document.activeElement;
      if (a && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') && (dir === 'left' || dir === 'right') && a.type !== 'range') {
        const v = a.value || '', pos = a.selectionStart;
        if (!((dir === 'left' && pos === 0) || (dir === 'right' && pos === v.length))) return;   // deixa o cursor andar
      }
      e.preventDefault(); e.stopPropagation();
      tratar(dir);
      return;
    }
    if ((e.key === 'Enter' || e.key === ' ') && TV.ativo) {
      const a = document.activeElement;
      // o OK ativa também elementos que não são botões (cartão, Kiko)
      if (a && ['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON', 'SUMMARY', 'A'].indexOf(a.tagName) < 0 && a !== document.body) { a.click(); e.preventDefault(); }
    }
  }, true);

  // ao tocar no ecrã (telemóvel), esconde o contorno de foco
  document.addEventListener('pointerdown', () => { if (!eTV) { TV.ativo = false; document.documentElement.classList.remove('kbd'); } }, true);

  TV.ativo = eTV;
  if (eTV) document.documentElement.classList.add('kbd');

  // cartões que se viram e o Kiko também podem receber foco
  new MutationObserver(() => {
    document.querySelectorAll('#fc, #kiko').forEach((el) => { if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0'); });
  }).observe(document.getElementById('app'), { childList: true, subtree: true });
})();
