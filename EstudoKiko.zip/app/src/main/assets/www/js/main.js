/* Arranque, contagem de tempo de estudo e limite diário */
(function () {
  'use strict';
  S.load();
  if (S.perfil()) APP.ir('inicio'); else APP.ir('perfis');

  // conta o tempo com a app visível e um perfil escolhido
  setInterval(() => {
    if (document.hidden) return;
    const p = S.perfil();
    if (!p) return;
    const d = S.dia(p);
    d.seg = (d.seg || 0) + 15;
    S.save();
    const lim = S.cfg().limiteMin;
    if (lim && d.seg >= (lim + (d.extra || 0)) * 60 && !QUIZ.ativo()) {
      const atual = U.$('#app').getAttribute('data-ecra');
      if (atual !== 'pausa') APP.ir('pausa');
    }
  }, 15000);

  // remover o foco do teclado ao tocar fora de um campo
  document.addEventListener('touchstart', (e) => {
    const a = document.activeElement;
    if (a && /INPUT|TEXTAREA/.test(a.tagName) && e.target !== a && !e.target.closest('.typebox')) a.blur();
  }, { passive: true });
})();
