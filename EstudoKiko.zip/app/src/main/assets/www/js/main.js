/* Arranque, contagem de tempo de estudo e limite diário */
(function () {
  'use strict';
  // a página ocupa exatamente a altura visível (a barra de baixo fica sempre no fundo)
  function ajustarAltura() {
    const h = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    document.documentElement.style.height = h + 'px';
    document.body.style.height = h + 'px';
  }
  ajustarAltura();
  window.addEventListener('resize', ajustarAltura);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', ajustarAltura);
  window.addEventListener('orientationchange', () => setTimeout(ajustarAltura, 300));

  S.load();
  if (S.perfil()) APP.ir('inicio'); else APP.ir('perfis');

  // conta o tempo com a app visível e um perfil escolhido
  setInterval(() => {
    if (document.hidden) return;
    const p = S.perfil();
    if (!p) return;
    const d = S.dia(p);
    d.seg = (d.seg || 0) + 15;
    S.save();
    const lim = S.cfg().limiteMin;
    if (lim && d.seg >= (lim + (d.extra || 0)) * 60 && !QUIZ.ativo()) {
      const atual = U.$('#app').getAttribute('data-ecra');
      if (atual !== 'pausa') APP.ir('pausa');
    }
  }, 15000);

  // remover o foco do teclado ao tocar fora de um campo
  document.addEventListener('touchstart', (e) => {
    const a = document.activeElement;
    if (a && /INPUT|TEXTAREA/.test(a.tagName) && e.target !== a && !e.target.closest('.typebox')) a.blur();
  }, { passive: true });
})();
