/* IA opcional (Google Gemini ou Anthropic Claude) — usada para temas livres, explicações e quizzes novos */
(function () {
  'use strict';

  const MODELOS = { gemini: 'gemini-2.5-flash', claude: 'claude-haiku-5-5' };
  const pendentes = {};
  let seq = 0;

  NATIVO.on('http', (d) => {
    const p = pendentes[d.id];
    if (!p) return;
    delete pendentes[d.id];
    p(d);
  });

  function post(url, headers, body) {
    if (NATIVO.ok) {
      return new Promise((res) => {
        const id = 'h' + (++seq);
        pendentes[id] = res;
        window.Android.httpPost(id, url, JSON.stringify(headers), JSON.stringify(body));
      });
    }
    // pré-visualização no computador
    return fetch(url, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json', 'anthropic-dangerous-direct-browser-access': 'true' }, headers), body: JSON.stringify(body) })
      .then((r) => r.text().then((t) => ({ status: r.status, body: t })))
      .catch((e) => ({ status: 0, body: String(e) }));
  }

  function extrairJSON(txt) {
    if (!txt) return null;
    const limpo = txt.replace(/```json|```/g, '');
    const i = limpo.indexOf('{'), j = limpo.lastIndexOf('}');
    if (i < 0 || j < i) return null;
    try { return JSON.parse(limpo.slice(i, j + 1)); } catch (e) { return null; }
  }

  const IA = (window.IA = {});
  /** chave incluída na compilação (segredo do GitHub), usada quando os pais não colaram outra */
  IA.padrao = () => { const d = window.KIKO_IA_PADRAO; return d && (d.chave || '').trim() ? d : null; };
  IA.conf = () => {
    const c = S.cfg().ia;
    if ((c.chave || '').trim()) return c;
    const d = IA.padrao();
    return d ? { fornecedor: d.fornecedor || 'claude', chave: d.chave.trim(), modelo: d.modelo || '' } : c;
  };
  IA.ativa = () => !!(IA.conf().chave || '').trim();
  IA.modelo = () => (IA.conf().modelo || '').trim() || MODELOS[IA.conf().fornecedor] || MODELOS.gemini;

  /**
   * mensagens: [{ papel: 'user'|'assistant', texto }]
   * devolve Promise<string>
   */
  IA.pedir = async function (sistema, mensagens, opcoes) {
    opcoes = opcoes || {};
    const cfg = IA.conf();
    const chave = (cfg.chave || '').trim();
    if (!chave) throw new Error('IA desligada');
    let r, txt;
    if (cfg.fornecedor === 'claude') {
      r = await post('https://api.anthropic.com/v1/messages',
        { 'x-api-key': chave, 'anthropic-version': '2023-06-01' },
        {
          model: IA.modelo(), max_tokens: opcoes.max || 1800, system: sistema,
          messages: mensagens.map((m) => ({ role: m.papel === 'assistant' ? 'assistant' : 'user', content: m.texto }))
        });
      if (r.status !== 200) throw new Error(erroLegivel(r));
      const j = JSON.parse(r.body);
      txt = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('\n');
    } else {
      const body = {
        systemInstruction: { parts: [{ text: sistema }] },
        contents: mensagens.map((m) => ({ role: m.papel === 'assistant' ? 'model' : 'user', parts: [{ text: m.texto }] })),
        generationConfig: { temperature: opcoes.temp == null ? 0.6 : opcoes.temp, maxOutputTokens: 8192 } // margem para modelos que "pensam" antes de responder
      };
      if (opcoes.json) body.generationConfig.responseMimeType = 'application/json';
      r = await post('https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(IA.modelo()) + ':generateContent',
        { 'x-goog-api-key': chave }, body);
      if (r.status !== 200) throw new Error(erroLegivel(r));
      const j = JSON.parse(r.body);
      const c = j.candidates && j.candidates[0];
      txt = c && c.content && c.content.parts ? c.content.parts.map((p) => p.text || '').join('') : '';
    }
    if (!txt) throw new Error('A IA não respondeu.');
    return txt;
  };

  function erroLegivel(r) {
    if (r.status === 0) return 'Sem ligação à internet.';
    if (r.status === 401 || r.status === 403) return 'A chave da IA não é válida.';
    if (r.status === 429) return 'A IA está ocupada (limite atingido). Tenta daqui a pouco.';
    let m = '';
    try { const j = JSON.parse(r.body); m = (j.error && (j.error.message || j.error.type)) || ''; } catch (e) { }
    return 'Erro da IA (' + r.status + ') ' + m;
  }

  IA.json = async function (sistema, mensagens, opcoes) {
    const txt = await IA.pedir(sistema, mensagens, Object.assign({ json: true }, opcoes || {}));
    const j = extrairJSON(txt);
    if (!j) throw new Error('Resposta da IA em formato inesperado.');
    return j;
  };

  // ------------------------------------------------------------ prompts

  function nomeDisc(ano, disc) {
    const d = (CUR.disciplinas[ano] || []).find((x) => x.id === disc);
    return d ? d.nome : disc;
  }

  IA.sistemaBase = function (perfil) {
    const ano = perfil.ano;
    const ciclo = ano <= 4 ? '1.º ciclo do ensino básico' : '3.º ciclo do ensino básico';
    return [
      `És ${perfil.mascote === 'kika' ? 'a Kika' : 'o Kiko'}, uma caturra (pássaro) simpática e paciente que ajuda ${perfil.nome}, um(a) aluno(a) do ${ano}.º ano (${ciclo}) em Portugal, a estudar.`,
      'Regras obrigatórias:',
      '- Escreve SEMPRE em português europeu (de Portugal), com o vocabulário usado nas escolas portuguesas (ex.: "ecrã", "autocarro", "facto", "equipa"; nunca português do Brasil).',
      `- Segue rigorosamente as Aprendizagens Essenciais da DGE em vigor para o ${ano}.º ano e a terminologia dos manuais escolares portugueses (ex.: Dicionário Terminológico em Português, nomenclatura das AE de Matemática de 2021).`,
      `- Não ensines matéria de anos mais avançados. Se te perguntarem algo fora do ${ano}.º ano, explica de forma simples e diz que é matéria de outro ano.`,
      ano <= 4 ? '- Frases curtas, palavras simples, exemplos do dia a dia de uma criança de ' + (ano === 3 ? '8-9' : '9-10') + ' anos.' : '- Linguagem clara e motivadora para um(a) jovem de 12-13 anos, com rigor científico.',
      '- Sê caloroso(a) e encorajador(a). Nunca dês respostas erradas: se não tiveres a certeza, diz que é melhor confirmar no manual ou com o professor.',
      '- Só falas de temas escolares e de estudo. Se a conversa fugir para outros assuntos, puxa-a gentilmente de volta para o estudo. Não peças dados pessoais.',
      '- As tuas respostas vão ser lidas em voz alta: evita tabelas, markdown, listas longas e símbolos estranhos.',
      '- PRIORIDADE: a matéria, a ordem e a terminologia dos manuais adotados pelo aluno (abaixo). Quando conheceres o conteúdo desses manuais, segue-o; quando não, segue as Aprendizagens Essenciais.',
      '- Manuais adotados: ' + Object.keys((CUR.manuais || {})[ano] || {}).map(function (d) { return nomeDisc(ano, d) + ' — ' + CUR.manuais[ano][d]; }).join('; ') + '.'
    ].join('\n');
  };

  /** Encaminha uma frase da criança: decide se abre um tema existente, gera quiz, ou responde. */
  IA.conversar = async function (perfil, historico, frase) {
    const temas = [];
    (CUR.disciplinas[perfil.ano] || []).forEach((d) => {
      (CUR.porAno[perfil.ano][d.id] || []).forEach((t) => temas.push(t.id + ' = ' + d.nome + ': ' + t.t));
    });
    const sistema = IA.sistemaBase(perfil) + '\n\n' +
      'Temas disponíveis na app (id = disciplina: tema):\n' + temas.join('\n') + '\n\n' +
      'Responde APENAS com um objeto JSON com esta forma:\n' +
      '{"fala": "o que a caturra diz (máx. 4 frases curtas)", "acao": "nenhuma|resumo|quiz|cartoes|quiz_livre", "tema": "id de um tema da lista ou vazio", "disciplina": "id da disciplina ou vazio", "tema_livre": "título do tema se acao=quiz_livre"}\n' +
      '- Se a criança quer estudar/rever um tema que existe na lista, usa acao "resumo" (ou "quiz"/"cartoes" se pediu isso) e o id em "tema".\n' +
      '- Se quer estudar algo do seu ano que não está na lista, usa "quiz_livre" com "tema_livre" e a "disciplina".\n' +
      '- Se faz uma pergunta de matéria, responde em "fala" com uma explicação curta e correta e acao "nenhuma".';
    const msgs = historico.slice(-8).map((m) => ({ papel: m.quem === 'eu' ? 'user' : 'assistant', texto: m.texto }));
    msgs.push({ papel: 'user', texto: frase });
    return IA.json(sistema, msgs, { max: 900 });
  };

  /** Cria perguntas de escolha múltipla sobre um tema. */
  IA.criarQuiz = async function (perfil, disc, titulo, tema, n) {
    n = n || 8;
    const ae = tema ? ('\nAprendizagens Essenciais deste tema: ' + (tema.ae || '') + '\nPontos-chave: ' + (tema.r || []).join(' | ')) : '';
    const sistema = IA.sistemaBase(perfil) + '\n\nCrias perguntas de avaliação iguais às dos testes e fichas dos manuais portugueses.';
    const pedido = `Cria ${n} perguntas de escolha múltipla de ${nomeDisc(perfil.ano, disc)} do ${perfil.ano}.º ano sobre "${titulo}".${ae}\n` +
      (titulo.length > 60 ? 'O texto acima pode ser um índice copiado do manual: distribui as perguntas pelos vários tópicos.\n' : '') +
      'Varia a dificuldade (fácil, média, difícil). Cada pergunta tem 4 opções (ou 2 se for verdadeiro/falso), só uma correta, e uma explicação curta.\n' +
      'Responde APENAS em JSON: {"titulo":"título curto do tema, máx. 5 palavras, sem números de página","perguntas":[{"p":"enunciado","opcoes":["a","b","c","d"],"certa":0,"explicacao":"..."}]}';
    const j = await IA.json(sistema, [{ papel: 'user', texto: pedido }], { max: 3500, temp: 0.7 });
    const lista = (j.perguntas || []).filter((q) => q && q.p && Array.isArray(q.opcoes) && q.opcoes.length >= 2 &&
      Number.isInteger(q.certa) && q.certa >= 0 && q.certa < q.opcoes.length);
    if (!lista.length) throw new Error('A IA não conseguiu criar perguntas.');
    const out = lista.map((q) => {
      const certa = String(q.opcoes[q.certa]);
      const erradas = q.opcoes.filter((_, i) => i !== q.certa).map(String);
      return { p: String(q.p), certa: certa, erradas: erradas, exp: q.explicacao ? String(q.explicacao) : '', ia: true };
    });
    const tc = typeof j.titulo === 'string' ? j.titulo.replace(/\s+/g, ' ').trim() : '';
    out.titulo = tc && tc.length <= 50 ? tc : '';
    return out;
  };

  /** Explicação de um tema adaptada à idade. */
  IA.explicar = async function (perfil, tema, pergunta) {
    const sistema = IA.sistemaBase(perfil);
    const ctx = 'Tema: ' + tema.t + ' (' + nomeDisc(perfil.ano, tema.disc) + ')\nAE: ' + (tema.ae || '') + '\nPontos-chave do manual: ' + tema.r.join(' | ');
    const texto = pergunta
      ? ctx + '\n\nPergunta do aluno: ' + pergunta + '\nResponde em no máximo 6 frases.'
      : ctx + '\n\nExplica este tema como um professor muito simpático, em no máximo 8 frases, com um exemplo e um truque para memorizar.';
    return IA.pedir(sistema, [{ papel: 'user', texto: texto }], { max: 900 });
  };

  IA.testar = async function () {
    const t = await IA.pedir('Responde só com a palavra: ok', [{ papel: 'user', texto: 'Teste' }], { max: 20 });
    return t;
  };
})();
