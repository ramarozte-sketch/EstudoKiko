/* Geradores de exercícios de Matemática (prática ilimitada, offline).
 * Cada gerador devolve n perguntas { p, certa, erradas:[], exp } */
(function () {
  'use strict';
  const R = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const P = (a) => a[Math.floor(Math.random() * a.length)];
  // formato português: vírgula decimal e espaço nos milhares
  function f(n) {
    const neg = n < 0; n = Math.abs(n);
    let s = (Math.round(n * 1000) / 1000).toString();
    let [i, d] = s.split('.');
    i = i.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    return (neg ? '−' : '') + i + (d ? ',' + d : '');
  }
  function fz(n) { return n < 0 ? '(' + f(n) + ')' : f(n); }
  function distratores(certa, cands, fmt) {
    fmt = fmt || f;
    const out = new Set(); const c = fmt(certa);
    cands.forEach((x) => { const s = fmt(x); if (s !== c && !Number.isNaN(x)) out.add(s); });
    let k = 1;
    while (out.size < 3 && k < 50) { [certa + k, certa - k].forEach((x) => { const s = fmt(x); if (s !== c && out.size < 3) out.add(s); }); k++; }
    return Array.from(out).slice(0, 3);
  }
  function q(p, certa, cands, exp, fmt) {
    fmt = fmt || f;
    const c = typeof certa === 'string' ? certa : fmt(certa);
    const e = Array.isArray(cands) && typeof cands[0] === 'string' ? cands : distratores(certa, cands, fmt);
    const erradas = e.map(String).filter((x, i, arr) => x !== c && arr.indexOf(x) === i && !/NaN|undefined|Infinity/.test(x));
    return { p, certa: c, erradas, exp: exp || '' };
  }
  function varios(fn) { return (n) => { const out = [], vistos = new Set(); let g = 0; while (out.length < n && g++ < n * 10) { const x = fn(); if (x.erradas.length >= 2 && !vistos.has(x.p)) { vistos.add(x.p); out.push(x); } } return out; }; }

  const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
  const sup = (n) => String(n).split('').map((d) => SUP[+d]).join('');
  const G = (window.GERADORES = {});

  // ---------------------------------------------------------------- 4.º ano
  G.numeros4 = varios(() => {
    const n = R(100000, 999999);
    const ordens = ['unidades', 'dezenas', 'centenas', 'unidades de milhar', 'dezenas de milhar', 'centenas de milhar'];
    const k = R(0, 5);
    const dig = Math.floor(n / Math.pow(10, k)) % 10;
    if (Math.random() < 0.5 || dig === 0) {
      return q(`No número ${f(n)}, qual é o algarismo das ${ordens[k]}?`, String(dig),
        Array.from(new Set(String(n).split('').filter((d) => d !== String(dig)))).concat(['0', '9']).filter((d) => d !== String(dig)).slice(0, 3),
        `Conta da direita para a esquerda: unidades, dezenas, centenas, unidades de milhar, dezenas de milhar, centenas de milhar.`);
    }
    const valor = dig * Math.pow(10, k);
    return q(`No número ${f(n)}, qual é o valor do algarismo ${dig} que está nas ${ordens[k]}?`, valor,
      [valor * 10 || 10, Math.max(1, valor / 10) | 0, dig + 1000 * (k > 2 ? 1 : 0) || 100], 'O valor de um algarismo depende da posição (ordem) em que está.');
  });

  G.tabuada4 = varios(() => {
    if (Math.random() < 0.6) {
      const a = R(2, 10), b = R(2, 10);
      return q(`Quanto é ${a} × ${b}?`, a * b, [a * (b + 1), a * (b - 1), (a + 1) * b, a + b], `${a} × ${b} = ${a * b}`);
    }
    const a = R(12, 99), b = R(3, 9);
    return q(`Calcula: ${a} × ${b}`, a * b, [a * b + 10, a * b - 10, a * (b - 1), a * b + b], `Multiplica as unidades e depois as dezenas: ${a} × ${b} = ${f(a * b)}.`);
  });

  G.divisao4 = varios(() => {
    const d = R(2, 9), qu = R(3, 25), r = Math.random() < 0.5 ? 0 : R(1, d - 1);
    const D = d * qu + r;
    const ok = r ? `${qu}, resto ${r}` : `${qu}, resto 0`;
    const err = [`${qu + 1}, resto ${r}`, `${qu - 1}, resto ${r + d > d ? r : r + 1}`, `${qu}, resto ${(r + 1) % d}`].filter((x) => x !== ok);
    return q(`Na divisão inteira de ${D} por ${d}, qual é o quociente e o resto?`, ok, Array.from(new Set(err)).concat([`${qu + 2}, resto 0`]).slice(0, 3),
      `${d} × ${qu} = ${d * qu} e ${D} − ${d * qu} = ${r}. O resto é sempre menor do que o divisor.`);
  });

  G.multiplos4 = varios(() => {
    const m = P([2, 3, 4, 5, 6, 9, 10]);
    if (Math.random() < 0.5) {
      const certo = m * R(3, 12);
      const errados = []; while (errados.length < 3) { const x = R(10, 99); if (x % m && errados.indexOf(f(x)) < 0) errados.push(f(x)); }
      return q(`Qual destes números é múltiplo de ${m}?`, f(certo), errados, `${f(certo)} = ${m} × ${certo / m}`);
    }
    const n = P([12, 18, 20, 24, 30, 36]);
    const divs = []; for (let i = 1; i <= n; i++) if (n % i === 0) divs.push(i);
    const d = P(divs.filter((x) => x > 1 && x < n));
    const errados = []; while (errados.length < 3) { const x = R(2, n - 1); if (n % x && errados.indexOf(f(x)) < 0) errados.push(f(x)); }
    return q(`Qual destes números é divisor de ${n}?`, f(d), errados, `${n} : ${d} = ${n / d}, divisão exata (resto 0).`);
  });

  G.fracoes4 = varios(() => {
    const t = R(0, 2);
    if (t === 0) {
      const den = P([2, 3, 4, 5, 10]), num = R(1, den - 1), tot = den * R(2, 8);
      return q(`Quanto é ${num}/${den} de ${tot}?`, (tot / den) * num, [tot / den, tot - (tot / den) * num, (tot / den) * (num + 1)],
        `Divide ${tot} em ${den} partes iguais (${tot / den}) e junta ${num} ${num > 1 ? 'partes' : 'parte'}.`);
    }
    if (t === 1) {
      const den = P([4, 5, 6, 8, 10]), a = R(1, den - 1); let b = R(1, den - 1); if (b === a) b = a === 1 ? 2 : a - 1;
      const maior = a > b ? a : b;
      return q(`Qual é a fração maior: ${a}/${den} ou ${b}/${den}?`, `${maior}/${den}`, [`${a + b - maior}/${den}`, 'São iguais'],
        'Com o mesmo denominador, é maior a fração com maior numerador.');
    }
    const base = P([[1, 2], [1, 3], [1, 4], [3, 4], [2, 5]]), k = R(2, 4);
    return q(`Qual fração é equivalente a ${base[0]}/${base[1]}?`, `${base[0] * k}/${base[1] * k}`,
      [`${base[0] + k}/${base[1] + k}`, `${base[0] * k}/${base[1]}`, `${base[0]}/${base[1] * k}`], `Multiplica o numerador e o denominador pelo mesmo número (${k}).`);
  });

  G.decimais4 = varios(() => {
    const t = R(0, 2);
    if (t === 0) {
      const a = R(1, 99) / 10, b = R(1, 99) / 100;
      return q(`Quanto é ${f(a)} + ${f(b)}?`, Math.round((a + b) * 100) / 100, [Math.round((a + b * 10) * 100) / 100, Math.round((a + b + 0.1) * 100) / 100, Math.round((a + b - 0.01) * 100) / 100],
        'Alinha as vírgulas: décimas com décimas e centésimas com centésimas.');
    }
    if (t === 1) {
      const a = R(1, 9) / 10; let b = Math.round((a - 0.1 + R(1, 19) / 100) * 100) / 100;
      if (b === a) b = Math.round((a + 0.01) * 100) / 100;
      const certo = a > b ? a : b;
      return q(`Qual é o número maior: ${f(a)} ou ${f(b)}?`, certo, [a > b ? b : a], 'Compara primeiro as décimas, depois as centésimas. Podes acrescentar zeros: 0,5 = 0,50.');
    }
    const n = R(1, 9), ordem = P([['décimas', 10], ['centésimas', 100], ['milésimas', 1000]]);
    return q(`${n} ${ordem[0]} escreve-se…`, n / ordem[1], [n / (ordem[1] === 10 ? 100 : 10), n, n / (ordem[1] === 1000 ? 100 : 1000)],
      `1 décima = 0,1; 1 centésima = 0,01; 1 milésima = 0,001.`);
  });

  G.medida4 = varios(() => {
    const conv = P([
      ['m', 'cm', 100], ['km', 'm', 1000], ['m', 'mm', 1000], ['cm', 'mm', 10], ['m', 'dm', 10],
      ['kg', 'g', 1000], ['t', 'kg', 1000], ['L', 'mL', 1000], ['L', 'dL', 10], ['L', 'cL', 100]
    ]);
    if (Math.random() < 0.6) {
      const v = P([2, 3, 4, 5, 1.5, 2.5, 0.5]);
      return q(`${f(v)} ${conv[0]} = quantos ${conv[1]}?`, v * conv[2], [v * conv[2] / 10, v * conv[2] * 10, v + conv[2]].map((x) => Math.round(x * 100) / 100),
        `1 ${conv[0]} = ${f(conv[2])} ${conv[1]}, por isso multiplica por ${f(conv[2])}.`);
    }
    const v = conv[2] * P([2, 3, 5, 0.5, 1.5]);
    return q(`${f(v)} ${conv[1]} = quantos ${conv[0]}?`, v / conv[2], [v / conv[2] * 10, v / conv[2] / 10, v].map((x) => Math.round(x * 1000) / 1000),
      `Para passar de ${conv[1]} para ${conv[0]} divide por ${f(conv[2])}.`);
  });

  G.area4 = varios(() => {
    const b = R(2, 9), a = b + R(1, 6);
    if (Math.random() < 0.5) return q(`Um retângulo tem ${a} cm de comprimento e ${b} cm de largura. Qual é o perímetro?`, (a + b) * 2 + ' cm', [a * b + ' cm', a + b + ' cm', (a + b) * 2 + ' cm²'], 'Perímetro = soma de todos os lados = 2 × comprimento + 2 × largura.');
    if (Math.random() < 0.5) return q(`Um retângulo tem ${a} cm por ${b} cm. Qual é a área?`, a * b + ' cm²', [(a + b) * 2 + ' cm²', a * b + ' cm', a + b + ' cm²'], 'Área do retângulo = comprimento × largura, em cm² (centímetros quadrados).');
    const l = R(2, 10);
    return q(`Um quadrado tem ${l} cm de lado. Qual é a área?`, l * l + ' cm²', [4 * l + ' cm²', l * 2 + ' cm²', l * l + ' cm'], 'Área do quadrado = lado × lado.');
  });

  G.tempo4 = varios(() => {
    const t = R(0, 2);
    if (t === 0) { const h = R(1, 3), m = P([10, 15, 20, 30, 45]); return q(`Quantos minutos há em ${h} h e ${m} min?`, h * 60 + m + ' min', [h * 100 + m + ' min', h * 60 + ' min', (h + 1) * 60 + m + ' min'], '1 hora = 60 minutos.'); }
    if (t === 1) {
      const h = R(8, 17), m = P([10, 20, 35, 40, 50]), d = P([25, 30, 35, 45, 50]);
      const tot = h * 60 + m + d; const hh = Math.floor(tot / 60), mm = tot % 60;
      const s = (H, M) => H + 'h' + String(M).padStart(2, '0');
      return q(`Um filme começou às ${s(h, m)} e durou ${d} minutos. A que horas acabou?`, s(hh, mm), [s(h, m + d > 59 ? (m + d) % 100 : m + d), s(hh + 1, mm), s(hh, (mm + 10) % 60)].filter((x) => x !== s(hh, mm)),
        'Junta os minutos; quando passas dos 60, acrescenta 1 hora.');
    }
    const e = R(1, 9), c = P([5, 10, 20, 50]);
    const tot = e * 100 + c * R(1, 3);
    return q(`Quanto dinheiro há em ${e} € e ${tot - e * 100} cêntimos?`, f(tot / 100) + ' €', [f(e + (tot - e * 100) / 10) + ' €', f(tot) + ' €', f(e + 1) + ' €'], '100 cêntimos = 1 euro.');
  });


  // ---------------------------------------------------------------- 3.º ano
  G.numeros3 = varios(() => {
    const t = R(0, 2);
    if (t === 0) {
      const n = R(1000, 9999), ordens = ['unidades', 'dezenas', 'centenas', 'milhares'], k = R(0, 3);
      const dig = Math.floor(n / Math.pow(10, k)) % 10;
      const err = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'].filter((d) => d !== String(dig));
      return q(`No número ${n}, qual é o algarismo das ${ordens[k]}?`, String(dig), U.shuffle(err).slice(0, 3), 'Da direita para a esquerda: unidades, dezenas, centenas, milhares.');
    }
    if (t === 1) {
      const n = R(101, 9989), d = P([1, 10, 100]);
      return q(`Qual é o número que vem ${d === 1 ? 'a seguir a' : d + ' unidades depois de'} ${n}?`, n + d, [n + d + 1, n - d, n + d * 10], `${n} + ${d} = ${n + d}`, String);
    }
    const m = R(1, 9), c = R(0, 9), dz = R(0, 9), u = R(0, 9), n = m * 1000 + c * 100 + dz * 10 + u;
    return q(`${m} milhares, ${c} centenas, ${dz} dezenas e ${u} unidades formam o número…`, n, [m * 100 + c * 10 + dz, m * 1000 + dz * 100 + c * 10 + u, n + 100], 'Escreve os algarismos pela ordem: milhares, centenas, dezenas, unidades.', String);
  });

  G.adicao3 = varios(() => {
    if (Math.random() < 0.5) {
      const a = R(100, 899), b = R(50, 999 - a);
      return q(`Quanto é ${a} + ${b}?`, a + b, [a + b + 10, a + b - 10, a + b + 1], 'Soma unidades com unidades, dezenas com dezenas, centenas com centenas (e não te esqueças do "vai um").', String);
    }
    const a = R(200, 999), b = R(20, a - 50);
    return q(`Quanto é ${a} − ${b}?`, a - b, [a - b + 10, a - b - 10, a + b], 'Subtrai começando pelas unidades. Confirma: a diferença + o subtrativo = o aditivo.', String);
  });

  G.divisao3 = varios(() => {
    const d = R(2, 10), qu = R(2, 10), tot = d * qu;
    const t = R(0, 2);
    if (t === 0) return q(`Repartem-se ${tot} berlindes igualmente por ${d} amigos. Quantos recebe cada um?`, qu, [qu + 1, qu - 1, tot - d], `${tot} : ${d} = ${qu}, porque ${d} × ${qu} = ${tot}.`, String);
    if (t === 1) { const n = R(2, 50) * 2; return q(`Qual é a metade de ${n}?`, n / 2, [n * 2, n / 2 + 1, n - 2], 'Metade é dividir por 2.', String); }
    const n = R(2, 30); return q(`Qual é o triplo de ${n}?`, n * 3, [n * 2, n + 3, n * 4], 'Triplo é multiplicar por 3.', String);
  });

  G.fracoes3 = varios(() => {
    const p = P([[2, 'metade'], [3, 'terça parte'], [4, 'quarta parte'], [5, 'quinta parte'], [10, 'décima parte']]);
    const tot = p[0] * R(2, 9);
    if (Math.random() < 0.6) return q(`Qual é a ${p[1]} de ${tot}?`, tot / p[0], [tot / p[0] + 1, tot * p[0], tot - p[0]], `Divide ${tot} em ${p[0]} partes iguais: ${tot} : ${p[0]} = ${tot / p[0]}.`, String);
    return q(`Como se escreve "${p[1]}" em fração?`, '1/' + p[0], ['1/' + (p[0] === 2 ? 3 : 2), p[0] + '/1', '2/' + p[0]].filter((x) => x !== '1/' + p[0]), `${p[1]} = 1/${p[0]}`);
  });

  G.medida3 = varios(() => {
    const c = P([['m', 'cm', 100], ['km', 'm', 1000], ['kg', 'g', 1000], ['L', 'mL', 1000], ['cm', 'mm', 10]]);
    const v = R(2, 9);
    return q(`${v} ${c[0]} = quantos ${c[1]}?`, v * c[2], [v * c[2] / 10, v * c[2] * 10, v + c[2]], `1 ${c[0]} = ${c[2]} ${c[1]}`);
  });


  // ---------------------------------------------------------------- 4.º ano (PLIM): novos
  G.mult2alg4 = varios(() => {
    const a = R(12, 99), b = R(11, 39);
    return q(`Calcula: ${a} × ${b}`, a * b, [a * b + 10, a * (b - 1), a * b - a, a * b + 100], `${a} × ${b} = ${a} × ${Math.floor(b / 10) * 10} + ${a} × ${b % 10} = ${f(a * Math.floor(b / 10) * 10)} + ${f(a * (b % 10))}`);
  });
  G.div2alg4 = varios(() => {
    const d = R(11, 36), qu = R(3, 25), r = Math.random() < 0.6 ? 0 : R(1, d - 1), D = d * qu + r;
    const ok = r ? `${qu}, resto ${r}` : `${qu}`;
    const err = r ? [`${qu + 1}, resto ${r}`, `${qu - 1}, resto ${r}`, `${qu}, resto ${(r + 1) % d || 1}`] : [`${qu + 1}`, `${qu - 1}`, `${qu * 10}`];
    return q(`Quanto é ${D} : ${d}?${r ? ' (quociente e resto)' : ''}`, ok, err, `Prova: ${d} × ${qu}${r ? ' + ' + r : ''} = ${D}.`);
  });
  G.capacidade4 = varios(() => {
    const c = P([['l', 'ml', 1000], ['l', 'cl', 100], ['cl', 'ml', 10]]);
    if (Math.random() < 0.5) { const v = P([2, 3, 5, 0.5, 0.25, 1.5]); return q(`${f(v)} ${c[0]} = quantos ${c[1]}?`, v * c[2], [v * c[2] / 10, v * c[2] * 10, v * 100 === v * c[2] ? v * 1000 : v * 100], `1 ${c[0]} = ${c[2]} ${c[1]}`); }
    const n = P([2, 4, 5, 8]), cap = P([250, 500, 200, 1000]);
    return q(`Quantos mililitros levam ${n} copos de ${cap} ml?`, n * cap + ' ml', [n * cap / 10 + ' ml', (n + 1) * cap + ' ml', n * cap * 10 + ' ml'], `${n} × ${cap} = ${n * cap} ml${n * cap >= 1000 ? ' = ' + f(n * cap / 1000) + ' l' : ''}`);
  });
  G.percent4 = varios(() => {
    const t = R(0, 2);
    if (t === 0) { const p = P([10, 25, 50, 75]); return q(`Como se escreve ${p}% em número decimal?`, p / 100, [p / 10, p, p / 1000], `${p}% = ${p}/100 = ${f(p / 100)}`); }
    if (t === 1) { const p = P([[50, '1/2'], [25, '1/4'], [75, '3/4'], [10, '1/10']]); return q(`A que fração corresponde ${p[0]}%?`, p[1], ['1/2', '1/4', '3/4', '1/10', '1/5'].filter((x) => x !== p[1]).slice(0, 3), `${p[0]}% = ${p[0]}/100 = ${p[1]}`); }
    const p = P([10, 25, 50]), tot = P([20, 40, 60, 80, 100, 200]);
    return q(`Quanto é ${p}% de ${tot}?`, tot * p / 100, [tot * p / 10, tot - tot * p / 100, p], `${p}% de ${tot} = ${tot} × ${f(p / 100)} = ${f(tot * p / 100)}`);
  });
  G.dividir10_4 = varios(() => {
    const div = P([10, 100, 1000]);
    if (Math.random() < 0.5) { const n = P([4, 7, 25, 36, 1234, 5000, 680]); return q(`Quanto é ${f(n)} : ${f(div)}?`, n / div, [n / div * 10, n / div / 10, n * div], `Dividir por ${f(div)}: a vírgula anda ${String(div).length - 1} casa(s) para a esquerda.`); }
    const n = P([2.5, 0.4, 1.234, 3.07, 0.05]); return q(`Quanto é ${f(n)} × ${f(div)}?`, Math.round(n * div * 1000) / 1000, [Math.round(n * div / 10 * 1000) / 1000, Math.round(n * div * 10 * 1000) / 1000, n + div], `Multiplicar por ${f(div)}: a vírgula anda ${String(div).length - 1} casa(s) para a direita.`);
  });
  G.opdec4 = varios(() => {
    const a = R(10, 999) / 100, b = R(10, 499) / 100;
    if (Math.random() < 0.5) return q(`Quanto é ${f(a)} + ${f(b)}?`, Math.round((a + b) * 100) / 100, [Math.round((a + b + 0.1) * 100) / 100, Math.round((a + b - 1) * 100) / 100, Math.round((a * 10 + b) * 100) / 100], 'Alinha as vírgulas (unidades com unidades, décimas com décimas…).');
    const x = Math.max(a, b) + 2, y = Math.min(a, b);
    return q(`Quanto é ${f(x)} − ${f(y)}?`, Math.round((x - y) * 100) / 100, [Math.round((x - y + 0.1) * 100) / 100, Math.round((x - y - 0.01) * 100) / 100, Math.round((x + y) * 100) / 100], 'Alinha as vírgulas e subtrai ordem a ordem, da direita para a esquerda.');
  });
  G.saldo4 = varios(() => {
    const rec = P([20, 25, 30, 40, 50]), d1 = R(3, 12) + P([0, 0.5]), d2 = R(2, 8) + P([0, 0.25, 0.5]);
    const s2 = Math.round((rec - d1 - d2) * 100) / 100;
    return q(`O Tiago recebeu ${rec} € de mesada e gastou ${f(d1)} € e ${f(d2)} €. Qual é o saldo?`, f(s2) + ' €', [f(s2 + 1) + ' €', f(rec - d1) + ' €', f(Math.round((d1 + d2) * 100) / 100) + ' €'], 'Saldo = receita − despesas.');
  });

  // ---------------------------------------------------------------- 7.º ano

  // ---------------------------------------------------------------- 7.º ano (Escola Virtual)
  G.simetricos7 = varios(() => {
    const a = R(-30, 30) || 7, t = R(0, 2);
    if (t === 0) return q(`Qual é o valor absoluto de ${fz(a)}?`, Math.abs(a), [-Math.abs(a), a === Math.abs(a) ? -a : a, Math.abs(a) + 1], 'O valor absoluto é a distância ao zero: nunca é negativo.');
    if (t === 1) return q(`Qual é o simétrico de ${fz(a)}?`, -a, [Math.abs(a) === -a ? a + 1 : Math.abs(a) + 1, a, a - 1], 'Simétricos têm o mesmo valor absoluto e sinais contrários.');
    const b = R(-30, 30) || -5;
    if (a === b) return q(`Qual é o simétrico de ${fz(a)}?`, -a, [a, a + 1, -a + 1]);
    return q(`Qual é o maior: ${fz(a)} ou ${fz(b)}?`, fz(Math.max(a, b)), [fz(Math.min(a, b)), 'são iguais', fz(-Math.max(a, b)) === fz(Math.min(a, b)) ? fz(Math.max(a, b) + 1) : fz(-Math.max(a, b))], 'Na reta numérica, o maior está mais à direita.');
  });
  G.notacao7 = varios(() => {
    const m = P([1.2, 2.5, 3, 4.07, 5.6, 7.8, 9.1]), e = R(3, 9);
    const n = Math.round(m * Math.pow(10, e));
    const fm = String(m).replace('.', ',');
    if (Math.random() < 0.5) return q(`Escreve ${f(n)} em notação científica.`, `${fm} × 10${sup(e)}`, [`${fm} × 10${sup(e - 1)}`, `${fm} × 10${sup(e + 1)}`, `${String(m * 10).replace('.', ',')} × 10${sup(e - 1)}`], 'Na notação científica, o primeiro número está entre 1 e 10 (sem chegar a 10).');
    return q(`Quanto é ${fm} × 10${sup(e)}?`, f(n), [f(n / 10), f(n * 10), f(Math.round(m * 100) * Math.pow(10, Math.max(0, e - 3)))], `Mover a vírgula ${e} casas para a direita.`);
  });
  G.areas7 = varios(() => {
    const t = R(0, 3);
    if (t === 0) { const b = R(3, 15), h = R(2, 12); return q(`Área de um paralelogramo com base ${b} cm e altura ${h} cm (em cm²)?`, b * h, [b * h / 2, 2 * (b + h), b + h], 'A = base × altura'); }
    if (t === 1) { const b = R(2, 10) * 2, h = R(3, 14); return q(`Área de um triângulo com base ${b} cm e altura ${h} cm (em cm²)?`, b * h / 2, [b * h, b + h, b * h / 4], 'A = (base × altura) : 2'); }
    if (t === 2) { const B = R(6, 16), b = R(2, B - 2), h = R(2, 10) * 2; return q(`Área de um trapézio com bases ${B} cm e ${b} cm e altura ${h} cm (em cm²)?`, (B + b) * h / 2, [(B + b) * h, B * b * h / 2, (B - b) * h / 2], 'A = (base maior + base menor) : 2 × altura'); }
    const D = R(3, 10) * 2, d = R(2, 9); return q(`Área de um losango com diagonais ${D} cm e ${d} cm (em cm²)?`, D * d / 2, [D * d, D + d, (D + d) * 2], 'A = (diagonal maior × diagonal menor) : 2 — vale também para o papagaio.');
  });
  G.euler7 = varios(() => {
    const s = P([['cubo', 6, 8, 12], ['prisma triangular', 5, 6, 9], ['pirâmide quadrangular', 5, 5, 8], ['prisma pentagonal', 7, 10, 15], ['pirâmide hexagonal', 7, 7, 12], ['tetraedro', 4, 4, 6], ['prisma hexagonal', 8, 12, 18], ['octaedro', 8, 6, 12]]);
    const t = R(0, 2);
    if (t === 0) return q(`Um ${s[0]} tem ${s[1]} faces e ${s[2]} vértices. Quantas arestas tem?`, s[3], [s[1] + s[2], s[3] + 2, s[3] - 2], 'Relação de Euler: F + V = A + 2');
    if (t === 1) return q(`Um ${s[0]} tem ${s[2]} vértices e ${s[3]} arestas. Quantas faces tem?`, s[1], [s[1] + 2, s[3] - s[2], s[1] - 1], 'Relação de Euler: F + V = A + 2');
    return q(`Um ${s[0]} tem ${s[1]} faces e ${s[3]} arestas. Quantos vértices tem?`, s[2], [s[2] + 2, s[3] - s[1], s[2] - 1], 'Relação de Euler: F + V = A + 2');
  });

  G.inteiros7 = varios(() => {
    const a = R(-15, 15) || -4, b = R(-12, 12) || 3, op = R(0, 3);
    if (op === 0) return q(`Calcula: ${fz(a)} + ${fz(b)}`, a + b, [a - b, -(a + b), Math.abs(a) + Math.abs(b)], 'Sinais iguais: soma e mantém o sinal. Sinais diferentes: subtrai e fica o sinal do maior em valor absoluto.');
    if (op === 1) return q(`Calcula: ${fz(a)} − ${fz(b)}`, a - b, [a + b, b - a, -(a - b) + 2], 'Subtrair é adicionar o simétrico: a − b = a + (−b).');
    if (op === 2) { const x = R(-9, 9) || 2, y = R(-9, 9) || -3; return q(`Calcula: ${fz(x)} × ${fz(y)}`, x * y, [-(x * y), x + y, x * y + (x * y > 0 ? 1 : -1)], 'Sinais iguais → resultado positivo; sinais diferentes → negativo.'); }
    const x = R(-9, 9) || -3, y = R(-9, 9) || 4; const D = x * y;
    return q(`Calcula: ${fz(D)} : ${fz(x)}`, y, [-y, D - x, y + 1], 'Na divisão, a regra dos sinais é igual à da multiplicação.');
  });

  G.potencias7 = varios(() => {
    const t = R(0, 3);
    if (t === 0) { const b = R(2, 5), e = R(2, 4); return q(`Quanto é ${b}${sup(e)}?`, Math.pow(b, e), [b * e, Math.pow(b, e - 1), Math.pow(b + 1, e)], `${b}${sup(e)} é ${b} multiplicado por si próprio ${e} vezes.`); }
    if (t === 1) { const b = R(2, 7), m = R(2, 5), n = R(2, 5); return q(`${b}${sup(m)} × ${b}${sup(n)} = ${b} elevado a quanto?`, m + n, [m * n, m + n + 1, Math.abs(m - n) || 7], 'Produto de potências com a mesma base: mantém a base e adiciona os expoentes.'); }
    if (t === 2) { const r = R(2, 15); return q(`Qual é a raiz quadrada de ${r * r}?`, r, [r * 2, (r * r) / 2, r + 1], `${r} × ${r} = ${r * r}`); }
    const r = R(2, 6); return q(`Qual é a raiz cúbica de ${r * r * r}?`, r, [r * r, r * 3, r + 1], `${r} × ${r} × ${r} = ${r * r * r}`);
  });

  G.equacoes7 = varios(() => {
    const x = R(-6, 12) || 5, t = R(0, 3);
    let p, a, b, c;
    if (t === 0) { a = R(2, 15); p = `x + ${a} = ${x + a}`; }
    else if (t === 1) { a = R(2, 9); p = `${a}x = ${a * x}`; }
    else if (t === 2) { a = R(2, 6); b = R(1, 12); p = `${a}x − ${b} = ${a * x - b}`; }
    else { a = R(3, 7); c = R(1, a - 1); b = R(1, 9); const d = (a - c) * x + b; p = `${a}x + ${b} = ${c}x + ${d}`; }
    return q(`Resolve a equação: ${p}`, 'x = ' + f(x), ['x = ' + f(-x || 1), 'x = ' + f(x + 1), 'x = ' + f(x * 2 === x ? 3 : x * 2)].filter((s, i, arr) => s !== 'x = ' + f(x) && arr.indexOf(s) === i),
      'Isola o x: passa os termos de um membro para o outro trocando a operação (ou o sinal), e verifica substituindo a solução.');
  });

  G.proporc7 = varios(() => {
    if (Math.random() < 0.5) {
      const n = R(2, 5), preco = P([1.5, 2, 0.8, 1.2, 2.5]), m = R(n + 1, 10);
      return q(`${n} cadernos custam ${f(n * preco)} €. Quanto custam ${m} cadernos (mesmo preço cada)?`, f(m * preco) + ' €',
        [f(m * preco + preco) + ' €', f(n * preco + m) + ' €', f(m * preco - preco) + ' €'], `Preço de 1 caderno: ${f(n * preco)} : ${n} = ${f(preco)} €. Depois multiplica por ${m}.`);
    }
    const k = R(2, 9), x = R(2, 8);
    return q(`Numa proporcionalidade direta, quando x = ${x}, y = ${k * x}. Qual é a constante de proporcionalidade?`, k, [k * x, x, k + 1], 'A constante de proporcionalidade direta é k = y : x.');
  });

  G.estat7 = varios(() => {
    const n = P([5, 6, 7]);
    const dados = Array.from({ length: n }, () => R(2, 10));
    const ord = dados.slice().sort((a, b) => a - b);
    const t = R(0, 3);
    const lista = dados.join(', ');
    if (t === 0) { const s = dados.reduce((a, b) => a + b, 0); const m = Math.round((s / n) * 100) / 100; return q(`Qual é a média de: ${lista}?`, m, [Math.round((s / (n - 1)) * 10) / 10, s, ord[Math.floor(n / 2)]], `Soma todos (${s}) e divide pelo número de dados (${n}).`); }
    if (t === 1) { const med = n % 2 ? ord[(n - 1) / 2] : (ord[n / 2 - 1] + ord[n / 2]) / 2; return q(`Qual é a mediana de: ${lista}?`, med, [dados[Math.floor(n / 2)], ord[0], ord[n - 1]], `Ordena (${ord.join(', ')}) e escolhe o valor do meio${n % 2 ? '' : ' (média dos dois do meio)'}.`); }
    if (t === 2) { const amp = ord[n - 1] - ord[0]; return q(`Qual é a amplitude de: ${lista}?`, amp, [ord[n - 1], ord[n - 1] + ord[0], amp + 1], 'Amplitude = máximo − mínimo.'); }
    const moda = R(2, 9); const d2 = U.shuffle([moda, moda, moda].concat(Array.from({ length: 4 }, () => { let v; do { v = R(1, 10); } while (v === moda); return v; })));
    const cont = {}; d2.forEach((v) => (cont[v] = (cont[v] || 0) + 1));
    if (Object.keys(cont).some((k) => +k !== moda && cont[k] >= 3)) return q(`Qual é a amplitude de: 3, 9, 4, 7?`, 6, [9, 3, 7], 'Amplitude = máximo − mínimo.');
    return q(`Qual é a moda de: ${d2.join(', ')}?`, moda, Object.keys(cont).map(Number).filter((v) => v !== moda), 'A moda é o valor que aparece mais vezes.');
  });

  G.sequencias7 = varios(() => {
    const a = R(2, 6), b = R(-3, 8);
    const termo = (n) => a * n + b;
    if (Math.random() < 0.5) {
      const ts = [1, 2, 3, 4].map(termo);
      return q(`Qual é o próximo termo da sequência ${ts.map(f).join(', ')}, …?`, termo(5), [termo(5) + a, termo(5) - 1, ts[3] + 1], `A diferença entre termos consecutivos é ${a}.`);
    }
    const n = R(5, 20);
    return q(`O termo geral de uma sequência é ${a}n ${b < 0 ? '− ' + -b : '+ ' + b}. Qual é o ${n}.º termo?`, termo(n), [a * n, termo(n) + a, termo(n - 1)], `Substitui n por ${n}: ${a} × ${n} ${b < 0 ? '− ' + -b : '+ ' + b} = ${termo(n)}.`);
  });

  G.angulos7 = varios(() => {
    if (Math.random() < 0.6) {
      const a = R(30, 90), b = R(20, 150 - a);
      return q(`Num triângulo, dois ângulos medem ${a}° e ${b}°. Quanto mede o terceiro?`, (180 - a - b) + '°', [(360 - a - b) + '°', (a + b) + '°', (180 - a) + '°'], 'A soma dos ângulos internos de um triângulo é 180°.');
    }
    const a = R(60, 120), b = R(60, 120), c = R(50, 110);
    const d = 360 - a - b - c;
    if (d <= 10 || d >= 180) return q('Quanto é a soma dos ângulos internos de um quadrilátero?', '360°', ['180°', '540°', '90°'], 'Um quadrilátero divide-se em dois triângulos: 2 × 180° = 360°.');
    return q(`Num quadrilátero, três ângulos medem ${a}°, ${b}° e ${c}°. Quanto mede o quarto?`, d + '°', [(180 - (a + b + c) % 180) + '°', (d + 10) + '°', (360 - a - b) + '°'], 'A soma dos ângulos internos de um quadrilátero é 360°.');
  });

  G.fmt = f;
})();
