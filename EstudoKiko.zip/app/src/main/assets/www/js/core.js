/* Núcleo: utilitários, armazenamento, voz (ouvir/falar), sons, toast, modal */
(function () {
  'use strict';

  // ------------------------------------------------------------ utilitários
  const U = (window.U = {});
  U.$ = (s, r) => (r || document).querySelector(s);
  U.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  U.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  U.norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9ºª%\s-]/g, ' ').replace(/\s+/g, ' ').trim();
  U.shuffle = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  U.pick = (a) => a[Math.floor(Math.random() * a.length)];
  U.rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  U.today = () => { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  U.addDays = (iso, n) => { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
  U.daysBetween = (a, b) => Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000);
  const DS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'], MS = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  U.fmtDate = (iso) => { const d = new Date(iso + 'T12:00:00'); return DS[d.getDay()] + ', ' + d.getDate() + ' ' + MS[d.getMonth()]; };
  U.fmtCurto = (iso) => { const d = new Date(iso + 'T12:00:00'); return DS[d.getDay()] + '<br>' + d.getDate() + '/' + (d.getMonth() + 1); };
  U.hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); };
  U.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // ---- temas escritos/colados pelo aluno (ex.: índice de um manual copiado)
  // Limpa números de página, marcadores e espaços; devolve uma lista de tópicos.
  U.topicosTema = function (s) {
    let t = String(s || '').replace(/[\r\n\t]+/g, ' ');
    t = t.replace(/[•·▪■●◦‣∙|]/g, ' ; ')
      .replace(/\.{2,}/g, ' ')                            // "Tema ........ 36"
      .replace(/(^|\s)\.(?=\s|$)/g, ' ; ')                 // " . " solto
      .replace(/(^|\s)(p(?:ágina|agina|ág|ag)?s?\.?\s*)?\d{1,3}(?=\s|$)/gi, ' ; ') // números de página soltos
      .replace(/\s+/g, ' ');
    const partes = t.split(/\s*;\s*|(?<=\?)\s+/)
      .map((x) => x.replace(/^[\s,.:–—-]+|[\s,:–—-]+$/g, '').trim())
      .filter((x) => x.length > 1 && /[a-zà-ú]/i.test(x));
    // TUDO EM MAIÚSCULAS → frase normal
    return partes.map((x) => {
      const letras = x.replace(/[^a-zà-úA-ZÀ-Ú]/g, '');
      if (letras.length > 3 && letras === letras.toUpperCase()) {
        x = x.toLowerCase();
        x = x.replace(/\b(sig|ue|cplp|onu|gps)\b/g, (m) => m.toUpperCase());
        x = x.charAt(0).toUpperCase() + x.slice(1);
      }
      return x;
    });
  };
  // Texto completo limpo (para enviar à IA)
  U.limparTema = (s) => { const p = U.topicosTema(s); return p.length ? p.join('; ') : String(s || '').trim(); };
  // Título curto para mostrar no ecrã (cabeçalho do quiz, resultados, histórico)
  U.tituloCurto = function (s, max) {
    max = max || 48;
    const p = U.topicosTema(s);
    let t = p.length ? p[0] : String(s || '').replace(/\s+/g, ' ').trim();
    if (p.length > 1 && t.length < 18 && (t + ' · ' + p[1]).length <= max) t += ' · ' + p[1];
    if (t.length > max) t = t.slice(0, max - 1).replace(/\s+\S*$/, '') + '…';
    return t.charAt(0).toUpperCase() + t.slice(1);
  };
  U.plainForSpeech = (s) => String(s || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}]/gu, '')
    .replace(/\*\*?/g, '').replace(/_/g, ' ').replace(/×/g, ' vezes ').replace(/÷/g, ' a dividir por ')
    .replace(/\s+/g, ' ').trim();
  // ---------- pronúncia: o texto mostrado não muda, só o que o Kiko diz
  const UNID = { L: 'litros', dL: 'decilitros', cL: 'centilitros', mL: 'mililitros', km: 'quilómetros', dm: 'decímetros', cm: 'centímetros', mm: 'milímetros', m: 'metros', kg: 'quilogramas', g: 'gramas', mg: 'miligramas', l: 'litros', dl: 'decilitros', cl: 'centilitros', ml: 'mililitros', h: 'horas', min: 'minutos', s: 'segundos' };
  const UNID1 = { quilómetros: 'quilómetro', decímetros: 'decímetro', centímetros: 'centímetro', milímetros: 'milímetro', metros: 'metro', quilogramas: 'quilograma', gramas: 'grama', miligramas: 'miligrama', litros: 'litro', decilitros: 'decilitro', centilitros: 'centilitro', mililitros: 'mililitro', horas: 'hora', minutos: 'minuto', segundos: 'segundo' };
  const ORD_M = ['', 'primeiro', 'segundo', 'terceiro', 'quarto', 'quinto', 'sexto', 'sétimo', 'oitavo', 'nono', 'décimo', 'décimo primeiro', 'décimo segundo'];
  const ROMANO = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7, VIII: 8, IX: 9, X: 10, XI: 11, XII: 12, XIII: 13, XIV: 14, XV: 15, XVI: 16, XVII: 17, XVIII: 18, XIX: 19, XX: 20, XXI: 21 };
  const DEN = { 2: ['meio', 'meios'], 3: ['terço', 'terços'], 4: ['quarto', 'quartos'], 5: ['quinto', 'quintos'], 6: ['sexto', 'sextos'], 7: ['sétimo', 'sétimos'], 8: ['oitavo', 'oitavos'], 9: ['nono', 'nonos'], 10: ['décimo', 'décimos'], 100: ['centésimo', 'centésimos'], 1000: ['milésimo', 'milésimos'] };
  const DONA = /^(Teresa|Maria|Leonor|Filipa|Beatriz|Isabel|Catarina|Mafalda|Amélia|Urraca|Inês|Joana|Carlota|Estefânia)$/;
  // palavras que os motores de voz portugueses costumam ler mal (troca só no que é dito)
  const PRON = [
    [/\bacertaste tudo\b/gi, 'respondeste tudo certo'],
    [/\bacertaste\b/gi, 'está certo'],
    [/\bacertaram\b/gi, 'responderam certo'],
    [/\bhihi\b/gi, 'i i i'], [/\bho ?ho ?ho\b/gi, 'hô, hô, hô'], [/\bbu+u\b/gi, 'búúú'],
    [/\bm{2,}\b/gi, 'hum'], [/\bnham nham\b/gi, 'nham, nham'], [/\bcrunch\b/gi, 'cranch'],
    [/\bpiu[- ]piu\b/gi, 'piu, piu'], [/\bok\b/gi, 'ó quêi'], [/\bquiz(z)?\b/gi, 'cuíz'], [/\bquizzes\b/gi, 'cuízes'],
    [/\bIA\b/g, 'í á'], [/\bUE\b/g, 'União Europeia'], [/\bEUA\b/g, 'Estados Unidos'], [/\bCPLP\b/g, 'cê pê éle pê'],
    [/\bPNL\b/g, 'Plano Nacional de Leitura'], [/\bGN\b/g, 'grupo nominal'], [/\bGV\b/g, 'grupo verbal'], [/\bTIC\b/g, 'tic'],
    [/\bAE\b/g, 'Aprendizagens Essenciais'], [/\bPIN\b/g, 'pin']
  ];
  U.falaPT = function (s) {
    let t = String(s || '');
    const extra = (window.S && S.data && S.cfg().pron) || {};
    Object.keys(extra).forEach((w) => { if (w && extra[w]) t = t.replace(new RegExp('(^|[^\\p{L}])' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?=$|[^\\p{L}])', 'giu'), '$1' + extra[w]); });
    t = t
      .replace(/\b(1[0-9]{3}|20[0-9]{2})\s?[–—]\s?(1[0-9]{3}|20[0-9]{2}|[0-9]{2})\b/g, '$1 a $2')
      .replace(/\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b/g, '$1 a $2')
      .replace(/°\s?C\b/g, ' graus Celsius').replace(/(\d)\s?°/g, '$1 graus')
      .replace(/(\d)[  \u202f](?=\d{3}(?!\d))/g, '$1')                                     // 25 641 → 25641
      .replace(/\b(\d{1,2})\.?\s?º/g, (x, n) => ORD_M[+n] || n + '.º')
      .replace(/\b(\d{1,2})\.?\s?ª/g, (x, n) => (ORD_M[+n] ? ORD_M[+n].replace(/o\b/g, 'a') : n + '.ª'))
      .replace(/\bD\.\s?([A-ZÀ-Ú][a-zà-ú]+)/g, (x, n) => (DONA.test(n) ? 'Dona ' : 'Dom ') + n)
      .replace(/\b(Dom|Dona|Papa|rei|rainha)\s+([A-ZÀ-Ú][a-zà-ú]+)\s+([IVX]{1,5})\b/g, (x, a, n, r) => ROMANO[r] ? a + ' ' + n + ' ' + (ROMANO[r] <= 12 ? ORD_M[ROMANO[r]].replace(/o\b/g, a === 'Dona' || a === 'rainha' ? 'a' : 'o') : ROMANO[r]) : x)
      .replace(/\bsé(c|culo)\.?\s+([IVX]{1,5})\b/gi, (x, c, r) => 'século ' + (ROMANO[r] || r))
      .replace(/\ba\.\s?C\./g, 'antes de Cristo').replace(/\bd\.\s?C\./g, 'depois de Cristo')
      .replace(/\bex\.\s?:?/gi, 'por exemplo, ').replace(/\betc\./gi, 'etcétera').replace(/\bpágs?\.\s?/gi, 'página ').replace(/\bn\.?º\s?/gi, 'número ')
      .replace(/(\d+),(\d{2})\s?€/g, (x, e, c) => e + (e === '1' ? ' euro' : ' euros') + (+c ? ' e ' + +c + ' cêntimos' : ''))
      .replace(/(\d+)\s?€/g, (x, e) => e + (e === '1' ? ' euro' : ' euros')).replace(/€/g, ' euros')
      .replace(/(\d)\s?km\/h\b/g, '$1 quilómetros por hora')
      .replace(/\s?\((k?m|[cdm]m|k?g|mg|[cdm]?[lL]|h|min|s|m²|cm²|km²)\)/g, '')
      .replace(/\b(\d+(?:,\d+)?)\s?(km|dm|cm|mm|mg|kg|ml|cl|dl|mL|cL|dL|min|m|g|l|L|h|s)\b(?![\/\p{L}])/gu, (x, n, u) => n + ' ' + (n === '1' ? UNID1[UNID[u]] : UNID[u]))
      .replace(/\b(\d{1,3})\/(\d{1,4})\b/g, (x, a, b) => DEN[b] ? (a === '1' ? 'um ' + DEN[b][0] : a + ' ' + DEN[b][1]) : a + ' sobre ' + b)
      .replace(/(\d)\s?<\s?(\d)/g, '$1 menor do que $2').replace(/(\d)\s?>\s?(\d)/g, '$1 maior do que $2')
      .replace(/\s?(→|⇒|➜)\s?/g, ', ').replace(/≈/g, ' aproximadamente ').replace(/\be\/ou\b/g, 'e ou')
      .replace(/…/g, '. ').replace(/\s[–—]\s/g, ', ').replace(/[«»“”"]/g, '').replace(/[()]/g, ', ');
    PRON.forEach(([re, por]) => { t = t.replace(re, por); });
    return t.replace(/\s+,/g, ',').replace(/,\s*,/g, ',').replace(/,\s*([.;:!?])/g, '$1').replace(/\s+/g, ' ').replace(/^,\s*/, '').trim();
  };

  // escreve números/sinais de forma a que o TTS leia bem
  U.mathForSpeech = (s) => String(s)
    .replace(/\b(1[0-9]{3}|20[0-9]{2})\s?[-–]\s?(1[0-9]{3}|20[0-9]{2}|[0-9]{2})\b/g, '$1 a $2')   // 1383-1385 → de 1383 a 1385 (não é subtração)
    .replace(/(\d+(?:,\d+)?)\s?(km|dm|cm|mm|m)²/g, (x, n, u) => n + ' ' + (n === '1' ? UNID1[UNID[u]] + ' quadrado' : UNID[u] + ' quadrados'))
    .replace(/(\d+(?:,\d+)?)\s?(km|dm|cm|mm|m)³/g, (x, n, u) => n + ' ' + (n === '1' ? UNID1[UNID[u]] + ' cúbico' : UNID[u] + ' cúbicos'))
    .replace(/°\s?C\b/g, ' graus Celsius').replace(/√/g, ' raiz quadrada de ').replace(/∛/g, ' raiz cúbica de ')
    .replace(/²/g, ' ao quadrado').replace(/³/g, ' ao cubo')
    .replace(/[⁰¹⁴⁵⁶⁷⁸⁹]+/g, (m) => ' elevado a ' + m.split('').map((c) => '⁰¹²³⁴⁵⁶⁷⁸⁹'.indexOf(c)).join(''))
    .replace(/−/g, ' menos ').replace(/(\d)x\b/g, '$1 x').replace(/°/g, ' graus').replace(/cm²/g, 'centímetros quadrados').replace(/(\d)\s*%/g, '$1 por cento').replace(/(\d)\s*-\s*(\d)/g, '$1 menos $2').replace(/(\d)\s*\+\s*(\d)/g, '$1 mais $2').replace(/(\d)\s*:\s*(\d)/g, '$1 a dividir por $2').replace(/\s=\s/g, ' igual a ');

  // ------------------------------------------------------------ armazenamento
  const KEY = 'kiko.v1';
  const S = (window.S = {});
  function base() {
    return {
      perfis: [],
      atual: null,
      cfg: {
        pin: '',
        ia: { fornecedor: 'gemini', chave: '', modelo: '' },
        vel: 1.0,
        tom: 1.15,
        genero: 'f',          // 'f' voz feminina, 'm' voz masculina
        vozNativa: true,      // Inglês e Francês lidos com voz inglesa/francesa
        pron: {},             // correções de pronúncia feitas pelos pais: { palavra: 'como dizer' }
        vozNome: '',          // voz escolhida manualmente (opcional)
        som: true,
        lerAuto: true,
        meta: 15,
        limiteMin: 0,
        relatorioAuto: true   // sugere partilhar o relatório com os pais a cada 7 dias
      }
    };
  }
  S.load = function () {
    try {
      const raw = localStorage.getItem(KEY);
      S.data = raw ? Object.assign(base(), JSON.parse(raw)) : base();
      S.data.cfg = Object.assign(base().cfg, S.data.cfg || {});
      S.data.cfg.ia = Object.assign(base().cfg.ia, S.data.cfg.ia || {});
    } catch (e) { S.data = base(); }
  };
  S.save = function () { try { localStorage.setItem(KEY, JSON.stringify(S.data)); } catch (e) { } };
  S.base = base;  // usado na restauração de cópias de segurança
  S.cfg = () => S.data.cfg;
  S.perfil = () => S.data.perfis.find((p) => p.id === S.data.atual) || null;
  S.novoPerfil = function (nome, ano, cor, emo, mascote, voz) {
    const p = {
      id: U.uid(), nome: nome, ano: ano, cor: cor, emo: emo,
      mascote: mascote || 'kiko', voz: voz || (mascote === 'kika' ? 'f' : 'm'),
      estrelas: 0, gastas: 0, loja: [], veste: [],
      dias: {},          // 'AAAA-MM-DD' -> { r: respostas, c: certas, seg: segundos }
      dominio: {},       // temaId -> { n, c, ult: [1,0,...], data }
      erros: {},         // chave -> { tema, q, vezes, prox }
      testes: [],        // { id, data, disc, temas:[], nota }
      historico: [],     // { data, tema, titulo, c, n, modo }
      medalhas: {},
      corrigidos: 0,
      criado: U.today()
    };
    S.data.perfis.push(p); S.data.atual = p.id; S.save();
    return p;
  };
  S.dia = function (p) {
    const d = U.today();
    p.dias[d] = p.dias[d] || { r: 0, c: 0, seg: 0 };
    return p.dias[d];
  };
  S.saldo = (p) => p.estrelas - p.gastas;
  S.sequencia = function (p) {
    // dias seguidos com pelo menos 5 respostas
    let n = 0, d = U.today();
    if (!(p.dias[d] && p.dias[d].r >= 5)) d = U.addDays(d, -1);
    while (p.dias[d] && p.dias[d].r >= 5) { n++; d = U.addDays(d, -1); }
    return n;
  };
  S.nivelTema = function (p, id) {
    const m = p.dominio[id];
    if (!m || !m.ult.length) return -1;
    return Math.round(100 * m.ult.reduce((a, b) => a + b, 0) / m.ult.length);
  };
  S.estrelasTema = function (p, id) {
    const n = S.nivelTema(p, id);
    return n < 0 ? 0 : n >= 90 ? 3 : n >= 70 ? 2 : n >= 40 ? 1 : 0;
  };
  S.nivelDisc = function (p, disc) {
    const temas = CUR.porAno[p.ano][disc] || [];
    if (!temas.length) return 0;
    let s = 0; temas.forEach((t) => { const n = S.nivelTema(p, t.id); s += n < 0 ? 0 : n; });
    return Math.round(s / temas.length);
  };

  // ------------------------------------------------------------ eventos nativos
  const N = (window.NATIVO = { ok: !!(window.Android && window.Android.isNative) });
  const ouvintes = {};
  N.on = (tipo, fn) => { (ouvintes[tipo] = ouvintes[tipo] || []).push(fn); };
  window.nativeEvent = function (tipo, dados) {
    (ouvintes[tipo] || []).slice().forEach((fn) => { try { fn(dados || {}); } catch (e) { console.error(e); } });
  };

  // ------------------------------------------------------------ falar (TTS)
  const Voz = (window.VOZ = { aFalar: false });
  let falaId = 0, falaResolve = null, falaTimer = null;
  function terminouFala() {
    Voz.aFalar = false;
    clearTimeout(falaTimer);
    if (window.KIKO) KIKO.estado('talking', false);
    const r = falaResolve; falaResolve = null; if (r) r();
  }
  N.on('tts', (d) => {
    if (d.state === 'start' && window.KIKO) KIKO.estado('talking', true);
    if (d.state === 'done' && d.id === 'f' + falaId) terminouFala();
  });
  // ---------- idioma de cada frase (Inglês e Francês lidos com voz nativa)
  const PT_W = /(?<![\p{L}'])(o|que|é|em|para|não|com|ou|na|no|os|uma|um|isso|se|da|do|dos|das|como|qual|quantos|português|palavra|frase|significa|quer dizer|escolhe|completa)(?![\p{L}])|[ãõáíóú]/giu;
  const EN_W = /(?<![\p{L}'])(the|is|are|you|what|how|do|does|it|in|of|and|my|your|i'm|it's|on|she|he|they|we|this|there|at|can|have|has|got|like|where|when|which|who|was|were|a|an|to)(?![\p{L}])/giu;
  const FR_W = /(?<![\p{L}'])(le|les|est|je|tu|il|elle|nous|vous|une|des|et|du|au|c'est|qu'est|ce|sont|avec|pour|dans|très|mon|ma|mes|ton|ta|son|sa|j'ai|suis|aime|quel|quelle|où)(?![\p{L}])|[àèùëïœ]/giu;
  const conta = (t, re) => (String(t).match(re) || []).length;
  Voz.LINGUA = { ing: 'en-GB', fr: 'fr-FR' };
  Voz.idioma = function (texto, disc) {
    const lang = Voz.LINGUA[disc];
    if (!lang) return 'pt-PT';
    const pt = conta(texto, PT_W), out = conta(texto, lang === 'en-GB' ? EN_W : FR_W);
    if (out === 0 && pt === 0) return /^[\x00-\x7F’'\s.,!?;:…—-]+$/.test(texto) || (lang === 'fr-FR' && /[éèàùâêîôûçëïœ]/i.test(texto)) ? lang : 'pt-PT';
    return out >= pt ? lang : 'pt-PT';
  };
  /** divide um texto misturado em partes com a língua de cada uma.
   *  Entre parênteses costuma estar a tradução em português; entre aspas, a palavra estrangeira. */
  Voz.partes = function (texto, disc) {
    const lang = Voz.LINGUA[disc];
    if (!lang || S.cfg().vozNativa === false) return [{ t: String(texto), l: 'pt-PT' }];
    const base = Voz.idioma(String(texto).replace(/\([^)]*\)|"[^"]*"|«[^»]*»|“[^”]*”/g, ' '), disc);
    const out = [];
    const juntar = (t, l) => {
      t = t.replace(/^[\s,;:]+|[\s,;]+$/g, '');
      if (!t || /^[.,;:!?…\s]+$/.test(t)) { if (out.length && t) out[out.length - 1].t += t; return; }
      if (out.length && out[out.length - 1].l === l) out[out.length - 1].t += ' ' + t; else out.push({ t, l });
    };
    String(texto).split(/(\([^)]*\)|"[^"]*"|«[^»]*»|“[^”]*”|(?:^|(?<=\s))'[^']+'(?=[\s.,!?…:;]|$))/).forEach((x) => {
      if (!x) return;
      if (/^\(/.test(x)) { const t = x.slice(1, -1); juntar(t, conta(t, lang === 'en-GB' ? EN_W : FR_W) > conta(t, PT_W) ? lang : 'pt-PT'); }
      else if (/^["«“']/.test(x)) {
        const t = x.slice(1, -1), p = conta(t, PT_W), e = conta(t, lang === 'en-GB' ? EN_W : FR_W);
        const traduzir = /como se diz|traduz|em (inglês|francês) (é|se diz)/i.test(texto);
        juntar(t, p > e || (p === e && traduzir) ? 'pt-PT' : lang);
      }
      else juntar(x, base === 'pt-PT' ? 'pt-PT' : Voz.idioma(x, disc) === 'pt-PT' && conta(x, PT_W) > 0 ? 'pt-PT' : lang);
    });
    out.forEach((o) => { o.t = o.t.replace(/([?!.…])\s*\.+/g, '$1').replace(/\s+([?!.,])/g, '$1'); });
    return out.length ? out : [{ t: String(texto), l: base }];
  };
  /** lê várias partes seguidas, cada uma com a sua voz */
  Voz.falarPartes = async function (partes) {
    const meu = ++Voz._seq;
    for (const pt of partes) {
      if (meu !== Voz._seq) return;
      await falar0(pt.l === 'pt-PT' ? U.mathForSpeech(pt.t) : pt.t, pt.l);
    }
  };
  /** lê um texto de Inglês/Francês misturado com Português: cada parte com a voz certa */
  Voz.falarAuto = function (texto, disc) {
    if (!Voz.LINGUA[disc] || S.cfg().vozNativa === false) return Voz.falar(disc === 'mat' || disc === 'fq' ? U.mathForSpeech(texto) : texto);
    return Voz.falarPartes(Voz.partes(texto, disc));
  };
  Voz._seq = 0;
  /** lang: 'pt-PT' (omissão), 'en-GB' ou 'fr-FR' para ler Inglês e Francês com voz nativa */
  Voz.falar = function (texto, lang) { Voz._seq++; return falar0(texto, lang); };
  function falar0(texto, lang) {
    pararJa();
    const estrangeira = lang && !/^pt/.test(lang) && S.cfg().vozNativa !== false;
    const t = estrangeira ? U.plainForSpeech(texto).replace(/…/g, '. ') : U.falaPT(U.plainForSpeech(texto));
    if (!t) return Promise.resolve();
    falaId++;
    const id = 'f' + falaId;
    const cfg = S.cfg();
    Voz.aFalar = true;
    if (window.KIKO) KIKO.estado('talking', true);
    // salvaguarda: termina sozinho se o motor não responder
    const est = 1500 + t.length * 85 / (cfg.vel || 1);
    return new Promise((res) => {
      falaResolve = res;
      falaTimer = setTimeout(terminouFala, est + 4000);
      if (N.ok) {
        if (window.Android.speakLang) window.Android.speakLang(t, id, cfg.vel, Voz.tomEfetivo(), estrangeira ? lang : 'pt-PT', Voz.genero());
        else window.Android.speak(t, id, cfg.vel, Voz.tomEfetivo());
      } else if (window.speechSynthesis) {
        const u = new SpeechSynthesisUtterance(t);
        u.lang = estrangeira ? lang : 'pt-PT'; u.rate = cfg.vel; u.pitch = Voz.tomEfetivo();
        const vs = speechSynthesis.getVoices();
        const v = estrangeira ? (vs.find((x) => x.lang.replace('_', '-') === lang) || vs.find((x) => x.lang.slice(0, 2) === lang.slice(0, 2)))
          : (vs.find((x) => x.name === Voz.atual) || vs.find((x) => x.lang === 'pt-PT') || vs.find((x) => /^pt/.test(x.lang)));
        if (v) u.voice = v;
        u.onend = u.onerror = () => { if (id === 'f' + falaId) terminouFala(); };
        speechSynthesis.speak(u);
        clearTimeout(falaTimer); falaTimer = setTimeout(terminouFala, est + 4000);
      } else {
        clearTimeout(falaTimer); falaTimer = setTimeout(terminouFala, Math.min(est, 6000));
      }
    });
  }
  // ---------- escolha de voz feminina / masculina
  // Vozes Google pt-PT conhecidas: jfb e sfs (femininas), jmn e pmj (masculinas)
  const FEM = /(jfb|sfs|fem|female|mulher|joana|catarina|ines|helena|raquel|fernanda|francisca|luciana)/i;
  const MAS = /(jmn|pmj|masc|male|homem|duarte|joaquim|antonio|cristiano|ricardo|daniel)/i;
  Voz.lista = function () {
    let vs = [];
    if (N.ok && window.Android.listVoices) { try { vs = JSON.parse(window.Android.listVoices()); } catch (e) { } }
    else if (window.speechSynthesis) vs = speechSynthesis.getVoices().filter((v) => /^pt/i.test(v.lang)).map((v) => ({ name: v.name, country: (v.lang.split('-')[1] || '').toUpperCase(), quality: 300, net: !v.localService }));
    return vs.map((v) => Object.assign(v, { genero: MAS.test(v.name) && !/female/i.test(v.name) ? 'm' : FEM.test(v.name) ? 'f' : '?' }))
      .sort((a, b) => (b.country === 'PT') - (a.country === 'PT') || (a.net - b.net) || (b.quality - a.quality));
  };
  /** Escolhe a melhor voz para o género pedido; se não houver, ajusta o tom. */
  Voz.escolher = function () {
    const cfg = S.cfg();
    const gen = Voz.genero();
    const vs = Voz.lista();
    let v = cfg.vozNome ? vs.find((x) => x.name === cfg.vozNome) : null;
    if (!v) v = vs.find((x) => x.country === 'PT' && x.genero === gen) || vs.find((x) => x.genero === gen);
    Voz.atual = v ? v.name : '';
    Voz.generoReal = v && v.genero !== '?' ? v.genero : null;
    if (N.ok && window.Android.setVoiceName) window.Android.setVoiceName(Voz.atual);
    return v;
  };
  // tom final: se não existir voz do género pedido, o tom faz a diferença
  // cada perfil pode ter a sua voz; senão usa a voz por omissão
  Voz.genero = function () { const p = S.perfil(); return (p && p.voz) || S.cfg().genero; };
  Voz.tomEfetivo = function () {
    const cfg = S.cfg(), gen = Voz.genero();
    if (Voz.generoReal === gen) return gen === 'm' ? Math.min(cfg.tom, 1.0) : cfg.tom;
    return gen === 'm' ? Math.min(cfg.tom, 0.85) : Math.max(cfg.tom, 1.2);
  };
  N.on('ttsReady', () => Voz.escolher());
  if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => { if (S.data) Voz.escolher(); };

  Voz.parar = function () { Voz._seq++; pararJa(); };
  function pararJa() {
    if (N.ok) window.Android.stopSpeaking();
    else if (window.speechSynthesis) speechSynthesis.cancel();
    if (Voz.aFalar) terminouFala();
  };

  // ------------------------------------------------------------ ouvir (microfone)
  const Mic = (window.MIC = { ativo: false, cb: null });
  let webRec = null;
  N.on('speech', (d) => {
    const cb = Mic.cb || {};
    if (d.state === 'ready' || d.state === 'begin') { Mic.ativo = true; cb.estado && cb.estado('ouvir'); }
    else if (d.state === 'rms') cb.nivel && cb.nivel(Math.max(0, Math.min(1, (d.rms + 2) / 12)));
    else if (d.state === 'partial') cb.parcial && cb.parcial(d.text);
    else if (d.state === 'end') { cb.estado && cb.estado('pensar'); }
    else if (d.state === 'result') { Mic.ativo = false; Mic.cb = null; cb.resultado && cb.resultado(d.texts || []); }
    else if (d.state === 'error') { Mic.ativo = false; Mic.cb = null; cb.erro && cb.erro(d.message || 'Não percebi.'); }
  });
  Mic.ouvir = function (callbacks) {
    Voz.parar();
    Mic.cb = callbacks; Mic.ativo = true;
    callbacks.estado && callbacks.estado('ouvir');
    if (N.ok) { window.Android.startListening(); return; }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      // sem reconhecimento de voz (ex.: pré-visualização no computador)
      setTimeout(() => window.nativeEvent('speech', { state: 'error', message: 'Aqui não há microfone. Escreve a tua pergunta.' }), 300);
      return;
    }
    webRec = new SR(); webRec.lang = 'pt-PT'; webRec.interimResults = true; webRec.maxAlternatives = 3;
    webRec.onresult = (e) => {
      const r = e.results[e.results.length - 1];
      if (r.isFinal) window.nativeEvent('speech', { state: 'result', texts: Array.from(r).map((a) => a.transcript) });
      else window.nativeEvent('speech', { state: 'partial', text: r[0].transcript });
    };
    webRec.onerror = () => window.nativeEvent('speech', { state: 'error', message: 'Não percebi. Podes repetir?' });
    webRec.start();
  };
  Mic.parar = function () {
    if (N.ok) window.Android.cancelListening(); else if (webRec) try { webRec.abort(); } catch (e) { }
    Mic.ativo = false; Mic.cb = null;
  };
  N.on('pause', () => { Mic.parar(); Voz.parar(); });

  // ------------------------------------------------------------ sons
  let actx = null;
  function tom(freq, dur, quando, tipo, vol) {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = tipo || 'sine'; o.frequency.value = freq;
    const t0 = actx.currentTime + (quando || 0);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.18, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(actx.destination); o.start(t0); o.stop(t0 + dur + 0.05);
  }
  window.SOM = {
    certo() { if (!S.cfg().som) return; try { tom(660, 0.12); tom(880, 0.18, 0.1); } catch (e) { } },
    errado() { if (!S.cfg().som) return; try { tom(300, 0.18, 0, 'triangle'); tom(220, 0.25, 0.14, 'triangle'); } catch (e) { } },
    festa() { if (!S.cfg().som) return; try { [523, 659, 784, 1047].forEach((f, i) => tom(f, 0.2, i * 0.11)); } catch (e) { } },
    clique() { if (!S.cfg().som) return; try { tom(520, 0.05, 0, 'sine', 0.08); } catch (e) { } }
  };

  // ------------------------------------------------------------ toast, modal, confettis
  let toastT = null;
  window.toast = function (msg) {
    const t = U.$('#toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2400);
  };
  window.MODAL = {
    abrir(html, aoAbrir) {
      U.$('#modalCard').innerHTML = html;
      U.$('#modal').classList.remove('hidden');
      if (aoAbrir) aoAbrir(U.$('#modalCard'));
      if (window.TV && TV.ativo) setTimeout(() => TV.focoInicial(U.$('#modalCard')), 50);
    },
    fechar() { U.$('#modal').classList.add('hidden'); U.$('#modalCard').innerHTML = ''; },
    aberto() { return !U.$('#modal').classList.contains('hidden'); }
  };
  document.addEventListener('click', (e) => { if (e.target.id === 'modal') MODAL.fechar(); });
  window.confettis = function () {
    const c = U.$('#confetti'); const cores = ['#FF9F1C', '#2EC4A0', '#4D96FF', '#F15BB5', '#FFC233', '#9B5DE5'];
    for (let i = 0; i < 70; i++) {
      const el = document.createElement('i');
      el.style.left = Math.random() * 100 + 'vw';
      el.style.background = U.pick(cores);
      el.style.animationDuration = 1.6 + Math.random() * 1.6 + 's';
      el.style.animationDelay = Math.random() * 0.5 + 's';
      c.appendChild(el);
    }
    setTimeout(() => { c.innerHTML = ''; }, 4000);
  };
})();
