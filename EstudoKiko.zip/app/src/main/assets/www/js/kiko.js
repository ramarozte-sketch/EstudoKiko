/* O Kiko: mocho fofinho em SVG, com estados (a falar, a ouvir, contente, triste, a pensar) e acessórios */
(function () {
  'use strict';

  const ACESSORIOS = [
    { id: 'laco', nome: 'Laço', emo: '🎀', preco: 20 },
    { id: 'oculos', nome: 'Óculos', emo: '👓', preco: 30 },
    { id: 'chapeu', nome: 'Chapéu de mago', emo: '🧙', preco: 40 },
    { id: 'cachecol', nome: 'Cachecol', emo: '🧣', preco: 50 },
    { id: 'auscult', nome: 'Auscultadores', emo: '🎧', preco: 60 },
    { id: 'capelo', nome: 'Capelo de doutor', emo: '🎓', preco: 80 },
    { id: 'coroa', nome: 'Coroa', emo: '👑', preco: 120 },
    { id: 'estrela', nome: 'Varinha', emo: '🪄', preco: 150 }
  ];

  function svg(veste) {
    const on = (id) => (veste && veste.indexOf(id) >= 0 ? ' on' : '');
    return `
<svg viewBox="0 0 200 220" aria-label="Kiko">
  <defs>
    <radialGradient id="kb" cx="50%" cy="38%" r="65%"><stop offset="0" stop-color="#C08A5E"/><stop offset="1" stop-color="#9A6440"/></radialGradient>
    <radialGradient id="kt" cx="50%" cy="30%" r="70%"><stop offset="0" stop-color="#FFF1DA"/><stop offset="1" stop-color="#F2D3A6"/></radialGradient>
  </defs>
  <circle class="ring" cx="100" cy="110" r="96" fill="none" stroke="#FF9F1C" stroke-width="6"/>
  <ellipse cx="100" cy="208" rx="58" ry="8" fill="rgba(58,46,40,.12)"/>
  <g class="body-g">
    <!-- acessório traseiro: varinha -->
    <g class="acc${on('estrela')}">
      <line x1="160" y1="150" x2="190" y2="90" stroke="#5B3A29" stroke-width="5" stroke-linecap="round"/>
      <path d="M190 72 l5 11 12 1 -9 8 3 12 -11 -6 -11 6 3 -12 -9 -8 12 -1z" fill="#FFC233" stroke="#E5A100" stroke-width="2"/>
    </g>
    <!-- orelhas -->
    <path d="M52 52 L44 14 L80 40 Z" fill="#8A5A3B"/>
    <path d="M148 52 L156 14 L120 40 Z" fill="#8A5A3B"/>
    <!-- asas -->
    <path class="wing-l" d="M48 92 C22 110 22 160 50 178 C58 150 60 120 48 92 Z" fill="#8A5A3B"/>
    <path class="wing-r" d="M152 92 C178 110 178 160 150 178 C142 150 140 120 152 92 Z" fill="#8A5A3B"/>
    <!-- corpo -->
    <path d="M100 26 C150 26 168 66 168 112 C168 166 140 202 100 202 C60 202 32 166 32 112 C32 66 50 26 100 26 Z" fill="url(#kb)"/>
    <!-- barriga -->
    <path d="M100 118 C130 118 146 140 146 166 C146 188 124 200 100 200 C76 200 54 188 54 166 C54 140 70 118 100 118 Z" fill="url(#kt)"/>
    <path d="M82 150 q6 6 12 0 M106 150 q6 6 12 0 M94 168 q6 6 12 0 M82 184 q6 5 12 0 M106 184 q6 5 12 0" stroke="#E2BC88" stroke-width="3" fill="none" stroke-linecap="round"/>
    <!-- patas -->
    <path d="M78 200 l-6 8 M84 201 l0 9 M90 200 l6 8" stroke="#F29E38" stroke-width="5" stroke-linecap="round"/>
    <path d="M110 200 l-6 8 M116 201 l0 9 M122 200 l6 8" stroke="#F29E38" stroke-width="5" stroke-linecap="round"/>
    <!-- discos faciais -->
    <circle cx="72" cy="80" r="30" fill="#F7E4C6"/>
    <circle cx="128" cy="80" r="30" fill="#F7E4C6"/>
    <!-- olhos abertos -->
    <g class="eyes-open">
      <circle cx="72" cy="80" r="22" fill="#fff"/>
      <circle cx="128" cy="80" r="22" fill="#fff"/>
      <g class="pupils">
        <circle cx="74" cy="82" r="12" fill="#2B2B2B"/>
        <circle cx="126" cy="82" r="12" fill="#2B2B2B"/>
        <circle cx="78" cy="77" r="4.5" fill="#fff"/>
        <circle cx="130" cy="77" r="4.5" fill="#fff"/>
        <circle cx="70" cy="87" r="2" fill="#fff"/>
        <circle cx="122" cy="87" r="2" fill="#fff"/>
      </g>
      <ellipse class="lid" cx="72" cy="80" rx="23" ry="23" fill="#9A6440"/>
      <ellipse class="lid" cx="128" cy="80" rx="23" ry="23" fill="#9A6440"/>
    </g>
    <!-- olhos contentes ^^ -->
    <g class="eyes-happy" stroke="#2B2B2B" stroke-width="6" fill="none" stroke-linecap="round">
      <path d="M58 86 Q72 66 86 86"/><path d="M114 86 Q128 66 142 86"/>
    </g>
    <!-- sobrancelhas tristes -->
    <g class="brows" stroke="#5B3A29" stroke-width="5" stroke-linecap="round">
      <path d="M56 54 L84 62"/><path d="M144 54 L116 62"/>
    </g>
    <!-- bochechas -->
    <ellipse cx="50" cy="108" rx="9" ry="6" fill="#F7A3A3" opacity=".8"/>
    <ellipse cx="150" cy="108" rx="9" ry="6" fill="#F7A3A3" opacity=".8"/>
    <!-- bico -->
    <path class="beak-low" d="M92 104 Q100 118 108 104 Z" fill="#E5850A"/>
    <path d="M88 96 Q100 92 112 96 L100 110 Z" fill="#FFB347"/>
    <!-- acessórios -->
    <g class="acc${on('laco')}">
      <path d="M126 34 L108 24 L108 46 Z M126 34 L144 24 L144 46 Z" fill="#F15BB5"/><circle cx="126" cy="35" r="6" fill="#D93D9C"/>
    </g>
    <g class="acc${on('oculos')}" fill="none" stroke="#3A2E28" stroke-width="4">
      <circle cx="72" cy="80" r="25"/><circle cx="128" cy="80" r="25"/><path d="M97 78 Q100 72 103 78"/>
    </g>
    <g class="acc${on('cachecol')}">
      <path d="M44 132 Q100 158 156 132 L158 146 Q100 172 42 146 Z" fill="#FF5A5F"/>
      <path d="M128 150 L140 196 L124 196 L116 154 Z" fill="#FF5A5F"/>
      <path d="M60 138 l4 10 M80 145 l3 10 M100 148 l0 10 M120 145 l-3 10 M140 138 l-4 10" stroke="#fff" stroke-width="3"/>
    </g>
    <g class="acc${on('auscult')}">
      <path d="M40 80 Q40 20 100 18 Q160 20 160 80" stroke="#4D96FF" stroke-width="8" fill="none"/>
      <rect x="28" y="70" width="18" height="30" rx="8" fill="#4D96FF"/><rect x="154" y="70" width="18" height="30" rx="8" fill="#4D96FF"/>
    </g>
    <g class="acc${on('chapeu')}">
      <path d="M100 -30 L130 34 L70 34 Z" fill="#9B5DE5"/><path d="M58 34 Q100 46 142 34 Q100 26 58 34 Z" fill="#7B3FC4"/>
      <circle cx="94" cy="6" r="4" fill="#FFC233"/><circle cx="108" cy="20" r="3" fill="#FFC233"/>
    </g>
    <g class="acc${on('capelo')}">
      <path d="M100 6 L148 22 L100 38 L52 22 Z" fill="#2B2B2B"/><rect x="80" y="26" width="40" height="14" fill="#2B2B2B"/>
      <path d="M140 25 L142 48" stroke="#FFC233" stroke-width="3"/><circle cx="142" cy="50" r="4" fill="#FFC233"/>
    </g>
    <g class="acc${on('coroa')}">
      <path d="M68 34 L72 6 L86 22 L100 2 L114 22 L128 6 L132 34 Z" fill="#FFC233" stroke="#E5A100" stroke-width="3" stroke-linejoin="round"/>
      <circle cx="100" cy="24" r="4" fill="#FF5A5F"/><circle cx="82" cy="28" r="3" fill="#4D96FF"/><circle cx="118" cy="28" r="3" fill="#2EC4A0"/>
    </g>
  </g>
  <g class="think" fill="#8C7B70"><circle cx="160" cy="30" r="5"/><circle cx="176" cy="18" r="6"/><circle cx="192" cy="4" r="7"/></g>
</svg>`;
  }

  let el = null;               // elemento atual do Kiko no ecrã
  let bolha = null;            // balão de fala associado
  let reacaoT = null;

  const FRASES_TOQUE = [
    'Hihi! Fazes-me cócegas!', 'Uh-uh! Sabias que os mochos conseguem rodar a cabeça quase toda a volta?',
    'Vamos aprender alguma coisa nova?', 'Estou pronto! Carrega no microfone e fala comigo.',
    'Quanto mais praticares, mais estrelas ganhas!', 'Um bocadinho todos os dias faz milagres!'
  ];

  window.KIKO = {
    ACESSORIOS,
    html(classe, veste) {
      return `<div class="kiko ${classe || ''}" id="kiko">${svg(veste || [])}</div>`;
    },
    ligar(raiz) {
      el = (raiz || document).querySelector('#kiko');
      bolha = (raiz || document).querySelector('#bolha');
      if (el) el.addEventListener('click', () => {
        if (MIC.ativo || VOZ.aFalar) return;
        KIKO.reagir('happy');
        KIKO.dizer(U.pick(FRASES_TOQUE));
      });
    },
    estado(nome, ligado) { if (el) el.classList.toggle(nome, !!ligado); },
    limpar() { if (el) ['listening', 'thinking', 'happy', 'sad'].forEach((c) => el.classList.remove(c)); },
    reagir(tipo, ms) {
      if (!el) return;
      clearTimeout(reacaoT);
      el.classList.remove('happy', 'sad');
      void el.offsetWidth;
      el.classList.add(tipo);
      reacaoT = setTimeout(() => el && el.classList.remove(tipo), ms || 1800);
    },
    /** Mostra no balão e diz em voz alta. Devolve uma promessa que termina quando acaba de falar. */
    dizer(texto, semVoz) {
      if (bolha) bolha.innerHTML = U.esc(texto);
      if (window.CONVERSA && U.$('#chat')) CONVERSA.registar('kiko', texto);
      return semVoz ? Promise.resolve() : VOZ.falar(texto);
    },
    balao(html) { if (bolha) bolha.innerHTML = html; }
  };
})();
