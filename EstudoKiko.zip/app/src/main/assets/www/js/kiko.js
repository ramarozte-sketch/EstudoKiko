/* O Kiko: caturra fofinha em SVG, com estados (a falar, a ouvir, contente, triste, a pensar) e acessórios */
(function () {
  'use strict';

  const ACESSORIOS = [
    { id: 'laco', nome: 'Laço', emo: '🎀', preco: 20 },
    { id: 'oculos', nome: 'Óculos', emo: '👓', preco: 30 },
    { id: 'chapeu', nome: 'Chapéu de mago', emo: '🧙', preco: 40 },
    { id: 'cachecol', nome: 'Cachecol', emo: '🧣', preco: 50 },
    { id: 'auscult', nome: 'Auscultadores', emo: '🎧', preco: 60 },
    { id: 'capelo', nome: 'Capelo de doutor', emo: '🎓', preco: 80 },
    { id: 'coroa', nome: 'Coroa', emo: '👑', preco: 120 },
    { id: 'estrela', nome: 'Varinha', emo: '🪄', preco: 150 }
  ];

  function svg(veste, tipo) {
    const on = (id) => (veste && veste.indexOf(id) >= 0 ? ' on' : '');
    const kika = tipo === 'kika';
    // Kika: caturra "lutino" (corpo creme), pestanas e uma florzinha; Kiko: caturra cinzenta
    const C = kika
      ? { b1: '#FFFDF5', b2: '#EADFC4', w1: '#F1E6C8', w2: '#D9C99F', barriga: '#FFF8E6', cauda1: '#E2D3AA', cauda2: '#EBDDB8', ch1: '#FF9E8A', ch2: '#F2665A', tampa: '#FFE36E' }
      : { b1: '#C4CBD3', b2: '#8E98A3', w1: '#9AA4AE', w2: '#6F7983', barriga: '#D3D8DE', cauda1: '#6F7983', cauda2: '#7E8892', ch1: '#FFA05C', ch2: '#F26B2A', tampa: '#FFD84D' };
    return `
<svg viewBox="0 0 200 220" aria-label="${kika ? 'Kika' : 'Kiko'}, a caturra">
  <defs>
    <radialGradient id="kgb" cx="45%" cy="35%" r="70%"><stop offset="0" stop-color="${C.b1}"/><stop offset="1" stop-color="${C.b2}"/></radialGradient>
    <radialGradient id="kgh" cx="45%" cy="40%" r="65%"><stop offset="0" stop-color="#FFF3B0"/><stop offset="1" stop-color="#FFD84D"/></radialGradient>
    <radialGradient id="kgc" cx="40%" cy="40%" r="60%"><stop offset="0" stop-color="${C.ch1}"/><stop offset="1" stop-color="${C.ch2}"/></radialGradient>
    <linearGradient id="kgw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.w1}"/><stop offset="1" stop-color="${C.w2}"/></linearGradient>
  </defs>
  <circle class="ring" cx="100" cy="110" r="96" fill="none" stroke="#FF9F1C" stroke-width="6"/>
  <ellipse cx="100" cy="210" rx="56" ry="7" fill="rgba(58,46,40,.12)"/>
  <g class="body-g">
    <!-- varinha (atrás) -->
    <g class="acc${on('estrela')}">
      <line x1="160" y1="160" x2="190" y2="100" stroke="#5B3A29" stroke-width="5" stroke-linecap="round"/>
      <path d="M190 82 l5 11 12 1 -9 8 3 12 -11 -6 -11 6 3 -12 -9 -8 12 -1z" fill="#FFC233" stroke="#E5A100" stroke-width="2"/>
    </g>
    <!-- cauda comprida -->
    <path d="M92 182 L78 216 L92 214 L100 188 Z" fill="${C.cauda1}"/>
    <path d="M108 182 L122 216 L108 214 L100 188 Z" fill="${C.cauda2}"/>
    <!-- poupa (crista) -->
    <g class="crest">
      <path d="M98 34 C92 10 102 -6 124 -10 C112 4 108 18 110 34 Z" fill="#FFD84D"/>
      <path d="M92 36 C82 16 86 0 102 -8 C96 8 96 22 102 36 Z" fill="#FFE27A"/>
      <path d="M106 34 C110 14 124 4 144 6 C128 14 120 24 118 38 Z" fill="#F5C93A"/>
    </g>
    <!-- asas cinzentas com banda branca -->
    <g class="wing-l">
      <path d="M50 118 C26 132 26 172 52 190 C64 166 66 138 50 118 Z" fill="url(#kgw)"/>
      <path d="M46 132 C38 146 38 160 44 170 C50 156 52 144 46 132 Z" fill="#F4F6F8"/>
    </g>
    <g class="wing-r">
      <path d="M150 118 C174 132 174 172 148 190 C136 166 134 138 150 118 Z" fill="url(#kgw)"/>
      <path d="M154 132 C162 146 162 160 156 170 C150 156 148 144 154 132 Z" fill="#F4F6F8"/>
    </g>
    <!-- corpo -->
    <ellipse cx="100" cy="148" rx="56" ry="58" fill="url(#kgb)"/>
    <ellipse cx="100" cy="160" rx="34" ry="38" fill="${C.barriga}" opacity=".7"/>
    <!-- patas -->
    <path d="M84 202 l-7 8 M88 204 l0 9 M92 202 l7 8" stroke="#E9A9A0" stroke-width="5" stroke-linecap="round"/>
    <path d="M108 202 l-7 8 M112 204 l0 9 M116 202 l7 8" stroke="#E9A9A0" stroke-width="5" stroke-linecap="round"/>
    <!-- cabeça amarela -->
    <circle cx="100" cy="80" r="54" fill="url(#kgh)"/>
    <path d="M52 100 C60 126 80 136 100 136 C120 136 140 126 148 100 C140 116 122 124 100 124 C78 124 60 116 52 100 Z" fill="#E8EBEE" opacity=".55"/>
    <!-- bochechas cor de laranja (típicas da caturra) -->
    <circle cx="64" cy="98" r="15" fill="url(#kgc)"/>
    <circle cx="136" cy="98" r="15" fill="url(#kgc)"/>
    <!-- olhos -->
    <g class="eyes-open">
      <g class="pupils">
        <circle cx="78" cy="78" r="13" fill="#2B2B2B"/>
        <circle cx="122" cy="78" r="13" fill="#2B2B2B"/>
        <circle cx="82" cy="73" r="5" fill="#fff"/>
        <circle cx="126" cy="73" r="5" fill="#fff"/>
        <circle cx="74" cy="83" r="2" fill="#fff"/>
        <circle cx="118" cy="83" r="2" fill="#fff"/>
      </g>
      <ellipse class="lid" cx="78" cy="78" rx="14.5" ry="14.5" fill="${C.tampa}"/>
      <ellipse class="lid" cx="122" cy="78" rx="14.5" ry="14.5" fill="${C.tampa}"/>
    </g>
    ${kika ? `<g class="lashes" stroke="#2B2B2B" stroke-width="3" stroke-linecap="round">
      <path d="M66 68 L60 63"/><path d="M70 64 L66 58"/><path d="M134 68 L140 63"/><path d="M130 64 L134 58"/></g>
    <g class="flor"><circle cx="58" cy="44" r="7" fill="#FF8FC7"/><circle cx="68" cy="40" r="7" fill="#FF8FC7"/><circle cx="66" cy="51" r="7" fill="#FF8FC7"/><circle cx="55" cy="54" r="7" fill="#FF8FC7"/><circle cx="62" cy="47" r="5" fill="#FFE36E"/></g>` : ''}
    <g class="eyes-happy" stroke="#2B2B2B" stroke-width="6" fill="none" stroke-linecap="round">
      <path d="M66 82 Q78 66 90 82"/><path d="M110 82 Q122 66 134 82"/>
    </g>
    <g class="brows" stroke="#B08A1E" stroke-width="5" stroke-linecap="round">
      <path d="M64 66 L90 57"/><path d="M136 66 L110 57"/>
    </g>
    <!-- bico curvo cinzento -->
    <path class="beak-low" d="M93 104 Q100 114 107 104 Z" fill="#6B6F75"/>
    <path d="M90 94 Q100 86 110 94 Q108 104 100 110 Q92 104 90 94 Z" fill="#8C9096"/>
    <path d="M94 95 Q100 91 106 95" stroke="#B9BDC2" stroke-width="2" fill="none" stroke-linecap="round"/>
    <!-- acessórios -->
    <g class="acc${on('laco')}">
      <path d="M146 46 L128 36 L130 58 Z M146 46 L164 38 L160 60 Z" fill="#F15BB5"/><circle cx="146" cy="47" r="6" fill="#D93D9C"/>
    </g>
    <g class="acc${on('oculos')}" fill="none" stroke="#3A2E28" stroke-width="4">
      <circle cx="78" cy="78" r="20"/><circle cx="122" cy="78" r="20"/><path d="M98 76 Q100 71 102 76"/>
    </g>
    <g class="acc${on('cachecol')}">
      <path d="M50 124 Q100 150 150 124 L152 138 Q100 164 48 138 Z" fill="#FF5A5F"/>
      <path d="M126 142 L138 188 L122 188 L114 146 Z" fill="#FF5A5F"/>
      <path d="M64 130 l4 10 M82 137 l3 10 M100 140 l0 10 M118 137 l-3 10 M136 130 l-4 10" stroke="#fff" stroke-width="3"/>
    </g>
    <g class="acc${on('auscult')}">
      <path d="M44 84 Q42 24 100 22 Q158 24 156 84" stroke="#4D96FF" stroke-width="8" fill="none"/>
      <rect x="34" y="74" width="18" height="30" rx="8" fill="#4D96FF"/><rect x="148" y="74" width="18" height="30" rx="8" fill="#4D96FF"/>
    </g>
    <g class="acc${on('chapeu')}">
      <path d="M100 -24 L130 36 L70 36 Z" fill="#9B5DE5"/><path d="M58 36 Q100 48 142 36 Q100 28 58 36 Z" fill="#7B3FC4"/>
      <circle cx="94" cy="10" r="4" fill="#FFC233"/><circle cx="108" cy="24" r="3" fill="#FFC233"/>
    </g>
    <g class="acc${on('capelo')}">
      <path d="M100 12 L148 28 L100 44 L52 28 Z" fill="#2B2B2B"/><rect x="80" y="32" width="40" height="12" fill="#2B2B2B"/>
      <path d="M140 31 L142 54" stroke="#FFC233" stroke-width="3"/><circle cx="142" cy="56" r="4" fill="#FFC233"/>
    </g>
    <g class="acc${on('coroa')}">
      <path d="M70 40 L74 12 L88 28 L100 8 L112 28 L126 12 L130 40 Z" fill="#FFC233" stroke="#E5A100" stroke-width="3" stroke-linejoin="round"/>
      <circle cx="100" cy="30" r="4" fill="#FF5A5F"/><circle cx="84" cy="34" r="3" fill="#4D96FF"/><circle cx="116" cy="34" r="3" fill="#2EC4A0"/>
    </g>
  </g>
  <g class="think" fill="#8C7B70"><circle cx="160" cy="30" r="5"/><circle cx="176" cy="18" r="6"/><circle cx="192" cy="4" r="7"/></g>
</svg>`;
  }

  let el = null;               // elemento atual do Kiko no ecrã
  let bolha = null;            // balão de fala associado
  let reacaoT = null;

  const frasesToque = () => [
    'Hihi! Fazes-me cócegas!', KIKO.tipo() === 'kika' ? 'Estou pronta! Carrega no microfone e fala comigo.' : 'Estou pronto! Carrega no microfone e fala comigo.', 'Piu-piu! Sabias que as caturras vêm da Austrália?', 'Quando estou contente levanto a minha poupa amarela!',
    'Vamos aprender alguma coisa nova?',
    'Quanto mais praticares, mais estrelas ganhas!', 'Um bocadinho todos os dias faz milagres!'
  ];

  window.KIKO = {
    _n: 0,
    ACESSORIOS,
    tipo() { const p = window.S && S.data && S.perfil(); return (p && p.mascote) || 'kiko'; },
    nome() { return KIKO.tipo() === 'kika' ? 'Kika' : 'Kiko'; },
    o() { return KIKO.tipo() === 'kika' ? 'a' : 'o'; },          // artigo: "o Kiko" / "a Kika"
    oNome() { return KIKO.o() + ' ' + KIKO.nome(); },             // "o Kiko"
    ONome() { return (KIKO.o() === 'a' ? 'A ' : 'O ') + KIKO.nome(); },
    html(classe, veste, tipo) {
      // ids únicos para os gradientes: vários desenhos no mesmo ecrã não se misturam
      const u = 'g' + (++KIKO._n);
      const desenho = svg(veste || [], tipo || KIKO.tipo()).replace(/id="(kg[a-z])"/g, 'id="$1' + u + '"').replace(/url\(#(kg[a-z])\)/g, 'url(#$1' + u + ')');
      return `<div class="kiko ${classe || ''}" id="kiko">${desenho}</div>`;
    },
    ligar(raiz) {
      el = (raiz || document).querySelector('#kiko');
      bolha = (raiz || document).querySelector('#bolha');
      if (el) el.addEventListener('click', () => {
        if (MIC.ativo || VOZ.aFalar) return;
        KIKO.reagir('happy');
        KIKO.dizer(U.pick(frasesToque()));
      });
    },
    estado(nome, ligado) { if (el) el.classList.toggle(nome, !!ligado); },
    limpar() { if (el) ['listening', 'thinking', 'happy', 'sad'].forEach((c) => el.classList.remove(c)); },
    reagir(tipo, ms) {
      if (!el) return;
      clearTimeout(reacaoT);
      el.classList.remove('happy', 'sad');
      void el.offsetWidth;
      el.classList.add(tipo);
      reacaoT = setTimeout(() => el && el.classList.remove(tipo), ms || 1800);
    },
    /** Mostra no balão e diz em voz alta. Devolve uma promessa que termina quando acaba de falar. */
    dizer(texto, semVoz) {
      if (bolha) bolha.innerHTML = U.esc(texto);
      if (window.CONVERSA && U.$('#chat')) CONVERSA.registar('kiko', texto);
      return semVoz ? Promise.resolve() : VOZ.falar(texto);
    },
    balao(html) { if (bolha) bolha.innerHTML = html; }
  };
})();
