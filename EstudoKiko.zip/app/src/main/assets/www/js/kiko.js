/* O Kiko: caturra fofinha em SVG, com estados (a falar, a ouvir, contente, triste, a pensar) e acessórios */
(function () {
  'use strict';

  // zona: só se usa um acessório de cada zona de cada vez. festa: só se ganha no presente dessa festa.
  const ACESSORIOS = [
    { id: 'laco', nome: 'Laço', emo: '🎀', preco: 20, zona: 'laco' },
    { id: 'oculos', nome: 'Óculos', emo: '👓', preco: 30, zona: 'olhos' },
    { id: 'bone', nome: 'Boné', emo: '🧢', preco: 35, zona: 'cabeca' },
    { id: 'chapeu', nome: 'Chapéu de mago', emo: '🧙', preco: 40, zona: 'cabeca' },
    { id: 'cachecol', nome: 'Cachecol', emo: '🧣', preco: 50, zona: 'pescoco' },
    { id: 'tiara', nome: 'Tiara', emo: '💎', preco: 55, zona: 'cabeca' },
    { id: 'auscult', nome: 'Auscultadores', emo: '🎧', preco: 60, zona: 'orelhas' },
    { id: 'gelado', nome: 'Gelado', emo: '🍦', preco: 65, zona: 'mao' },
    { id: 'pirata', nome: 'Chapéu de pirata', emo: '🏴‍☠️', preco: 70, zona: 'cabeca' },
    { id: 'colar', nome: 'Colar de flores', emo: '🌺', preco: 75, zona: 'pescoco' },
    { id: 'capelo', nome: 'Capelo de doutor', emo: '🎓', preco: 80, zona: 'cabeca' },
    { id: 'medalha', nome: 'Medalha de ouro', emo: '🥇', preco: 90, zona: 'peito' },
    { id: 'balao', nome: 'Balão', emo: '🎈', preco: 90, zona: 'mao' },
    { id: 'presente', nome: 'Caixa-surpresa', emo: '🎁', preco: 100, zona: 'chao' },
    { id: 'capa', nome: 'Capa de super-herói', emo: '🦸', preco: 110, zona: 'costas' },
    { id: 'fada', nome: 'Asas de fada', emo: '🧚', preco: 110, zona: 'costas' },
    { id: 'coroa', nome: 'Coroa', emo: '👑', preco: 120, zona: 'cabeca' },
    { id: 'estrela', nome: 'Varinha', emo: '🪄', preco: 150, zona: 'mao' },
    // só nas festas (presente do dia)
    { id: 'bruxa', nome: 'Chapéu de bruxa', emo: '🧹', festa: 'halloween', zona: 'cabeca' },
    { id: 'abobora', nome: 'Abóbora', emo: '🎃', festa: 'halloween', zona: 'chao' },
    { id: 'castanhas', nome: 'Castanhas', emo: '🌰', festa: 'smartinho', zona: 'chao' },
    { id: 'natal', nome: 'Gorro de Natal', emo: '🎅', festa: 'natal', zona: 'cabeca' },
    { id: 'arvore', nome: 'Árvore de Natal', emo: '🎄', festa: 'natal', zona: 'chao' },
    { id: 'festa', nome: 'Chapéu de festa', emo: '🥳', festa: 'anonovo', zona: 'cabeca' },
    { id: 'mascara', nome: 'Máscara de Carnaval', emo: '🎭', festa: 'carnaval', zona: 'olhos' },
    { id: 'gravata', nome: 'Laço-gravata', emo: '👔', festa: 'pai', zona: 'pescoco' },
    { id: 'coelho', nome: 'Orelhas de coelho', emo: '🐰', festa: 'pascoa', zona: 'cabeca' },
    { id: 'ovos', nome: 'Ovos da Páscoa', emo: '🥚', festa: 'pascoa', zona: 'chao' },
    { id: 'cravo', nome: 'Cravo', emo: '🌹', festa: 'abril', zona: 'mao' },
    { id: 'flores', nome: 'Coroa de flores', emo: '💐', festa: 'mae', zona: 'cabeca' },
    { id: 'manjerico', nome: 'Manjerico', emo: '🌿', festa: 'santos', zona: 'chao' },
    { id: 'sol', nome: 'Óculos de sol', emo: '😎', festa: 'verao', zona: 'olhos' },
    { id: 'bolo', nome: 'Bolo de anos', emo: '🎂', festa: 'anos', zona: 'chao' }
  ];

  // colar havaiano: flores em arco à volta do pescoço
  const COLAR = Array.from({ length: 9 }, (_, i) => {
    const x = 56 + 11 * i, y = 124 + 16 * Math.sin((Math.PI * i) / 8);
    return `<circle cx="${x}" cy="${y.toFixed(1)}" r="7" fill="${['#FF5A5F', '#FFC233', '#F15BB5'][i % 3]}"/><circle cx="${x}" cy="${y.toFixed(1)}" r="2.5" fill="#fff"/>`;
  }).join('');
  const FLORES = Array.from({ length: 7 }, (_, i) => {
    const x = 62 + 12.7 * i, y = 40 - 10 * Math.sin((Math.PI * i) / 6);
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" fill="${['#FF8FC7', '#FFE27A', '#B8A1FF', '#FFFFFF'][i % 4]}"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.5" fill="#FF9F1C"/>`;
  }).join('');

  function svg(veste, tipo) {
    const on = (id) => (veste && veste.indexOf(id) >= 0 ? ' on' : '');
    const kika = tipo === 'kika';
    // Kika: caturra "lutino" (corpo creme), pestanas e uma florzinha; Kiko: caturra cinzenta
    const C = kika
      ? { b1: '#FFFDF5', b2: '#EADFC4', w1: '#F1E6C8', w2: '#D9C99F', barriga: '#FFF8E6', cauda1: '#E2D3AA', cauda2: '#EBDDB8', ch1: '#FF9E8A', ch2: '#F2665A', tampa: '#FFE36E' }
      : { b1: '#C4CBD3', b2: '#8E98A3', w1: '#9AA4AE', w2: '#6F7983', barriga: '#D3D8DE', cauda1: '#6F7983', cauda2: '#7E8892', ch1: '#FFA05C', ch2: '#F26B2A', tampa: '#FFD84D' };
    return `
<svg viewBox="0 0 200 220" aria-label="${kika ? 'Kika' : 'Kiko'}, a caturra">
  <defs>
    <radialGradient id="kgb" cx="45%" cy="35%" r="70%"><stop offset="0" stop-color="${C.b1}"/><stop offset="1" stop-color="${C.b2}"/></radialGradient>
    <radialGradient id="kgh" cx="45%" cy="40%" r="65%"><stop offset="0" stop-color="#FFF3B0"/><stop offset="1" stop-color="#FFD84D"/></radialGradient>
    <radialGradient id="kgc" cx="40%" cy="40%" r="60%"><stop offset="0" stop-color="${C.ch1}"/><stop offset="1" stop-color="${C.ch2}"/></radialGradient>
    <linearGradient id="kgw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.w1}"/><stop offset="1" stop-color="${C.w2}"/></linearGradient>
  </defs>
  <circle class="ring" cx="100" cy="110" r="96" fill="none" stroke="#FF9F1C" stroke-width="6"/>
  <ellipse cx="100" cy="210" rx="56" ry="7" fill="rgba(58,46,40,.12)"/>
  <g class="body-g">
    <!-- varinha (atrás) -->
    <g class="acc${on('estrela')}">
      <line x1="160" y1="160" x2="190" y2="100" stroke="#5B3A29" stroke-width="5" stroke-linecap="round"/>
      <path d="M190 82 l5 11 12 1 -9 8 3 12 -11 -6 -11 6 3 -12 -9 -8 12 -1z" fill="#FFC233" stroke="#E5A100" stroke-width="2"/>
    </g>
    <g class="acc${on('balao')}">
      <path d="M158 170 Q150 132 172 96" stroke="#8C7B70" stroke-width="2" fill="none"/>
      <ellipse cx="176" cy="72" rx="20" ry="25" fill="#FF5A5F"/><path d="M172 97 l4 -5 l4 5 z" fill="#E04449"/>
      <ellipse cx="169" cy="62" rx="5" ry="8" fill="#fff" opacity=".5"/>
    </g>
    <g class="acc${on('fada')}">
      <path d="M58 132 Q8 88 16 150 Q26 178 62 160 Z M142 132 Q192 88 184 150 Q174 178 138 160 Z" fill="#B8E6FF" opacity=".9" stroke="#7CC8F2" stroke-width="2"/>
      <path d="M50 140 Q32 128 30 148 M150 140 Q168 128 170 148" stroke="#7CC8F2" stroke-width="2" fill="none"/>
    </g>
    <g class="acc${on('capa')}">
      <path d="M58 112 Q16 166 26 210 Q100 194 174 210 Q184 166 142 112 Z" fill="#E63946"/><path d="M58 112 Q22 166 30 206 L40 204 Q36 168 66 120 Z" fill="#B5222F" opacity=".5"/>
      <path d="M60 116 Q100 134 140 116" stroke="#B5222F" stroke-width="6" fill="none"/>
    </g>
    <!-- cauda comprida -->
    <path d="M92 182 L78 216 L92 214 L100 188 Z" fill="${C.cauda1}"/>
    <path d="M108 182 L122 216 L108 214 L100 188 Z" fill="${C.cauda2}"/>
    <!-- poupa (crista) -->
    <g class="crest">
      <path d="M98 34 C92 10 102 -6 124 -10 C112 4 108 18 110 34 Z" fill="#FFD84D"/>
      <path d="M92 36 C82 16 86 0 102 -8 C96 8 96 22 102 36 Z" fill="#FFE27A"/>
      <path d="M106 34 C110 14 124 4 144 6 C128 14 120 24 118 38 Z" fill="#F5C93A"/>
    </g>
    <!-- asas cinzentas com banda branca -->
    <g class="wing-l">
      <path d="M50 118 C26 132 26 172 52 190 C64 166 66 138 50 118 Z" fill="url(#kgw)"/>
      <path d="M46 132 C38 146 38 160 44 170 C50 156 52 144 46 132 Z" fill="#F4F6F8"/>
    </g>
    <g class="wing-r">
      <path d="M150 118 C174 132 174 172 148 190 C136 166 134 138 150 118 Z" fill="url(#kgw)"/>
      <path d="M154 132 C162 146 162 160 156 170 C150 156 148 144 154 132 Z" fill="#F4F6F8"/>
    </g>
    <!-- corpo -->
    <ellipse cx="100" cy="148" rx="56" ry="58" fill="url(#kgb)"/>
    <ellipse cx="100" cy="160" rx="34" ry="38" fill="${C.barriga}" opacity=".7"/>
    <!-- patas -->
    <path d="M84 202 l-7 8 M88 204 l0 9 M92 202 l7 8" stroke="#E9A9A0" stroke-width="5" stroke-linecap="round"/>
    <path d="M108 202 l-7 8 M112 204 l0 9 M116 202 l7 8" stroke="#E9A9A0" stroke-width="5" stroke-linecap="round"/>
    <!-- cabeça amarela -->
    <circle cx="100" cy="80" r="54" fill="url(#kgh)"/>
    <path d="M52 100 C60 126 80 136 100 136 C120 136 140 126 148 100 C140 116 122 124 100 124 C78 124 60 116 52 100 Z" fill="#E8EBEE" opacity=".55"/>
    <!-- bochechas cor de laranja (típicas da caturra) -->
    <circle cx="64" cy="98" r="15" fill="url(#kgc)"/>
    <circle cx="136" cy="98" r="15" fill="url(#kgc)"/>
    <!-- olhos -->
    <g class="eyes-open">
      <g class="pupils">
        <circle cx="78" cy="78" r="13" fill="#2B2B2B"/>
        <circle cx="122" cy="78" r="13" fill="#2B2B2B"/>
        <circle cx="82" cy="73" r="5" fill="#fff"/>
        <circle cx="126" cy="73" r="5" fill="#fff"/>
        <circle cx="74" cy="83" r="2" fill="#fff"/>
        <circle cx="118" cy="83" r="2" fill="#fff"/>
      </g>
      <ellipse class="lid" cx="78" cy="78" rx="14.5" ry="14.5" fill="${C.tampa}"/>
      <ellipse class="lid" cx="122" cy="78" rx="14.5" ry="14.5" fill="${C.tampa}"/>
    </g>
    ${kika ? `<g class="lashes" stroke="#2B2B2B" stroke-width="3" stroke-linecap="round">
      <path d="M66 68 L60 63"/><path d="M70 64 L66 58"/><path d="M134 68 L140 63"/><path d="M130 64 L134 58"/></g>
    <g class="flor"><circle cx="58" cy="44" r="7" fill="#FF8FC7"/><circle cx="68" cy="40" r="7" fill="#FF8FC7"/><circle cx="66" cy="51" r="7" fill="#FF8FC7"/><circle cx="55" cy="54" r="7" fill="#FF8FC7"/><circle cx="62" cy="47" r="5" fill="#FFE36E"/></g>` : ''}
    <g class="eyes-happy" stroke="#2B2B2B" stroke-width="6" fill="none" stroke-linecap="round">
      <path d="M66 82 Q78 66 90 82"/><path d="M110 82 Q122 66 134 82"/>
    </g>
    <g class="brows" stroke="#B08A1E" stroke-width="5" stroke-linecap="round">
      <path d="M64 66 L90 57"/><path d="M136 66 L110 57"/>
    </g>
    <!-- bico curvo cinzento -->
    <path class="beak-low" d="M93 104 Q100 114 107 104 Z" fill="#6B6F75"/>
    <path d="M90 94 Q100 86 110 94 Q108 104 100 110 Q92 104 90 94 Z" fill="#8C9096"/>
    <path d="M94 95 Q100 91 106 95" stroke="#B9BDC2" stroke-width="2" fill="none" stroke-linecap="round"/>
    <!-- acessórios -->
    <g class="acc${on('laco')}">
      <path d="M146 46 L128 36 L130 58 Z M146 46 L164 38 L160 60 Z" fill="#F15BB5"/><circle cx="146" cy="47" r="6" fill="#D93D9C"/>
    </g>
    <g class="acc${on('oculos')}" fill="none" stroke="#3A2E28" stroke-width="4">
      <circle cx="78" cy="78" r="20"/><circle cx="122" cy="78" r="20"/><path d="M98 76 Q100 71 102 76"/>
    </g>
    <g class="acc${on('cachecol')}">
      <path d="M50 124 Q100 150 150 124 L152 138 Q100 164 48 138 Z" fill="#FF5A5F"/>
      <path d="M126 142 L138 188 L122 188 L114 146 Z" fill="#FF5A5F"/>
      <path d="M64 130 l4 10 M82 137 l3 10 M100 140 l0 10 M118 137 l-3 10 M136 130 l-4 10" stroke="#fff" stroke-width="3"/>
    </g>
    <g class="acc${on('auscult')}">
      <path d="M44 84 Q42 24 100 22 Q158 24 156 84" stroke="#4D96FF" stroke-width="8" fill="none"/>
      <rect x="34" y="74" width="18" height="30" rx="8" fill="#4D96FF"/><rect x="148" y="74" width="18" height="30" rx="8" fill="#4D96FF"/>
    </g>
    <g class="acc${on('chapeu')}">
      <path d="M100 -24 L130 36 L70 36 Z" fill="#9B5DE5"/><path d="M58 36 Q100 48 142 36 Q100 28 58 36 Z" fill="#7B3FC4"/>
      <circle cx="94" cy="10" r="4" fill="#FFC233"/><circle cx="108" cy="24" r="3" fill="#FFC233"/>
    </g>
    <g class="acc${on('capelo')}">
      <path d="M100 12 L148 28 L100 44 L52 28 Z" fill="#2B2B2B"/><rect x="80" y="32" width="40" height="12" fill="#2B2B2B"/>
      <path d="M140 31 L142 54" stroke="#FFC233" stroke-width="3"/><circle cx="142" cy="56" r="4" fill="#FFC233"/>
    </g>
    <g class="acc${on('coroa')}">
      <path d="M70 40 L74 12 L88 28 L100 8 L112 28 L126 12 L130 40 Z" fill="#FFC233" stroke="#E5A100" stroke-width="3" stroke-linejoin="round"/>
      <circle cx="100" cy="30" r="4" fill="#FF5A5F"/><circle cx="84" cy="34" r="3" fill="#4D96FF"/><circle cx="116" cy="34" r="3" fill="#2EC4A0"/>
    </g>
    <g class="acc${on('gravata')}">
      <path d="M100 134 L78 122 L78 148 Z M100 134 L122 122 L122 148 Z" fill="#4D96FF"/><circle cx="100" cy="135" r="6" fill="#2B6FD6"/>
    </g>
    <g class="acc${on('colar')}">${COLAR}</g>
    <g class="acc${on('medalha')}">
      <path d="M86 128 L100 154 L114 128" stroke="#4D96FF" stroke-width="6" fill="none" stroke-linejoin="round"/>
      <circle cx="100" cy="164" r="13" fill="#FFC233" stroke="#E5A100" stroke-width="3"/><path d="M100 156 l2.5 5 5.5 .8 -4 3.9 1 5.5 -5 -2.6 -5 2.6 1 -5.5 -4 -3.9 5.5 -.8z" fill="#FFF3B0"/>
    </g>
    <g class="acc${on('sol')}">
      <rect x="57" y="65" width="40" height="27" rx="11" fill="#2B2B2B"/><rect x="103" y="65" width="40" height="27" rx="11" fill="#2B2B2B"/>
      <path d="M97 75 L103 75" stroke="#2B2B2B" stroke-width="4"/><path d="M64 72 L76 70 M110 72 L122 70" stroke="#fff" stroke-width="3" opacity=".55" stroke-linecap="round"/>
    </g>
    <g class="acc${on('mascara')}">
      <path fill-rule="evenodd" d="M50 72 Q74 54 100 70 Q126 54 150 72 Q150 96 126 96 Q110 96 100 86 Q90 96 74 96 Q50 96 50 72 Z M66 78 a12 12 0 1 0 24 0 a12 12 0 1 0 -24 0 Z M110 78 a12 12 0 1 0 24 0 a12 12 0 1 0 -24 0 Z" fill="#9B5DE5"/>
      <path d="M52 70 Q36 40 46 24 Q50 50 60 64 Z" fill="#F15BB5"/><path d="M58 66 Q52 40 64 28 Q62 50 68 62 Z" fill="#FFC233"/>
      <circle cx="100" cy="72" r="3" fill="#FFC233"/>
    </g>
    <g class="acc${on('bone')}">
      <path d="M56 46 Q56 6 100 4 Q144 6 144 46 Q100 36 56 46 Z" fill="#2EC4A0"/><path d="M140 42 Q170 36 184 46 Q166 55 138 50 Z" fill="#1E9E80"/>
      <circle cx="100" cy="6" r="5" fill="#1E9E80"/><path d="M100 8 L100 40" stroke="#1E9E80" stroke-width="2" opacity=".6"/>
    </g>
    <g class="acc${on('pirata')}">
      <path d="M48 42 Q58 0 100 6 Q142 0 152 42 Q100 26 48 42 Z" fill="#2B2B2B"/><path d="M48 42 Q100 26 152 42" stroke="#FFC233" stroke-width="3" fill="none"/>
      <circle cx="100" cy="20" r="7" fill="#fff"/><circle cx="97.5" cy="19" r="1.6" fill="#2B2B2B"/><circle cx="102.5" cy="19" r="1.6" fill="#2B2B2B"/>
      <path d="M91 29 L109 37 M109 29 L91 37" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
    </g>
    <g class="acc${on('tiara')}">
      <path d="M68 40 Q100 22 132 40 L128 44 Q100 30 72 44 Z" fill="#C9D3DD"/>
      <path d="M84 34 L88 20 L94 31 L100 12 L106 31 L112 20 L116 34 Z" fill="#DDE4EA" stroke="#9AA6B2" stroke-width="2" stroke-linejoin="round"/>
      <circle cx="100" cy="24" r="4" fill="#F15BB5"/><circle cx="88" cy="28" r="2.5" fill="#4D96FF"/><circle cx="112" cy="28" r="2.5" fill="#4D96FF"/>
    </g>
    <g class="acc${on('festa')}">
      <path d="M100 -30 L124 36 L76 36 Z" fill="#4D96FF"/><path d="M87 6 L113 6 M81 22 L119 22" stroke="#FFC233" stroke-width="5"/>
      <circle cx="100" cy="-30" r="8" fill="#F15BB5"/>
    </g>
    <g class="acc${on('natal')}">
      <path d="M60 42 Q66 -2 112 -4 Q150 -2 168 36 L158 42 Q146 18 128 16 Q138 28 140 42 Z" fill="#E63946"/>
      <rect x="56" y="34" width="88" height="14" rx="7" fill="#fff"/><circle cx="164" cy="42" r="10" fill="#fff"/>
    </g>
    <g class="acc${on('bruxa')}">
      <ellipse cx="100" cy="40" rx="64" ry="10" fill="#2B2B2B"/>
      <path d="M70 38 Q78 -4 104 -22 Q116 -30 130 -26 Q112 -14 118 4 L130 38 Z" fill="#3A2E48"/>
      <path d="M73 28 L127 28 L130 38 L70 38 Z" fill="#FF9F1C"/><rect x="94" y="28" width="12" height="10" fill="#FFC233"/>
    </g>
    <g class="acc${on('coelho')}">
      <ellipse cx="80" cy="2" rx="12" ry="32" fill="#fff" stroke="#E7D7DD" stroke-width="2" transform="rotate(-12 80 2)"/>
      <ellipse cx="80" cy="4" rx="6" ry="22" fill="#FFC2DC" transform="rotate(-12 80 4)"/>
      <ellipse cx="120" cy="2" rx="12" ry="32" fill="#fff" stroke="#E7D7DD" stroke-width="2" transform="rotate(12 120 2)"/>
      <ellipse cx="120" cy="4" rx="6" ry="22" fill="#FFC2DC" transform="rotate(12 120 4)"/>
      <path d="M58 44 Q100 22 142 44" stroke="#F15BB5" stroke-width="6" fill="none" stroke-linecap="round"/>
    </g>
    <g class="acc${on('flores')}">${FLORES}</g>
    <g class="acc${on('gelado')}">
      <path d="M164 152 L178 188 L192 152 Z" fill="#E8B26A"/><path d="M167 160 L189 160 M171 170 L185 170" stroke="#C98A3E" stroke-width="2"/>
      <circle cx="171" cy="146" r="10" fill="#FFB3D1"/><circle cx="185" cy="146" r="10" fill="#B8F2E6"/><circle cx="178" cy="134" r="10" fill="#FFE27A"/>
    </g>
    <g class="acc${on('cravo')}">
      <path d="M160 192 Q170 150 176 112" stroke="#2E9E5B" stroke-width="4" fill="none"/><path d="M171 140 Q160 132 162 124 Q170 128 171 140 Z" fill="#2E9E5B"/>
      <g fill="#E63946"><circle cx="176" cy="104" r="9"/><circle cx="167" cy="98" r="7"/><circle cx="185" cy="98" r="7"/><circle cx="176" cy="91" r="7"/></g>
    </g>
    <!-- objetos no chão -->
    <g class="acc${on('abobora')}" transform="translate(24 198)">
      <ellipse rx="21" ry="15" fill="#FF8C1A"/><ellipse rx="8" ry="15" fill="#F57A00"/><path d="M-1 -14 q2 -8 7 -9" stroke="#2E9E5B" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M-12 -3 l5 -6 l3 6 z M12 -3 l-5 -6 l-3 6 z" fill="#5B2A00"/><path d="M-10 4 q10 8 20 0 q-10 3 -20 0 z" fill="#5B2A00"/>
    </g>
    <g class="acc${on('bolo')}" transform="translate(24 198)">
      <rect x="-20" y="-12" width="40" height="24" rx="4" fill="#FFB3D1"/><path d="M-20 -8 q5 7 10 0 q5 7 10 0 q5 7 10 0 q5 7 10 0 L20 -12 L-20 -12 Z" fill="#fff"/>
      <rect x="-2" y="-26" width="4" height="14" fill="#4D96FF"/><path d="M0 -35 q5 5 0 9 q-5 -4 0 -9z" fill="#FFC233"/>
    </g>
    <g class="acc${on('presente')}" transform="translate(24 198)">
      <rect x="-17" y="-14" width="34" height="28" rx="3" fill="#2EC4A0"/><rect x="-3" y="-14" width="6" height="28" fill="#FFC233"/><rect x="-17" y="-3" width="34" height="6" fill="#FFC233"/>
      <path d="M0 -14 q-13 -12 -12 -1 z M0 -14 q13 -12 12 -1 z" fill="#FFC233"/>
    </g>
    <g class="acc${on('castanhas')}" transform="translate(24 198)">
      <path d="M-16 -8 L16 -8 L0 18 Z" fill="#F2E6CF" stroke="#CDBB98" stroke-width="2"/>
      <circle cx="-8" cy="-11" r="7" fill="#7B3F1D"/><circle cx="4" cy="-14" r="7" fill="#8E4B24"/><circle cx="10" cy="-7" r="6" fill="#6B3418"/>
    </g>
    <g class="acc${on('arvore')}" transform="translate(24 194)">
      <path d="M0 -32 L16 -6 L8 -6 L18 10 L-18 10 L-8 -6 L-16 -6 Z" fill="#2E9E5B"/><rect x="-3" y="10" width="6" height="9" fill="#7B3F1D"/>
      <path d="M0 -40 l2.4 5 5.4 .8 -4 3.8 1 5.4 -4.8 -2.6 -4.8 2.6 1 -5.4 -4 -3.8 5.4 -.8z" fill="#FFC233"/>
      <circle cx="-6" cy="2" r="2.5" fill="#E63946"/><circle cx="5" cy="-12" r="2.5" fill="#4D96FF"/><circle cx="8" cy="4" r="2.5" fill="#FFC233"/>
    </g>
    <g class="acc${on('ovos')}" transform="translate(24 198)">
      <ellipse cx="-8" cy="-6" rx="7" ry="9" fill="#FFB3D1"/><ellipse cx="7" cy="-8" rx="7" ry="9" fill="#B8F2E6"/><ellipse cx="0" cy="-3" rx="7" ry="9" fill="#FFE27A"/>
      <path d="M-18 0 L18 0 L13 16 L-13 16 Z" fill="#C98A3E"/><path d="M-16 6 L16 6" stroke="#A86F2E" stroke-width="2"/>
    </g>
    <g class="acc${on('manjerico')}" transform="translate(24 198)">
      <path d="M-12 0 L12 0 L9 17 L-9 17 Z" fill="#C8643C"/><circle cy="-10" r="15" fill="#3FAE5C"/><circle cx="-5" cy="-15" r="4" fill="#5CC877"/>
      <path d="M8 -20 L8 -40" stroke="#5B3A29" stroke-width="2"/><path d="M8 -40 l13 4 l-13 4 z" fill="#E63946"/>
    </g>
  </g>
  <g class="think" fill="#8C7B70"><circle cx="160" cy="30" r="5"/><circle cx="176" cy="18" r="6"/><circle cx="192" cy="4" r="7"/></g>
</svg>`;
  }

  let el = null;               // elemento atual do Kiko no ecrã
  let bolha = null;            // balão de fala associado
  let reacaoT = null;

  const frasesToque = () => [
    'Hihi! Fazes-me cócegas!', KIKO.tipo() === 'kika' ? 'Estou pronta! Carrega no microfone e fala comigo.' : 'Estou pronto! Carrega no microfone e fala comigo.', 'Piu-piu! Sabias que as caturras vêm da Austrália?', 'Quando estou contente levanto a minha poupa amarela!',
    'Vamos aprender alguma coisa nova?',
    'Quanto mais praticares, mais estrelas ganhas!', 'Um bocadinho todos os dias faz milagres!'
  ];

  window.KIKO = {
    _n: 0,
    ACESSORIOS,
    tipo() { const p = window.S && S.data && S.perfil(); return (p && p.mascote) || 'kiko'; },
    nome() { return KIKO.tipo() === 'kika' ? 'Kika' : 'Kiko'; },
    o() { return KIKO.tipo() === 'kika' ? 'a' : 'o'; },          // artigo: "o Kiko" / "a Kika"
    oNome() { return KIKO.o() + ' ' + KIKO.nome(); },             // "o Kiko"
    ONome() { return (KIKO.o() === 'a' ? 'A ' : 'O ') + KIKO.nome(); },
    html(classe, veste, tipo) {
      // ids únicos para os gradientes: vários desenhos no mesmo ecrã não se misturam
      const u = 'g' + (++KIKO._n);
      const desenho = svg(veste || [], tipo || KIKO.tipo()).replace(/id="(kg[a-z])"/g, 'id="$1' + u + '"').replace(/url\(#(kg[a-z])\)/g, 'url(#$1' + u + ')');
      return `<div class="kiko ${classe || ''}" id="kiko">${desenho}</div>`;
    },
    ligar(raiz) {
      el = (raiz || document).querySelector('#kiko');
      bolha = (raiz || document).querySelector('#bolha');
      if (el) el.addEventListener('click', () => {
        if (MIC.ativo || VOZ.aFalar) return;
        KIKO.reagir('happy');
        KIKO.dizer(U.pick(frasesToque()));
      });
    },
    estado(nome, ligado) { if (el) el.classList.toggle(nome, !!ligado); },
    limpar() { if (el) ['listening', 'thinking', 'happy', 'sad'].forEach((c) => el.classList.remove(c)); },
    reagir(tipo, ms) {
      if (!el) return;
      clearTimeout(reacaoT);
      el.classList.remove('happy', 'sad');
      void el.offsetWidth;
      el.classList.add(tipo);
      reacaoT = setTimeout(() => el && el.classList.remove(tipo), ms || 1800);
    },
    /** Mostra no balão e diz em voz alta. Devolve uma promessa que termina quando acaba de falar. */
    dizer(texto, semVoz) {
      if (bolha) bolha.innerHTML = U.esc(texto);
      if (window.CONVERSA && U.$('#chat')) CONVERSA.registar('kiko', texto);
      return semVoz ? Promise.resolve() : VOZ.falar(texto);
    },
    balao(html) { if (bolha) bolha.innerHTML = html; }
  };
})();
