/* O Kiko: caturra fofinha em SVG, com estados (a falar, a ouvir, contente, triste, a pensar) e acessórios */
(function () {
  'use strict';

  // zona: só se usa um acessório de cada zona de cada vez. festa: só se ganha no presente dessa festa.
  const ACESSORIOS = [
    { id: 'laco', nome: 'Laço', emo: '🎀', preco: 20, zona: 'laco' },
    { id: 'oculos', nome: 'Óculos', emo: '👓', preco: 30, zona: 'olhos' },
    { id: 'bone', nome: 'Boné', emo: '🧢', preco: 35, zona: 'cabeca' },
    { id: 'chapeu', nome: 'Chapéu de mago', emo: '🧙', preco: 40, zona: 'cabeca' },
    { id: 'cachecol', nome: 'Cachecol', emo: '🧣', preco: 50, zona: 'pescoco' },
    { id: 'tiara', nome: 'Tiara', emo: '💎', preco: 55, zona: 'cabeca' },
    { id: 'auscult', nome: 'Auscultadores', emo: '🎧', preco: 60, zona: 'orelhas' },
    { id: 'gelado', nome: 'Gelado', emo: '🍦', preco: 65, zona: 'mao' },
    { id: 'pirata', nome: 'Chapéu de pirata', emo: '🏴‍☠️', preco: 70, zona: 'cabeca' },
    { id: 'colar', nome: 'Colar de flores', emo: '🌺', preco: 75, zona: 'pescoco' },
    { id: 'capelo', nome: 'Capelo de doutor', emo: '🎓', preco: 80, zona: 'cabeca' },
    { id: 'medalha', nome: 'Medalha de ouro', emo: '🥇', preco: 90, zona: 'peito' },
    { id: 'balao', nome: 'Balão', emo: '🎈', preco: 90, zona: 'mao' },
    { id: 'presente', nome: 'Caixa-surpresa', emo: '🎁', preco: 100, zona: 'chao' },
    { id: 'capa', nome: 'Capa de super-herói', emo: '🦸', preco: 110, zona: 'costas' },
    { id: 'fada', nome: 'Asas de fada', emo: '🧚', preco: 110, zona: 'costas' },
    { id: 'coroa', nome: 'Coroa', emo: '👑', preco: 120, zona: 'cabeca' },
    { id: 'estrela', nome: 'Varinha', emo: '🪄', preco: 150, zona: 'mao' },
    // só nas festas (presente do dia)
    { id: 'bruxa', nome: 'Chapéu de bruxa', emo: '🧹', festa: 'halloween', zona: 'cabeca' },
    { id: 'abobora', nome: 'Abóbora', emo: '🎃', festa: 'halloween', zona: 'chao' },
    { id: 'castanhas', nome: 'Castanhas', emo: '🌰', festa: 'smartinho', zona: 'chao' },
    { id: 'natal', nome: 'Gorro de Natal', emo: '🎅', festa: 'natal', zona: 'cabeca' },
    { id: 'arvore', nome: 'Árvore de Natal', emo: '🎄', festa: 'natal', zona: 'chao' },
    { id: 'festa', nome: 'Chapéu de festa', emo: '🥳', festa: 'anonovo', zona: 'cabeca' },
    { id: 'mascara', nome: 'Máscara de Carnaval', emo: '🎭', festa: 'carnaval', zona: 'olhos' },
    { id: 'gravata', nome: 'Laço-gravata', emo: '👔', festa: 'pai', zona: 'pescoco' },
    { id: 'coelho', nome: 'Orelhas de coelho', emo: '🐰', festa: 'pascoa', zona: 'cabeca' },
    { id: 'ovos', nome: 'Ovos da Páscoa', emo: '🥚', festa: 'pascoa', zona: 'chao' },
    { id: 'cravo', nome: 'Cravo', emo: '🌹', festa: 'abril', zona: 'mao' },
    { id: 'flores', nome: 'Coroa de flores', emo: '💐', festa: 'mae', zona: 'cabeca' },
    { id: 'manjerico', nome: 'Manjerico', emo: '🌿', festa: 'santos', zona: 'chao' },
    { id: 'sol', nome: 'Óculos de sol', emo: '😎', festa: 'verao', zona: 'olhos' },
    { id: 'bolo', nome: 'Bolo de anos', emo: '🎂', festa: 'anos', zona: 'chao' }
  ];

  // colar havaiano: flores em arco à volta do pescoço
  const COLAR = Array.from({ length: 9 }, (_, i) => {
    const x = 56 + 11 * i, y = 124 + 16 * Math.sin((Math.PI * i) / 8);
    return `<circle cx="${x}" cy="${y.toFixed(1)}" r="7" fill="${['#FF5A5F', '#FFC233', '#F15BB5'][i % 3]}"/><circle cx="${x}" cy="${y.toFixed(1)}" r="2.5" fill="#fff"/>`;
  }).join('');
  const FLORES = Array.from({ length: 7 }, (_, i) => {
    const x = 62 + 12.7 * i, y = 40 - 10 * Math.sin((Math.PI * i) / 6);
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" fill="${['#FF8FC7', '#FFE27A', '#B8A1FF', '#FFFFFF'][i % 4]}"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="2.5" fill="#FF9F1C"/>`;
  }).join('');

  // pequenas penas/pelos desenhados como arcos, para dar textura ao corpo — usado por qualquer bicho
  const penas = (cx, cy, linhas, cols, dx, dy, cor, op) => {
    let o = '';
    for (let l = 0; l < linhas; l++) for (let c = 0; c < cols; c++) {
      const x = cx + (c - (cols - 1) / 2) * dx + (l % 2 ? dx / 2 : 0), y = cy + l * dy;
      o += `<path d="M${(x - 5).toFixed(1)} ${y.toFixed(1)} Q${x.toFixed(1)} ${(y + 5).toFixed(1)} ${(x + 5).toFixed(1)} ${y.toFixed(1)}"/>`;
    }
    return `<g fill="none" stroke="${cor}" stroke-width="1.4" stroke-linecap="round" opacity="${op}">${o}</g>`;
  };

  // Acessórios comuns a qualquer mascote (Kiko/Kika ou um dos bichos) — assim a loja funciona igual para todos
  function acessoriosCorpoTras(on) {
    return `
    <g class="acc${on('estrela')}">
      <line x1="160" y1="160" x2="190" y2="100" stroke="#5B3A29" stroke-width="5" stroke-linecap="round"/>
      <path d="M190 82 l5 11 12 1 -9 8 3 12 -11 -6 -11 6 3 -12 -9 -8 12 -1z" fill="#FFC233" stroke="#E5A100" stroke-width="2"/>
    </g>
    <g class="acc${on('balao')}">
      <path d="M158 170 Q150 132 172 96" stroke="#8C7B70" stroke-width="2" fill="none"/>
      <ellipse cx="176" cy="72" rx="20" ry="25" fill="#FF5A5F"/><path d="M172 97 l4 -5 l4 5 z" fill="#E04449"/>
      <ellipse cx="169" cy="62" rx="5" ry="8" fill="#fff" opacity=".5"/>
    </g>
    <g class="acc${on('fada')}">
      <path d="M58 132 Q8 88 16 150 Q26 178 62 160 Z M142 132 Q192 88 184 150 Q174 178 138 160 Z" fill="#B8E6FF" opacity=".9" stroke="#7CC8F2" stroke-width="2"/>
      <path d="M50 140 Q32 128 30 148 M150 140 Q168 128 170 148" stroke="#7CC8F2" stroke-width="2" fill="none"/>
    </g>
    <g class="acc${on('capa')}">
      <path d="M58 112 Q16 166 26 210 Q100 194 174 210 Q184 166 142 112 Z" fill="#E63946"/><path d="M58 112 Q22 166 30 206 L40 204 Q36 168 66 120 Z" fill="#B5222F" opacity=".5"/>
      <path d="M60 116 Q100 134 140 116" stroke="#B5222F" stroke-width="6" fill="none"/>
    </g>`;
  }
  function acessoriosCorpoFrente(on) {
    return `
    <g class="acc${on('cachecol')}">
      <path d="M50 124 Q100 150 150 124 L152 138 Q100 164 48 138 Z" fill="#FF5A5F"/>
      <path d="M126 142 L138 188 L122 188 L114 146 Z" fill="#FF5A5F"/>
      <path d="M64 130 l4 10 M82 137 l3 10 M100 140 l0 10 M118 137 l-3 10 M136 130 l-4 10" stroke="#fff" stroke-width="3"/>
    </g>
    <g class="acc${on('gravata')}">
      <path d="M100 134 L78 122 L78 148 Z M100 134 L122 122 L122 148 Z" fill="#4D96FF"/><circle cx="100" cy="135" r="6" fill="#2B6FD6"/>
    </g>
    <g class="acc${on('colar')}">${COLAR}</g>
    <g class="acc${on('medalha')}">
      <path d="M86 128 L100 154 L114 128" stroke="#4D96FF" stroke-width="6" fill="none" stroke-linejoin="round"/>
      <circle cx="100" cy="164" r="13" fill="#FFC233" stroke="#E5A100" stroke-width="3"/><path d="M100 156 l2.5 5 5.5 .8 -4 3.9 1 5.5 -5 -2.6 -5 2.6 1 -5.5 -4 -3.9 5.5 -.8z" fill="#FFF3B0"/>
    </g>
    <g class="acc${on('gelado')}">
      <path d="M164 152 L178 188 L192 152 Z" fill="#E8B26A"/><path d="M167 160 L189 160 M171 170 L185 170" stroke="#C98A3E" stroke-width="2"/>
      <circle cx="171" cy="146" r="10" fill="#FFB3D1"/><circle cx="185" cy="146" r="10" fill="#B8F2E6"/><circle cx="178" cy="134" r="10" fill="#FFE27A"/>
    </g>
    <g class="acc${on('cravo')}">
      <path d="M160 192 Q170 150 176 112" stroke="#2E9E5B" stroke-width="4" fill="none"/><path d="M171 140 Q160 132 162 124 Q170 128 171 140 Z" fill="#2E9E5B"/>
      <g fill="#E63946"><circle cx="176" cy="104" r="9"/><circle cx="167" cy="98" r="7"/><circle cx="185" cy="98" r="7"/><circle cx="176" cy="91" r="7"/></g>
    </g>
    <g class="acc${on('abobora')}" transform="translate(24 198)">
      <ellipse rx="21" ry="15" fill="#FF8C1A"/><ellipse rx="8" ry="15" fill="#F57A00"/><path d="M-1 -14 q2 -8 7 -9" stroke="#2E9E5B" stroke-width="4" fill="none" stroke-linecap="round"/>
      <path d="M-12 -3 l5 -6 l3 6 z M12 -3 l-5 -6 l-3 6 z" fill="#5B2A00"/><path d="M-10 4 q10 8 20 0 q-10 3 -20 0 z" fill="#5B2A00"/>
    </g>
    <g class="acc${on('bolo')}" transform="translate(24 198)">
      <rect x="-20" y="-12" width="40" height="24" rx="4" fill="#FFB3D1"/><path d="M-20 -8 q5 7 10 0 q5 7 10 0 q5 7 10 0 q5 7 10 0 L20 -12 L-20 -12 Z" fill="#fff"/>
      <rect x="-2" y="-26" width="4" height="14" fill="#4D96FF"/><path d="M0 -35 q5 5 0 9 q-5 -4 0 -9z" fill="#FFC233"/>
    </g>
    <g class="acc${on('presente')}" transform="translate(24 198)">
      <rect x="-17" y="-14" width="34" height="28" rx="3" fill="#2EC4A0"/><rect x="-3" y="-14" width="6" height="28" fill="#FFC233"/><rect x="-17" y="-3" width="34" height="6" fill="#FFC233"/>
      <path d="M0 -14 q-13 -12 -12 -1 z M0 -14 q13 -12 12 -1 z" fill="#FFC233"/>
    </g>
    <g class="acc${on('castanhas')}" transform="translate(24 198)">
      <path d="M-16 -8 L16 -8 L0 18 Z" fill="#F2E6CF" stroke="#CDBB98" stroke-width="2"/>
      <circle cx="-8" cy="-11" r="7" fill="#7B3F1D"/><circle cx="4" cy="-14" r="7" fill="#8E4B24"/><circle cx="10" cy="-7" r="6" fill="#6B3418"/>
    </g>
    <g class="acc${on('arvore')}" transform="translate(24 194)">
      <path d="M0 -32 L16 -6 L8 -6 L18 10 L-18 10 L-8 -6 L-16 -6 Z" fill="#2E9E5B"/><rect x="-3" y="10" width="6" height="9" fill="#7B3F1D"/>
      <path d="M0 -40 l2.4 5 5.4 .8 -4 3.8 1 5.4 -4.8 -2.6 -4.8 2.6 1 -5.4 -4 -3.8 5.4 -.8z" fill="#FFC233"/>
      <circle cx="-6" cy="2" r="2.5" fill="#E63946"/><circle cx="5" cy="-12" r="2.5" fill="#4D96FF"/><circle cx="8" cy="4" r="2.5" fill="#FFC233"/>
    </g>
    <g class="acc${on('ovos')}" transform="translate(24 198)">
      <ellipse cx="-8" cy="-6" rx="7" ry="9" fill="#FFB3D1"/><ellipse cx="7" cy="-8" rx="7" ry="9" fill="#B8F2E6"/><ellipse cx="0" cy="-3" rx="7" ry="9" fill="#FFE27A"/>
      <path d="M-18 0 L18 0 L13 16 L-13 16 Z" fill="#C98A3E"/><path d="M-16 6 L16 6" stroke="#A86F2E" stroke-width="2"/>
    </g>
    <g class="acc${on('manjerico')}" transform="translate(24 198)">
      <path d="M-12 0 L12 0 L9 17 L-9 17 Z" fill="#C8643C"/><circle cy="-10" r="15" fill="#3FAE5C"/><circle cx="-5" cy="-15" r="4" fill="#5CC877"/>
      <path d="M8 -20 L8 -40" stroke="#5B3A29" stroke-width="2"/><path d="M8 -40 l13 4 l-13 4 z" fill="#E63946"/>
    </g>`;
  }
  function acessoriosCabeca(on) {
    return `
      <g class="acc${on('laco')}">
        <path d="M146 46 L128 36 L130 58 Z M146 46 L164 38 L160 60 Z" fill="#F15BB5"/><circle cx="146" cy="47" r="6" fill="#D93D9C"/>
      </g>
      <g class="acc${on('oculos')}" fill="none" stroke="#3A2E28" stroke-width="4">
        <circle cx="78" cy="78" r="20"/><circle cx="122" cy="78" r="20"/><path d="M98 76 Q100 71 102 76"/>
      </g>
      <g class="acc${on('sol')}">
        <rect x="57" y="65" width="40" height="27" rx="11" fill="#2B2B2B"/><rect x="103" y="65" width="40" height="27" rx="11" fill="#2B2B2B"/>
        <path d="M97 75 L103 75" stroke="#2B2B2B" stroke-width="4"/><path d="M64 72 L76 70 M110 72 L122 70" stroke="#fff" stroke-width="3" opacity=".55" stroke-linecap="round"/>
      </g>
      <g class="acc${on('mascara')}">
        <path fill-rule="evenodd" d="M50 72 Q74 54 100 70 Q126 54 150 72 Q150 96 126 96 Q110 96 100 86 Q90 96 74 96 Q50 96 50 72 Z M66 78 a12 12 0 1 0 24 0 a12 12 0 1 0 -24 0 Z M110 78 a12 12 0 1 0 24 0 a12 12 0 1 0 -24 0 Z" fill="#9B5DE5"/>
        <path d="M52 70 Q36 40 46 24 Q50 50 60 64 Z" fill="#F15BB5"/><path d="M58 66 Q52 40 64 28 Q62 50 68 62 Z" fill="#FFC233"/>
        <circle cx="100" cy="72" r="3" fill="#FFC233"/>
      </g>
      <g class="acc${on('auscult')}">
        <path d="M44 84 Q42 24 100 22 Q158 24 156 84" stroke="#4D96FF" stroke-width="8" fill="none"/>
        <rect x="34" y="74" width="18" height="30" rx="8" fill="#4D96FF"/><rect x="148" y="74" width="18" height="30" rx="8" fill="#4D96FF"/>
      </g>
      <g class="acc${on('flores')}">${FLORES}</g>
      <g class="acc${on('coelho')}">
        <ellipse cx="80" cy="2" rx="12" ry="32" fill="#fff" stroke="#E7D7DD" stroke-width="2" transform="rotate(-12 80 2)"/>
        <ellipse cx="80" cy="4" rx="6" ry="22" fill="#FFC2DC" transform="rotate(-12 80 4)"/>
        <ellipse cx="120" cy="2" rx="12" ry="32" fill="#fff" stroke="#E7D7DD" stroke-width="2" transform="rotate(12 120 2)"/>
        <ellipse cx="120" cy="4" rx="6" ry="22" fill="#FFC2DC" transform="rotate(12 120 4)"/>
        <path d="M58 44 Q100 22 142 44" stroke="#F15BB5" stroke-width="6" fill="none" stroke-linecap="round"/>
      </g>
      <g class="acc${on('chapeu')}">
        <path d="M100 -24 L130 36 L70 36 Z" fill="#9B5DE5"/><path d="M58 36 Q100 48 142 36 Q100 28 58 36 Z" fill="#7B3FC4"/>
        <circle cx="94" cy="10" r="4" fill="#FFC233"/><circle cx="108" cy="24" r="3" fill="#FFC233"/>
      </g>
      <g class="acc${on('capelo')}">
        <path d="M100 12 L148 28 L100 44 L52 28 Z" fill="#2B2B2B"/><rect x="80" y="32" width="40" height="12" fill="#2B2B2B"/>
        <path d="M140 31 L142 54" stroke="#FFC233" stroke-width="3"/><circle cx="142" cy="56" r="4" fill="#FFC233"/>
      </g>
      <g class="acc${on('coroa')}">
        <path d="M70 40 L74 12 L88 28 L100 8 L112 28 L126 12 L130 40 Z" fill="#FFC233" stroke="#E5A100" stroke-width="3" stroke-linejoin="round"/>
        <circle cx="100" cy="30" r="4" fill="#FF5A5F"/><circle cx="84" cy="34" r="3" fill="#4D96FF"/><circle cx="116" cy="34" r="3" fill="#2EC4A0"/>
      </g>
      <g class="acc${on('bone')}">
        <path d="M56 46 Q56 6 100 4 Q144 6 144 46 Q100 36 56 46 Z" fill="#2EC4A0"/><path d="M140 42 Q170 36 184 46 Q166 55 138 50 Z" fill="#1E9E80"/>
        <circle cx="100" cy="6" r="5" fill="#1E9E80"/><path d="M100 8 L100 40" stroke="#1E9E80" stroke-width="2" opacity=".6"/>
      </g>
      <g class="acc${on('pirata')}">
        <path d="M48 42 Q58 0 100 6 Q142 0 152 42 Q100 26 48 42 Z" fill="#2B2B2B"/><path d="M48 42 Q100 26 152 42" stroke="#FFC233" stroke-width="3" fill="none"/>
        <circle cx="100" cy="20" r="7" fill="#fff"/><circle cx="97.5" cy="19" r="1.6" fill="#2B2B2B"/><circle cx="102.5" cy="19" r="1.6" fill="#2B2B2B"/>
        <path d="M91 29 L109 37 M109 29 L91 37" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
      </g>
      <g class="acc${on('tiara')}">
        <path d="M68 40 Q100 22 132 40 L128 44 Q100 30 72 44 Z" fill="#C9D3DD"/>
        <path d="M84 34 L88 20 L94 31 L100 12 L106 31 L112 20 L116 34 Z" fill="#DDE4EA" stroke="#9AA6B2" stroke-width="2" stroke-linejoin="round"/>
        <circle cx="100" cy="24" r="4" fill="#F15BB5"/><circle cx="88" cy="28" r="2.5" fill="#4D96FF"/><circle cx="112" cy="28" r="2.5" fill="#4D96FF"/>
      </g>
      <g class="acc${on('festa')}">
        <path d="M100 -30 L124 36 L76 36 Z" fill="#4D96FF"/><path d="M87 6 L113 6 M81 22 L119 22" stroke="#FFC233" stroke-width="5"/>
        <circle cx="100" cy="-30" r="8" fill="#F15BB5"/>
      </g>
      <g class="acc${on('natal')}">
        <path d="M60 42 Q66 -2 112 -4 Q150 -2 168 36 L158 42 Q146 18 128 16 Q138 28 140 42 Z" fill="#E63946"/>
        <rect x="56" y="34" width="88" height="14" rx="7" fill="#fff"/><circle cx="164" cy="42" r="10" fill="#fff"/>
      </g>
      <g class="acc${on('bruxa')}">
        <ellipse cx="100" cy="40" rx="64" ry="10" fill="#2B2B2B"/>
        <path d="M70 38 Q78 -4 104 -22 Q116 -30 130 -26 Q112 -14 118 4 L130 38 Z" fill="#3A2E48"/>
        <path d="M73 28 L127 28 L130 38 L70 38 Z" fill="#FF9F1C"/><rect x="94" y="28" width="12" height="10" fill="#FFC233"/>
      </g>`;
  }

  function svg(veste, tipo) {
    const on = (id) => (veste && veste.indexOf(id) >= 0 ? ' on' : '');
    const kika = tipo === 'kika';
    // Kika: caturra "lutino" (corpo creme), pestanas e uma florzinha; Kiko: caturra cinzenta
    const C = kika
      ? { b0: '#FFFFFB', b1: '#F7EEDA', b2: '#D9C9A3', w0: '#FBF3DF', w1: '#EADDBB', w2: '#C7B487', barriga: '#FFF9EA', cauda1: '#E2D3AA', cauda2: '#D2C08F', ch1: '#FFB39E', ch2: '#F2665A', tampa: '#FFE36E' }
      : { b0: '#E2E7EC', b1: '#B9C1CA', b2: '#7D8792', w0: '#B3BCC5', w1: '#8D97A1', w2: '#5E6872', barriga: '#D9DEE3', cauda1: '#6F7983', cauda2: '#59626B', ch1: '#FFB070', ch2: '#F26B2A', tampa: '#FFD84D' };
    return `
<svg viewBox="0 0 200 220" aria-label="${kika ? 'Kika' : 'Kiko'}, a caturra">
  <defs>
    <radialGradient id="kgb" cx="38%" cy="28%" r="80%"><stop offset="0" stop-color="${C.b0}"/><stop offset=".45" stop-color="${C.b1}"/><stop offset="1" stop-color="${C.b2}"/></radialGradient>
    <radialGradient id="kgh" cx="40%" cy="32%" r="72%"><stop offset="0" stop-color="#FFF9D2"/><stop offset=".55" stop-color="#FFE266"/><stop offset="1" stop-color="#F0B728"/></radialGradient>
    <radialGradient id="kgr" cx="50%" cy="50%" r="50%"><stop offset=".72" stop-color="#C98A00" stop-opacity="0"/><stop offset="1" stop-color="#B07400" stop-opacity=".28"/></radialGradient>
    <radialGradient id="kgc" cx="45%" cy="40%" r="55%"><stop offset="0" stop-color="${C.ch1}"/><stop offset=".6" stop-color="${C.ch2}"/><stop offset="1" stop-color="${C.ch2}" stop-opacity="0"/></radialGradient>
    <linearGradient id="kgw" x1="0" y1="0" x2=".3" y2="1"><stop offset="0" stop-color="${C.w0}"/><stop offset=".5" stop-color="${C.w1}"/><stop offset="1" stop-color="${C.w2}"/></linearGradient>
    <linearGradient id="kgt" x1="0" y1="1" x2=".4" y2="0"><stop offset="0" stop-color="#F2B92E"/><stop offset="1" stop-color="#FFEB8A"/></linearGradient>
    <linearGradient id="kgk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#B4B8BE"/><stop offset="1" stop-color="#6A6F76"/></linearGradient>
    <radialGradient id="kgi" cx="40%" cy="35%" r="65%"><stop offset="0" stop-color="#5A4030"/><stop offset=".55" stop-color="#2A1C14"/><stop offset="1" stop-color="#0E0906"/></radialGradient>
    <radialGradient id="kge" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff" stop-opacity=".85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
    <radialGradient id="kgv" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="${C.barriga}" stop-opacity=".95"/><stop offset="1" stop-color="${C.barriga}" stop-opacity="0"/></radialGradient>
    <linearGradient id="kgp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F3B8AE"/><stop offset="1" stop-color="#D98B80"/></linearGradient>
    <radialGradient id="kgo" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#3A2E28" stop-opacity=".35"/><stop offset="1" stop-color="#3A2E28" stop-opacity="0"/></radialGradient>
  </defs>
  <circle class="ring" cx="100" cy="110" r="96" fill="none" stroke="#FF9F1C" stroke-width="6"/>
  <ellipse class="sombra" cx="100" cy="210" rx="62" ry="9" fill="url(#kgo)"/>
  <g class="body-g">
    ${acessoriosCorpoTras(on)}
    <!-- cauda comprida, em três penas -->
    <g class="cauda">
      <path d="M90 180 Q80 200 76 218 Q86 216 94 198 Z" fill="${C.cauda2}"/>
      <path d="M110 180 Q120 200 124 218 Q114 216 106 198 Z" fill="${C.cauda2}"/>
      <path d="M95 182 Q97 204 100 220 Q103 204 105 182 Z" fill="${C.cauda1}"/>
      <path d="M100 186 L100 216" stroke="rgba(0,0,0,.18)" stroke-width="1.2"/>
    </g>
    <!-- asas com penas em camadas e a banda branca típica da caturra -->
    <g class="wing-l">
      <path d="M52 114 C22 128 20 172 50 194 C66 168 68 136 52 114 Z" fill="url(#kgw)"/>
      <path d="M44 128 C34 144 34 162 42 174 C49 158 51 142 44 128 Z" fill="#F7F9FB" opacity=".95"/>
      <path d="M30 168 Q36 182 48 190 M27 156 Q33 172 46 182 M28 144 Q34 160 46 170" stroke="rgba(0,0,0,.16)" stroke-width="1.6" fill="none" stroke-linecap="round"/>
      <path d="M50 120 C40 126 34 136 32 146" stroke="rgba(255,255,255,.45)" stroke-width="2" fill="none" stroke-linecap="round"/>
    </g>
    <g class="wing-r">
      <path d="M148 114 C178 128 180 172 150 194 C134 168 132 136 148 114 Z" fill="url(#kgw)"/>
      <path d="M156 128 C166 144 166 162 158 174 C151 158 149 142 156 128 Z" fill="#F7F9FB" opacity=".95"/>
      <path d="M170 168 Q164 182 152 190 M173 156 Q167 172 154 182 M172 144 Q166 160 154 170" stroke="rgba(0,0,0,.16)" stroke-width="1.6" fill="none" stroke-linecap="round"/>
    </g>
    <!-- corpo -->
    <ellipse cx="100" cy="148" rx="56" ry="58" fill="url(#kgb)"/>
    <ellipse cx="100" cy="162" rx="36" ry="40" fill="url(#kgv)"/>
    ${penas(100, 140, 5, 5, 11, 10, kika ? '#C9B98F' : '#FFFFFF', kika ? 0.35 : 0.28)}
    <ellipse cx="78" cy="122" rx="18" ry="10" fill="url(#kge)" opacity=".35"/>
    <!-- sombra da cabeça sobre o peito -->
    <ellipse cx="100" cy="130" rx="46" ry="12" fill="url(#kgo)" opacity=".8"/>
    <!-- patas -->
    <g class="patas" stroke="url(#kgp)" stroke-width="5.5" stroke-linecap="round" fill="none">
      <path d="M86 200 l-8 9 M90 202 l0 10 M94 200 l8 9"/><path d="M106 200 l-8 9 M110 202 l0 10 M114 200 l8 9"/>
    </g>
    <path d="M76 210 l2 1 M90 213 l0 1.5 M104 210 l-2 1 M96 210 l2 1 M110 213 l0 1.5 M124 210 l-2 1" stroke="#7A5A55" stroke-width="2" stroke-linecap="round"/>
    ${acessoriosCorpoFrente(on)}
    <!-- cabeça (move-se sozinha, com a poupa e os acessórios de cabeça) -->
    <g class="head-g">
      <g class="crest">
        <path d="M98 36 C92 10 102 -8 126 -12 C112 4 108 18 111 36 Z" fill="url(#kgt)"/>
        <path d="M91 38 C80 16 85 -2 103 -10 C96 8 96 22 102 38 Z" fill="#FFE27A"/>
        <path d="M106 36 C110 14 125 3 147 5 C130 14 121 25 119 40 Z" fill="url(#kgt)"/>
        <path d="M103 34 C102 18 108 4 122 -6 M95 34 C91 20 92 8 100 -4 M112 34 C116 22 124 12 140 7" stroke="rgba(176,116,0,.35)" stroke-width="1.3" fill="none"/>
      </g>
      <circle cx="100" cy="80" r="54" fill="url(#kgh)"/>
      <circle cx="100" cy="80" r="54" fill="url(#kgr)"/>
      ${penas(100, 36, 2, 5, 12, 8, '#E2A812', 0.35)}
      <path d="M52 100 C60 126 80 136 100 136 C120 136 140 126 148 100 C140 116 122 124 100 124 C78 124 60 116 52 100 Z" fill="#E8EBEE" opacity=".45"/>
      <ellipse cx="80" cy="48" rx="20" ry="12" fill="url(#kge)" opacity=".75" transform="rotate(-20 80 48)"/>
      <!-- bochechas cor de laranja (típicas da caturra) -->
      <circle cx="64" cy="98" r="17" fill="url(#kgc)"/>
      <circle cx="136" cy="98" r="17" fill="url(#kgc)"/>
      <!-- olhos -->
      <g class="eyes-open">
        <circle cx="78" cy="78" r="14.5" fill="#1A120D" opacity=".18"/>
        <circle cx="122" cy="78" r="14.5" fill="#1A120D" opacity=".18"/>
        <g class="pupils">
          <circle cx="78" cy="78" r="13" fill="url(#kgi)"/>
          <circle cx="122" cy="78" r="13" fill="url(#kgi)"/>
          <circle cx="82.5" cy="72.5" r="5" fill="#fff"/>
          <circle cx="126.5" cy="72.5" r="5" fill="#fff"/>
          <circle cx="73.5" cy="83.5" r="2.2" fill="#fff" opacity=".85"/>
          <circle cx="117.5" cy="83.5" r="2.2" fill="#fff" opacity=".85"/>
        </g>
        <ellipse class="lid" cx="78" cy="78" rx="15" ry="15" fill="${C.tampa}"/>
        <ellipse class="lid" cx="122" cy="78" rx="15" ry="15" fill="${C.tampa}"/>
      </g>
      ${kika ? `<g class="lashes" stroke="#2B2B2B" stroke-width="3" stroke-linecap="round">
        <path d="M66 68 L60 63"/><path d="M70 64 L66 58"/><path d="M134 68 L140 63"/><path d="M130 64 L134 58"/></g>
      <g class="flor"><circle cx="58" cy="44" r="7" fill="#FF8FC7"/><circle cx="68" cy="40" r="7" fill="#FF8FC7"/><circle cx="66" cy="51" r="7" fill="#FF8FC7"/><circle cx="55" cy="54" r="7" fill="#FF8FC7"/><circle cx="62" cy="47" r="5" fill="#FFE36E"/><circle cx="60" cy="45" r="2" fill="#fff" opacity=".7"/></g>` : ''}
      <g class="eyes-happy" stroke="#2B2B2B" stroke-width="6" fill="none" stroke-linecap="round">
        <path d="M66 82 Q78 66 90 82"/><path d="M110 82 Q122 66 134 82"/>
      </g>
      <g class="brows" stroke="#B08A1E" stroke-width="5" stroke-linecap="round">
        <path d="M64 66 L90 57"/><path d="M136 66 L110 57"/>
      </g>
      <!-- bico curvo -->
      <path class="beak-low" d="M91 99 Q100 120 109 99 Z" fill="#43282A"/>
      <path d="M89 94 Q100 85 111 94 Q109 105 100 111 Q91 105 89 94 Z" fill="url(#kgk)"/>
      <path d="M93 94 Q100 89.5 107 94" stroke="#D3D6DA" stroke-width="2" fill="none" stroke-linecap="round"/>
      <circle cx="96" cy="91" r="1.1" fill="#4A4E54"/><circle cx="104" cy="91" r="1.1" fill="#4A4E54"/>
      ${acessoriosCabeca(on)}
    </g>
  </g>
  <g class="think" fill="#8C7B70"><circle cx="160" cy="30" r="5"/><circle cx="176" cy="18" r="6"/><circle cx="192" cy="4" r="7"/></g>
</svg>`;
  }

  // =====================================================================
  // Mascote à medida: para além do Kiko/da Kika, pode escolher-se um bicho.
  // Usa a mesma estrutura (corpo, olhos, boca que mexe a falar, acessórios),
  // só mudando as orelhas/chifres, o focinho ou bico, a cauda e as cores.
  // =====================================================================
  const BICHOS = {
    cao: {
      nome: 'Cão', artigo: 'o', emo: '🐶', orelhas: 'caida', cauda: 'media', membros: 'braco', pe: 'pata', nariz: '#2B2320', boca: '#43282A',
      cores: { b0: '#FFF3DE', b1: '#F0CB93', b2: '#C99A5B', w0: '#F7DDB0', w1: '#E8BE80', w2: '#C2944F', barriga: '#FFF8EC', cauda1: '#C99A5B', cauda2: '#E0B378', ch1: '#FFC2A8', ch2: '#F2836B', tampa: '#E8BE80' }
    },
    gato: {
      nome: 'Gato', artigo: 'o', emo: '🐱', orelhas: 'ponta', cauda: 'longa', membros: 'braco', pe: 'pata', bigodes: true, nariz: '#D98B80', boca: '#43282A',
      cores: { b0: '#FFE3C2', b1: '#F5B46B', b2: '#D8863A', w0: '#FBD09A', w1: '#EFA85C', w2: '#C97E34', barriga: '#FFF3E0', cauda1: '#D8863A', cauda2: '#F5B46B', ch1: '#FFB3C6', ch2: '#F0718F', tampa: '#EFA85C' }
    },
    coelho: {
      nome: 'Coelho', artigo: 'o', emo: '🐰', orelhas: 'comprida', cauda: 'bolota', membros: 'braco', pe: 'pata-grande', bigodes: true, nariz: '#F28FA8', boca: '#5E3A3F',
      cores: { b0: '#FFFFFF', b1: '#F5EDF0', b2: '#DCC7CF', w0: '#FDF6F8', w1: '#F0DEE4', w2: '#D6B9C3', barriga: '#FFFFFF', cauda1: '#F0DEE4', cauda2: '#FFFFFF', ch1: '#FFC2D6', ch2: '#F2819F', tampa: '#F0DEE4' }
    },
    urso: {
      nome: 'Urso', artigo: 'o', emo: '🐻', orelhas: 'redonda', cauda: 'nenhuma', membros: 'braco-grosso', pe: 'pata-grande', nariz: '#2B2320', boca: '#3A2420',
      cores: { b0: '#E9C9A0', b1: '#C99A63', b2: '#8E6436', w0: '#D9B183', w1: '#B4824D', w2: '#7C5429', barriga: '#F3DDB8', cauda1: '#8E6436', cauda2: '#C99A63', ch1: '#F0A98A', ch2: '#D9744F', tampa: '#B4824D' }
    },
    raposa: {
      nome: 'Raposa', artigo: 'a', emo: '🦊', orelhas: 'ponta-grande', cauda: 'fofa', membros: 'braco', pe: 'pata', bigodes: true, nariz: '#2B2320', boca: '#43282A',
      cores: { b0: '#FFB06B', b1: '#F2863A', b2: '#C45F1D', w0: '#F7985A', w1: '#ED7A32', w2: '#B85A1C', barriga: '#FFF6E8', cauda1: '#C45F1D', cauda2: '#F2863A', ch1: '#FFCE9E', ch2: '#F2863A', tampa: '#ED7A32' }
    },
    panda: {
      nome: 'Panda', artigo: 'o', emo: '🐼', orelhas: 'redonda-preta', cauda: 'nenhuma', membros: 'braco-grosso', pe: 'pata-grande', manchas: 'panda', nariz: '#1C1C1C', boca: '#1C1C1C',
      cores: { b0: '#FFFFFF', b1: '#F2F2F2', b2: '#D9D9D9', w0: '#2B2B2B', w1: '#1C1C1C', w2: '#000000', barriga: '#FFFFFF', cauda1: '#D9D9D9', cauda2: '#FFFFFF', ch1: '#FFC2D6', ch2: '#F28FA8', tampa: '#D9D9D9' }
    },
    leao: {
      nome: 'Leão', artigo: 'o', emo: '🦁', orelhas: 'redonda', cauda: 'tufo', membros: 'braco', pe: 'pata-grande', juba: true, nariz: '#5A3A22', boca: '#3A2015',
      cores: { b0: '#FFE199', b1: '#F2BD55', b2: '#C98F2C', w0: '#F0C066', w1: '#E0A23E', w2: '#B87B22', barriga: '#FFF3D0', cauda1: '#C98F2C', cauda2: '#8E5A1C', ch1: '#FFC08A', ch2: '#E8824A', tampa: '#E0A23E' }
    },
    coruja: {
      nome: 'Coruja', artigo: 'a', emo: '🦉', orelhas: 'tufo', cauda: 'pena', membros: 'asas', pe: 'garra-ave', bico: true,
      cores: { b0: '#E9DAB8', b1: '#C9A86C', b2: '#8E6B3A', w0: '#D9C292', w1: '#B99656', w2: '#7C5A2E', barriga: '#F5EDD8', cauda1: '#8E6B3A', cauda2: '#C9A86C', ch1: '#F0C28A', ch2: '#D98B4A', tampa: '#B99656', bico0: '#B4B8BE', bico1: '#6A6F76' }
    },
    pinguim: {
      nome: 'Pinguim', artigo: 'o', emo: '🐧', orelhas: 'nenhuma', cauda: 'curta', membros: 'flipper', pe: 'pe-nadador', bico: true,
      cores: { b0: '#5A5A5E', b1: '#33333A', b2: '#18181C', w0: '#3A3A42', w1: '#222228', w2: '#0E0E12', barriga: '#FFFFFF', cauda1: '#18181C', cauda2: '#33333A', ch1: '#FFD9A0', ch2: '#F2A33E', tampa: '#33333A', bico0: '#FFC24D', bico1: '#E8922A' }
    },
    dragao: {
      nome: 'Dragão', artigo: 'o', emo: '🐉', orelhas: 'chifre', cauda: 'escamas', membros: 'asas-dragao', pe: 'garra-dragao', nariz: '#1F4A26', boca: '#2B1B12',
      cores: { b0: '#BDEBC0', b1: '#6FBF73', b2: '#3C8F49', w0: '#9BDBA0', w1: '#5FAE66', w2: '#357F3E', barriga: '#E9FBEA', cauda1: '#3C8F49', cauda2: '#6FBF73', ch1: '#FFC98A', ch2: '#F2954A', tampa: '#5FAE66' }
    }
  };

  // orelhas/chifres (ficam dentro de ".crest", por isso mexem-se a falar/contente/triste tal como a poupa do Kiko)
  function ornamento(tipo, C) {
    switch (tipo) {
      case 'caida': return `
        <path d="M60 46 C32 52 24 92 44 112 C62 100 66 66 60 46 Z" fill="${C.b1}"/>
        <path d="M140 46 C168 52 176 92 156 112 C138 100 134 66 140 46 Z" fill="${C.b1}"/>
        <path d="M54 58 C42 66 38 86 48 98 C56 88 58 70 54 58 Z" fill="${C.ch1}" opacity=".55"/>
        <path d="M146 58 C158 66 162 86 152 98 C144 88 142 70 146 58 Z" fill="${C.ch1}" opacity=".55"/>`;
      case 'ponta': return `
        <path d="M58 42 L46 2 L84 34 Z" fill="${C.b1}"/>
        <path d="M142 42 L154 2 L116 34 Z" fill="${C.b1}"/>
        <path d="M62 36 L55 12 L78 32 Z" fill="${C.ch1}"/>
        <path d="M138 36 L145 12 L122 32 Z" fill="${C.ch1}"/>`;
      case 'ponta-grande': return `
        <path d="M56 44 L34 -12 L86 32 Z" fill="${C.b1}"/>
        <path d="M144 44 L166 -12 L114 32 Z" fill="${C.b1}"/>
        <path d="M60 36 L44 0 L80 30 Z" fill="${C.ch1}"/>
        <path d="M140 36 L156 0 L120 30 Z" fill="${C.ch1}"/>`;
      case 'comprida': return `
        <ellipse cx="78" cy="-2" rx="13" ry="42" fill="${C.b1}" transform="rotate(-8 78 -2)"/>
        <ellipse cx="78" cy="2" rx="6.5" ry="30" fill="${C.ch1}" transform="rotate(-8 78 2)"/>
        <ellipse cx="122" cy="-2" rx="13" ry="42" fill="${C.b1}" transform="rotate(8 122 -2)"/>
        <ellipse cx="122" cy="2" rx="6.5" ry="30" fill="${C.ch1}" transform="rotate(8 122 2)"/>`;
      case 'redonda': return `
        <circle cx="66" cy="34" r="17" fill="${C.b1}"/><circle cx="134" cy="34" r="17" fill="${C.b1}"/>
        <circle cx="66" cy="36" r="9" fill="${C.ch1}"/><circle cx="134" cy="36" r="9" fill="${C.ch1}"/>`;
      case 'redonda-preta': return `<circle cx="64" cy="32" r="19" fill="#2B2B2B"/><circle cx="136" cy="32" r="19" fill="#2B2B2B"/>`;
      case 'tufo': return `
        <path d="M82 40 L72 6 L96 34 Z" fill="${C.b1}"/>
        <path d="M118 40 L128 6 L104 34 Z" fill="${C.b1}"/>`;
      case 'chifre': return `
        <path d="M72 40 C64 20 68 0 82 -10 C78 10 80 26 86 40 Z" fill="#E8D9A8"/>
        <path d="M128 40 C136 20 132 0 118 -10 C122 10 120 26 114 40 Z" fill="#E8D9A8"/>`;
      default: return '';
    }
  }

  // juba do leão: uma coroa de tufos atrás da cabeça, sem ser a parte animada (".crest" são só as orelhas)
  function juba(C) {
    let o = '';
    for (let i = 0; i < 14; i++) {
      const ang = (i / 14) * Math.PI * 2;
      const x1 = (100 + Math.cos(ang) * 58).toFixed(1), y1 = (80 + Math.sin(ang) * 58).toFixed(1);
      const x2 = (100 + Math.cos(ang) * 76).toFixed(1), y2 = (80 + Math.sin(ang) * 76).toFixed(1);
      o += `<path d="M${x1} ${y1} L${x2} ${y2}" stroke="${C.cauda2}" stroke-width="15" stroke-linecap="round"/>`;
    }
    return `<g opacity=".95">${o}</g>`;
  }

  function caudaBicho(tipo, C) {
    switch (tipo) {
      case 'media': return `<path d="M140 178 Q170 168 178 188 Q160 200 138 192 Z" fill="${C.cauda1}"/>`;
      case 'longa': return `
        <path d="M130 186 Q176 176 180 140 Q184 108 166 92" stroke="${C.cauda1}" stroke-width="15" fill="none" stroke-linecap="round"/>
        <path d="M160 100 Q170 96 166 92" stroke="${C.cauda2}" stroke-width="7" fill="none" stroke-linecap="round"/>`;
      case 'bolota': return `<circle cx="100" cy="193" r="15" fill="#fff"/><circle cx="100" cy="193" r="15" fill="${C.cauda1}" opacity=".35"/>`;
      case 'fofa': return `
        <path d="M128 178 Q182 168 186 128 Q190 96 166 84 Q180 116 168 150 Q156 176 128 184 Z" fill="${C.cauda1}"/>
        <path d="M178 98 Q188 96 184 116 Q176 126 168 120 Z" fill="#fff"/>`;
      case 'tufo': return `
        <path d="M135 182 Q172 180 182 206" stroke="${C.cauda1}" stroke-width="6" fill="none" stroke-linecap="round"/>
        <circle cx="184" cy="210" r="11" fill="${C.cauda2}"/>`;
      case 'pena': return `
        <path d="M90 180 Q80 200 76 218 Q86 216 94 198 Z" fill="${C.cauda2}"/>
        <path d="M110 180 Q120 200 124 218 Q114 216 106 198 Z" fill="${C.cauda2}"/>
        <path d="M95 182 Q97 204 100 220 Q103 204 105 182 Z" fill="${C.cauda1}"/>`;
      case 'curta': return `<path d="M92 196 L100 214 L108 196 Z" fill="${C.cauda1}"/>`;
      case 'escamas': return `
        <path d="M130 180 Q168 185 180 210" stroke="${C.cauda1}" stroke-width="10" fill="none" stroke-linecap="round"/>
        <path d="M145 178 l6 -10 M158 184 l6 -10 M170 194 l6 -9" stroke="${C.cauda2}" stroke-width="4" stroke-linecap="round"/>`;
      default: return '';
    }
  }

  // membros: asas só nas aves/dragão — os mamíferos têm bracinhos com patinha, não penas
  function membrosBicho(tipo, C) {
    switch (tipo) {
      case 'asas': return {
        l: `<path d="M52 114 C22 128 20 172 50 194 C66 168 68 136 52 114 Z" fill="url(#kgw)"/>
            <path d="M44 128 C34 144 34 162 42 174 C49 158 51 142 44 128 Z" fill="#F7F9FB" opacity=".95"/>
            <path d="M30 168 Q36 182 48 190 M27 156 Q33 172 46 182 M28 144 Q34 160 46 170" stroke="rgba(0,0,0,.16)" stroke-width="1.6" fill="none" stroke-linecap="round"/>`,
        r: `<path d="M148 114 C178 128 180 172 150 194 C134 168 132 136 148 114 Z" fill="url(#kgw)"/>
            <path d="M170 168 Q164 182 152 190 M173 156 Q167 172 154 182 M172 144 Q166 160 154 170" stroke="rgba(0,0,0,.16)" stroke-width="1.6" fill="none" stroke-linecap="round"/>`
      };
      case 'flipper': return {
        // barbatanas curtas e lisas do pinguim, sem penas nem dedos
        l: `<path d="M56 122 C36 132 32 162 50 184 C62 166 62 140 56 122 Z" fill="url(#kgw)"/>`,
        r: `<path d="M144 122 C164 132 168 162 150 184 C138 166 138 140 144 122 Z" fill="url(#kgw)"/>`
      };
      case 'asas-dragao': return {
        // asas de couro, com "dedos" a esticar a membrana, como num morcego
        l: `<path d="M50 108 C14 96 -8 126 2 158 C14 144 24 142 28 160 C36 144 44 142 48 162 C54 144 56 124 50 108 Z" fill="url(#kgw)"/>
            <path d="M8 130 L46 116 M6 150 L44 138" stroke="${C.cauda1}" stroke-width="2" fill="none" opacity=".55"/>`,
        r: `<path d="M150 108 C186 96 208 126 198 158 C186 144 176 142 172 160 C164 144 156 142 152 162 C146 144 144 124 150 108 Z" fill="url(#kgw)"/>
            <path d="M192 130 L154 116 M194 150 L156 138" stroke="${C.cauda1}" stroke-width="2" fill="none" opacity=".55"/>`
      };
      case 'braco-grosso': return {
        // braços redondos e robustos (urso/panda), terminam numa pata larga
        l: `<path d="M48 128 C28 138 22 166 34 192 C50 200 64 194 64 174 C64 152 60 138 48 128 Z" fill="url(#kgw)"/>
            <ellipse cx="42" cy="190" rx="15" ry="11" fill="url(#kgw)"/>`,
        r: `<path d="M152 128 C172 138 178 166 166 192 C150 200 136 194 136 174 C136 152 140 138 152 128 Z" fill="url(#kgw)"/>
            <ellipse cx="158" cy="190" rx="15" ry="11" fill="url(#kgw)"/>`
      };
      default: return {
        // braço fininho comum à maioria dos mamíferos, com patinha arredondada na ponta
        l: `<path d="M50 126 C34 134 28 158 38 182 C48 190 60 186 60 168 C60 150 58 136 50 126 Z" fill="url(#kgw)"/>
            <ellipse cx="44" cy="182" rx="12" ry="9.5" fill="url(#kgw)"/>`,
        r: `<path d="M150 126 C166 134 172 158 162 182 C152 190 140 186 140 168 C140 150 142 136 150 126 Z" fill="url(#kgw)"/>
            <ellipse cx="156" cy="182" rx="12" ry="9.5" fill="url(#kgw)"/>`
      };
    }
  }

  // pés: patinhas arredondadas nos mamíferos, dedos de ave só na coruja, barbatanas no pinguim, garras no dragão
  function pesBicho(tipo, C) {
    switch (tipo) {
      case 'garra-ave': return `
        <g class="patas" stroke="url(#kgp)" stroke-width="5.5" stroke-linecap="round" fill="none">
          <path d="M86 200 l-8 9 M90 202 l0 10 M94 200 l8 9"/><path d="M106 200 l-8 9 M110 202 l0 10 M114 200 l8 9"/>
        </g>`;
      case 'pe-nadador': return `
        <g class="patas" fill="${C.bico0 || '#F2A33E'}">
          <path d="M72 200 Q86 214 102 202 Q99 211 84 215 Q70 211 72 200 Z"/>
          <path d="M98 202 Q114 214 130 200 Q127 211 112 215 Q98 211 98 202 Z"/>
        </g>`;
      case 'garra-dragao': return `
        <g class="patas">
          <ellipse cx="88" cy="201" rx="10" ry="8" fill="${C.b2}"/><ellipse cx="112" cy="201" rx="10" ry="8" fill="${C.b2}"/>
          <path d="M80 203 l-6 9 M88 207 l-3 10 M96 203 l1 10" stroke="${C.boca}" stroke-width="2.6" stroke-linecap="round"/>
          <path d="M104 203 l-1 10 M112 207 l3 10 M120 203 l6 9" stroke="${C.boca}" stroke-width="2.6" stroke-linecap="round"/>
        </g>`;
      case 'pata-grande': return `
        <g class="patas">
          <ellipse cx="86" cy="203" rx="14" ry="10.5" fill="url(#kgp)"/><ellipse cx="114" cy="203" rx="14" ry="10.5" fill="url(#kgp)"/>
          <circle cx="76" cy="197" r="3" fill="${C.b2}" opacity=".55"/><circle cx="86" cy="193" r="3" fill="${C.b2}" opacity=".55"/><circle cx="96" cy="197" r="3" fill="${C.b2}" opacity=".55"/>
          <circle cx="104" cy="197" r="3" fill="${C.b2}" opacity=".55"/><circle cx="114" cy="193" r="3" fill="${C.b2}" opacity=".55"/><circle cx="124" cy="197" r="3" fill="${C.b2}" opacity=".55"/>
        </g>`;
      default: return `
        <g class="patas">
          <ellipse cx="88" cy="203" rx="11" ry="8.5" fill="url(#kgp)"/><ellipse cx="112" cy="203" rx="11" ry="8.5" fill="url(#kgp)"/>
          <circle cx="82" cy="199" r="2.5" fill="${C.b2}" opacity=".55"/><circle cx="88" cy="196" r="2.5" fill="${C.b2}" opacity=".55"/><circle cx="94" cy="199" r="2.5" fill="${C.b2}" opacity=".55"/>
          <circle cx="106" cy="199" r="2.5" fill="${C.b2}" opacity=".55"/><circle cx="112" cy="196" r="2.5" fill="${C.b2}" opacity=".55"/><circle cx="118" cy="199" r="2.5" fill="${C.b2}" opacity=".55"/>
        </g>`;
    }
  }

  // boca: bico (ave) reaproveita o desenho do Kiko; focinho (mamífero/réptil) é um focinho com nariz e boca que abre
  function boca(def) {
    if (def.bico) {
      return `
      <path class="beak-low" d="M91 99 Q100 120 109 99 Z" fill="#43282A"/>
      <path d="M89 94 Q100 85 111 94 Q109 105 100 111 Q91 105 89 94 Z" fill="url(#kgk)"/>
      <path d="M93 94 Q100 89.5 107 94" stroke="#D3D6DA" stroke-width="2" fill="none" stroke-linecap="round"/>
      <circle cx="96" cy="91" r="1.1" fill="#4A4E54"/><circle cx="104" cy="91" r="1.1" fill="#4A4E54"/>`;
    }
    return `
      <ellipse cx="100" cy="91" rx="7" ry="5" fill="${def.nariz}"/>
      <path d="M100 96 L100 99" stroke="${def.nariz}" stroke-width="2" stroke-linecap="round"/>
      <path class="beak-low" d="M90 99 Q100 108 110 99 Z" fill="${def.boca}"/>
      ${def.bigodes ? `<g stroke="#fff" stroke-width="1.6" opacity=".8" stroke-linecap="round">
        <path d="M86 94 L58 88 M86 98 L56 98 M86 102 L58 108"/>
        <path d="M114 94 L142 88 M114 98 L144 98 M114 102 L142 108"/>
      </g>` : ''}`;
  }

  function svgBicho(veste, especie) {
    const on = (id) => (veste && veste.indexOf(id) >= 0 ? ' on' : '');
    const def = BICHOS[especie] || BICHOS.cao;
    const C = def.cores;
    return `
<svg viewBox="0 0 200 220" aria-label="${def.nome}">
  <defs>
    <radialGradient id="kgb" cx="38%" cy="28%" r="80%"><stop offset="0" stop-color="${C.b0}"/><stop offset=".45" stop-color="${C.b1}"/><stop offset="1" stop-color="${C.b2}"/></radialGradient>
    <radialGradient id="kgc" cx="45%" cy="40%" r="55%"><stop offset="0" stop-color="${C.ch1}"/><stop offset=".6" stop-color="${C.ch2}"/><stop offset="1" stop-color="${C.ch2}" stop-opacity="0"/></radialGradient>
    <linearGradient id="kgw" x1="0" y1="0" x2=".3" y2="1"><stop offset="0" stop-color="${C.w0}"/><stop offset=".5" stop-color="${C.w1}"/><stop offset="1" stop-color="${C.w2}"/></linearGradient>
    <linearGradient id="kgk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${C.bico0 || '#B4B8BE'}"/><stop offset="1" stop-color="${C.bico1 || '#6A6F76'}"/></linearGradient>
    <radialGradient id="kgi" cx="40%" cy="35%" r="65%"><stop offset="0" stop-color="#5A4030"/><stop offset=".55" stop-color="#2A1C14"/><stop offset="1" stop-color="#0E0906"/></radialGradient>
    <radialGradient id="kge" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff" stop-opacity=".85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
    <radialGradient id="kgv" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="${C.barriga}" stop-opacity=".95"/><stop offset="1" stop-color="${C.barriga}" stop-opacity="0"/></radialGradient>
    <linearGradient id="kgp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F3B8AE"/><stop offset="1" stop-color="#D98B80"/></linearGradient>
    <radialGradient id="kgo" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#3A2E28" stop-opacity=".35"/><stop offset="1" stop-color="#3A2E28" stop-opacity="0"/></radialGradient>
  </defs>
  <circle class="ring" cx="100" cy="110" r="96" fill="none" stroke="#FF9F1C" stroke-width="6"/>
  <ellipse class="sombra" cx="100" cy="210" rx="62" ry="9" fill="url(#kgo)"/>
  <g class="body-g">
    ${acessoriosCorpoTras(on)}
    <g class="cauda">${caudaBicho(def.cauda, C)}</g>
    <g class="wing-l">${membrosBicho(def.membros, C).l}</g>
    <g class="wing-r">${membrosBicho(def.membros, C).r}</g>
    <ellipse cx="100" cy="148" rx="56" ry="58" fill="url(#kgb)"/>
    <ellipse cx="100" cy="162" rx="36" ry="40" fill="url(#kgv)"/>
    ${penas(100, 140, 5, 5, 11, 10, '#FFFFFF', .22)}
    <ellipse cx="78" cy="122" rx="18" ry="10" fill="url(#kge)" opacity=".3"/>
    <ellipse cx="100" cy="130" rx="46" ry="12" fill="url(#kgo)" opacity=".8"/>
    ${pesBicho(def.pe, C)}
    <path d="M76 210 l2 1 M90 213 l0 1.5 M104 210 l-2 1 M96 210 l2 1 M110 213 l0 1.5 M124 210 l-2 1" stroke="#7A5A55" stroke-width="2" stroke-linecap="round"/>
    ${acessoriosCorpoFrente(on)}
    <g class="head-g">
      ${def.juba ? juba(C) : ''}
      <g class="crest">${ornamento(def.orelhas, C)}</g>
      <circle cx="100" cy="80" r="54" fill="url(#kgb)"/>
      <path d="M52 100 C60 126 80 136 100 136 C120 136 140 126 148 100 C140 116 122 124 100 124 C78 124 60 116 52 100 Z" fill="${C.b2}" opacity=".3"/>
      <ellipse cx="80" cy="48" rx="20" ry="12" fill="url(#kge)" opacity=".6" transform="rotate(-20 80 48)"/>
      <circle cx="64" cy="98" r="17" fill="url(#kgc)"/><circle cx="136" cy="98" r="17" fill="url(#kgc)"/>
      ${def.manchas === 'panda' ? '<g class="manchas"><ellipse cx="74" cy="74" rx="19" ry="24" fill="#222" transform="rotate(-10 74 74)"/><ellipse cx="126" cy="74" rx="19" ry="24" fill="#222" transform="rotate(10 126 74)"/></g>' : ''}
      <g class="eyes-open">
        <circle cx="78" cy="78" r="14.5" fill="#1A120D" opacity=".18"/>
        <circle cx="122" cy="78" r="14.5" fill="#1A120D" opacity=".18"/>
        <g class="pupils">
          <circle cx="78" cy="78" r="13" fill="url(#kgi)"/>
          <circle cx="122" cy="78" r="13" fill="url(#kgi)"/>
          <circle cx="82.5" cy="72.5" r="5" fill="#fff"/>
          <circle cx="126.5" cy="72.5" r="5" fill="#fff"/>
          <circle cx="73.5" cy="83.5" r="2.2" fill="#fff" opacity=".85"/>
          <circle cx="117.5" cy="83.5" r="2.2" fill="#fff" opacity=".85"/>
        </g>
        <ellipse class="lid" cx="78" cy="78" rx="15" ry="15" fill="${C.tampa}"/>
        <ellipse class="lid" cx="122" cy="78" rx="15" ry="15" fill="${C.tampa}"/>
      </g>
      <g class="eyes-happy" stroke="#2B2B2B" stroke-width="6" fill="none" stroke-linecap="round">
        <path d="M66 82 Q78 66 90 82"/><path d="M110 82 Q122 66 134 82"/>
      </g>
      <g class="brows" stroke="${C.b2}" stroke-width="5" stroke-linecap="round">
        <path d="M64 66 L90 57"/><path d="M136 66 L110 57"/>
      </g>
      ${boca(def)}
      ${acessoriosCabeca(on)}
    </g>
  </g>
  <g class="think" fill="#8C7B70"><circle cx="160" cy="30" r="5"/><circle cx="176" cy="18" r="6"/><circle cx="192" cy="4" r="7"/></g>
</svg>`;
  }

  let el = null;               // elemento atual do Kiko no ecrã
  let bolha = null;            // balão de fala associado
  let reacaoT = null;
  let falaT = null;

  // ---------- abertura do bico ao falar: ritmo variável, como sílabas, em vez de um "pêndulo" mecânico
  function falarComecar() {
    clearTimeout(falaT);
    const passo = () => {
      const b = el && el.querySelector('.beak-low');
      if (!b) return;
      const abre = Math.random() * Math.random(); // mais sílabas pequenas, de vez em quando uma bem aberta
      b.style.transform = `translateY(${(1 + abre * 11).toFixed(1)}px) scaleY(${(1 + abre * 1.4).toFixed(2)})`;
      falaT = setTimeout(passo, 70 + Math.random() * 110);
    };
    passo();
  }
  function falarParar() {
    clearTimeout(falaT);
    falaT = null;
    const b = el && el.querySelector('.beak-low');
    if (b) b.style.transform = '';
  }

  const frasesToque = () => [
    'Hihi! Fazes-me cócegas!', KIKO.tipo() === 'kika' ? 'Estou pronta! Carrega no microfone e fala comigo.' : 'Estou pronto! Carrega no microfone e fala comigo.', 'Piu-piu! Sabias que as caturras vêm da Austrália?', 'Quando estou contente levanto a minha poupa amarela!',
    'Vamos aprender alguma coisa nova?',
    'Quanto mais praticares, mais estrelas ganhas!', 'Um bocadinho todos os dias faz milagres!'
  ];

  // ---------- o Kiko segue o dedo/rato com os olhos e inclina-se em 3D
  let olharLigado = false, alvo = null, rafOlhar = 0, voltarT = null;
  function aplicarOlhar(dx, dy) {
    if (!el) return;
    const cl = (v, m) => Math.max(-m, Math.min(m, v));
    el.style.setProperty('--px', cl(dx * 6, 4.5).toFixed(2) + 'px');
    el.style.setProperty('--py', cl(dy * 6, 4).toFixed(2) + 'px');
    el.style.setProperty('--hx', cl(dx * 7, 6).toFixed(2) + 'px');
    el.style.setProperty('--hy', cl(dy * 4, 3).toFixed(2) + 'px');
    el.style.setProperty('--ry', cl(dx * 16, 14).toFixed(1) + 'deg');
    el.style.setProperty('--rx', cl(-dy * 10, 9).toFixed(1) + 'deg');
  }
  function seguirOlhar() {
    if (olharLigado) return;
    olharLigado = true;
    const mover = (x, y) => {
      alvo = { x, y, t: Date.now() };
      if (rafOlhar) return;
      rafOlhar = requestAnimationFrame(() => {
        rafOlhar = 0;
        if (!el || !document.body.contains(el)) return;
        const r = el.getBoundingClientRect();
        if (!r.width) return;
        const cx = r.left + r.width / 2, cy = r.top + r.height * 0.4;
        const d = Math.max(r.width * 1.6, 180);
        aplicarOlhar((alvo.x - cx) / d, (alvo.y - cy) / d);
        clearTimeout(voltarT);
        voltarT = setTimeout(() => aplicarOlhar(0, 0), 2500);
      });
    };
    document.addEventListener('pointermove', (e) => mover(e.clientX, e.clientY), { passive: true });
    document.addEventListener('pointerdown', (e) => mover(e.clientX, e.clientY), { passive: true });
    // no telemóvel, inclinar o aparelho também mexe ligeiramente o Kiko
    window.addEventListener('deviceorientation', (e) => {
      if (e.gamma == null || !el || (alvo && Date.now() - (alvo.t || 0) < 3000) || Date.now() - (seguirOlhar.ult || 0) < 120) return;
      seguirOlhar.ult = Date.now();
      aplicarOlhar(Math.max(-1, Math.min(1, e.gamma / 45)) * 0.5, Math.max(-1, Math.min(1, ((e.beta || 45) - 45) / 45)) * 0.4);
    }, { passive: true });
  }

  window.KIKO = {
    _n: 0,
    ACESSORIOS,
    BICHOS,
    // todas as opções de mascote disponíveis, para os ecrãs de perfil montarem o seletor
    MASCOTES: [{ id: 'kiko', nome: 'Kiko', emo: '🦜' }, { id: 'kika', nome: 'Kika', emo: '🦜' }]
      .concat(Object.keys(BICHOS).map((id) => ({ id, nome: BICHOS[id].nome, emo: BICHOS[id].emo }))),
    tipo() { const p = window.S && S.data && S.perfil(); return (p && p.mascote) || 'kiko'; },
    nome() { const t = KIKO.tipo(); if (t === 'kika') return 'Kika'; if (t === 'kiko') return 'Kiko'; return (BICHOS[t] && BICHOS[t].nome) || 'Kiko'; },
    o() { const t = KIKO.tipo(); if (t === 'kika') return 'a'; if (t === 'kiko') return 'o'; return (BICHOS[t] && BICHOS[t].artigo) || 'o'; },          // artigo: "o Kiko" / "a Kika" / "a Raposa"
    oNome() { return KIKO.o() + ' ' + KIKO.nome(); },             // "o Kiko"
    ONome() { return (KIKO.o() === 'a' ? 'A ' : 'O ') + KIKO.nome(); },
    html(classe, veste, tipo) {
      // ids únicos para os gradientes: vários desenhos no mesmo ecrã não se misturam
      const u = 'g' + (++KIKO._n);
      const t = tipo || KIKO.tipo();
      const bruto = (t === 'kiko' || t === 'kika') ? svg(veste || [], t) : svgBicho(veste || [], t);
      const desenho = bruto.replace(/id="(kg[a-z0-9]+)"/g, 'id="$1' + u + '"').replace(/url\(#(kg[a-z0-9]+)\)/g, 'url(#$1' + u + ')');
      return `<div class="kiko ${classe || ''}" id="kiko">${desenho}</div>`;
    },
    ligar(raiz) {
      el = (raiz || document).querySelector('#kiko');
      seguirOlhar();
      bolha = (raiz || document).querySelector('#bolha');
      if (el) el.addEventListener('click', () => {
        if (MIC.ativo || VOZ.aFalar) return;
        KIKO.reagir('happy');
        KIKO.dizer(U.pick(frasesToque()));
      });
    },
    estado(nome, ligado) {
      if (!el) return;
      el.classList.toggle(nome, !!ligado);
      if (nome === 'talking') { if (ligado) falarComecar(); else falarParar(); }
    },
    limpar() { if (el) ['listening', 'thinking', 'happy', 'sad'].forEach((c) => el.classList.remove(c)); },
    reagir(tipo, ms) {
      if (!el) return;
      clearTimeout(reacaoT);
      el.classList.remove('happy', 'sad');
      void el.offsetWidth;
      el.classList.add(tipo);
      reacaoT = setTimeout(() => el && el.classList.remove(tipo), ms || 1800);
    },
    /** Mostra no balão e diz em voz alta. Devolve uma promessa que termina quando acaba de falar. */
    dizer(texto, semVoz) {
      if (bolha) bolha.innerHTML = U.esc(texto);
      if (window.CONVERSA && U.$('#chat')) CONVERSA.registar('kiko', texto);
      return semVoz ? Promise.resolve() : VOZ.falar(texto);
    },
    balao(html) { if (bolha) bolha.innerHTML = html; }
  };
})();
