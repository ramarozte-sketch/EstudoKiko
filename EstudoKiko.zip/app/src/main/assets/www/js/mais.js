/* Mais atividades: relatório, fotografar e estudar, explica-me tu, ditado/leitura, placar da família */
(function () {
  'use strict';

  const topo = (t) => `<div class="topbar"><button class="iconbtn" data-voltar>←</button><h2>${U.esc(t)}</h2></div>`;
  const voltar = (r) => U.$$('[data-voltar]', r).forEach((b) => (b.onclick = () => APP.voltar()));

  let fotoAtual = null;
  NATIVO.on('foto', (d) => {
    if (U.$('#app').getAttribute('data-ecra') !== 'foto') return;
    if (!d.ok) { if (d.erro) toast(d.erro); return; }
    fotoAtual = d.base64;
    const prev = U.$('#fprev');
    if (prev) prev.innerHTML = `<img src="data:image/jpeg;base64,${d.base64}" style="max-width:100%;max-height:220px;border-radius:14px;box-shadow:0 4px 14px #0002">`;
    const btn = U.$('#fcriar');
    if (btn) btn.classList.remove('hidden');
  });

  // ================================================================== HUB
  ECRAS.mais = function (r) {
    r.innerHTML = topo('✨ Mais atividades') + `
      <div class="section jogos-lista">
        <button class="jogo" data-ir="relatorio" style="--jc:#4D96FF"><span class="je">📊</span><b>Relatório da semana</b><span>Vê e partilha o resumo do teu estudo.</span></button>
        <button class="jogo" data-ir="foto" style="--jc:#FF9F1C"><span class="je">📸</span><b>Fotografar e estudar</b><span>Fotografa o caderno e ${KIKO.o() === 'a' ? 'a' : 'o'} ${KIKO.nome()} cria-te um quiz.</span></button>
        <button class="jogo" data-ir="explicar" style="--jc:#2EC4A0"><span class="je">🗣️</span><b>Explica-me tu</b><span>Explica um tema em voz alta e recebe feedback.</span></button>
        <button class="jogo" data-ir="ditado" style="--jc:#9B5DE5"><span class="je">✍️</span><b>Ditado e leitura</b><span>Português, Inglês e Francês.</span></button>
        <button class="jogo" data-ir="placar" style="--jc:#F15BB5"><span class="je">🏆</span><b>Placar da família</b><span>Compara estrelas e desafia os teus irmãos.</span></button>
      </div>`;
    voltar(r); KIKO.ligar(r);
    U.$$('[data-ir]', r).forEach((b) => (b.onclick = () => APP.ir(b.dataset.ir)));
  };

  // ================================================================== RELATÓRIO
  ECRAS.relatorio = function (r) {
    const p = S.perfil();
    r.innerHTML = topo('📊 Relatório da semana') + `<div class="section">${RELATORIO.html(p)}</div>`;
    voltar(r); KIKO.ligar(r);
    U.$$('[data-partilha]', r).forEach((b) => (b.onclick = () => RELATORIO.partilhar(p)));
    // esta cópia do cartão é só informativa aqui: esconder as ações de gestão de perfil (são da Área dos pais)
    U.$$('[data-ano],[data-apaga]', r).forEach((b) => (b.style.display = 'none'));
  };

  // ================================================================== FOTOGRAFAR E ESTUDAR
  ECRAS.foto = function (r) {
    const p = S.perfil();
    if (NATIVO.ok && window.Android.isTv && window.Android.isTv()) {
      r.innerHTML = topo('📸 Fotografar e estudar') + `<div class="hero" style="padding-top:20px"><div class="bubble">Esta atividade precisa de uma câmara — usa o telemóvel ou tablet para fotografar o caderno. 📱</div>${KIKO.html('small')}</div>`;
      voltar(r); KIKO.ligar(r);
      return;
    }
    fotoAtual = null;
    r.innerHTML = topo('📸 Fotografar e estudar') + `
      <div class="section stack">
        <div class="card center stack">
          <div id="fprev" style="min-height:40px">${KIKO.html('small')}<p class="muted small" style="font-weight:700">Fotografa uma página do caderno, de uma ficha ou do manual. ${KIKO.oNome()} vai ler e criar um quiz sobre o que vê.</p></div>
          ${!IA.ativa() ? '<p class="small" style="font-weight:800;color:#B3262B">⚠️ Esta atividade precisa da IA ligada. Pede a um adulto para a ligar na Área dos pais.</p>' : ''}
          <div class="chips" id="fdisc">${CUR.disciplinas[p.ano].map((d) => `<button class="chip" data-d="${d.id}">${d.emo} ${U.esc(d.nome)}</button>`).join('')}</div>
          <div class="row" style="gap:8px"><button class="btn grow" id="fcam" ${NATIVO.ok ? '' : 'disabled'}>📷 Tirar foto</button><button class="btn sec grow" id="fgal" ${NATIVO.ok ? '' : 'disabled'}>🖼️ Da galeria</button></div>
          ${!NATIVO.ok ? '<p class="small muted" style="font-weight:700">Só funciona dentro da app instalada no telemóvel.</p>' : ''}
          <button class="btn purple hidden" id="fcriar" style="width:100%">✨ Criar quiz a partir da foto</button>
        </div>
      </div>`;
    voltar(r); KIKO.ligar(r);
    let dsel = CUR.disciplinas[p.ano][0].id;
    U.$$('#fdisc .chip', r).forEach((b, i) => { if (!i) b.classList.add('on'); b.onclick = () => { dsel = b.dataset.d; U.$$('#fdisc .chip', r).forEach((x) => x.classList.toggle('on', x === b)); }; });
    fotoAtual = null;
    U.$('#fcam').onclick = () => { toast('A abrir a câmara…'); window.Android.tirarFoto(); };
    U.$('#fgal').onclick = () => { toast('A abrir a galeria…'); window.Android.escolherFoto(); };
    U.$('#fcriar').onclick = () => { if (fotoAtual) QUIZ.iniciarIAFoto(dsel, fotoAtual); };
  };

  // ================================================================== EXPLICA-ME TU
  ECRAS.explicar = function (r, params) {
    const p = S.perfil();
    if (params && params.id) return mostrarTemaExplicar(r, CUR.temas[params.id]);
    r.innerHTML = topo('🗣️ Explica-me tu') + `
      <div class="section stack">
        <div class="card center stack">${KIKO.html('small')}<p class="muted small" style="font-weight:700">Escolhe um tema e explica-o em voz alta, com as tuas palavras. ${KIKO.oNome()} ouve e diz-te como foste.</p></div>
        ${CUR.disciplinas[p.ano].map((d) => `<details class="card"><summary style="font-weight:900;cursor:pointer">${d.emo} ${U.esc(d.nome)}</summary>
          <div class="chips" style="margin-top:8px">${(CUR.porAno[p.ano][d.id] || []).map((t) => `<button class="chip" data-t="${t.id}">${U.esc(t.t)}</button>`).join('')}</div></details>`).join('')}
      </div>`;
    voltar(r); KIKO.ligar(r);
    U.$$('[data-t]', r).forEach((b) => (b.onclick = () => APP.ir('explicar', { id: b.dataset.t })));
  };

  function mostrarTemaExplicar(r, t) {
    if (!t) return APP.voltar();
    r.innerHTML = topo('🗣️ Explica: ' + t.t) + `
      <div class="section stack">
        <div class="card center stack">${KIKO.html('small')}<div class="bubble" id="ebolha" style="margin:0">Explica-me o que sabes sobre "${U.esc(t.t)}", com as tuas palavras. Carrega no microfone quando estiveres pronto(a).</div>
        <button class="mic" id="emic" style="margin:10px auto">🎤</button>
        <p class="small muted" style="font-weight:700" id="estado">Toca no microfone e começa a falar. Toca outra vez para terminar.</p></div>
        <div class="card hidden" id="eresultado"></div>
      </div>`;
    voltar(r); KIKO.ligar(r);
    U.$('#emic').onclick = () => ouvirExplicacao(t);
  }

  function ouvirExplicacao(t) {
    const btn = U.$('#emic');
    if (MIC.ativo) { MIC.parar(); return; }
    btn.classList.add('on');
    U.$('#estado').textContent = 'A ouvir… fala com calma.';
    MIC.ouvir({
      nivel: (v) => btn.style.setProperty('--lvl', Math.round(v * 16) + 'px'),
      parcial: (txt) => U.$('#ebolha').innerHTML = '<span class="partial">' + U.esc(txt) + '…</span>',
      estado: (e) => { if (e === 'pensar') U.$('#estado').textContent = 'A pensar…'; },
      resultado: async (textos) => {
        btn.classList.remove('on');
        if (!textos.length) { U.$('#estado').textContent = 'Não ouvi nada. Tenta outra vez!'; return; }
        const transcricao = textos[0];
        U.$('#ebolha').textContent = '«' + transcricao + '»';
        await avaliarExplicacao(t, transcricao);
      },
      erro: (m) => { btn.classList.remove('on'); U.$('#estado').textContent = m; }
    });
  }

  async function avaliarExplicacao(t, transcricao) {
    const p = S.perfil();
    const box = U.$('#eresultado');
    box.classList.remove('hidden');
    if (IA.ativa()) {
      box.innerHTML = '<span class="spinner"></span>';
      try {
        const fb = await IA.avaliarExplicacao(p, t, transcricao);
        box.innerHTML = `<h3>💬 Feedback</h3><p style="font-weight:700;line-height:1.5">${U.esc(fb)}</p><button class="btn small" id="eouvir2">🔊 Ouvir</button><button class="btn sec small" id="enovamente">🎤 Explicar outra vez</button>`;
        VOZ.falar(fb);
        U.$('#eouvir2').onclick = () => VOZ.falar(fb);
        U.$('#enovamente').onclick = () => mostrarTemaExplicar(U.$('#app'), t);
        premiarAtividade(p, 3, 'por explicares ' + t.t);
      } catch (e) {
        box.innerHTML = '<p style="font-weight:700">' + U.esc(e.message) + '</p>';
      }
      return;
    }
    // sem IA: comparação local por palavras-chave dos pontos-chave do tema
    const norm = U.norm(transcricao);
    const chaves = (t.r || []).map((ponto) => ({ ponto, ok: (U.norm(ponto).split(' ').filter((w) => w.length > 3).some((w) => norm.indexOf(w) >= 0)) }));
    const certos = chaves.filter((c) => c.ok).length;
    const pct = chaves.length ? Math.round((100 * certos) / chaves.length) : 0;
    const msg = pct >= 70 ? 'Boa explicação! Falaste da maior parte do essencial. 🎉' : pct >= 40 ? 'Está no bom caminho! Ainda faltam algumas partes importantes.' : 'Ainda falta falar do essencial deste tema. Lê o resumo e tenta outra vez!';
    box.innerHTML = `<h3>💬 Como foste</h3><p style="font-weight:700">${msg}</p><div class="hbar"><span class="lbl">Cobriste</span><span class="tr"><i style="width:${pct}%;background:#2EC4A0"></i></span><span class="v">${pct}%</span></div>
      <button class="btn sec small" id="everresumo">📖 Ver resumo do tema</button><button class="btn small" id="enovamente">🎤 Explicar outra vez</button>`;
    VOZ.falar(msg);
    if (pct >= 70) { SOM.festa(); confettis(); }
    U.$('#everresumo').onclick = () => APP.ir('tema', { id: t.id });
    U.$('#enovamente').onclick = () => mostrarTemaExplicar(U.$('#app'), t);
    if (pct >= 70) premiarAtividade(S.perfil(), 2, 'por explicares ' + t.t);
  }

  function premiarAtividade(p, n, motivo) {
    p.estrelas += n; const d = S.dia(p); d.jogos = (d.jogos || 0) + 1; S.save();
    toast('⭐ +' + n + ' ' + motivo);
  }

  // ================================================================== DITADO E LEITURA
  const FRASES = {
    pt: {
      3: ['O gato dorme no sofá da sala.', 'Hoje faz sol e o céu está azul.', 'A Maria foi à praia com os pais.', 'O cão corre atrás da bola no jardim.', 'Nós gostamos muito de ler histórias.', 'A professora escreveu a lição no quadro.'],
      7: ['A revolução industrial mudou a forma como as pessoas trabalhavam.', 'Os rios de Portugal nascem, na sua maioria, em Espanha.', 'A fotossíntese permite que as plantas produzam o seu próprio alimento.', 'Dom Afonso Henriques tornou-se o primeiro rei de Portugal em 1139.', 'As equações do primeiro grau têm sempre uma incógnita.', 'O ecossistema depende do equilíbrio entre todos os seres vivos.']
    },
    ing: {
      3: ['The sun is shining today.', 'I have a small red ball.', 'My dog likes to play in the garden.', 'She is reading a book.', 'We go to school every day.'],
      7: ['Yesterday we visited an old castle near the river.', 'Scientists are studying how climate change affects the oceans.', 'She has been learning English for three years.', 'The students will present their project next Monday.']
    },
    fr: {
      3: ['Le chat dort sur le canapé.', "J'aime beaucoup les pommes.", 'Il fait beau aujourd\'hui.', 'Nous allons à l\'école le matin.'],
      7: ['La tour Eiffel se trouve à Paris, en France.', 'Les élèves étudient la grammaire française chaque semaine.', "Elle a visité le musée avec sa classe.", 'Le professeur explique la leçon avec patience.']
    }
  };
  const LINGUAS = { pt: { nome: 'Português', emo: '🇵🇹', voz: 'pt-PT' }, ing: { nome: 'Inglês', emo: '🇬🇧', voz: 'en-GB' }, fr: { nome: 'Francês', emo: '🇫🇷', voz: 'fr-FR' } };

  function nivelFrases(ano) { return ano <= 4 ? 3 : 7; }

  ECRAS.ditado = function (r, params) {
    const p = S.perfil();
    const lng = (params && params.lng) || 'pt';
    const modo = (params && params.modo) || 'ditado';
    r.innerHTML = topo('✍️ Ditado e leitura') + `
      <div class="section stack">
        <div class="chips" id="dlng">${Object.keys(LINGUAS).map((k) => `<button class="chip ${k === lng ? 'on' : ''}" data-l="${k}">${LINGUAS[k].emo} ${LINGUAS[k].nome}</button>`).join('')}</div>
        <div class="seg" id="dmodo"><button data-m="ditado" class="${modo === 'ditado' ? 'on' : ''}">✍️ Ditado (ouve e escreve)</button>${lng === 'pt' ? `<button data-m="leitura" class="${modo === 'leitura' ? 'on' : ''}">🎤 Leitura em voz alta</button>` : ''}</div>
        <div id="dcorpo"></div>
      </div>`;
    voltar(r); KIKO.ligar(r);
    U.$$('#dlng .chip', r).forEach((b) => (b.onclick = () => APP.ir('ditado', { lng: b.dataset.l, modo: b.dataset.l === lng ? modo : 'ditado' }, true)));
    U.$$('#dmodo button', r).forEach((b) => (b.onclick = () => APP.ir('ditado', { lng, modo: b.dataset.m }, true)));
    if (modo === 'ditado') corpoDitado(p, lng); else corpoLeitura(p);
  };

  function escolherFrase(p, lng) {
    const banco = (FRASES[lng] || FRASES.pt)[nivelFrases(p.ano)] || FRASES.pt[3];
    return U.pick(banco);
  }

  function diffPalavras(certo, escrito) {
    const a = U.norm(certo).split(' ').filter(Boolean);
    const b = U.norm(escrito).split(' ').filter(Boolean);
    let acertos = 0;
    a.forEach((w, i) => { if (b[i] === w) acertos++; });
    return Math.round((100 * acertos) / Math.max(1, a.length));
  }

  function corpoDitado(p, lng) {
    const frase = escolherFrase(p, lng);
    const box = U.$('#dcorpo');
    box.innerHTML = `<div class="card center stack">${KIKO.html('small')}
      <p class="muted small" style="font-weight:700">Ouve a frase e escreve-a tal como a ouves.</p>
      <button class="btn" id="dler">🔊 Ouvir a frase</button>
      <textarea class="input" id="dresp" rows="2" placeholder="Escreve aqui o que ouviste…"></textarea>
      <button class="btn purple" id="dverif">Verificar</button>
      <div id="dfb"></div></div>`;
    const ler = () => VOZ.falar(frase, lng === 'pt' ? undefined : LINGUAS[lng].voz);
    U.$('#dler').onclick = ler;
    setTimeout(ler, 400);
    U.$('#dverif').onclick = () => {
      const pct = diffPalavras(frase, U.$('#dresp').value);
      const fb = U.$('#dfb');
      fb.innerHTML = `<div class="hbar"><span class="lbl">Acertaste</span><span class="tr"><i style="width:${pct}%;background:${pct >= 80 ? '#2EC4A0' : pct >= 50 ? '#FF9F1C' : '#B3262B'}"></i></span><span class="v">${pct}%</span></div>
        <p class="small" style="font-weight:800">Frase correta: "${U.esc(frase)}"</p>
        <div class="row" style="gap:8px"><button class="btn sec small grow" id="doutra">➜ Outra frase</button></div>`;
      if (pct >= 80) { SOM.certo(); confettis(); premiarAtividade(p, 2, 'no ditado'); } else SOM.errado();
      U.$('#doutra').onclick = () => corpoDitado(p, lng);
    };
  }

  function corpoLeitura(p) {
    const frase = escolherFrase(p, 'pt');
    const box = U.$('#dcorpo');
    box.innerHTML = `<div class="card center stack">${KIKO.html('small')}
      <p class="muted small" style="font-weight:700">Lê esta frase em voz alta, com calma e boa pronúncia:</p>
      <p style="font-weight:900;font-size:18px;text-align:center">"${U.esc(frase)}"</p>
      <button class="mic" id="lmic">🎤</button>
      <p class="small muted" style="font-weight:700" id="lestado">Toca no microfone e lê a frase.</p>
      <div id="lfb"></div></div>`;
    U.$('#lmic').onclick = () => {
      const btn = U.$('#lmic');
      if (MIC.ativo) { MIC.parar(); return; }
      btn.classList.add('on'); U.$('#lestado').textContent = 'A ouvir…';
      MIC.ouvir({
        nivel: (v) => btn.style.setProperty('--lvl', Math.round(v * 16) + 'px'),
        estado: (e) => { if (e === 'pensar') U.$('#lestado').textContent = 'A verificar…'; },
        resultado: (textos) => {
          btn.classList.remove('on');
          if (!textos.length) { U.$('#lestado').textContent = 'Não ouvi nada. Tenta outra vez!'; return; }
          const pct = diffPalavras(frase, textos[0]);
          U.$('#lfb').innerHTML = `<div class="hbar"><span class="lbl">Fluência</span><span class="tr"><i style="width:${pct}%;background:${pct >= 80 ? '#2EC4A0' : pct >= 50 ? '#FF9F1C' : '#B3262B'}"></i></span><span class="v">${pct}%</span></div>
            <div class="row" style="gap:8px"><button class="btn sec small grow" id="loutra">➜ Outra frase</button></div>`;
          if (pct >= 75) { SOM.certo(); confettis(); premiarAtividade(p, 2, 'na leitura'); } else { SOM.errado(); U.$('#lestado').textContent = 'Lê de novo, com calma.'; }
          U.$('#loutra').onclick = () => corpoLeitura(p);
        },
        erro: (m) => { btn.classList.remove('on'); U.$('#lestado').textContent = m; }
      });
    };
  }

  // ================================================================== PLACAR DA FAMÍLIA + DUELO
  function pontosSemana(p) {
    let r = 0, c = 0;
    for (let i = 0; i < 7; i++) { const d = p.dias[U.addDays(U.today(), -i)]; if (d) { r += d.r || 0; c += d.c || 0; } }
    return { r, c };
  }

  ECRAS.placar = function (r) {
    const ps = S.data.perfis;
    const ranking = ps.map((p) => Object.assign({ p }, pontosSemana(p))).sort((a, b) => b.c - a.c);
    r.innerHTML = topo('🏆 Placar da família') + `
      <div class="section stack">
        <div class="card stack">
          ${ranking.length < 1 ? '<p class="muted" style="font-weight:700">Ainda não há dados esta semana.</p>' : ranking.map((x, i) => `
          <div class="row" style="align-items:center;gap:10px">
            <span style="font-size:22px;width:28px;text-align:center">${['🥇', '🥈', '🥉'][i] || (i + 1) + 'º'}</span>
            <div class="avatar" style="width:40px;height:40px;font-size:18px;background:${x.p.cor}">${x.p.emo}</div>
            <div class="grow"><b>${U.esc(x.p.nome)}</b><div class="small muted" style="font-weight:800">${x.r} perguntas · ${x.r ? Math.round(100 * x.c / x.r) : 0}% certas</div></div>
            <span class="pill">⭐ ${x.c}</span>
          </div>`).join('')}
        </div>
        ${ps.length >= 2 ? '<button class="btn purple" id="pduelo">⚔️ Desafio entre irmãos</button>' : '<p class="small muted" style="font-weight:700">Cria mais um perfil para desafiares um irmão ou irmã.</p>'}
      </div>`;
    voltar(r); KIKO.ligar(r);
    if (U.$('#pduelo')) U.$('#pduelo').onclick = () => APP.ir('duelo');
    setTimeout(() => { if (ranking.length) KIKO.dizer(ranking[0].c > 0 ? U.esc(ranking[0].p.nome) + ' está na frente esta semana! Quem o(a) consegue alcançar?' : 'Vamos estudar para apareceres no placar!'); }, 400);
  };

  ECRAS.duelo = function (r, params) {
    const ps = S.data.perfis;
    if (ps.length < 2) return APP.ir('placar');
    if (params && params.a && params.b) return jogarDuelo(r, params.a, params.b);
    r.innerHTML = topo('⚔️ Desafio entre irmãos') + `
      <div class="section stack"><div class="card center stack">${KIKO.html('small')}
        <p class="muted small" style="font-weight:700">Escolhe os dois jogadores. Cada um responde a 5 perguntas do seu ano — quem acertar mais, ganha!</p>
        <div class="field"><label>Jogador 1</label><div class="chips" id="dua">${ps.map((p) => `<button class="chip" data-p="${p.id}">${p.emo} ${U.esc(p.nome)}</button>`).join('')}</div></div>
        <div class="field"><label>Jogador 2</label><div class="chips" id="dub">${ps.map((p) => `<button class="chip" data-p="${p.id}">${p.emo} ${U.esc(p.nome)}</button>`).join('')}</div></div>
        <button class="btn purple" id="dustart" disabled>Começar o duelo!</button>
      </div></div>`;
    voltar(r); KIKO.ligar(r);
    let a = null, b = null;
    const atualizar = () => { U.$('#dustart').disabled = !(a && b && a !== b); };
    U.$$('#dua .chip', r).forEach((btn) => (btn.onclick = () => { a = btn.dataset.p; U.$$('#dua .chip', r).forEach((x) => x.classList.toggle('on', x === btn)); atualizar(); }));
    U.$$('#dub .chip', r).forEach((btn) => (btn.onclick = () => { b = btn.dataset.p; U.$$('#dub .chip', r).forEach((x) => x.classList.toggle('on', x === btn)); atualizar(); }));
    U.$('#dustart').onclick = () => { if (a === b) return toast('Escolhe dois jogadores diferentes.'); APP.ir('duelo', { a, b }, true); };
  };

  function bancoDuelo(p) {
    const out = [];
    (CUR.disciplinas[p.ano] || []).forEach((d) => (CUR.porAno[p.ano][d.id] || []).forEach((t) => (t.q || []).forEach((raw) => out.push(QUIZ.daTabela(t, raw)))));
    return U.shuffle(out).slice(0, 5);
  }

  function jogarDuelo(r, idA, idB) {
    const pa = S.data.perfis.find((p) => p.id === idA), pb = S.data.perfis.find((p) => p.id === idB);
    if (!pa || !pb) return APP.ir('placar');
    const estado = { vez: 0, pontos: { a: 0, b: 0 }, qa: bancoDuelo(pa), qb: bancoDuelo(pb), ronda: 0, total: 5 };
    function opcoes(q) { return U.shuffle([q.certa].concat(U.shuffle(q.erradas).slice(0, 3))); }
    function render() {
      if (estado.ronda >= estado.total) return terminarDuelo(r, pa, pb, estado);
      const vezA = estado.vez === 0;
      const jogador = vezA ? pa : pb;
      const q = (vezA ? estado.qa : estado.qb)[estado.ronda] || (vezA ? estado.qa : estado.qb)[0];
      const ops = opcoes(q);
      r.innerHTML = topo('⚔️ Duelo: ronda ' + (estado.ronda + 1) + '/' + estado.total) + `
        <div class="section stack">
          <div class="row" style="justify-content:center;gap:18px"><span class="pill">${pa.emo} ${estado.pontos.a}</span><span class="pill">${pb.emo} ${estado.pontos.b}</span></div>
          <div class="card center stack"><div class="avatar" style="width:48px;height:48px;font-size:22px;background:${jogador.cor}">${jogador.emo}</div>
            <h3>Vez de ${U.esc(jogador.nome)}!</h3>
            <p style="font-weight:800">${U.esc(q.p)}</p>
            <div class="opts">${ops.map((o, i) => `<button class="opt" data-i="${i}"><span>${U.esc(o)}</span></button>`).join('')}</div>
          </div>
        </div>`;
      voltar(r); KIKO.ligar(r);
      U.$$('.opt', r).forEach((b, i) => (b.onclick = () => {
        const certo = ops[+b.dataset.i] === q.certa;
        if (certo) { estado.pontos[vezA ? 'a' : 'b']++; SOM.certo(); } else SOM.errado();
        toast(certo ? '✅ ' + jogador.nome + ' acertou!' : '❌ Era: ' + q.certa);
        estado.vez = vezA ? 1 : 0;
        if (!vezA) estado.ronda++;
        setTimeout(render, 900);
      }));
    }
    render();
  }

  function terminarDuelo(r, pa, pb, estado) {
    const empate = estado.pontos.a === estado.pontos.b;
    const venceu = estado.pontos.a > estado.pontos.b ? pa : pb;
    r.innerHTML = topo('⚔️ Resultado do duelo') + `
      <div class="section"><div class="card center stack">
        <div style="font-size:48px">${empate ? '🤝' : '🏆'}</div>
        <h2>${empate ? 'Empate! Os dois jogaram muito bem.' : U.esc(venceu.nome) + ' venceu o duelo!'}</h2>
        <div class="row" style="justify-content:center;gap:18px"><span class="pill">${pa.emo} ${pa.nome}: ${estado.pontos.a}</span><span class="pill">${pb.emo} ${pb.nome}: ${estado.pontos.b}</span></div>
        <button class="btn" id="dfim">Terminar</button>
      </div></div>`;
    KIKO.ligar(r);
    confettis(); SOM.festa();
    pa.estrelas += empate ? 2 : (venceu === pa ? 4 : 1); pb.estrelas += empate ? 2 : (venceu === pb ? 4 : 1); S.save();
    U.$('#dfim').onclick = () => APP.ir('placar');
  }
})();
