/* Quizzes: perguntas do banco, geradas por exercícios, revisão de erros, modo teste e perguntas da IA */
(function () {
  'use strict';

  const Q = (window.QUIZ = {});
  let sess = null;
  const LETRAS = ['A', 'B', 'C', 'D', 'E'];

  // ------------------------------------------------------------ construção de perguntas
  Q.daTabela = function (tema, raw) {
    let certa, erradas, tf = false;
    if (typeof raw[1] === 'boolean') { tf = true; certa = raw[1] ? 'Verdadeiro' : 'Falso'; erradas = [raw[1] ? 'Falso' : 'Verdadeiro']; }
    else { certa = raw[1][0]; erradas = raw[1].slice(1); }
    return { p: raw[0], certa: String(certa), erradas: erradas.map(String), exp: raw[2] || '', tema: tema.id, tf };
  };
  function chave(q) { return q.tema + '|' + U.hash(q.p + '#' + q.certa); }
  function opcoes(q) {
    if (q.tf) return ['Verdadeiro', 'Falso'];
    return U.shuffle([q.certa].concat(U.shuffle(q.erradas).slice(0, 3)));
  }

  function perguntasTema(t, n) {
    let lista = U.shuffle((t.q || []).map((raw) => Q.daTabela(t, raw)));
    if (t.gen && window.GERADORES && GERADORES[t.gen]) {
      const g = GERADORES[t.gen](Math.max(4, n - lista.length + 3)).map((q) => Object.assign(q, { tema: t.id }));
      // mistura: até metade geradas, ou mais se faltarem perguntas fixas
      const nG = Math.max(Math.ceil(n / 2) - 1, n - lista.length);
      lista = U.shuffle(lista.slice(0, n - Math.min(nG, g.length)).concat(g.slice(0, nG)));
    }
    return lista.slice(0, n);
  }

  // ------------------------------------------------------------ inícios
  Q.iniciarTema = function (temaId, n) {
    const t = CUR.temas[temaId];
    if (!t) return;
    const lista = perguntasTema(t, n || 10);
    if (!lista.length) {
      if (IA.ativa()) return Q.iniciarIA(t.disc, t.t, t);
      return toast('Este tema ainda não tem perguntas.');
    }
    iniciar({ modo: 'tema', titulo: t.t, temaId: t.id, perguntas: lista });
  };

  Q.iniciarSurpresa = function (disc) {
    const p = S.perfil();
    const temas = [];
    (CUR.disciplinas[p.ano] || []).forEach((d) => {
      if (disc && d.id !== disc) return;
      (CUR.porAno[p.ano][d.id] || []).forEach((t) => temas.push(t));
    });
    // dá prioridade a temas com menos domínio
    const pesados = [];
    temas.forEach((t) => { const nv = S.nivelTema(p, t.id); const w = nv < 0 ? 2 : nv < 70 ? 3 : 1; for (let i = 0; i < w; i++) pesados.push(t); });
    const usados = new Set(), lista = [];
    let guarda = 0;
    while (lista.length < 10 && guarda++ < 200) {
      const t = U.pick(pesados);
      const q = perguntasTema(t, 3).find((x) => !usados.has(x.p));
      if (q) { usados.add(q.p); lista.push(q); }
    }
    iniciar({ modo: 'surpresa', titulo: disc ? 'Quiz surpresa' : 'Quiz surpresa (tudo)', perguntas: lista });
  };

  Q.errosPendentes = function (p) {
    const hoje = U.today();
    return Object.keys(p.erros).filter((k) => p.erros[k].prox <= hoje);
  };
  Q.iniciarErros = function () {
    const p = S.perfil();
    const ks = U.shuffle(Q.errosPendentes(p)).slice(0, 10);
    if (!ks.length) return toast('Não há erros para rever hoje 🎉');
    const lista = ks.map((k) => Object.assign({}, p.erros[k].q, { tema: p.erros[k].tema, revisao: k }));
    iniciar({ modo: 'erros', titulo: 'Corrigir erros', perguntas: lista });
  };

  Q.iniciarTeste = function (teste, exame) {
    const temas = (teste.temas || []).map((id) => CUR.temas[id]).filter(Boolean);
    if (!temas.length) return toast('Escolhe pelo menos um tema.');
    const p = S.perfil();
    const n = exame ? 20 : 12, lista = [], usados = new Set();
    let guarda = 0;
    // mais peso aos temas mais fracos
    const pesados = [];
    temas.forEach((t) => { const nv = S.nivelTema(p, t.id); const w = nv < 0 || nv < 60 ? 3 : nv < 85 ? 2 : 1; for (let i = 0; i < w; i++) pesados.push(t); });
    while (lista.length < n && guarda++ < 400) {
      const t = U.pick(pesados);
      const q = perguntasTema(t, 4).find((x) => !usados.has(x.p));
      if (q) { usados.add(q.p); lista.push(q); }
    }
    const dn = (CUR.disciplinas[p.ano].find((d) => d.id === teste.disc) || {}).nome || '';
    iniciar({ modo: exame ? 'exame' : 'teste', titulo: (exame ? 'Simulação de teste' : 'Treino') + ' · ' + dn, perguntas: lista, exame: !!exame, limite: exame ? lista.length * 60 : 0 });
  };

  Q.iniciarIA = async function (disc, titulo, tema) {
    const p = S.perfil();
    if (!IA.ativa()) return toast('Pede a um adulto para ligar a IA na Área dos pais.');
    const pedido = tema ? titulo : U.limparTema(titulo);   // texto completo, limpo, para a IA
    let curto = tema ? tema.t : U.tituloCurto(titulo);      // o que aparece no ecrã
    APP.carregar(KIKO.ONome() + ' está a preparar perguntas sobre ' + curto + '…');
    try {
      const lista = await IA.criarQuiz(p, disc, pedido, tema, 8);
      if (!tema && lista.titulo) curto = lista.titulo;
      lista.forEach((q) => { q.tema = tema ? tema.id : ('ia:' + disc + ':' + curto); });
      iniciar({ modo: 'ia', titulo: curto, pedido: pedido, temaId: tema ? tema.id : null, perguntas: lista, disc });
    } catch (e) {
      toast(e.message);
      APP.voltar();
    }
  };

  function iniciar(o) {
    sess = Object.assign({ i: 0, certas: 0, respostas: [], inicio: Date.now(), ganhas: 0 }, o);
    sess.perguntas.forEach((q) => { q.ops = opcoes(q); });
    APP.ir('quiz', {}, true);
  }

  // ------------------------------------------------------------ ecrã
  Q.render = function (raiz) {
    if (!sess) return APP.ir('inicio');
    const q = sess.perguntas[sess.i];
    const p = S.perfil();
    const tema = CUR.temas[q.tema];
    raiz.innerHTML = `
      <div class="qhead">
        <button class="iconbtn" id="qx">✕</button>
        <div class="qprog"><i style="width:${(100 * sess.i) / sess.perguntas.length}%"></i></div>
        ${sess.exame ? `<span class="pill timer" id="qtimer">⏱️ --:--</span>` : `<span class="pill">⭐ ${S.saldo(p)}</span>`}
      </div>
      <div class="row" style="padding:4px 16px 0">
        ${KIKO.html('mini', p.veste)}
        <div class="bubble grow" id="bolha" style="margin:0;text-align:left;font-size:15px">${sess.i + 1} de ${sess.perguntas.length}${sess.modo === 'erros' ? ' · revisão' : ''}</div>
      </div>
      <div class="qcard fade-in">
        <div class="qtopic">${U.esc(tema ? tema.t : U.tituloCurto(sess.titulo, 60))}</div>
        <div class="qtext">${U.esc(q.p)}</div>
      </div>
      <div class="opts" id="opts">
        ${q.ops.map((o, i) => `<button class="opt" data-i="${i}"><span class="l">${q.tf ? (i ? '✗' : '✓') : LETRAS[i]}</span><span>${U.esc(o)}</span></button>`).join('')}
      </div>
      <div id="fb"></div>
      <div class="row" style="padding:10px 16px;justify-content:center;gap:14px" id="qtools">
        <button class="btn sec small" id="qler">🔊 Ouvir</button>
        <button class="mic smallmic" id="qmic">🎤</button>
        <button class="btn sec small" id="qpista">💡 Pista</button>
      </div>`;
    KIKO.ligar(raiz);
    U.$('#qx').onclick = () => sair();
    U.$$('.opt', raiz).forEach((b) => (b.onclick = () => responder(+b.dataset.i)));
    U.$('#qler').onclick = () => lerPergunta();
    U.$('#qmic').onclick = () => ouvirResposta();
    U.$('#qpista').onclick = () => pista();
    if (sess.exame) relogio();
    if (S.cfg().lerAuto && !sess.exame) setTimeout(lerPergunta, 250);
  };

  function lerPergunta() {
    const q = sess && sess.perguntas && sess.perguntas[sess.i];
    if (!q) return;
    const txt = U.mathForSpeech(q.p) + '. ' + q.ops.map((o, i) => (q.tf ? '' : LETRAS[i] + ': ') + U.mathForSpeech(o)).join('. ');
    VOZ.falar(txt);
  }

  function pista() {
    const q = sess.perguntas[sess.i];
    if (q.tf) return KIKO.dizer('Pensa bem: há alguma palavra na frase que a torna falsa?');
    // elimina uma opção errada
    const btns = U.$$('.opt');
    const erradas = btns.filter((b) => q.ops[+b.dataset.i] !== q.certa && !b.disabled && b.style.opacity !== '0.3');
    if (erradas.length > 1) {
      const b = U.pick(erradas); b.style.opacity = '0.3'; b.disabled = true;
      KIKO.dizer('Tirei uma opção errada. Agora é contigo!');
      sess.pistas = (sess.pistas || 0) + 1;
    } else KIKO.dizer('Já não posso ajudar mais. Confia em ti!');
  }

  function ouvirResposta() {
    const btn = U.$('#qmic');
    btn.classList.add('on');
    KIKO.estado('listening', true);
    KIKO.balao('A ouvir… diz a letra ou a resposta');
    MIC.ouvir({
      nivel: (v) => btn.style.setProperty('--lvl', Math.round(v * 14) + 'px'),
      parcial: (t) => KIKO.balao('<span class="partial">' + U.esc(t) + '</span>'),
      resultado: (textos) => {
        btn.classList.remove('on'); KIKO.estado('listening', false);
        const i = interpretar(textos);
        if (i < 0) { KIKO.dizer('Não percebi qual escolheste. Diz a letra, por exemplo "B".'); return; }
        responder(i);
      },
      erro: (m) => { btn.classList.remove('on'); KIKO.estado('listening', false); KIKO.dizer(m); }
    });
  }

  function interpretar(textos) {
    const q = sess.perguntas[sess.i];
    const ops = q.ops.map(U.norm);
    for (const bruto of textos) {
      const t = U.norm(bruto);
      if (q.tf) {
        if (/\b(verdadeiro|verdadeira|verdade|certo|sim|v)\b/.test(t)) return 0;
        if (/\b(falso|falsa|mentira|errado|nao|f)\b/.test(t)) return 1;
      }
      const m = t.match(/^(?:(?:e |a )?(?:letra|opcao|alinea|resposta)\s+)?([abcd])$/) || t.match(/\b(?:letra|opcao|alinea|resposta)\s+([abcd])\b/);
      if (m) return 'abcd'.indexOf(m[1]);
      const ord = [/\b(primeira|primeiro|um|1)\b$/, /\b(segunda|segundo|dois|2)\b$/, /\b(terceira|terceiro|tres|3)\b$/, /\b(quarta|quarto|quatro|4)\b$/];
      // texto da opção
      let melhor = -1, pont = 0;
      ops.forEach((o, i) => {
        if (!o) return;
        let s = 0;
        if (t === o) s = 100;
        else if (t.indexOf(o) >= 0 && o.length >= 2) s = 50 + o.length;
        else if (o.indexOf(t) >= 0 && t.length >= 3) s = 30 + t.length;
        else {
          const ws = t.split(' ').filter((w) => w.length > 3);
          s = ws.filter((w) => o.indexOf(w) >= 0).length * 5;
        }
        // números: "12,5" vs "12.5" e "doze" já vem como dígitos na maioria dos telemóveis
        const nT = (t.match(/-?\d+(?:[.,]\d+)?/g) || []).join(' '), nO = (o.match(/-?\d+(?:[.,]\d+)?/g) || []).join(' ');
        if (nT && nO && nT.replace(',', '.') === nO.replace(',', '.')) s = Math.max(s, 60);
        if (s > pont) { pont = s; melhor = i; }
      });
      if (pont >= 10) return melhor;
      for (let k = 0; k < ord.length && k < q.ops.length; k++) if (ord[k].test(t) && t.split(' ').length <= 3) return k;
    }
    return -1;
  }

  function responder(i) {
    const q = sess.perguntas[sess.i];
    if (q.respondida) return;
    q.respondida = true;
    MIC.parar();
    const certa = q.ops[i] === q.certa;
    sess.respostas.push({ q, escolha: q.ops[i], certa });
    registar(q, certa);
    const btns = U.$$('.opt');
    btns.forEach((b) => (b.disabled = true));
    if (sess.exame) {
      btns[i].classList.add('chosen');
      SOM.clique();
      setTimeout(seguinte, 450);
      return;
    }
    if (certa) {
      sess.certas++;
      btns[i].classList.add('right');
      SOM.certo(); KIKO.reagir('happy', 1200);
    } else {
      btns[i].classList.add('wrong');
      btns[q.ops.indexOf(q.certa)].classList.add('right');
      SOM.errado(); KIKO.reagir('sad', 1600);
    }
    const elogio = U.pick(['Muito bem!', 'Boa!', 'Excelente!', 'Isso mesmo!', 'Fantástico!', 'Acertaste!']);
    const anima = U.pick(['Quase!', 'Não faz mal, aprendemos com os erros.', 'Ups! Vamos ver porquê.', 'Ainda não, mas vais lá chegar!']);
    const fala = certa ? elogio + (q.exp && S.perfil().ano === 4 ? '' : '') : anima + ' A resposta certa é: ' + q.certa + '.';
    U.$('#fb').innerHTML = `
      <div class="feedback ${certa ? 'ok' : 'bad'} fade-in">${certa ? '✅ ' + elogio : '❌ ' + U.esc(anima) + '<br>Certa: <b>' + U.esc(q.certa) + '</b>'}
      ${q.exp ? '<div style="margin-top:6px;font-weight:700">💡 ' + U.esc(q.exp) + '</div>' : ''}</div>
      <div style="padding:0 16px"><button class="btn ${certa ? 'ok' : ''}" id="qnext">${sess.i + 1 < sess.perguntas.length ? 'Continuar ➜' : 'Ver resultado 🏁'}</button></div>`;
    U.$('#qtools').classList.add('hidden');
    U.$('#qnext').onclick = seguinte;
    if (window.TV && TV.ativo) U.$('#qnext').focus();
    U.$('#bolha').textContent = certa ? elogio + ' ⭐' : anima;
    VOZ.falar(U.mathForSpeech(fala + (q.exp && !certa ? ' ' + q.exp : '')));
    U.$('#qnext').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function seguinte() {
    VOZ.parar();
    sess.i++;
    if (sess.i >= sess.perguntas.length) return terminar();
    Q.render(U.$('#app'));
    U.$('#app').scrollTop = 0;
  }

  let relT = null;
  function relogio() {
    clearInterval(relT);
    const el = U.$('#qtimer');
    const tic = () => {
      if (!sess || !document.body.contains(el)) return clearInterval(relT);
      const rest = Math.max(0, sess.limite - Math.round((Date.now() - sess.inicio) / 1000));
      el.textContent = '⏱️ ' + Math.floor(rest / 60) + ':' + String(rest % 60).padStart(2, '0');
      if (rest <= 0) { clearInterval(relT); toast('Acabou o tempo!'); while (sess.i < sess.perguntas.length) { sess.perguntas[sess.i].respondida = true; sess.i++; } terminar(); }
    };
    tic(); relT = setInterval(tic, 1000);
  }

  // ------------------------------------------------------------ progresso
  function registar(q, certa) {
    const p = S.perfil();
    const d = S.dia(p);
    d.r++; if (certa) d.c++;
    if (q.tema && CUR.temas[q.tema]) {
      const m = (p.dominio[q.tema] = p.dominio[q.tema] || { n: 0, c: 0, ult: [], data: '' });
      m.n++; if (certa) m.c++;
      m.ult.push(certa ? 1 : 0); if (m.ult.length > 10) m.ult.shift();
      m.data = U.today();
    }
    if (certa) { p.estrelas++; sess.ganhas++; }
    const k = q.revisao || chave(q);
    if (q.revisao) {
      const e = p.erros[k];
      if (e) {
        if (certa) { e.vezes--; e.prox = U.addDays(U.today(), 2); if (e.vezes <= 0) { delete p.erros[k]; p.corrigidos = (p.corrigidos || 0) + 1; } }
        else { e.vezes = 2; e.prox = U.addDays(U.today(), 1); }
      }
    } else if (!certa) {
      p.erros[k] = { tema: q.tema, q: { p: q.p, certa: q.certa, erradas: q.erradas, exp: q.exp, tf: q.tf }, vezes: 2, prox: U.today() };
    } else if (p.erros[k]) {
      p.erros[k].vezes--; if (p.erros[k].vezes <= 0) { delete p.erros[k]; p.corrigidos = (p.corrigidos || 0) + 1; }
    }
    // meta diária
    if (d.r === S.cfg().meta) { p.estrelas += 5; sess.ganhas += 5; setTimeout(() => toast('🎯 Meta do dia cumprida! +5 ⭐'), 600); }
    S.save();
  }

  function terminar() {
    clearInterval(relT);
    const p = S.perfil();
    const n = sess.respostas.length, c = sess.respostas.filter((r) => r.certa).length;
    sess.certas = c;
    if (n && c === n && n >= 5) { p.estrelas += 3; sess.ganhas += 3; }
    p.historico.push({ data: U.today(), tema: sess.temaId || null, titulo: sess.titulo, c, n, modo: sess.modo });
    if (p.historico.length > 300) p.historico.splice(0, p.historico.length - 300);
    S.save();
    const novas = APP.verMedalhas(p);
    APP.ir('resultado', { novas }, true);
  }

  Q.renderResultado = function (raiz, params) {
    const p = S.perfil();
    const n = sess.respostas.length || sess.perguntas.length, c = sess.certas;
    const pct = n ? Math.round((100 * c) / n) : 0;
    const est = pct >= 90 ? 3 : pct >= 70 ? 2 : pct >= 40 ? 1 : 0;
    const msg = pct === 100 ? 'Perfeito! Acertaste tudo!' : pct >= 80 ? 'Muito bem! Estás quase a dominar isto.' : pct >= 50 ? 'Bom trabalho! Com mais um treino ficas craque.' : 'Não desistas! Vamos rever e tentar outra vez.';
    raiz.innerHTML = `
      <div class="topbar"><button class="iconbtn" id="rx">✕</button><h2>${U.esc(sess.titulo)}</h2></div>
      <div class="hero"><div class="bubble" id="bolha">${U.esc(msg)}</div>${KIKO.html('', p.veste)}</div>
      <div class="result-big">${c}/${n}</div>
      <div class="center stars" style="font-size:34px">${'★'.repeat(est)}<span class="off">${'★'.repeat(3 - est)}</span></div>
      <p class="center" style="font-weight:900;margin:6px 0 4px">+${sess.ganhas} ⭐ ganhas</p>
      ${(params.novas || []).map((m) => `<div class="section"><div class="banner" style="background:var(--purple)"><span class="big">${m.e}</span><span>Nova medalha: ${U.esc(m.n)}!</span></div></div>`).join('')}
      <div class="section stack">
        ${sess.exame || sess.respostas.some((r) => !r.certa) ? '<button class="btn sec" id="rrev">📝 Ver as respostas</button>' : ''}
        <button class="btn" id="rdenovo">🔁 Outra vez</button>
        ${IA.ativa() && (sess.temaId || sess.disc) ? '<button class="btn purple" id="ria">✨ Perguntas novas (IA)</button>' : ''}
        <button class="btn sec" id="rvolta">Voltar</button>
      </div>
      <div id="rlista" class="section"></div>`;
    KIKO.ligar(raiz);
    const ganhas = sess.ganhas;
    setTimeout(() => { if (U.$('#app').getAttribute('data-ecra') !== 'resultado') return; if (pct >= 70) { KIKO.reagir('happy', 2500); confettis(); SOM.festa(); } else KIKO.reagir('sad', 1500); KIKO.dizer(msg + ' Ganhaste ' + ganhas + ' estrelas.'); }, 300);
    U.$('#rx').onclick = U.$('#rvolta').onclick = () => { sess = null; APP.voltar(); };
    U.$('#rdenovo').onclick = () => {
      const s = sess;
      if (s.modo === 'tema') Q.iniciarTema(s.temaId);
      else if (s.modo === 'erros') Q.iniciarErros();
      else if (s.modo === 'ia') { const t = CUR.temas[s.temaId]; Q.iniciarIA(t ? t.disc : s.disc, s.pedido || s.titulo, t); }
      else if (s.modo === 'teste' || s.modo === 'exame') { const t = APP._testeAtual; if (t) Q.iniciarTeste(t, s.modo === 'exame'); }
      else Q.iniciarSurpresa();
    };
    const ria = U.$('#ria');
    if (ria) ria.onclick = () => { const t = CUR.temas[sess.temaId]; Q.iniciarIA(t ? t.disc : sess.disc, t ? t.t : (sess.pedido || sess.titulo), t); };
    const rrev = U.$('#rrev');
    if (rrev) rrev.onclick = () => {
      rrev.remove();
      U.$('#rlista').innerHTML = '<div class="stack">' + sess.respostas.map((r, i) => `
        <div class="card tight"><div style="font-weight:900">${i + 1}. ${U.esc(r.q.p)}</div>
        <div style="margin-top:6px;font-weight:800;color:${r.certa ? '#137A62' : '#B3262B'}">${r.certa ? '✅' : '❌'} ${U.esc(r.escolha)}</div>
        ${r.certa ? '' : `<div style="font-weight:800;color:#137A62">✔ ${U.esc(r.q.certa)}</div>`}
        ${r.q.exp ? `<div class="small muted" style="margin-top:4px;font-weight:700">💡 ${U.esc(r.q.exp)}</div>` : ''}</div>`).join('') + '</div>';
    };
  };

  function sair() {
    if (sess && sess.respostas.length && sess.i < sess.perguntas.length) {
      MODAL.abrir(`<h2>Sair do quiz?</h2><p class="muted" style="margin:8px 0 16px;font-weight:700">As respostas que já deste ficam guardadas.</p>
        <div class="stack"><button class="btn" id="mfica">Continuar a jogar</button><button class="btn sec" id="msai">Sair</button></div>`, (m) => {
        U.$('#mfica', m).onclick = MODAL.fechar;
        U.$('#msai', m).onclick = () => { MODAL.fechar(); VOZ.parar(); MIC.parar(); sess = null; APP.voltar(); };
      });
    } else { VOZ.parar(); MIC.parar(); sess = null; APP.voltar(); }
  }
  Q.sair = sair;
  Q.ativo = () => !!sess;
})();
