package pt.rui.estudokiko

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.UiModeManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Atividade única: a interface (mascote, quizzes, conteúdos) vive em assets/www
 * e esta classe fornece-lhe as capacidades nativas: reconhecimento de voz em
 * português de Portugal, leitura em voz alta (TTS) e pedidos HTTP para a IA.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private val main = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listenAfterPermission = false
    private var fotoUriAtual: Uri? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#FFF6E9"))
        webView = WebView(this)
        root.addView(
            webView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)
        applyInsets(root)
        // Na TV o ecrã não deve apagar-se durante o estudo
        if (isTv()) root.keepScreenOn = true
        webView.isFocusable = true
        webView.isFocusableInTouchMode = true

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            textZoom = 100
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(Bridge(), "Android")
        webView.loadUrl("file:///android_asset/www/index.html")
        webView.requestFocus()

        initTts()
    }

    private fun isTv(): Boolean {
        val ui = getSystemService(UI_MODE_SERVICE) as UiModeManager
        return ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }

    /** Evita que o conteúdo fique por baixo da barra de estado / navegação (Android 15+). */
    private fun applyInsets(root: View) {
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
    }

    // ---------------------------------------------------------------- eventos para o JS

    private fun sendToJs(type: String, payload: JSONObject) {
        main.post {
            val js = "window.nativeEvent && window.nativeEvent(" +
                JSONObject.quote(type) + "," + payload.toString() + ")"
            webView.evaluateJavascript(js, null)
        }
    }

    // ---------------------------------------------------------------- TTS

    // voz portuguesa escolhida na app e língua da voz que está ativa agora
    private var ptVoiceName: String = ""
    private var vozAtualLang: String = "pt-PT"
    private val vozMasculina = Regex("(jmn|pmj|gbb|gbd|rjs|frb|frd|iom|iol|male|masc)", RegexOption.IGNORE_CASE)

    private fun escolherVozLingua(t: TextToSpeech, lang: String, gender: String) {
        val partes = lang.split("-", "_")
        val loc = if (partes.size > 1) Locale(partes[0], partes[1]) else Locale(partes[0])
        if (loc.language == "pt") {
            if (vozAtualLang == "pt-PT") return
            val v = t.voices?.firstOrNull { it.name == ptVoiceName }
                ?: t.voices?.filter { it.locale.language == "pt" && it.locale.country == "PT" && !it.isNetworkConnectionRequired }?.maxByOrNull { it.quality }
            if (v != null) t.setVoice(v) else t.setLanguage(Locale("pt", "PT"))
            vozAtualLang = "pt-PT"
            return
        }
        val chave = lang + "/" + gender
        if (vozAtualLang == chave) return
        val todas = t.voices ?: emptySet()
        val instaladas = todas.filter {
            it.locale.language == loc.language && !it.isNetworkConnectionRequired &&
                !(it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) ?: false)
        }
        val doPais = instaladas.filter { it.locale.country == loc.country }
        val grupo = if (doPais.isNotEmpty()) doPais else instaladas
        val doGenero = grupo.filter { (gender == "m") == vozMasculina.containsMatchIn(it.name) }
        val melhor = (if (doGenero.isNotEmpty()) doGenero else grupo).maxByOrNull { it.quality }
        if (melhor != null) t.setVoice(melhor) else t.setLanguage(loc)
        vozAtualLang = chave
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status -> onTtsInit(status) }
    }

    private fun onTtsInit(status: Int) {
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return
                val pt = Locale("pt", "PT")
                val r = t.setLanguage(pt)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale("pt"))
                }
                // Preferir uma voz pt-PT local se existir
                try {
                    val voices = t.voices
                    if (voices != null) {
                        val best = voices.filter {
                            it.locale.language == "pt" && it.locale.country == "PT" && !it.isNetworkConnectionRequired
                        }.maxByOrNull { it.quality }
                        if (best != null) { t.setVoice(best); ptVoiceName = best.name }
                    }
                } catch (e: Exception) { }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        sendToJs("tts", JSONObject().put("state", "start").put("id", utteranceId ?: ""))
                    }
                    override fun onDone(utteranceId: String?) {
                        sendToJs("tts", JSONObject().put("state", "done").put("id", utteranceId ?: ""))
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        sendToJs("tts", JSONObject().put("state", "done").put("id", utteranceId ?: ""))
                    }
                })
                ttsReady = true
                sendToJs("ttsReady", JSONObject().put("ok", true))
            } else {
                sendToJs("ttsReady", JSONObject().put("ok", false))
            }
    }

    // ---------------------------------------------------------------- Reconhecimento de voz

    private fun hasMicPermission(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListeningInternal() {
        if (!hasMicPermission()) {
            listenAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendToJs("speech", JSONObject().put("state", "error").put("code", -1)
                .put("message", "Este telemóvel não tem reconhecimento de voz disponível."))
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                sendToJs("speech", JSONObject().put("state", "ready"))
            }
            override fun onBeginningOfSpeech() {
                sendToJs("speech", JSONObject().put("state", "begin"))
            }
            override fun onRmsChanged(rmsdB: Float) {
                sendToJs("speech", JSONObject().put("state", "rms").put("rms", rmsdB.toDouble()))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                sendToJs("speech", JSONObject().put("state", "end"))
            }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Não percebi. Podes repetir?"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Sem internet para perceber a voz."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Preciso de autorização para usar o microfone."
                    else -> "O microfone teve um problema. Tenta outra vez."
                }
                sendToJs("speech", JSONObject().put("state", "error").put("code", error).put("message", msg))
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                sendToJs("speech", JSONObject().put("state", "result").put("texts", JSONArray(list)))
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                if (list.isNotEmpty()) {
                    sendToJs("speech", JSONObject().put("state", "partial").put("text", list[0]))
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        rec.startListening(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (ok && listenAfterPermission) {
                startListeningInternal()
            } else if (!ok) {
                sendToJs("speech", JSONObject().put("state", "error").put("code", 9)
                    .put("message", "Sem autorização para o microfone. Podes escrever a pergunta."))
            }
            listenAfterPermission = false
        }
    }

    // ---------------------------------------------------------------- Fotografar (quiz a partir de uma foto)

    private fun ficheiroFotoTemp(): File {
        val dir = File(cacheDir, "fotos").apply { mkdirs() }
        return File(dir, "foto_${System.currentTimeMillis()}.jpg")
    }

    private fun lancarCamara() {
        try {
            val ficheiro = ficheiroFotoTemp()
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", ficheiro)
            fotoUriAtual = uri
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, uri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            }
            startActivityForResult(intent, REQ_FOTO_CAMARA)
        } catch (e: Exception) {
            sendToJs("foto", JSONObject().put("ok", false).put("erro", "Não foi possível abrir a câmara."))
        }
    }

    private fun lancarGaleria() {
        try {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(intent, "Escolhe uma foto"), REQ_FOTO_GALERIA)
        } catch (e: Exception) {
            sendToJs("foto", JSONObject().put("ok", false).put("erro", "Não foi possível abrir a galeria."))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FOTO_CAMARA && requestCode != REQ_FOTO_GALERIA) return
        if (resultCode != Activity.RESULT_OK) {
            sendToJs("foto", JSONObject().put("ok", false).put("erro", ""))
            return
        }
        val uri = if (requestCode == REQ_FOTO_CAMARA) fotoUriAtual else data?.data
        if (uri == null) { sendToJs("foto", JSONObject().put("ok", false).put("erro", "Não recebi a foto.")); return }
        Thread {
            try {
                val b64 = processarImagemParaBase64(uri)
                sendToJs("foto", JSONObject().put("ok", true).put("base64", b64))
            } catch (e: Exception) {
                sendToJs("foto", JSONObject().put("ok", false).put("erro", "Não consegui processar a foto."))
            } finally {
                if (requestCode == REQ_FOTO_CAMARA) { try { contentResolver.delete(uri, null, null) } catch (e: Exception) { } }
            }
        }.start()
    }

    /** Lê a imagem, roda-a conforme o EXIF, reduz para no máximo 1280px e devolve em base64 JPEG. */
    private fun processarImagemParaBase64(uri: Uri): String {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var escala = 1
        val maxLado = maxOf(opts.outWidth, opts.outHeight)
        while (maxLado / (escala * 2) > 1280) escala *= 2
        val opts2 = BitmapFactory.Options().apply { inSampleSize = escala }
        var bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts2) }
            ?: throw IllegalStateException("imagem inválida")
        val rotacao = try {
            contentResolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) }
                ?: ExifInterface.ORIENTATION_NORMAL
        } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
        val graus = when (rotacao) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (graus != 0f) {
            val m = Matrix().apply { postRotate(graus) }
            bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
        }
        val maior = maxOf(bitmap.width, bitmap.height)
        if (maior > 1280) {
            val f = 1280f / maior
            bitmap = Bitmap.createScaledBitmap(bitmap, (bitmap.width * f).toInt(), (bitmap.height * f).toInt(), true)
        }
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    // ---------------------------------------------------------------- Ponte JS

    inner class Bridge {

        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun isTv(): Boolean = this@MainActivity.isTv()

        @JavascriptInterface
        fun startListening() {
            main.post { startListeningInternal() }
        }

        @JavascriptInterface
        fun stopListening() {
            main.post { recognizer?.stopListening() }
        }

        @JavascriptInterface
        fun cancelListening() {
            main.post { recognizer?.cancel() }
        }

        @JavascriptInterface
        fun speak(text: String, id: String, rate: Float, pitch: Float) {
            speakLang(text, id, rate, pitch, "pt-PT", "")
        }

        /** Fala com a voz da língua pedida (pt-PT, en-GB, fr-FR...) e, se possível, do género pedido ("f"/"m"). */
        @JavascriptInterface
        fun speakLang(text: String, id: String, rate: Float, pitch: Float, lang: String, gender: String) {
            main.post {
                val t = tts
                if (t == null || !ttsReady) {
                    sendToJs("tts", JSONObject().put("state", "done").put("id", id))
                    return@post
                }
                try { escolherVozLingua(t, lang, gender) } catch (e: Exception) { }
                t.setSpeechRate(rate)
                t.setPitch(pitch)
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            }
        }

        /** Lista as vozes portuguesas instaladas: [{name, country, quality, net}] */
        @JavascriptInterface
        fun listVoices(): String {
            val arr = JSONArray()
            try {
                val vs = tts?.voices ?: return arr.toString()
                for (v in vs) {
                    if (v.locale.language != "pt") continue
                    arr.put(
                        JSONObject()
                            .put("name", v.name)
                            .put("country", v.locale.country)
                            .put("quality", v.quality)
                            .put("net", v.isNetworkConnectionRequired)
                    )
                }
            } catch (e: Exception) { }
            return arr.toString()
        }

        /** Escolhe a voz pelo nome (vazio = voz pt-PT por omissão). */
        @JavascriptInterface
        fun setVoiceName(name: String) {
            main.post {
                val t = tts ?: return@post
                try {
                    ptVoiceName = name
                    val v = t.voices?.firstOrNull { it.name == name }
                    if (v != null) t.setVoice(v) else t.setLanguage(Locale("pt", "PT"))
                    vozAtualLang = "pt-PT"
                } catch (e: Exception) { }
            }
        }

        @JavascriptInterface
        fun stopSpeaking() {
            main.post { tts?.stop() }
        }

        /** Pedido HTTP genérico (usado para a IA). Resposta chega via nativeEvent("http", ...). */
        @JavascriptInterface
        fun httpPost(id: String, url: String, headersJson: String, body: String) {
            Thread {
                val result = JSONObject().put("id", id)
                var conn: HttpURLConnection? = null
                try {
                    val c = (URL(url).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 20000
                        readTimeout = 90000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    conn = c
                    val headers = JSONObject(headersJson)
                    val keys = headers.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        c.setRequestProperty(k, headers.getString(k))
                    }
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val text = if (stream != null) {
                        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                    } else ""
                    result.put("status", code).put("body", text)
                } catch (e: Exception) {
                    result.put("status", 0).put("body", e.message ?: "erro de rede")
                } finally {
                    conn?.disconnect()
                }
                sendToJs("http", result)
            }.start()
        }

        @JavascriptInterface
        fun shareText(title: String, text: String) {
            main.post {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, title))
            }
        }

        @JavascriptInterface
        fun exitApp() {
            main.post { finish() }
        }

        /** Abre a câmara para fotografar uma página do manual/caderno. Resposta via nativeEvent("foto", ...). */
        @JavascriptInterface
        fun tirarFoto() {
            main.post { lancarCamara() }
        }

        /** Abre a galeria para escolher uma foto já tirada. Resposta via nativeEvent("foto", ...). */
        @JavascriptInterface
        fun escolherFoto() {
            main.post { lancarGaleria() }
        }
    }

    // ---------------------------------------------------------------- comando da TV
    /**
     * As setas do comando são tratadas só pela app (navegação própria em tv.js).
     * Assim a WebView não faz a sua navegação automática ao mesmo tempo,
     * o que fazia o foco saltar dois botões de cada vez.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val dir = when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
            else -> null
        }
        if (dir != null) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                webView.evaluateJavascript("window.TV && TV.tecla(" + JSONObject.quote(dir) + ")", null)
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------------------------------------------------------------- ciclo de vida

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        webView.evaluateJavascript("(window.kikoBack ? window.kikoBack() : false)") { r ->
            if (r != "true") finish()
        }
    }

    override fun onPause() {
        super.onPause()
        tts?.stop()
        recognizer?.cancel()
        sendToJs("pause", JSONObject())
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQ_MIC = 42
        private const val REQ_FOTO_CAMARA = 43
        private const val REQ_FOTO_GALERIA = 44
    }
}
