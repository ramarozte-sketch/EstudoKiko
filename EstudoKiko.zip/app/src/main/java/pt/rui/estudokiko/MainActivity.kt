package pt.rui.estudokiko

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.View
import android.view.WindowInsets
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Atividade única: a interface (mascote, quizzes, conteúdos) vive em assets/www
 * e esta classe fornece-lhe as capacidades nativas: reconhecimento de voz em
 * português de Portugal, leitura em voz alta (TTS) e pedidos HTTP para a IA.
 */
class MainActivity : Activity() {

    private lateinit var webView: WebView
    private val main = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var listenAfterPermission = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#FFF6E9"))
        webView = WebView(this)
        root.addView(
            webView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)
        applyInsets(root)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            textZoom = 100
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(Bridge(), "Android")
        webView.loadUrl("file:///android_asset/www/index.html")

        initTts()
    }

    /** Evita que o conteúdo fique por baixo da barra de estado / navegação (Android 15+). */
    private fun applyInsets(root: View) {
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
    }

    // ---------------------------------------------------------------- eventos para o JS

    private fun sendToJs(type: String, payload: JSONObject) {
        main.post {
            val js = "window.nativeEvent && window.nativeEvent(" +
                JSONObject.quote(type) + "," + payload.toString() + ")"
            webView.evaluateJavascript(js, null)
        }
    }

    // ---------------------------------------------------------------- TTS

    private fun initTts() {
        tts = TextToSpeech(this) { status -> onTtsInit(status) }
    }

    private fun onTtsInit(status: Int) {
            if (status == TextToSpeech.SUCCESS) {
                val t = tts ?: return
                val pt = Locale("pt", "PT")
                val r = t.setLanguage(pt)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale("pt"))
                }
                // Preferir uma voz pt-PT local se existir
                try {
                    val voices = t.voices
                    if (voices != null) {
                        val best = voices.filter {
                            it.locale.language == "pt" && it.locale.country == "PT" && !it.isNetworkConnectionRequired
                        }.maxByOrNull { it.quality }
                        if (best != null) t.setVoice(best)
                    }
                } catch (e: Exception) { }
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        sendToJs("tts", JSONObject().put("state", "start").put("id", utteranceId ?: ""))
                    }
                    override fun onDone(utteranceId: String?) {
                        sendToJs("tts", JSONObject().put("state", "done").put("id", utteranceId ?: ""))
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        sendToJs("tts", JSONObject().put("state", "done").put("id", utteranceId ?: ""))
                    }
                })
                ttsReady = true
                sendToJs("ttsReady", JSONObject().put("ok", true))
            } else {
                sendToJs("ttsReady", JSONObject().put("ok", false))
            }
    }

    // ---------------------------------------------------------------- Reconhecimento de voz

    private fun hasMicPermission(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startListeningInternal() {
        if (!hasMicPermission()) {
            listenAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendToJs("speech", JSONObject().put("state", "error").put("code", -1)
                .put("message", "Este telemóvel não tem reconhecimento de voz disponível."))
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                sendToJs("speech", JSONObject().put("state", "ready"))
            }
            override fun onBeginningOfSpeech() {
                sendToJs("speech", JSONObject().put("state", "begin"))
            }
            override fun onRmsChanged(rmsdB: Float) {
                sendToJs("speech", JSONObject().put("state", "rms").put("rms", rmsdB.toDouble()))
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                sendToJs("speech", JSONObject().put("state", "end"))
            }
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        "Não percebi. Podes repetir?"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        "Sem internet para perceber a voz."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        "Preciso de autorização para usar o microfone."
                    else -> "O microfone teve um problema. Tenta outra vez."
                }
                sendToJs("speech", JSONObject().put("state", "error").put("code", error).put("message", msg))
            }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                sendToJs("speech", JSONObject().put("state", "result").put("texts", JSONArray(list)))
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                if (list.isNotEmpty()) {
                    sendToJs("speech", JSONObject().put("state", "partial").put("text", list[0]))
                }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        rec.startListening(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (ok && listenAfterPermission) {
                startListeningInternal()
            } else if (!ok) {
                sendToJs("speech", JSONObject().put("state", "error").put("code", 9)
                    .put("message", "Sem autorização para o microfone. Podes escrever a pergunta."))
            }
            listenAfterPermission = false
        }
    }

    // ---------------------------------------------------------------- Ponte JS

    inner class Bridge {

        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun startListening() {
            main.post { startListeningInternal() }
        }

        @JavascriptInterface
        fun stopListening() {
            main.post { recognizer?.stopListening() }
        }

        @JavascriptInterface
        fun cancelListening() {
            main.post { recognizer?.cancel() }
        }

        @JavascriptInterface
        fun speak(text: String, id: String, rate: Float, pitch: Float) {
            main.post {
                val t = tts
                if (t == null || !ttsReady) {
                    sendToJs("tts", JSONObject().put("state", "done").put("id", id))
                    return@post
                }
                t.setSpeechRate(rate)
                t.setPitch(pitch)
                t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            }
        }

        @JavascriptInterface
        fun stopSpeaking() {
            main.post { tts?.stop() }
        }

        /** Pedido HTTP genérico (usado para a IA). Resposta chega via nativeEvent("http", ...). */
        @JavascriptInterface
        fun httpPost(id: String, url: String, headersJson: String, body: String) {
            Thread {
                val result = JSONObject().put("id", id)
                var conn: HttpURLConnection? = null
                try {
                    val c = (URL(url).openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 20000
                        readTimeout = 90000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    conn = c
                    val headers = JSONObject(headersJson)
                    val keys = headers.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        c.setRequestProperty(k, headers.getString(k))
                    }
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val text = if (stream != null) {
                        BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
                    } else ""
                    result.put("status", code).put("body", text)
                } catch (e: Exception) {
                    result.put("status", 0).put("body", e.message ?: "erro de rede")
                } finally {
                    conn?.disconnect()
                }
                sendToJs("http", result)
            }.start()
        }

        @JavascriptInterface
        fun shareText(title: String, text: String) {
            main.post {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, title)
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, title))
            }
        }

        @JavascriptInterface
        fun exitApp() {
            main.post { finish() }
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        webView.evaluateJavascript("(window.kikoBack ? window.kikoBack() : false)") { r ->
            if (r != "true") finish()
        }
    }

    override fun onPause() {
        super.onPause()
        tts?.stop()
        recognizer?.cancel()
        sendToJs("pause", JSONObject())
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }

    companion object {
        private const val REQ_MIC = 42
    }
}
