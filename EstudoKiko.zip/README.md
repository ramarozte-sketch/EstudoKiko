# Estudo com o Kiko 🦉

App Android de estudo para o 4.º e o 7.º ano (Portugal), com o mocho Kiko que conversa por voz.

## Compilar (GitHub Actions)
1. Envia o conteúdo desta pasta para a raiz de um repositório GitHub (inclui a pasta `.github`).
2. O workflow **Compilar APK - Estudo com o Kiko** corre sozinho (ou em Actions → Run workflow).
3. O APK aparece em **Releases** (`EstudoKiko.apk`) e em Artifacts.

O APK é sempre assinado com a mesma chave (`app/kiko.jks`), por isso cada versão nova instala por cima da anterior sem apagar o progresso.

## Conteúdos
88 temas e 676 perguntas organizados pelas Aprendizagens Essenciais em vigor em 2026/2027, mais exercícios de Matemática gerados sem fim.
Ficheiros: `app/src/main/assets/www/data/` (ano4.js, ano7a.js, ano7b.js) — fáceis de editar.

## IA (opcional)
Área dos pais → colar uma chave Google Gemini (grátis em aistudio.google.com) ou Anthropic Claude.
